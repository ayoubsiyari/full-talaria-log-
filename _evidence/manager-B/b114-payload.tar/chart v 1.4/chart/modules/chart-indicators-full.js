// Full Chart Indicators Module with all basic indicators
(function(global) {
    
    // Wait for Chart class to be defined
    function initIndicatorsModule() {
        if (typeof global.Chart === 'undefined') {
            setTimeout(initIndicatorsModule, 100);
            return;
        }
        attachIndicatorMethods();
    }
    
    function attachIndicatorMethods() {
        const Chart = global.Chart;

        (function ensureIndLegendHoverCss() {
            if (typeof document === 'undefined') return;
            const css = [
                '@media (hover: hover) and (pointer: fine) {',
                '  .talaria-ind-legend-row .talaria-ind-actions {',
                '    opacity: 0;',
                '    transition: opacity 0.12s ease;',
                '    pointer-events: none;',
                '  }',
                '  .talaria-ind-legend-row:hover .talaria-ind-actions {',
                '    opacity: 1;',
                '    pointer-events: auto;',
                '  }',
                '}',
                '#chart-container #chartWrapper .ohlc-indicators,',
                '#panels-container .ohlc-indicators,',
                '.ohlc-indicators {',
                '  pointer-events: auto;',
                '  position: relative;',
                '  z-index: 100;',
                '}',
                '#ohlcIndicators .talaria-ind-legend-row .talaria-ind-actions,',
                '.ohlc-indicators .talaria-ind-legend-row .talaria-ind-actions,',
                '#separatePanelsOverlay .talaria-ind-legend-row .talaria-ind-actions {',
                '  pointer-events: auto !important;',
                '}'
            ].join('\n');
            let s = document.getElementById('talaria-ind-legend-hover-css');
            if (s) {
                s.textContent = css;
                return;
            }
            s = document.createElement('style');
            s.id = 'talaria-ind-legend-hover-css';
            s.textContent = css;
            document.head.appendChild(s);
        })();

    /** TradingView-style legend chips — matches indicator-ui.js TALARIA_* (window set when indicator-ui loads) */
    function getTalariaChipStyles() {
        const w = global;
        const fallbackChip =
            'display:flex;align-items:center;gap:6px;width:fit-content;max-width:100%;align-self:flex-start;min-width:0;min-height:20px;box-sizing:border-box;' +
            'padding:1px 2px 1px 0;margin:0;border-radius:2px;line-height:1.2;' +
            'border:none;background:transparent;' +
            'transform:translateZ(0);-webkit-transform:translateZ(0);' +
            'cursor:default;vertical-align:middle;' +
            'font-family:-apple-system,BlinkMacSystemFont,Trebuchet MS,Roboto,Ubuntu,sans-serif;';
        return {
            chipCss: w.TALARIA_INDICATOR_CHIP_CSS || fallbackChip,
            bg: w.TALARIA_INDICATOR_CHIP_BG || 'transparent',
            bgHover: w.TALARIA_INDICATOR_CHIP_BG_HOVER || 'rgba(255, 255, 255, 0.06)',
            borderHover: w.TALARIA_INDICATOR_CHIP_BORDER_HOVER || 'transparent',
            borderDefault: w.TALARIA_IND_CHIP_BORDER || 'transparent',
            colorStrip: w.TALARIA_INDICATOR_COLOR_STRIP || function(c) {
                return 'display:inline-block;width:2px;height:12px;border-radius:1px;background:' + c + ';flex-shrink:0;';
            }
        };
    }

    function getTalariaActionBtnStyle() {
        return 'display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;min-width:26px;min-height:26px;padding:0;border-radius:3px;cursor:pointer;transition:background .15s,color .15s;flex-shrink:0;';
    }

    const MAX_ACTIVE_INDICATORS = 10;
    const INDICATOR_EVICT_V1_MAX_SETTINGS = 32;

    function indicatorEvictV1Enabled() {
        return typeof global === 'undefined'
            || global.__TALARIA_DISABLE_INDICATOR_EVICT_V1 !== true;
    }

    function indicatorEvictTypeKey(indicator) {
        return indicator && indicator.type != null
            ? String(indicator.type).toLowerCase()
            : '';
    }

    function indicatorEvictPlayhead(chart) {
        const replay = chart && chart.replaySystem;
        const candidates = [
            replay && replay.replayTimestamp,
            replay && replay.currentTimestamp,
            replay && replay.currentTime,
            replay && replay.playheadTime,
            chart && chart.replayTimestamp,
            chart && chart.currentTimestamp,
            chart && chart.currentTime,
        ];
        for (let i = 0; i < candidates.length; i++) {
            const n = Number(candidates[i]);
            if (Number.isFinite(n)) return n;
        }
        return null;
    }

    function isRc6IndicatorLifecycleStoreEnabled() {
        return typeof global.rc6IndicatorLifecycleStoreEnabled === 'function'
            ? global.rc6IndicatorLifecycleStoreEnabled(global)
            : global.__TALARIA_RC6_INDICATOR_LIFECYCLE_STORE !== false;
    }

    function isRc6IndicatorVisibilityV2Enabled() {
        return typeof global.rc6IndicatorVisibilityV2Enabled === 'function'
            ? global.rc6IndicatorVisibilityV2Enabled(global)
            : global.__TALARIA_RC6_INDICATOR_VISIBILITY_V2 !== false;
    }

    function isRc6IndicatorSettingsApplyV2Enabled() {
        return typeof global.rc6IndicatorSettingsApplyV2Enabled === 'function'
            ? global.rc6IndicatorSettingsApplyV2Enabled(global)
            : global.__TALARIA_RC6_INDICATOR_SETTINGS_APPLY_V2 !== false;
    }

    function isRc6IndicatorPersistRehydrateV2Enabled() {
        return typeof global.rc6IndicatorPersistRehydrateV2Enabled === 'function'
            ? global.rc6IndicatorPersistRehydrateV2Enabled(global)
            : global.__TALARIA_RC6_INDICATOR_PERSIST_REHYDRATE_V2 !== false;
    }

    function isRc6IndicatorReplayUiSyncV2Enabled() {
        return typeof global.rc6IndicatorReplayUiSyncV2Enabled === 'function'
            ? global.rc6IndicatorReplayUiSyncV2Enabled(global)
            : global.__TALARIA_RC6_INDICATOR_REPLAY_UI_SYNC_V2 !== false;
    }

    function _indicatorPerf() {
        return (typeof window !== 'undefined' && window.__TALARIA_DISABLE_INDICATOR_PERF_BRIDGE_V1 === true)
            ? null
            : global.IndicatorPerf;
    }

    function pinReplayLegendHoverBeforeRecalc(chart) {
        if (!isRc6IndicatorReplayUiSyncV2Enabled()) return;
        if (typeof global.pinReplayLegendHoverToPlayhead === 'function') {
            global.pinReplayLegendHoverToPlayhead(chart);
        } else if (typeof global.resolveReplayPlayheadBarIndex === 'function') {
            const barIdx = global.resolveReplayPlayheadBarIndex(chart);
            if (barIdx >= 0) chart.hoverIndex = barIdx;
        }
    }

    function syncReplayLegendAfterIndicatorRecalc(chart) {
        if (!isRc6IndicatorReplayUiSyncV2Enabled()) return;
        if (typeof global.applyReplayLegendSyncAfterRecalc === 'function') {
            global.applyReplayLegendSyncAfterRecalc(chart);
        }
    }

    function resolveIndicatorShownState(indicator, chartSettings) {
        if (isRc6IndicatorVisibilityV2Enabled() && typeof global.resolveIndicatorShown === 'function') {
            return global.resolveIndicatorShown(indicator, chartSettings);
        }
        if (!indicator) return false;
        if (indicator.visible === false) return false;
        if (indicator.hidePlot === true) return false;
        if (indicator.style && indicator.style.showLine === false) return false;
        return true;
    }

    function mapIndicatorActionToStoreEvent(action) {
        switch (action) {
            case 'add': return 'indicatorAdded';
            case 'update': return 'indicatorUpdated';
            case 'remove': return 'indicatorRemoved';
            case 'clear': return 'indicatorCleared';
            case 'rehydrate': return 'indicatorRehydrated';
            case 'visibility': return 'indicatorVisibilityChanged';
            case 'settings': return 'indicatorSettingsApplied';
            default: return 'indicatorChanged';
        }
    }

    function getIndicatorLifecycleStore(chart) {
        if (!chart || typeof global.IndicatorLifecycleStore !== 'function') return null;
        if (!chart._indicatorLifecycleStore) {
            chart._indicatorLifecycleStore = new global.IndicatorLifecycleStore(chart);
            if (typeof chart._installIndicatorLifecycleStoreSubscribers === 'function') {
                chart._installIndicatorLifecycleStoreSubscribers();
            }
        }
        return chart._indicatorLifecycleStore;
    }

    function emitIndicatorsChanged(chart, action, indicator) {
        const indicators = chart && chart.indicators && Array.isArray(chart.indicators.active)
            ? chart.indicators.active.slice()
            : [];
        if (typeof global !== 'undefined' && typeof global.dispatchEvent === 'function') {
            try {
                global.dispatchEvent(new CustomEvent('indicatorsChanged', {
                    detail: {
                        chart: chart,
                        action: action,
                        indicator: indicator || null,
                        indicators: indicators
                    }
                }));
            } catch (_) {}
        }
        if (!isRc6IndicatorLifecycleStoreEnabled()) return;
        if (typeof global.shouldSuppressStoreIncrementalDuringRehydrate === 'function'
            && global.shouldSuppressStoreIncrementalDuringRehydrate(chart, action)) {
            return;
        }
        const store = getIndicatorLifecycleStore(chart);
        if (!store || !store.isEnabled()) return;
        store.emit(mapIndicatorActionToStoreEvent(action), {
            chart: chart,
            action: action,
            indicator: indicator || null,
            indicators: indicators
        });
    }

    /** Framed color tile — matches V9 sidebar buttons; prefers indicator-ui factory when loaded. */
    function createIndLegendSwatch(displayColor) {
        const w = global;
        if (typeof w.createIndicatorLegendSwatch === 'function') {
            return w.createIndicatorLegendSwatch(displayColor);
        }
        if (typeof document !== 'undefined' && !document.getElementById('talaria-ind-swatch-css')) {
            const st = document.createElement('style');
            st.id = 'talaria-ind-swatch-css';
            st.textContent = [
                '.talaria-ind-swatch {',
                '  display: inline-flex; align-items: center; justify-content: center;',
                '  width: 20px; height: 20px; min-width: 20px; min-height: 20px;',
                '  box-sizing: border-box; flex-shrink: 0;',
                '  border: 1px solid rgba(140, 160, 255, 0.22); border-radius: 4px;',
                '  background: rgba(18, 22, 34, 0.92);',
                '  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.05);',
                '  transition: border-color 0.12s ease, box-shadow 0.12s ease;',
                '}',
                '.talaria-ind-legend-row:hover .talaria-ind-swatch {',
                '  border-color: rgba(140, 160, 255, 0.38);',
                '  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.07), 0 0 0 1px rgba(74, 106, 255, 0.12);',
                '}',
                '.talaria-ind-swatch-fill {',
                '  display: block; width: 3px; height: 14px; border-radius: 2px; flex-shrink: 0; position: relative;',
                '}',
                'body.light-mode .talaria-ind-swatch {',
                '  background: rgba(248, 249, 252, 0.96); border-color: rgba(100, 110, 140, 0.28);',
                '}',
                'body.light-mode .talaria-ind-legend-row:hover .talaria-ind-swatch {',
                '  border-color: rgba(74, 106, 255, 0.42);',
                '}'
            ].join('\n');
            document.head.appendChild(st);
        }
        const wrap = document.createElement('span');
        wrap.className = 'talaria-ind-swatch';
        const fill = document.createElement('span');
        fill.className = 'talaria-ind-swatch-fill';
        if (typeof w.applyIndicatorSwatchRailGlow === 'function') {
            w.applyIndicatorSwatchRailGlow(fill, displayColor);
        } else {
            const c = displayColor || '#2962ff';
            fill.style.background = 'linear-gradient(180deg, transparent, ' + c + ', transparent)';
            fill.style.boxShadow = '0 0 4px ' + c;
            fill.style.filter = 'drop-shadow(0 0 5px ' + c + ')';
        }
        wrap.appendChild(fill);
        return wrap;
    }
    
    // ===== Calculation Functions =====

    function resolveOhlcSourceValue(candle, source) {
        if (!candle) return NaN;
        const o = candle.o != null ? candle.o : candle.open;
        const h = candle.h != null ? candle.h : candle.high;
        const l = candle.l != null ? candle.l : candle.low;
        const c = candle.c != null ? candle.c : candle.close;
        switch (String(source || 'close').toLowerCase()) {
            case 'open': return o;
            case 'high': return h;
            case 'low': return l;
            case 'close': return c;
            case 'hl2': return (h + l) / 2;
            case 'hlc3': return (h + l + c) / 3;
            case 'ohlc4': return (o + h + l + c) / 4;
            default: return c;
        }
    }

    function applyOverlayLineStyleFromParams(indicator, params, colorDefault) {
        indicator.style.color = params.color != null ? params.color : (colorDefault || '#2962ff');
        indicator.style.lineWidth = clampIndicatorLineWidth(params.lineWidth, 2);
        indicator.style.lineStyle = params.lineStyle || 'Line';
        indicator.style.showLabel = params.showLabel !== false;
    }

    function applyHmaStyleFromParams(indicator, params) {
        applyMaLengthSourceFromParams(indicator, params, 20);
        const offsetRaw = params.offset != null ? Number(params.offset) : 0;
        indicator.params.offset = Number.isFinite(offsetRaw) ? offsetRaw : 0;
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.overlay = true;
        indicator.separatePanel = false;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#26c6da';
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.lineStyle = params.lineStyle || legacyS;
        indicator.style.showLabel = params.showLabel !== false;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS]
        ]);
    }

    function applyTemaStyleFromParams(indicator, params) {
        applyMaLengthSourceFromParams(indicator, params, 20);
        const offsetRaw = params.offset != null ? Number(params.offset) : 0;
        indicator.params.offset = Number.isFinite(offsetRaw) ? offsetRaw : 0;
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.overlay = true;
        indicator.separatePanel = false;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#ab47bc';
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.lineStyle = params.lineStyle || legacyS;
        indicator.style.showLabel = params.showLabel !== false;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS]
        ]);
    }

    function applyDemaStyleFromParams(indicator, params) {
        applyMaLengthSourceFromParams(indicator, params, 20);
        const offsetRaw = params.offset != null ? Number(params.offset) : 0;
        indicator.params.offset = Number.isFinite(offsetRaw) ? offsetRaw : 0;
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.overlay = true;
        indicator.separatePanel = false;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#00bcd4';
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.lineStyle = params.lineStyle || legacyS;
        indicator.style.showLabel = params.showLabel !== false;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS]
        ]);
    }

    function applySmoothedOverlayMaCalcParams(indicator, params, defaultPeriod) {
        applyMaLengthSourceFromParams(indicator, params, defaultPeriod != null ? defaultPeriod : 20);
        const offsetRaw = params.offset != null ? Number(params.offset) : 0;
        indicator.params.offset = Number.isFinite(offsetRaw) ? offsetRaw : 0;
        indicator.params.smoothingType = params.smoothingType || 'None';
        indicator.params.smoothingLength = params.smoothingLength != null ? Number(params.smoothingLength) : 14;
        indicator.params.bbStdDev = params.bbStdDev != null ? Number(params.bbStdDev) : 2;
    }

    function applySmoothedOverlayMaStyleFromParams(indicator, params, defaultColor) {
        applySmoothedOverlayMaCalcParams(indicator, params, 20);
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.overlay = true;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || defaultColor || '#2962ff';
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.lineStyle = params.lineStyle || legacyS;
        indicator.style.showLabel = params.showLabel !== false;
        const hasSmoothing = String(indicator.params.smoothingType || 'None') !== 'None';
        // Derived from smoothing type only — do not gate on stale indicator.style.showSmooth
        // left false when type was None (merged back into params on live flush).
        indicator.style.showSmooth = hasSmoothing;
        indicator.style.smoothColor = params.smoothColor || '#787b86';
        indicator.style.smoothLineWidth = params.smoothLineWidth != null ? params.smoothLineWidth : 1;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS],
            ['smoothLineStyle', 'smoothLineDashStyle', 'Line']
        ]);
    }

    function applyWmaStyleFromParams(indicator, params) {
        applyMaLengthSourceFromParams(indicator, params, 20);
        const offsetRaw = params.offset != null ? Number(params.offset) : 0;
        indicator.params.offset = Number.isFinite(offsetRaw) ? offsetRaw : 0;
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.overlay = true;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#ff9800';
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.lineStyle = params.lineStyle || legacyS;
        indicator.style.showLabel = params.showLabel !== false;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS]
        ]);
    }

    function applySmaStyleFromParams(indicator, params) {
        applySmoothedOverlayMaCalcParams(indicator, params, 20);
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.overlay = true;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#2962ff';
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.lineStyle = params.lineStyle || legacyS;
        indicator.style.showLabel = params.showLabel !== false;
        if (params.showSmoothMa !== undefined) {
            indicator.style.showSmoothMa = params.showSmoothMa === true;
        } else if (params.showSmooth === true) {
            indicator.style.showSmoothMa = true;
        } else {
            indicator.style.showSmoothMa = false;
        }
        indicator.style.smoothColor = params.smoothColor || '#787b86';
        indicator.style.smoothLineWidth = params.smoothLineWidth != null ? params.smoothLineWidth : 1;
        indicator.style.smoothLineStyle = params.smoothLineStyle || 'Line';
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS],
            ['smoothLineStyle', 'smoothLineDashStyle', 'Line']
        ]);
    }

    function applyEmaStyleFromParams(indicator, params) {
        applySmoothedOverlayMaCalcParams(indicator, params, 20);
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.overlay = true;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#f23645';
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.lineStyle = params.lineStyle || legacyS;
        indicator.style.showLabel = params.showLabel !== false;
        if (params.showSmoothEma !== undefined) {
            indicator.style.showSmoothEma = params.showSmoothEma === true;
        } else if (params.showSmooth === true) {
            indicator.style.showSmoothEma = true;
        } else {
            indicator.style.showSmoothEma = false;
        }
        indicator.style.smoothColor = params.smoothColor || '#787b86';
        indicator.style.smoothLineWidth = params.smoothLineWidth != null ? params.smoothLineWidth : 1;
        indicator.style.smoothLineStyle = params.smoothLineStyle || 'Line';
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS],
            ['smoothLineStyle', 'smoothLineDashStyle', 'Line']
        ]);
    }

    function clampIndicatorLineWidth(w, fallback) {
        if (typeof window.__v9ClampIndicatorLineWidth === 'function') {
            return window.__v9ClampIndicatorLineWidth(w, fallback);
        }
        fallback = fallback != null ? fallback : 2;
        const n = Number(w);
        if (!Number.isFinite(n)) return fallback;
        return Math.max(1, Math.min(4, Math.round(n)));
    }

    function clampIndicatorStyleLineWidths(style) {
        if (typeof window.__v9ClampIndicatorStyleLineWidths === 'function') {
            window.__v9ClampIndicatorStyleLineWidths(style);
            return;
        }
        if (!style) return;
        Object.keys(style).forEach(function (key) {
            if (/linewidth/i.test(key)) {
                style[key] = clampIndicatorLineWidth(style[key], style[key]);
            }
        });
    }

    function sanitizeIndicatorRuntimePayload(indicator, params) {
        const defKey = typeof window.__v9ResolveIndicatorDefinitionKey === 'function'
            ? window.__v9ResolveIndicatorDefinitionKey(indicator.type)
            : indicator.type;
        const def = window.INDICATOR_DEFINITIONS && window.INDICATOR_DEFINITIONS[defKey];
        if (def && typeof window.__v9SanitizeIndicatorPayloadFromDefinition === 'function') {
            return window.__v9SanitizeIndicatorPayloadFromDefinition(def, params);
        }
        clampIndicatorStyleLineWidths(params);
        return params;
    }

    function applyMaLengthSourceFromParams(indicator, params, defaultPeriod) {
        indicator.params.period = params.period != null ? params.period : defaultPeriod;
        indicator.params.source = params.source || 'close';
    }

    function applyDonchianStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 1;
        const legacyS = params.lineStyle || 'Line';
        indicator.overlay = true;
        indicator.separatePanel = false;
        indicator.style.showUpper = params.showUpper !== false;
        indicator.style.upperColor = params.upperColor || '#2962ff';
        indicator.style.upperLineWidth = params.upperLineWidth != null ? params.upperLineWidth : legacyW;
        indicator.style.showMiddle = params.showMiddle !== false;
        indicator.style.middleColor = params.middleColor || '#787b86';
        indicator.style.middleLineWidth = params.middleLineWidth != null ? params.middleLineWidth : legacyW;
        indicator.style.showLower = params.showLower !== false;
        indicator.style.lowerColor = params.lowerColor || '#2962ff';
        indicator.style.lowerLineWidth = params.lowerLineWidth != null ? params.lowerLineWidth : legacyW;
        indicator.style.showBg = params.showBg === true;
        indicator.style.bgColor = params.bgColor || 'rgba(41,98,255,0.1)';
        indicator.style.showFill = false;
        indicator.style.showLabel = params.showLabel !== false;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['upperLineStyle', 'upperLineDashStyle', legacyS],
            ['middleLineStyle', 'middleLineDashStyle', legacyS],
            ['lowerLineStyle', 'lowerLineDashStyle', legacyS]
        ]);
    }

    function resolveBandLineColor(color, opacityPct) {
        if (!color) return color;
        let op = opacityPct != null ? Number(opacityPct) : 100;
        if (!Number.isFinite(op) || op >= 100) return color;
        op = Math.max(0, Math.min(100, op)) / 100;
        const s = String(color).trim();
        const rgbaMatch = s.match(/^rgba\s*\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/i);
        if (rgbaMatch) {
            return 'rgba(' + rgbaMatch[1] + ',' + rgbaMatch[2] + ',' + rgbaMatch[3] + ',' + (parseFloat(rgbaMatch[4]) * op) + ')';
        }
        if (s.charAt(0) === '#') {
            let h = s.slice(1);
            if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
            if (h.length === 6) {
                const r = parseInt(h.slice(0, 2), 16);
                const g = parseInt(h.slice(2, 4), 16);
                const b = parseInt(h.slice(4, 6), 16);
                if (Number.isFinite(r) && Number.isFinite(g) && Number.isFinite(b)) {
                    return 'rgba(' + r + ',' + g + ',' + b + ',' + op + ')';
                }
            }
        }
        return color;
    }

    function applyBollingerStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 1;
        const legacyS = params.lineStyle || 'Line';
        indicator.overlay = true;
        indicator.separatePanel = false;
        indicator.style.showMiddle = params.showMiddle !== false;
        indicator.style.middleColor = params.middleColor || '#787b86';
        indicator.style.middleLineWidth = params.middleLineWidth != null ? params.middleLineWidth : legacyW;
        indicator.style.showUpper = params.showUpper !== false;
        indicator.style.upperColor = params.upperColor || '#2962ff';
        indicator.style.upperLineWidth = params.upperLineWidth != null ? params.upperLineWidth : legacyW;
        indicator.style.showLower = params.showLower !== false;
        indicator.style.lowerColor = params.lowerColor || '#2962ff';
        indicator.style.lowerLineWidth = params.lowerLineWidth != null ? params.lowerLineWidth : legacyW;
        indicator.style.showFill = params.showFill !== false;
        if (params.fillColor && String(params.fillColor).indexOf('rgba') >= 0 && params.fillOpacity == null) {
            indicator.style.fillColor = params.fillColor;
            indicator.style.fillOpacity = null;
        } else {
            indicator.style.fillColor = params.fillColor || '#2962ff';
            indicator.style.fillOpacity = params.fillOpacity != null ? params.fillOpacity : 10;
        }
        indicator.style.showLabel = params.showLabel !== false;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['middleLineStyle', 'middleLineDashStyle', legacyS],
            ['upperLineStyle', 'upperLineDashStyle', legacyS],
            ['lowerLineStyle', 'lowerLineDashStyle', legacyS]
        ]);
    }

    function applyKeltnerStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 1;
        const legacyS = params.lineStyle || 'Line';
        indicator.style.showMiddle = params.showMiddle !== false;
        indicator.style.middleColor = params.middleColor || '#787b86';
        indicator.style.middleLineWidth = params.middleLineWidth != null ? params.middleLineWidth : legacyW;
        indicator.style.middleLineStyle = params.middleLineStyle || legacyS;
        indicator.style.showUpper = params.showUpper !== false;
        indicator.style.upperColor = params.upperColor || '#2962ff';
        indicator.style.upperLineWidth = params.upperLineWidth != null ? params.upperLineWidth : legacyW;
        indicator.style.upperLineStyle = params.upperLineStyle || legacyS;
        indicator.style.showLower = params.showLower !== false;
        indicator.style.lowerColor = params.lowerColor || '#2962ff';
        indicator.style.lowerLineWidth = params.lowerLineWidth != null ? params.lowerLineWidth : legacyW;
        indicator.style.lowerLineStyle = params.lowerLineStyle || legacyS;
        if (params.showBg !== undefined) {
            indicator.style.showBg = params.showBg === true;
        } else if (params.showFill !== undefined) {
            indicator.style.showBg = params.showFill === true;
        } else {
            indicator.style.showBg = false;
        }
        indicator.style.bgColor = params.bgColor || params.fillColor || 'rgba(41,98,255,0.1)';
        indicator.style.showLabel = params.showLabel !== false;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['middleLineStyle', 'middleLineDashStyle', legacyS],
            ['upperLineStyle', 'upperLineDashStyle', legacyS],
            ['lowerLineStyle', 'lowerLineDashStyle', legacyS]
        ]);
    }

    function resolveBbCalcParams(params) {
        params = params || {};
        const periodRaw = params.period != null ? Number(params.period) : 20;
        const stdDevRaw = params.stdDev != null ? Number(params.stdDev) : 2;
        const offsetRaw = params.offset != null ? Number(params.offset) : 0;
        let maType = params.maType || 'SMA';
        if (maType === 'SMMA') maType = 'RMA';
        return {
            period: Number.isFinite(periodRaw) ? periodRaw : 20,
            source: params.source || 'close',
            stdDev: Number.isFinite(stdDevRaw) ? stdDevRaw : 2,
            offset: Number.isFinite(offsetRaw) ? offsetRaw : 0,
            maType: maType
        };
    }

    function applyBbCalcParams(indicator, params) {
        const calc = resolveBbCalcParams(params);
        indicator.params.period = calc.period;
        indicator.params.source = calc.source;
        indicator.params.stdDev = calc.stdDev;
        indicator.params.offset = calc.offset;
        indicator.params.maType = calc.maType;
        return calc;
    }

    function bollingerFillRgba(style) {
        if (!style) return null;
        if (style.showBg === true) {
            const raw = style.bgColor || 'rgba(41,98,255,0.1)';
            if (String(raw).indexOf('rgba') >= 0) return raw;
            return raw;
        }
        if (style.showFill === false) return null;
        const raw = style.fillColor || '#2962ff';
        if (style.fillOpacity == null && String(raw).indexOf('rgba') >= 0) return raw;
        let op = style.fillOpacity != null ? Number(style.fillOpacity) : 10;
        if (!Number.isFinite(op)) op = 10;
        op = Math.max(0, Math.min(100, op)) / 100;
        const s = String(raw).trim();
        if (s.charAt(0) === '#') {
            let h = s.slice(1);
            if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
            if (h.length === 6) {
                const r = parseInt(h.slice(0, 2), 16);
                const g = parseInt(h.slice(2, 4), 16);
                const b = parseInt(h.slice(4, 6), 16);
                if (Number.isFinite(r) && Number.isFinite(g) && Number.isFinite(b)) {
                    return 'rgba(' + r + ',' + g + ',' + b + ',' + op + ')';
                }
            }
        }
        return raw;
    }

    function resolveIndPlotDashFromParams(params, plotKey, dashKey, fallbackPlot) {
        fallbackPlot = fallbackPlot || 'Line';
        var rawPlot = params[plotKey] != null ? params[plotKey] : fallbackPlot;
        var rawDash = params[dashKey];
        var plot = String(rawPlot || 'Line');
        var dash = rawDash != null ? String(rawDash) : null;
        if (plot === 'Dashed' || plot === 'Dotted' || plot === 'Dashdot') {
            if (!dash) dash = plot;
            plot = 'Line';
        } else if (plot === 'Solid') {
            plot = 'Line';
            if (!dash) dash = 'Solid';
        }
        if (!dash) dash = 'Solid';
        return { plot: plot, dash: dash };
    }

    function applyPlotDashFieldsFromParams(style, params, pairs) {
        pairs.forEach(function (pair) {
            var resolved = resolveIndPlotDashFromParams(params, pair[0], pair[1], pair[2]);
            style[pair[0]] = resolved.plot;
            style[pair[1]] = resolved.dash;
        });
    }

    function applyOscillatorLevelStyleFromParams(indicator, params, levelDefaults) {
        levelDefaults = levelDefaults || { overbought: 70, oversold: 30, mid: 50 };
        indicator.style.overboughtValue = params.overboughtValue != null ? Number(params.overboughtValue) : levelDefaults.overbought;
        indicator.style.showOverbought = params.showOverbought !== false;
        indicator.style.overboughtColor = params.overboughtColor || '#787b86';
        indicator.style.overboughtLineWidth = params.overboughtLineWidth != null ? params.overboughtLineWidth : 1;
        indicator.style.oversoldValue = params.oversoldValue != null ? Number(params.oversoldValue) : levelDefaults.oversold;
        indicator.style.showOversold = params.showOversold !== false;
        indicator.style.oversoldColor = params.oversoldColor || '#787b86';
        indicator.style.oversoldLineWidth = params.oversoldLineWidth != null ? params.oversoldLineWidth : 1;
        indicator.style.midValue = params.midValue != null ? Number(params.midValue) : levelDefaults.mid;
        indicator.style.showMid = params.showMid !== false;
        indicator.style.midColor = params.midColor || 'rgba(120,123,134,0.45)';
        indicator.style.midLineWidth = params.midLineWidth != null ? params.midLineWidth : 1;
        indicator.style.showBg = params.showBg === true;
        indicator.style.bgColor = params.bgColor || 'rgba(19,23,34,0.15)';
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['overboughtLineStyle', 'overboughtLineDashStyle', 'Dotted'],
            ['oversoldLineStyle', 'oversoldLineDashStyle', 'Dotted'],
            ['midLineStyle', 'midLineDashStyle', 'Dotted']
        ]);
    }

    function applyAroonStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.style.showUp = params.showUp !== false;
        indicator.style.upColor = params.upColor || '#26a69a';
        indicator.style.upLineWidth = params.upLineWidth != null ? params.upLineWidth : legacyW;
        indicator.style.showDown = params.showDown !== false;
        indicator.style.downColor = params.downColor || '#ef5350';
        indicator.style.downLineWidth = params.downLineWidth != null ? params.downLineWidth : legacyW;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['upLineStyle', 'upLineDashStyle', legacyS],
            ['downLineStyle', 'downLineDashStyle', legacyS]
        ]);
    }

    function buildAroonLegendTokens(upVal, downVal, style) {
        const st = style || {};
        const tokens = [];
        if (st.showUp !== false && upVal !== null && Number.isFinite(upVal)) {
            tokens.push({ text: '\u2191' + Math.round(upVal), color: st.upColor || '#26a69a' });
        }
        if (st.showDown !== false && downVal !== null && Number.isFinite(downVal)) {
            tokens.push({ text: '\u2193' + Math.round(downVal), color: st.downColor || '#ef5350' });
        }
        return tokens;
    }

    function buildVortexLegendTokens(plusVal, minusVal, style) {
        const st = style || {};
        const tokens = [];
        if (st.showPlus !== false && plusVal !== null && Number.isFinite(plusVal)) {
            tokens.push({ text: '+' + plusVal.toFixed(3), color: st.plusColor || '#00e676' });
        }
        if (st.showMinus !== false && minusVal !== null && Number.isFinite(minusVal)) {
            tokens.push({ text: '-' + minusVal.toFixed(3), color: st.minusColor || '#f23645' });
        }
        return tokens;
    }

    function formatObvLegendNumber(val) {
        if (val === null || !Number.isFinite(val)) return null;
        const decimals = Math.abs(val) >= 1e6 ? 0 : (Math.abs(val) >= 1000 ? 1 : 2);
        return val.toFixed(decimals);
    }

    function buildObvLegendTokens(obvVal, maVal, style) {
        const st = style || {};
        const tokens = [];
        if (st.showObv !== false && obvVal !== null && Number.isFinite(obvVal)) {
            tokens.push({ text: formatObvLegendNumber(obvVal), color: st.color || '#78909c' });
        }
        if (st.showMa !== false && maVal !== null && Number.isFinite(maVal)) {
            tokens.push({ text: formatObvLegendNumber(maVal), color: st.maColor || '#ff9800' });
        }
        return tokens;
    }

    function overlayLegendPriceRange(chart) {
        if (!chart || !chart.yScale || typeof chart.yScale.domain !== 'function') return 0;
        const dom = chart.yScale.domain();
        if (!dom || dom.length < 2) return 0;
        return Math.abs(dom[1] - dom[0]);
    }

    /** Same formatting as drawOverlayIndicatorPriceLabels / price-axis tags. */
    function formatOverlayLegendPrice(chart, price) {
        const p = Number(price);
        if (!Number.isFinite(p)) return '—';
        const priceRange = overlayLegendPriceRange(chart);
        const sym = chart && chart.currentSymbol;
        if (sym && typeof window !== 'undefined' && window.marketCalcEngine) {
            try {
                const calc = window.marketCalcEngine.getCalculator(sym, chart && chart.marketType);
                const specs = calc && calc.specs;
                if (calc && specs && !specs._genericFallback && typeof calc.formatPrice === 'function') {
                    return calc.formatPrice(p);
                }
            } catch (_) { /* fall through */ }
        }
        if (chart && typeof chart._formatLastPrice === 'function') {
            return chart._formatLastPrice(p, priceRange, sym);
        }
        let dec = 4;
        if (chart && typeof chart.getPriceDecimalsForSymbol === 'function' && sym) {
            dec = chart.getPriceDecimalsForSymbol(sym, priceRange);
        } else if (chart && typeof chart.getPriceDecimals === 'function') {
            dec = chart.getPriceDecimals(priceRange);
        }
        return p.toFixed(dec);
    }

    function buildOverlayBandLegendTokens(chart, store, barIdx, plotOff, style) {
        if (!chart || !store || barIdx < 0) return [];
        const st = style || {};
        const color = st.color || '#9ca3af';
        const bands = [
            { k: 'upper', show: st.showUpper !== false, color: st.upperColor || color },
            { k: 'middle', show: st.showMiddle !== false, color: st.middleColor || color },
            { k: 'lower', show: st.showLower !== false, color: st.lowerColor || color }
        ];
        const tokens = [];
        bands.forEach(function(b) {
            if (!b.show || !Array.isArray(store[b.k])) return;
            const val = seriesValueAtPlotOffset(store[b.k], barIdx, plotOff);
            if (!Number.isFinite(val)) return;
            tokens.push({ text: formatOverlayLegendPrice(chart, val), color: b.color || color });
        });
        return tokens;
    }

    function safeIndicatorNumber(raw, fallback) {
        let s = raw;
        if (typeof window !== 'undefined' && typeof window.__v9NormalizeIndicatorNumericString === 'function') {
            s = window.__v9NormalizeIndicatorNumericString(raw);
        } else if (raw != null && typeof raw !== 'number') {
            s = String(raw).trim().replace(/,/g, '.');
        }
        const n = Number(s);
        return Number.isFinite(n) ? n : fallback;
    }

    function applySupertrendStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        if (params.period != null) indicator.params.period = Math.max(1, Number(params.period) | 0) || 10;
        if (params.multiplier != null) {
            const mult = Number(params.multiplier);
            indicator.params.multiplier = Number.isFinite(mult) ? mult : 3;
        }
        indicator.overlay = true;
        indicator.separatePanel = false;
        indicator.style.showUp = params.showUp !== false;
        indicator.style.upColor = params.upColor || '#26a69a';
        indicator.style.upLineWidth = params.upLineWidth != null ? params.upLineWidth : legacyW;
        indicator.style.showDown = params.showDown !== false;
        indicator.style.downColor = params.downColor || '#ef5350';
        indicator.style.downLineWidth = params.downLineWidth != null ? params.downLineWidth : legacyW;
        indicator.style.showBody = params.showBody === true;
        indicator.style.bodyColor = params.bodyColor || 'rgba(120,123,134,0.5)';
        indicator.style.bodyLineWidth = params.bodyLineWidth != null ? params.bodyLineWidth : 1;
        indicator.style.showUpBg = params.showUpBg === true;
        indicator.style.upBgColor = params.upBgColor || 'rgba(38,166,154,0.15)';
        indicator.style.showDownBg = params.showDownBg === true;
        indicator.style.downBgColor = params.downBgColor || 'rgba(239,83,80,0.15)';
        indicator.style.showLabel = params.showLabel !== false;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['upLineStyle', 'upLineDashStyle', legacyS],
            ['downLineStyle', 'downLineDashStyle', legacyS],
            ['bodyLineStyle', 'bodyLineDashStyle', legacyS]
        ]);
    }

    function resolvePsarCalcParams(params) {
        params = params || {};
        const start = params.start != null ? Number(params.start) : (params.step != null ? Number(params.step) : 0.02);
        const increment = params.increment != null ? Number(params.increment) : start;
        const maxStep = params.maxStep != null ? Number(params.maxStep) : 0.2;
        return {
            start: Number.isFinite(start) ? start : 0.02,
            increment: Number.isFinite(increment) ? increment : 0.02,
            maxStep: Number.isFinite(maxStep) ? maxStep : 0.2
        };
    }

    function applyPsarStyleFromParams(indicator, params) {
        const calc = resolvePsarCalcParams(params);
        indicator.params.start = calc.start;
        indicator.params.increment = calc.increment;
        indicator.params.maxStep = calc.maxStep;
        let showUp = params.showUp !== false;
        let showDown = params.showDown !== false;
        if (params.showUp === undefined && params.showDown === undefined && params.showLine !== undefined) {
            const on = params.showLine !== false;
            showUp = on;
            showDown = on;
        }
        indicator.style.showUp = showUp;
        indicator.style.showDown = showDown;
        indicator.style.showLine = showUp || showDown;
        indicator.style.bullColor = params.bullColor || params.color || '#26a69a';
        indicator.style.bearColor = params.bearColor || '#ef5350';
        indicator.style.color = indicator.style.bullColor;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : 2;
        indicator.style.lineStyle = 'Circles';
        indicator.style.lineDashStyle = 'Solid';
    }

    function applyRsiStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.params.period = params.period != null ? Number(params.period) : (indicator.params.period != null ? indicator.params.period : 14);
        indicator.params.source = params.source || indicator.params.source || 'close';
        indicator.params.overboughtValue = params.overboughtValue != null ? Number(params.overboughtValue) : 70;
        indicator.params.midValue = params.midValue != null ? Number(params.midValue) : 50;
        indicator.params.oversoldValue = params.oversoldValue != null ? Number(params.oversoldValue) : 30;
        indicator.params.smoothingType = params.smoothingType || 'None';
        indicator.params.smoothingLength = params.smoothingLength != null ? Number(params.smoothingLength) : 14;
        indicator.params.bbStdDev = params.bbStdDev != null ? Number(params.bbStdDev) : 2;
        indicator.params.divergenceEnabled = params.divergenceEnabled === true;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#9c27b0';
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        applyPlotDashFieldsFromParams(indicator.style, params, [['lineStyle', 'lineDashStyle', legacyS]]);
        const hasSmoothing = String(indicator.params.smoothingType || 'None') !== 'None';
        indicator.style.showMa = hasSmoothing && params.showMa !== false;
        indicator.style.maColor = params.maColor || '#ff9800';
        indicator.style.maLineWidth = params.maLineWidth != null ? params.maLineWidth : 1;
        applyPlotDashFieldsFromParams(indicator.style, params, [['maLineStyle', 'maLineDashStyle', 'Line']]);
        indicator.style.overboughtValue = indicator.params.overboughtValue;
        indicator.style.showOverbought = params.showOverbought !== false;
        indicator.style.overboughtColor = params.overboughtColor || '#787b86';
        indicator.style.overboughtLineWidth = params.overboughtLineWidth != null ? params.overboughtLineWidth : 1;
        indicator.style.midValue = indicator.params.midValue;
        indicator.style.showMid = params.showMid !== false;
        indicator.style.midColor = params.midColor || 'rgba(120,123,134,0.45)';
        indicator.style.midLineWidth = params.midLineWidth != null ? params.midLineWidth : 1;
        indicator.style.oversoldValue = indicator.params.oversoldValue;
        indicator.style.showOversold = params.showOversold !== false;
        indicator.style.oversoldColor = params.oversoldColor || '#787b86';
        indicator.style.oversoldLineWidth = params.oversoldLineWidth != null ? params.oversoldLineWidth : 1;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['overboughtLineStyle', 'overboughtLineDashStyle', 'Dotted'],
            ['oversoldLineStyle', 'oversoldLineDashStyle', 'Dotted'],
            ['midLineStyle', 'midLineDashStyle', 'Dotted']
        ]);
        indicator.style.showBg = params.showBg === true;
        indicator.style.bgColor = params.bgColor || 'rgba(19,23,34,0.15)';
        indicator.style.showObGradient = params.showObGradient === true;
        indicator.style.obGradientColor = params.obGradientColor || 'rgba(239,83,80,0.12)';
        indicator.style.showOsGradient = params.showOsGradient === true;
        indicator.style.osGradientColor = params.osGradientColor || 'rgba(38,166,154,0.12)';
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyStochasticStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.params.overboughtValue = params.overboughtValue != null ? Number(params.overboughtValue) : 80;
        indicator.params.oversoldValue = params.oversoldValue != null ? Number(params.oversoldValue) : 20;
        indicator.params.midValue = params.midValue != null ? Number(params.midValue) : 50;
        indicator.style.showK = params.showK !== false;
        indicator.style.kColor = params.kColor || '#2962ff';
        indicator.style.kLineWidth = params.kLineWidth != null ? params.kLineWidth : legacyW;
        indicator.style.showD = params.showD !== false;
        indicator.style.dColor = params.dColor || '#f23645';
        indicator.style.dLineWidth = params.dLineWidth != null ? params.dLineWidth : legacyW;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['kLineStyle', 'kLineDashStyle', legacyS],
            ['dLineStyle', 'dLineDashStyle', legacyS]
        ]);
        applyOscillatorLevelStyleFromParams(indicator, params, { overbought: 80, oversold: 20, mid: 50 });
    }

    function applyMfiStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.params.period = params.period != null ? Number(params.period) : 14;
        indicator.params.overboughtValue = params.overboughtValue != null ? Number(params.overboughtValue) : 80;
        indicator.params.midValue = params.midValue != null ? Number(params.midValue) : 50;
        indicator.params.oversoldValue = params.oversoldValue != null ? Number(params.oversoldValue) : 20;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#5c6bc0';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        applyPlotDashFieldsFromParams(indicator.style, params, [['lineStyle', 'lineDashStyle', legacyS]]);
        applyOscillatorLevelStyleFromParams(indicator, params, { overbought: 80, oversold: 20, mid: 50 });
        indicator.style.overboughtOpacity = params.overboughtOpacity != null ? Number(params.overboughtOpacity) : 100;
        indicator.style.midOpacity = params.midOpacity != null ? Number(params.midOpacity) : 100;
        indicator.style.oversoldOpacity = params.oversoldOpacity != null ? Number(params.oversoldOpacity) : 100;
        indicator.style.bgOpacity = params.bgOpacity != null ? Number(params.bgOpacity) : 15;
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyCmfStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        const zeroS = params.zeroLineStyle || 'Dotted';
        indicator.params.period = params.period != null ? Number(params.period) : 20;
        indicator.params.zeroValue = params.zeroValue != null ? Number(params.zeroValue) : 0;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#29b6f6';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.showZero = params.showZero !== false;
        indicator.style.zeroValue = indicator.params.zeroValue;
        indicator.style.zeroColor = params.zeroColor || 'rgba(120,123,134,0.45)';
        indicator.style.zeroOpacity = params.zeroOpacity != null ? Number(params.zeroOpacity) : 100;
        indicator.style.zeroLineWidth = params.zeroLineWidth != null ? params.zeroLineWidth : 1;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS],
            ['zeroLineStyle', 'zeroLineDashStyle', zeroS]
        ]);
        indicator.hidePlot = params.hideFromContainer === true;
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyCciStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        const maS = params.maLineStyle || 'Line';
        indicator.params.period = params.period != null ? Number(params.period) : 20;
        indicator.params.source = params.source || 'hlc3';
        indicator.params.smoothingType = params.smoothingType || 'None';
        indicator.params.smoothingLength = params.smoothingLength != null ? Number(params.smoothingLength) : 14;
        indicator.params.bbStdDev = params.bbStdDev != null ? Number(params.bbStdDev) : 2;
        indicator.params.upperValue = params.upperValue != null ? Number(params.upperValue)
            : (params.overboughtValue != null ? Number(params.overboughtValue) : 100);
        indicator.params.midValue = params.midValue != null ? Number(params.midValue) : 0;
        indicator.params.lowerValue = params.lowerValue != null ? Number(params.lowerValue)
            : (params.oversoldValue != null ? Number(params.oversoldValue) : -100);
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#00e676';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        const hasSmoothing = String(indicator.params.smoothingType || 'None') !== 'None';
        indicator.style.showMa = hasSmoothing && params.showMa !== false;
        indicator.style.maColor = params.maColor || '#ff9800';
        indicator.style.maOpacity = params.maOpacity != null ? Number(params.maOpacity) : 100;
        indicator.style.maLineWidth = params.maLineWidth != null ? params.maLineWidth : 1;
        indicator.style.upperValue = indicator.params.upperValue;
        indicator.style.showUpper = params.showUpper !== false;
        indicator.style.upperColor = params.upperColor || '#787b86';
        indicator.style.upperOpacity = params.upperOpacity != null ? Number(params.upperOpacity) : 100;
        indicator.style.upperLineWidth = params.upperLineWidth != null ? params.upperLineWidth : 1;
        indicator.style.midValue = indicator.params.midValue;
        indicator.style.showMid = params.showMid !== false;
        indicator.style.midColor = params.midColor || 'rgba(120,123,134,0.45)';
        indicator.style.midOpacity = params.midOpacity != null ? Number(params.midOpacity) : 100;
        indicator.style.midLineWidth = params.midLineWidth != null ? params.midLineWidth : 1;
        indicator.style.lowerValue = indicator.params.lowerValue;
        indicator.style.showLower = params.showLower !== false;
        indicator.style.lowerColor = params.lowerColor || '#787b86';
        indicator.style.lowerOpacity = params.lowerOpacity != null ? Number(params.lowerOpacity) : 100;
        indicator.style.lowerLineWidth = params.lowerLineWidth != null ? params.lowerLineWidth : 1;
        indicator.style.showBg = params.showBg === true;
        indicator.style.bgColor = params.bgColor || 'rgba(19,23,34,0.15)';
        indicator.style.bgOpacity = params.bgOpacity != null ? Number(params.bgOpacity) : 15;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS],
            ['maLineStyle', 'maLineDashStyle', maS],
            ['upperLineStyle', 'upperLineDashStyle', 'Dotted'],
            ['midLineStyle', 'midLineDashStyle', 'Dotted'],
            ['lowerLineStyle', 'lowerLineDashStyle', 'Dotted']
        ]);
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyWillrStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.params.period = params.period != null ? Number(params.period) : 14;
        indicator.params.source = params.source || 'close';
        indicator.params.overboughtValue = params.overboughtValue != null ? Number(params.overboughtValue) : -20;
        indicator.params.oversoldValue = params.oversoldValue != null ? Number(params.oversoldValue) : -80;
        indicator.params.midValue = params.midValue != null ? Number(params.midValue) : -50;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#ec407a';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        applyPlotDashFieldsFromParams(indicator.style, params, [['lineStyle', 'lineDashStyle', legacyS]]);
        applyOscillatorLevelStyleFromParams(indicator, params, { overbought: -20, oversold: -80, mid: -50 });
        indicator.style.overboughtOpacity = params.overboughtOpacity != null ? Number(params.overboughtOpacity) : 100;
        indicator.style.midOpacity = params.midOpacity != null ? Number(params.midOpacity) : 100;
        indicator.style.oversoldOpacity = params.oversoldOpacity != null ? Number(params.oversoldOpacity) : 100;
        indicator.style.bgOpacity = params.bgOpacity != null ? Number(params.bgOpacity) : 15;
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyMacdStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.params.fast = params.fast != null ? Number(params.fast) : 12;
        indicator.params.slow = params.slow != null ? Number(params.slow) : 26;
        indicator.params.signal = params.signal != null ? Number(params.signal) : 9;
        indicator.params.source = params.source || 'close';
        indicator.params.oscillatorMaType = params.oscillatorMaType || 'EMA';
        indicator.params.signalMaType = params.signalMaType || 'EMA';
        indicator.style.showMacd = params.showMacd !== false;
        indicator.style.macdColor = params.macdColor || '#2962ff';
        indicator.style.macdLineWidth = params.macdLineWidth != null ? params.macdLineWidth : legacyW;
        indicator.style.showSignal = params.showSignal !== false;
        indicator.style.signalColor = params.signalColor || '#f23645';
        indicator.style.signalLineWidth = params.signalLineWidth != null ? params.signalLineWidth : legacyW;
        indicator.style.showHist = params.showHist !== false;
        const upLegacy = params.histUpColor || 'rgba(38,166,154,0.85)';
        const downLegacy = params.histDownColor || 'rgba(239,83,80,0.85)';
        indicator.style.histColor0 = params.histColor0 || upLegacy;
        indicator.style.histColor1 = params.histColor1 || 'rgba(38,166,154,0.45)';
        indicator.style.histColor2 = params.histColor2 || 'rgba(239,83,80,0.45)';
        indicator.style.histColor3 = params.histColor3 || downLegacy;
        indicator.style.histColor0LineWidth = params.histColor0LineWidth != null ? params.histColor0LineWidth : 1;
        indicator.style.histColor1LineWidth = params.histColor1LineWidth != null ? params.histColor1LineWidth : 1;
        indicator.style.histColor2LineWidth = params.histColor2LineWidth != null ? params.histColor2LineWidth : 1;
        indicator.style.histColor3LineWidth = params.histColor3LineWidth != null ? params.histColor3LineWidth : 1;
        indicator.style.histUpColor = indicator.style.histColor0;
        indicator.style.histDownColor = indicator.style.histColor3;
        indicator.style.zeroValue = params.zeroValue != null ? Number(params.zeroValue) : 0;
        indicator.style.showZero = params.showZero !== false;
        indicator.style.zeroColor = params.zeroColor || 'rgba(120,123,134,0.45)';
        indicator.style.zeroLineWidth = params.zeroLineWidth != null ? params.zeroLineWidth : 1;
        indicator.style.showBg = params.showBg === true;
        indicator.style.bgColor = params.bgColor || 'rgba(19,23,34,0.15)';
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['macdLineStyle', 'macdLineDashStyle', legacyS],
            ['signalLineStyle', 'signalLineDashStyle', legacyS],
            ['histColor0LineStyle', 'histColor0LineDashStyle', 'Line'],
            ['histColor1LineStyle', 'histColor1LineDashStyle', 'Line'],
            ['histColor2LineStyle', 'histColor2LineDashStyle', 'Line'],
            ['histColor3LineStyle', 'histColor3LineDashStyle', 'Line'],
            ['zeroLineStyle', 'zeroLineDashStyle', 'Line']
        ]);
    }

    function applyAdxStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        const legacyPeriod = params.period != null ? Number(params.period) : 14;
        indicator.params.diLength = params.diLength != null ? Number(params.diLength) : legacyPeriod;
        indicator.params.adxSmoothing = params.adxSmoothing != null ? Number(params.adxSmoothing) : legacyPeriod;
        indicator.style.showAdx = params.showAdx !== false;
        indicator.style.adxColor = params.adxColor || '#ff00ff';
        indicator.style.adxLineWidth = params.adxLineWidth != null ? params.adxLineWidth : legacyW;
        indicator.style.showPlusDI = params.showPlusDI !== false;
        indicator.style.plusDIColor = params.plusDIColor || '#00e676';
        indicator.style.plusDILineWidth = params.plusDILineWidth != null ? params.plusDILineWidth : legacyW;
        indicator.style.showMinusDI = params.showMinusDI !== false;
        indicator.style.minusDIColor = params.minusDIColor || '#f23645';
        indicator.style.minusDILineWidth = params.minusDILineWidth != null ? params.minusDILineWidth : legacyW;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['adxLineStyle', 'adxLineDashStyle', legacyS],
            ['plusDILineStyle', 'plusDILineDashStyle', legacyS],
            ['minusDILineStyle', 'minusDILineDashStyle', legacyS]
        ]);
    }

    function applyDpoStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        const midS = params.midLineStyle || 'Dotted';
        indicator.params.period = params.period != null ? Number(params.period) : 20;
        indicator.params.centered = params.centered === true;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#78909c';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.showMid = params.showMid !== false;
        indicator.style.midValue = params.midValue != null ? Number(params.midValue) : 0;
        indicator.style.midColor = params.midColor || 'rgba(120,123,134,0.45)';
        indicator.style.midOpacity = params.midOpacity != null ? Number(params.midOpacity) : 100;
        indicator.style.midLineWidth = params.midLineWidth != null ? params.midLineWidth : 1;
        indicator.style.showBg = params.showBg === true;
        indicator.style.bgColor = params.bgColor || 'rgba(19,23,34,0.15)';
        indicator.style.bgOpacity = params.bgOpacity != null ? Number(params.bgOpacity) : 15;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS],
            ['midLineStyle', 'midLineDashStyle', midS]
        ]);
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyStddevStyleFromParams(indicator, params) {
        applyMaLengthSourceFromParams(indicator, params, 20);
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#ab47bc';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        applyPlotDashFieldsFromParams(indicator.style, params, [['lineStyle', 'lineDashStyle', legacyS]]);
        indicator.style.showBg = params.showBg === true;
        indicator.style.bgColor = params.bgColor || 'rgba(19,23,34,0.15)';
        indicator.style.bgOpacity = params.bgOpacity != null ? Number(params.bgOpacity) : 15;
        indicator.overlay = false;
        indicator.separatePanel = true;
        indicator.hidePlot = false;
    }

    function applyOscZeroPanelStyleFromParams(indicator, params, defaultPeriod, defaultColor) {
        applyMaLengthSourceFromParams(indicator, params, defaultPeriod);
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.params.zeroValue = params.zeroValue != null ? Number(params.zeroValue) : 0;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || defaultColor;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.lineStyle = params.lineStyle || legacyS;
        indicator.style.showZero = params.showZero !== false;
        indicator.style.zeroValue = indicator.params.zeroValue;
        indicator.style.zeroColor = params.zeroColor || 'rgba(120,123,134,0.45)';
        indicator.style.zeroLineStyle = params.zeroLineStyle || 'Dotted';
        indicator.style.showBg = params.showBg === true;
        indicator.style.bgColor = params.bgColor || 'rgba(19,23,34,0.15)';
    }

    function applyMomStyleFromParams(indicator, params) {
        applyMaLengthSourceFromParams(indicator, params, 10);
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#66bb6a';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        applyPlotDashFieldsFromParams(indicator.style, params, [['lineStyle', 'lineDashStyle', legacyS]]);
        indicator.style.showBg = params.showBg === true;
        indicator.style.bgColor = params.bgColor || 'rgba(19,23,34,0.15)';
        indicator.style.bgOpacity = params.bgOpacity != null ? Number(params.bgOpacity) : 15;
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyRocStyleFromParams(indicator, params) {
        applyMaLengthSourceFromParams(indicator, params, 12);
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        const zeroS = params.zeroLineStyle || 'Dotted';
        indicator.params.zeroValue = params.zeroValue != null ? Number(params.zeroValue) : 0;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#ffa726';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.showZero = params.showZero !== false;
        indicator.style.zeroValue = indicator.params.zeroValue;
        indicator.style.zeroColor = params.zeroColor || 'rgba(120,123,134,0.45)';
        indicator.style.zeroOpacity = params.zeroOpacity != null ? Number(params.zeroOpacity) : 100;
        indicator.style.zeroLineWidth = params.zeroLineWidth != null ? params.zeroLineWidth : 1;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS],
            ['zeroLineStyle', 'zeroLineDashStyle', zeroS]
        ]);
        indicator.style.showBg = params.showBg === true;
        indicator.style.bgColor = params.bgColor || 'rgba(19,23,34,0.15)';
        indicator.style.bgOpacity = params.bgOpacity != null ? Number(params.bgOpacity) : 15;
        indicator.overlay = false;
        indicator.separatePanel = true;
    }
    
    // Simple Moving Average
    function calculateSMA(data, period, source) {
        period = period || 20;
        source = source || 'close';
        const result = [];
        for (let i = 0; i < data.length; i++) {
            if (i < period - 1) {
                result.push(null);
            } else {
                let sum = 0;
                let ok = true;
                for (let j = 0; j < period; j++) {
                    const v = resolveOhlcSourceValue(data[i - j], source);
                    if (!Number.isFinite(v)) { ok = false; break; }
                    sum += v;
                }
                result.push(ok ? sum / period : null);
            }
        }
        return result;
    }
    
    // Exponential Moving Average
    function calculateEMA(data, period, source) {
        period = period || 20;
        source = source || 'close';
        const result = [];
        const multiplier = 2 / (period + 1);
        let ema = null;

        for (let i = 0; i < data.length; i++) {
            if (i < period - 1) {
                result.push(null);
            } else if (i === period - 1) {
                let sum = 0;
                let ok = true;
                for (let j = 0; j < period; j++) {
                    const v = resolveOhlcSourceValue(data[i - j], source);
                    if (!Number.isFinite(v)) { ok = false; break; }
                    sum += v;
                }
                if (!ok) {
                    result.push(null);
                    ema = null;
                } else {
                    ema = sum / period;
                    result.push(ema);
                }
            } else {
                const v = resolveOhlcSourceValue(data[i], source);
                if (!Number.isFinite(v) || ema == null) {
                    result.push(null);
                } else {
                    ema = (v - ema) * multiplier + ema;
                    result.push(ema);
                }
            }
        }
        return result;
    }
    
    // Weighted Moving Average
    function calculateWMA(data, period, source) {
        period = period || 20;
        source = source || 'close';
        const result = [];
        const denominator = (period * (period + 1)) / 2;

        for (let i = 0; i < data.length; i++) {
            if (i < period - 1) {
                result.push(null);
            } else {
                let sum = 0;
                let ok = true;
                for (let j = 0; j < period; j++) {
                    const v = resolveOhlcSourceValue(data[i - j], source);
                    if (!Number.isFinite(v)) { ok = false; break; }
                    sum += v * (period - j);
                }
                result.push(ok ? sum / denominator : null);
            }
        }
        return result;
    }

    /** Value drawn at bar `barIndex` when plot is shifted right by `plotOffset` bars (TradingView-style). */
    function seriesValueAtPlotOffset(arr, barIndex, plotOffset) {
        const src = barIndex - (Number(plotOffset) | 0);
        if (!arr || src < 0 || src >= arr.length) return null;
        return arr[src];
    }

    /** Offset is applied at draw time (see drawLineIndicator plotOffset) — do not mutate series. */
    function shiftLineSeries(line, offset) {
        return line;
    }

    function rollingVwmaOnSeries(data, series, period) {
        const p = Math.max(1, period | 0);
        const out = series.map(function () { return null; });
        for (let i = 0; i < series.length; i++) {
            if (i < p - 1) continue;
            let wSum = 0;
            let vSum = 0;
            let ok = true;
            for (let j = 0; j < p; j++) {
                const rv = series[i - j];
                const bar = data[i - j];
                const volRaw = bar && (bar.v != null ? bar.v : bar.volume);
                const vol = volRaw != null ? Number(volRaw) : NaN;
                if (rv === null || rv === undefined || isNaN(rv) || !Number.isFinite(vol) || vol <= 0) {
                    ok = false;
                    break;
                }
                wSum += rv * vol;
                vSum += vol;
            }
            if (ok && vSum > 0) out[i] = wSum / vSum;
        }
        return out;
    }

    function applySmoothedOverlayMaSmoothing(line, data, params) {
        const type = String(params.smoothingType || 'None');
        const len = Math.max(1, safeIndicatorNumber(params.smoothingLength, 14));
        const bbStd = safeIndicatorNumber(params.bbStdDev, 2);
        let ma = null;
        let bbUpper = null;
        let bbLower = null;
        if (type === 'SMA') {
            ma = rollingSmaNullable(line, len);
        } else if (type === 'SMA+BB') {
            const bb = rollingBbOnSeries(line, len, bbStd);
            ma = bb.middle;
            bbUpper = bb.upper;
            bbLower = bb.lower;
        } else if (type === 'EMA') {
            ma = rollingEmaNullable(line, len);
        } else if (type === 'RMA') {
            ma = rollingRmaNullable(line, len);
        } else if (type === 'WMA') {
            ma = rollingWmaNullable(line, len);
        } else if (type === 'VWMA') {
            ma = rollingVwmaOnSeries(data, line, len);
        }
        return { line: line, ma: ma, bbUpper: bbUpper, bbLower: bbLower };
    }

    function calculateSmoothedOverlayMaData(data, params, computeBaseLine) {
        params = params || {};
        const period = params.period != null ? params.period : 20;
        const source = params.source || 'close';
        const offsetRaw = params.offset != null ? Number(params.offset) : 0;
        const offset = Number.isFinite(offsetRaw) ? (offsetRaw | 0) : 0;
        let line = computeBaseLine(data, period, source);
        line = shiftLineSeries(line, offset);
        return applySmoothedOverlayMaSmoothing(line, data, params);
    }

    function calculateWMAIndicatorData(data, params) {
        return calculateSmoothedOverlayMaData(data, params, calculateWMA);
    }

    function calculateWMAOverlayData(data, params) {
        params = params || {};
        const period = params.period != null ? params.period : 20;
        const source = params.source || 'close';
        const offsetRaw = params.offset != null ? Number(params.offset) : 0;
        const offset = Number.isFinite(offsetRaw) ? (offsetRaw | 0) : 0;
        let line = calculateWMA(data, period, source);
        if (offset) line = shiftLineSeries(line, offset);
        return line;
    }

    function calculateSMAIndicatorData(data, params) {
        return calculateSmoothedOverlayMaData(data, params, calculateSMA);
    }

    function calculateEMAIndicatorData(data, params) {
        return calculateSmoothedOverlayMaData(data, params, calculateEMA);
    }

    /** Rolling SMA; null until full window of finite values (O(n) sliding window). */
    function rollingSmaNullable(arr, period) {
        const perf = _indicatorPerf();
        if (perf && typeof perf.rollingSmaFast === 'function') {
            return perf.rollingSmaFast(arr, period);
        }
        const p = Math.max(1, period | 0);
        const n = arr.length;
        const out = new Array(n);
        for (let i = 0; i < n; i++) out[i] = null;
        if (n < p) return out;
        let sum = 0;
        let validCount = 0;
        for (let i = 0; i < p; i++) {
            const v = arr[i];
            if (v != null && !isNaN(v)) { sum += v; validCount++; }
        }
        if (validCount === p) out[p - 1] = sum / p;
        for (let i = p; i < n; i++) {
            const leaving = arr[i - p];
            const entering = arr[i];
            if (leaving != null && !isNaN(leaving)) { sum -= leaving; validCount--; }
            if (entering != null && !isNaN(entering)) { sum += entering; validCount++; }
            out[i] = validCount === p ? sum / p : null;
        }
        return out;
    }

    /** Weighted MA on a nullable numeric series (null until full window). */
    function rollingWmaNullable(arr, period) {
        const perf = _indicatorPerf();
        if (perf && typeof perf.rollingWmaFast === 'function') {
            return perf.rollingWmaFast(arr, period);
        }
        const p = Math.max(2, period | 0);
        const denom = (p * (p + 1)) / 2;
        const out = arr.map(function() { return null; });
        for (let i = p - 1; i < arr.length; i++) {
            let sum = 0;
            let ok = true;
            for (let j = 0; j < p; j++) {
                const v = arr[i - j];
                if (v === null || v === undefined || isNaN(v)) { ok = false; break; }
                sum += v * (p - j);
            }
            if (ok) out[i] = sum / denom;
        }
        return out;
    }

    function rollingEmaNullable(arr, period) {
        const p = Math.max(1, period | 0);
        const mult = 2 / (p + 1);
        const out = arr.map(function () { return null; });
        let ema = null;
        for (let i = 0; i < arr.length; i++) {
            const v = arr[i];
            if (v === null || v === undefined || isNaN(v)) {
                out[i] = null;
                continue;
            }
            if (ema === null) {
                let sum = 0;
                let count = 0;
                for (let j = 0; j < p; j++) {
                    const idx = i - (p - 1) + j;
                    if (idx < 0) { count = -1; break; }
                    const x = arr[idx];
                    if (x === null || x === undefined || isNaN(x)) { count = -1; break; }
                    sum += x;
                    count++;
                }
                if (count === p) {
                    ema = sum / p;
                    out[i] = ema;
                }
            } else {
                ema = (v - ema) * mult + ema;
                out[i] = ema;
            }
        }
        return out;
    }

    function rollingRmaNullable(arr, period) {
        const p = Math.max(1, period | 0);
        const out = arr.map(function () { return null; });
        let rma = null;
        let seedSum = 0;
        let seedCount = 0;
        for (let i = 0; i < arr.length; i++) {
            const v = arr[i];
            if (v === null || v === undefined || isNaN(v)) {
                out[i] = null;
                continue;
            }
            if (rma === null) {
                seedSum += v;
                seedCount++;
                if (seedCount >= p) {
                    rma = seedSum / p;
                    out[i] = rma;
                }
            } else {
                rma = (rma * (p - 1) + v) / p;
                out[i] = rma;
            }
        }
        return out;
    }

    function rollingVwmaOnRsi(data, rsi, period) {
        const p = Math.max(1, period | 0);
        const out = rsi.map(function () { return null; });
        for (let i = 0; i < rsi.length; i++) {
            if (i < p - 1) continue;
            let wSum = 0;
            let vSum = 0;
            let ok = true;
            for (let j = 0; j < p; j++) {
                const rv = rsi[i - j];
                const bar = data[i - j];
                const vol = bar && bar.volume != null ? Number(bar.volume) : NaN;
                if (rv === null || rv === undefined || isNaN(rv) || !Number.isFinite(vol) || vol <= 0) {
                    ok = false;
                    break;
                }
                wSum += rv * vol;
                vSum += vol;
            }
            if (ok && vSum > 0) out[i] = wSum / vSum;
        }
        return out;
    }

    function rollingBbOnSeries(arr, period, stdDev) {
        const p = Math.max(1, period | 0);
        const sd = Number(stdDev);
        const st = Number.isFinite(sd) ? sd : 2;
        const middle = rollingSmaNullable(arr, p);
        const upper = [];
        const lower = [];
        for (let i = 0; i < arr.length; i++) {
            if (middle[i] === null || middle[i] === undefined || isNaN(middle[i])) {
                upper.push(null);
                lower.push(null);
                continue;
            }
            let sumSq = 0;
            let ok = true;
            for (let j = 0; j < p; j++) {
                const idx = i - j;
                if (idx < 0) { ok = false; break; }
                const v = arr[idx];
                if (v === null || v === undefined || isNaN(v)) { ok = false; break; }
                const d = v - middle[i];
                sumSq += d * d;
            }
            if (!ok) {
                upper.push(null);
                lower.push(null);
            } else {
                const stdev = Math.sqrt(Math.max(0, sumSq / p));
                const hi = middle[i] + st * stdev;
                const lo = middle[i] - st * stdev;
                upper.push(hi);
                lower.push(lo);
                middle[i] = (hi + lo) / 2;
            }
        }
        return { middle: middle, upper: upper, lower: lower };
    }

    function calculateRSIIndicatorData(data, params) {
        params = params || {};
        const period = params.period != null ? params.period : 14;
        const source = params.source || 'close';
        const rsi = calculateRSI(data, period, source);
        const type = String(params.smoothingType || 'None');
        const len = Math.max(1, params.smoothingLength != null ? Number(params.smoothingLength) : 14);
        const bbStd = params.bbStdDev != null ? Number(params.bbStdDev) : 2;
        let ma = null;
        let bbUpper = null;
        let bbLower = null;
        if (type === 'SMA') {
            ma = rollingSmaNullable(rsi, len);
        } else if (type === 'SMA+BB') {
            const bb = rollingBbOnSeries(rsi, len, bbStd);
            ma = bb.middle;
            bbUpper = bb.upper;
            bbLower = bb.lower;
        } else if (type === 'EMA') {
            ma = rollingEmaNullable(rsi, len);
        } else if (type === 'RMA') {
            ma = rollingRmaNullable(rsi, len);
        } else if (type === 'WMA') {
            ma = rollingWmaNullable(rsi, len);
        } else if (type === 'VWMA') {
            ma = rollingVwmaOnRsi(data, rsi, len);
        }
        const out = { rsi: rsi, ma: ma, bbUpper: bbUpper, bbLower: bbLower, divergences: null };
        if (params.divergenceEnabled === true) {
            out.divergences = calculateRsiDivergences(data, rsi, rsiDivergencePivotWidth(params));
        }
        return out;
    }

    function rsiDivergencePivotWidth(params) {
        const period = params && params.period != null ? Number(params.period) : 14;
        const fromPeriod = Math.floor(period / 3);
        return Math.max(2, Math.min(10, Number.isFinite(fromPeriod) && fromPeriod > 0 ? fromPeriod : 5));
    }

    function collectPriceSwingPivots(data, w, kind) {
        const pivots = [];
        const n = data.length;
        for (let i = w; i < n - w; i++) {
            if (kind === 'high' && _ictSwingHigh(data, i, w)) {
                pivots.push({ idx: i, price: data[i].h });
            } else if (kind === 'low' && _ictSwingLow(data, i, w)) {
                pivots.push({ idx: i, price: data[i].l });
            }
        }
        return pivots;
    }

    /** Regular bullish/bearish RSI divergences from consecutive price swing pivots. */
    function calculateRsiDivergences(data, rsi, pivotWidth) {
        if (!data || !rsi || !data.length || !rsi.length) return [];
        const w = Math.max(2, Math.min(10, pivotWidth | 0) || 5);
        const divergences = [];
        const lows = collectPriceSwingPivots(data, w, 'low');
        for (let j = 1; j < lows.length; j++) {
            const a = lows[j - 1];
            const b = lows[j];
            const rsiA = rsi[a.idx];
            const rsiB = rsi[b.idx];
            if (!Number.isFinite(rsiA) || !Number.isFinite(rsiB)) continue;
            if (b.price < a.price && rsiB > rsiA) {
                divergences.push({
                    type: 'bull',
                    i0: a.idx,
                    i1: b.idx,
                    price0: a.price,
                    price1: b.price,
                    rsi0: rsiA,
                    rsi1: rsiB
                });
            }
        }
        const highs = collectPriceSwingPivots(data, w, 'high');
        for (let j = 1; j < highs.length; j++) {
            const a = highs[j - 1];
            const b = highs[j];
            const rsiA = rsi[a.idx];
            const rsiB = rsi[b.idx];
            if (!Number.isFinite(rsiA) || !Number.isFinite(rsiB)) continue;
            if (b.price > a.price && rsiB < rsiA) {
                divergences.push({
                    type: 'bear',
                    i0: a.idx,
                    i1: b.idx,
                    price0: a.price,
                    price1: b.price,
                    rsi0: rsiA,
                    rsi1: rsiB
                });
            }
        }
        return divergences.length > 30 ? divergences.slice(-30) : divergences;
    }

    function enrichRsiPackWithDivergences(chartData, pack, params) {
        if (!params || params.divergenceEnabled !== true || !pack || !pack.rsi || !chartData) return pack;
        return Object.assign({}, pack, {
            divergences: calculateRsiDivergences(chartData, pack.rsi, rsiDivergencePivotWidth(params))
        });
    }
    
    function rollingVwmaOnData(data, period, source) {
        const p = Math.max(1, period | 0);
        source = source || 'close';
        const out = data.map(function () { return null; });
        for (let i = 0; i < data.length; i++) {
            if (i < p - 1) continue;
            let wSum = 0;
            let vSum = 0;
            let ok = true;
            for (let j = 0; j < p; j++) {
                const bar = data[i - j];
                const val = resolveOhlcSourceValue(bar, source);
                const volRaw = bar && (bar.v != null ? bar.v : bar.volume);
                const vol = volRaw != null ? Number(volRaw) : NaN;
                if (!Number.isFinite(val) || !Number.isFinite(vol) || vol <= 0) {
                    ok = false;
                    break;
                }
                wSum += val * vol;
                vSum += vol;
            }
            if (ok && vSum > 0) out[i] = wSum / vSum;
        }
        return out;
    }

    // Bollinger Bands
    function calculateBollingerBands(data, calcOrPeriod, stdDev, source) {
        let calc;
        if (typeof calcOrPeriod === 'object' && calcOrPeriod !== null && !Array.isArray(calcOrPeriod)) {
            calc = resolveBbCalcParams(calcOrPeriod);
        } else {
            calc = resolveBbCalcParams({
                period: calcOrPeriod,
                stdDev: stdDev,
                source: source
            });
        }
        const p = Math.max(1, calc.period | 0);
        const sd = calc.stdDev;
        const src = calc.source;
        const maType = calc.maType;
        const srcArr = data.map(function (bar) {
            const v = resolveOhlcSourceValue(bar, src);
            return Number.isFinite(v) ? v : null;
        });

        let middle;
        if (maType === 'EMA') {
            middle = rollingEmaNullable(srcArr, p);
        } else if (maType === 'RMA') {
            middle = rollingRmaNullable(srcArr, p);
        } else if (maType === 'WMA') {
            middle = rollingWmaNullable(srcArr, p);
        } else if (maType === 'VWMA') {
            middle = rollingVwmaOnData(data, p, src);
        } else {
            middle = rollingSmaNullable(srcArr, p);
        }

        const upper = [];
        const lower = [];
        for (let i = 0; i < data.length; i++) {
            if (middle[i] == null || isNaN(middle[i])) {
                upper.push(null);
                lower.push(null);
                continue;
            }
            let sumSqDiff = 0;
            let ok = true;
            for (let j = 0; j < p; j++) {
                const idx = i - j;
                if (idx < 0) { ok = false; break; }
                const v = srcArr[idx];
                if (v == null || isNaN(v)) { ok = false; break; }
                const d = v - middle[i];
                sumSqDiff += d * d;
            }
            if (!ok) {
                upper.push(null);
                lower.push(null);
            } else {
                const basis = middle[i];
                const stdev = Math.sqrt(Math.max(0, sumSqDiff / p));
                const hi = basis + sd * stdev;
                const lo = basis - sd * stdev;
                upper.push(hi);
                lower.push(lo);
                middle[i] = (hi + lo) / 2;
            }
        }

        return shiftBandSeries({ upper: upper, middle: middle, lower: lower }, calc.offset);
    }
    
    // RSI (Relative Strength Index)
    function calculateRSI(data, period, source) {
        period = period || 14;
        source = source || 'close';
        const result = [];
        const gains = [];
        const losses = [];

        for (let i = 1; i < data.length; i++) {
            const cur = resolveOhlcSourceValue(data[i], source);
            const prev = resolveOhlcSourceValue(data[i - 1], source);
            if (!Number.isFinite(cur) || !Number.isFinite(prev)) {
                gains.push(0);
                losses.push(0);
                continue;
            }
            const change = cur - prev;
            gains.push(change > 0 ? change : 0);
            losses.push(change < 0 ? Math.abs(change) : 0);
        }

        result.push(null);

        let avgGain = 0, avgLoss = 0;
        for (let i = 0; i < period && i < gains.length; i++) {
            avgGain += gains[i];
            avgLoss += losses[i];
        }
        avgGain /= period;
        avgLoss /= period;

        for (let i = 0; i < gains.length; i++) {
            if (i < period) {
                result.push(null);
            } else {
                avgGain = ((avgGain * (period - 1)) + gains[i]) / period;
                avgLoss = ((avgLoss * (period - 1)) + losses[i]) / period;
                const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
                const rsi = 100 - (100 / (1 + rs));
                result.push(rsi);
            }
        }

        return result;
    }
    
    // MACD — oscillator MA type (EMA/SMA) + signal MA type (EMA/SMA)
    function calculateMACD(data, fast, slow, signal, source, opts) {
        opts = opts || {};
        source = source || 'close';
        const oscType = String(opts.oscillatorMaType || 'EMA').toUpperCase();
        const sigType = String(opts.signalMaType || 'EMA').toUpperCase();
        const calcOscMa = oscType === 'SMA' ? calculateSMA : calculateEMA;
        const fastMA = calcOscMa(data, fast, source);
        const slowMA = calcOscMa(data, slow, source);
        const macd = [];
        
        for (let i = 0; i < data.length; i++) {
            if (fastMA[i] !== null && slowMA[i] !== null) {
                macd.push(fastMA[i] - slowMA[i]);
            } else {
                macd.push(null);
            }
        }
        
        let signalLine;
        if (sigType === 'SMA') {
            signalLine = rollingSmaNullable(macd, Math.max(1, signal | 0));
        } else {
            signalLine = [];
            const multiplier = 2 / (signal + 1);
            let ema = null;
            for (let i = 0; i < macd.length; i++) {
                if (macd[i] === null) {
                    signalLine.push(null);
                } else if (ema === null) {
                    ema = macd[i];
                    signalLine.push(ema);
                } else {
                    ema = (macd[i] - ema) * multiplier + ema;
                    signalLine.push(ema);
                }
            }
        }
        
        const histogram = [];
        for (let i = 0; i < macd.length; i++) {
            if (macd[i] !== null && signalLine[i] !== null) {
                histogram.push(macd[i] - signalLine[i]);
            } else {
                histogram.push(null);
            }
        }
        
        return { macd: macd, signal: signalLine, histogram: histogram };
    }

    function macdHistogramBarColor(val, prevVal, style) {
        const c0 = style.histColor0 || style.histUpColor || 'rgba(38,166,154,0.85)';
        const c1 = style.histColor1 || 'rgba(38,166,154,0.45)';
        const c2 = style.histColor2 || 'rgba(239,83,80,0.45)';
        const c3 = style.histColor3 || style.histDownColor || 'rgba(239,83,80,0.85)';
        if (prevVal === null || prevVal === undefined || isNaN(prevVal)) {
            return val >= 0 ? c0 : c3;
        }
        if (val >= 0) return val >= prevVal ? c0 : c1;
        return val >= prevVal ? c2 : c3;
    }

    function aoHistogramBarColor(val, prevVal, style, resolve) {
        const c0 = resolve(style.histColor0 || '#26a69a', style.histColor0Opacity);
        const c1 = resolve(style.histColor1 || '#ef5350', style.histColor1Opacity);
        if (prevVal === null || prevVal === undefined || isNaN(prevVal)) {
            return val >= 0 ? c0 : c1;
        }
        return val > prevVal ? c0 : c1;
    }

    function applyTrixStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        const zeroS = params.zeroLineStyle || 'Dotted';
        indicator.params.period = params.period != null ? Math.max(1, Number(params.period) | 0) : 14;
        indicator.params.zeroValue = params.zeroValue != null ? Number(params.zeroValue) : 0;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#8d6e63';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.showZero = params.showZero !== false;
        indicator.style.zeroValue = indicator.params.zeroValue;
        indicator.style.zeroColor = params.zeroColor || 'rgba(120,123,134,0.45)';
        indicator.style.zeroOpacity = params.zeroOpacity != null ? Number(params.zeroOpacity) : 100;
        indicator.style.zeroLineWidth = params.zeroLineWidth != null ? params.zeroLineWidth : 1;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS],
            ['zeroLineStyle', 'zeroLineDashStyle', zeroS]
        ]);
        indicator.hidePlot = params.hideFromContainer === true;
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyRviStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        const sigS = params.signalLineStyle || 'Line';
        indicator.params.period = params.period != null ? Number(params.period) : 10;
        indicator.params.offset = params.offset != null ? Number(params.offset) : 0;
        indicator.style.showRvi = params.showRvi !== false;
        indicator.style.color = params.color || '#ffa726';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.showSignal = params.showSignal !== false;
        indicator.style.signalColor = params.signalColor || '#2962ff';
        indicator.style.signalOpacity = params.signalOpacity != null ? Number(params.signalOpacity) : 100;
        indicator.style.signalLineWidth = params.signalLineWidth != null ? params.signalLineWidth : legacyW;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS],
            ['signalLineStyle', 'signalLineDashStyle', sigS]
        ]);
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyVortexStyleFromParams(indicator, params) {
        indicator.params.period = params.period != null ? params.period : 14;
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        const plusS = params.plusLineStyle || legacyS;
        const minusS = params.minusLineStyle || legacyS;
        indicator.style.showPlus = params.showPlus !== false;
        indicator.style.plusColor = params.plusColor || '#00e676';
        indicator.style.plusOpacity = params.plusOpacity != null ? Number(params.plusOpacity) : 100;
        indicator.style.plusLineWidth = params.plusLineWidth != null ? params.plusLineWidth : legacyW;
        indicator.style.showMinus = params.showMinus !== false;
        indicator.style.minusColor = params.minusColor || '#f23645';
        indicator.style.minusOpacity = params.minusOpacity != null ? Number(params.minusOpacity) : 100;
        indicator.style.minusLineWidth = params.minusLineWidth != null ? params.minusLineWidth : legacyW;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['plusLineStyle', 'plusLineDashStyle', plusS],
            ['minusLineStyle', 'minusLineDashStyle', minusS]
        ]);
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyUoStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.params.period1 = params.period1 != null ? Number(params.period1) : 7;
        indicator.params.period2 = params.period2 != null ? Number(params.period2) : 14;
        indicator.params.period3 = params.period3 != null ? Number(params.period3) : 28;
        indicator.style.showLine = params.showLine !== false;
        indicator.style.color = params.color || '#7e57c2';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        applyPlotDashFieldsFromParams(indicator.style, params, [['lineStyle', 'lineDashStyle', legacyS]]);
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyAoStyleFromParams(indicator, params) {
        let fastLength = params.fastLength != null ? Math.max(1, Number(params.fastLength) | 0) : 5;
        let slowLength = params.slowLength != null ? Math.max(2, Number(params.slowLength) | 0) : 34;
        if (slowLength <= fastLength) slowLength = fastLength + 1;
        indicator.params.fastLength = fastLength;
        indicator.params.slowLength = slowLength;
        indicator.style.showAO = params.showAO !== false;
        indicator.style.histColor0 = params.histColor0 || '#26a69a';
        indicator.style.histColor0Opacity = params.histColor0Opacity != null ? Number(params.histColor0Opacity) : 100;
        indicator.style.histColor0LineWidth = params.histColor0LineWidth != null ? params.histColor0LineWidth : 1;
        indicator.style.histColor1 = params.histColor1 || '#ef5350';
        indicator.style.histColor1Opacity = params.histColor1Opacity != null ? Number(params.histColor1Opacity) : 100;
        indicator.style.histColor1LineWidth = params.histColor1LineWidth != null ? params.histColor1LineWidth : 1;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['histColor0LineStyle', 'histColor0LineDashStyle', 'Histogram'],
            ['histColor1LineStyle', 'histColor1LineDashStyle', 'Histogram']
        ]);
        indicator.hidePlot = params.hideFromContainer === true;
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function volumeColorsFromStyle(style, resolve) {
        style = style || {};
        const growingRaw = style.growingColor || style.upColor || 'rgba(8, 153, 129, 0.5)';
        const fallingRaw = style.fallingColor || style.downColor || 'rgba(242, 54, 69, 0.5)';
        const gOp = style.growingOpacity != null ? Number(style.growingOpacity) : null;
        const fOp = style.fallingOpacity != null ? Number(style.fallingOpacity) : null;
        return {
            growing: resolve(growingRaw, gOp),
            falling: resolve(fallingRaw, fOp)
        };
    }

    function volumeBarIsGrowing(chart, barIndex, bar, usePrevClose) {
        if (!bar) return true;
        const c = Number(bar.c);
        if (!usePrevClose) return c >= Number(bar.o);
        const data = chart && chart.data;
        const prev = barIndex > 0 && data && data[barIndex - 1] ? data[barIndex - 1] : null;
        const pc = prev ? Number(prev.c) : c;
        return c >= pc;
    }

    /** LOD buckets use vSum (chart.js) or v (display pipeline) — read either. */
    function volumeFromOhlcBar(bar) {
        if (!bar) return 0;
        const s = Number(bar.vSum);
        if (Number.isFinite(s)) return s;
        const v = Number(bar.v);
        return Number.isFinite(v) ? v : 0;
    }

    Chart.prototype._volumeFromOhlcBar = volumeFromOhlcBar;

    function applyVolumeStyleFromParams(indicator, params) {
        const legacyUp = params.upColor || 'rgba(8, 153, 129, 0.5)';
        const legacyDn = params.downColor || 'rgba(242, 54, 69, 0.5)';
        indicator.style.showVolume = params.showVolume !== false;
        indicator.style.growingColor = params.growingColor || legacyUp;
        indicator.style.growingOpacity = params.growingOpacity != null ? Number(params.growingOpacity) : 50;
        indicator.style.growingLineWidth = params.growingLineWidth != null ? params.growingLineWidth : 1;
        indicator.style.fallingColor = params.fallingColor || legacyDn;
        indicator.style.fallingOpacity = params.fallingOpacity != null ? Number(params.fallingOpacity) : 50;
        indicator.style.fallingLineWidth = params.fallingLineWidth != null ? params.fallingLineWidth : 1;
        indicator.style.maColor = params.maColor || '#2962ff';
        indicator.style.maOpacity = params.maOpacity != null ? Number(params.maOpacity) : 100;
        indicator.style.maLineWidth = params.maLineWidth != null ? params.maLineWidth : 2;
        indicator.params.colorBasedOnPrevClose = params.colorBasedOnPrevClose === true;
        indicator.params.showMa = params.showMa === true || params.showMA === true;
        indicator.params.maPeriod = params.maPeriod != null ? Math.max(1, Number(params.maPeriod) | 0) : 20;
        indicator.style.upColor = indicator.style.growingColor;
        indicator.style.downColor = indicator.style.fallingColor;
        indicator.params.showMA = indicator.params.showMa;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['growingLineStyle', 'growingLineDashStyle', 'Histogram'],
            ['fallingLineStyle', 'fallingLineDashStyle', 'Histogram'],
            ['maLineStyle', 'maLineDashStyle', 'Line']
        ]);
        indicator.overlay = false;
        indicator.separatePanel = false;
        indicator.isVolume = true;
    }

    function syncVolumeChartSettings(chart, indicator) {
        if (!chart || !chart.chartSettings || !indicator) return;
        const st = indicator.style || {};
        chart.chartSettings.volumeUpColor = st.growingColor || st.upColor || chart.chartSettings.volumeUpColor;
        chart.chartSettings.volumeDownColor = st.fallingColor || st.downColor || chart.chartSettings.volumeDownColor;
    }

    /** Dorsey Mass Index uses 9-period EMA of range; Length controls summation window. */
    const MASS_INDEX_EMA_PERIOD = 9;

    function massIndexPeriodFromParams(params) {
        if (params.period != null) return Math.max(2, Number(params.period) | 0);
        if (params.sumPeriod != null) return Math.max(2, Number(params.sumPeriod) | 0);
        return 10;
    }

    function applyAtrStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.params.period = atrPeriodFromParams(params);
        indicator.params.smoothingType = atrSmoothingTypeFromParams(params);
        indicator.style.color = params.color || '#ff6d00';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = legacyW;
        indicator.style.showLine = params.showLine !== false;
        applyPlotDashFieldsFromParams(indicator.style, params, [['lineStyle', 'lineDashStyle', legacyS]]);
        indicator.hidePlot = params.hideFromContainer === true;
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyAdrStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Step line';
        indicator.style.color = params.color || '#26a69a';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = legacyW;
        indicator.style.showLabel = params.showLabel !== false;
        applyPlotDashFieldsFromParams(indicator.style, params, [['lineStyle', 'lineDashStyle', legacyS]]);
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyMassIndexStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.style.color = params.color || '#00bcd4';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = legacyW;
        indicator.style.showLine = params.showLine !== false;
        applyPlotDashFieldsFromParams(indicator.style, params, [['lineStyle', 'lineDashStyle', legacyS]]);
        indicator.hidePlot = params.hideFromContainer === true;
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyElderRayStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 1;
        const legacyS = params.lineStyle || 'Columns';
        const zeroS = params.zeroLineStyle || 'Line';
        indicator.params.period = params.period != null ? Math.max(2, Number(params.period) | 0) : (indicator.params.period || 13);
        indicator.params.zeroValue = params.zeroValue != null ? Number(params.zeroValue) : 0;
        indicator.style.showBBPower = params.showBBPower !== false;
        indicator.style.bullColor = params.bullColor || '#26a69a';
        indicator.style.bullOpacity = params.bullOpacity != null ? Number(params.bullOpacity) : 100;
        indicator.style.bullLineWidth = params.bullLineWidth != null ? params.bullLineWidth : legacyW;
        indicator.style.bearColor = params.bearColor || '#ef5350';
        indicator.style.bearOpacity = params.bearOpacity != null ? Number(params.bearOpacity) : 100;
        indicator.style.bearLineWidth = params.bearLineWidth != null ? params.bearLineWidth : legacyW;
        indicator.style.showZero = params.showZero !== false;
        indicator.style.zeroValue = indicator.params.zeroValue;
        indicator.style.zeroColor = params.zeroColor || 'rgba(120,123,134,0.45)';
        indicator.style.zeroOpacity = params.zeroOpacity != null ? Number(params.zeroOpacity) : 100;
        indicator.style.zeroLineWidth = params.zeroLineWidth != null ? params.zeroLineWidth : 1;
        const bullS = params.bullLineStyle || (legacyS === 'Line' ? 'Columns' : legacyS);
        const bearS = params.bearLineStyle || (legacyS === 'Line' ? 'Columns' : legacyS);
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['bullLineStyle', 'bullLineDashStyle', bullS],
            ['bearLineStyle', 'bearLineDashStyle', bearS],
            ['zeroLineStyle', 'zeroLineDashStyle', zeroS]
        ]);
        indicator.overlay = false;
        indicator.separatePanel = true;
    }
    
    const VWAP_ANCHOR_PERIODS = [
        'session', 'week', 'month', 'quarter', 'year', 'decade', 'century',
        'earnings', 'dividends', 'splits'
    ];

    function normalizeVwapAnchorPeriod(raw) {
        const ap = String(raw || 'session').toLowerCase();
        return VWAP_ANCHOR_PERIODS.indexOf(ap) >= 0 ? ap : 'session';
    }

    function vwapChartTimezoneId() {
        const tm = typeof window !== 'undefined' ? window.timezoneManager : null;
        if (tm && typeof tm.getTimezone === 'function') {
            const tz = tm.getTimezone();
            if (tz) return tz;
        }
        return 'Etc/UTC';
    }

    function vwapCurrentAssetClass() {
        try {
            const chart = typeof window !== 'undefined' ? window.chart : null;
            if (!chart) return 'Forex';
            const sym = String(chart.currentSymbol || '').toUpperCase();
            const session = chart._normalizedSession || chart.sessionData || chart.session;
            const inst = session && session.instruments && sym ? session.instruments[sym] : null;
            const ac = inst && (inst.asset_class || inst.assetClass || session.asset_class || session.assetClass);
            if (ac) {
                const s = String(ac).toLowerCase();
                if (s.includes('stock') || s.includes('equit')) return 'Stocks';
                if (s.includes('crypto')) return 'Crypto';
                if (s.includes('future')) return 'Futures';
            }
        } catch (e) { /* ignore */ }
        return 'Forex';
    }

    // Replay was allocating a new Intl.DateTimeFormat per bar (×2 passes) → heap storm.
    // Kill-switch: window.__TALARIA_FIX_VWAP_REPLAY_PERF = false
    const _vwapBarPartsFmtCache = Object.create(null);

    function _vwapReplayPerfFixEnabled() {
        return typeof window === 'undefined'
            || window.__TALARIA_FIX_VWAP_REPLAY_PERF !== false;
    }

    function vwapCachedBarPartsFormatter(tzId) {
        const key = tzId || 'Etc/UTC';
        if (!_vwapBarPartsFmtCache[key]) {
            _vwapBarPartsFmtCache[key] = new Intl.DateTimeFormat('en-GB', {
                timeZone: key,
                year: 'numeric',
                month: 'numeric',
                day: 'numeric',
                hour: 'numeric',
                minute: 'numeric',
                hour12: false
            });
        }
        return _vwapBarPartsFmtCache[key];
    }

    function vwapBarPartsInTimezone(bar, tzId) {
        const t = bar && bar.t != null ? Number(bar.t) : NaN;
        if (!Number.isFinite(t)) return null;
        try {
            const fmt = _vwapReplayPerfFixEnabled()
                ? vwapCachedBarPartsFormatter(tzId)
                : new Intl.DateTimeFormat('en-GB', {
                    timeZone: tzId || 'Etc/UTC',
                    year: 'numeric',
                    month: 'numeric',
                    day: 'numeric',
                    hour: 'numeric',
                    minute: 'numeric',
                    hour12: false
                });
            const parts = fmt.formatToParts(new Date(t));
            const get = function (type) {
                const p = parts.find(function (x) { return x.type === type; });
                return p ? parseInt(p.value, 10) : 0;
            };
            return {
                y: get('year'),
                mo: get('month') - 1,
                day: get('day'),
                dec: get('hour') + get('minute') / 60
            };
        } catch (e) {
            const d = new Date(t);
            return {
                y: d.getUTCFullYear(),
                mo: d.getUTCMonth(),
                day: d.getUTCDate(),
                dec: d.getUTCHours() + d.getUTCMinutes() / 60
            };
        }
    }

    function vwapSessionAnchorKey(bar) {
        const asset = vwapCurrentAssetClass();
        const tz = asset === 'Stocks' ? 'America/New_York' : (asset === 'Forex' || asset === 'Futures' ? 'America/New_York' : vwapChartTimezoneId());
        const rolloverDec = asset === 'Stocks' ? 9.5 : 17;
        const parts = vwapBarPartsInTimezone(bar, tz);
        if (!parts) return '0';
        let y = parts.y;
        let mo = parts.mo;
        let day = parts.day;
        if (parts.dec >= rolloverDec) {
            const d = new Date(Date.UTC(y, mo, day));
            d.setUTCDate(d.getUTCDate() + 1);
            y = d.getUTCFullYear();
            mo = d.getUTCMonth();
            day = d.getUTCDate();
        }
        return y + '-' + mo + '-' + day;
    }

    function vwapCorporateEventTimestamps(eventType) {
        try {
            const chart = typeof window !== 'undefined' ? window.chart : null;
            if (!chart) return [];
            const sym = String(chart.currentSymbol || '').toUpperCase();
            const cache = chart._vwapCorporateEventCache;
            if (cache && sym && cache[sym] && Array.isArray(cache[sym][eventType])) {
                return cache[sym][eventType]
                    .map(function (x) { return Number(x); })
                    .filter(function (x) { return Number.isFinite(x); })
                    .sort(function (a, b) { return a - b; });
            }
        } catch (e) { /* ignore */ }
        return [];
    }

    function buildVwapCorporateEventKeys(data, eventType) {
        const events = vwapCorporateEventTimestamps(eventType);
        const keys = new Array(data.length);
        if (!events.length) {
            for (let i = 0; i < data.length; i++) keys[i] = 'corp-' + eventType;
            return keys;
        }
        let evtIdx = 0;
        let currentKey = 'corp-' + eventType + '-0';
        for (let i = 0; i < data.length; i++) {
            const t = data[i] && data[i].t != null ? Number(data[i].t) : NaN;
            while (evtIdx < events.length && Number.isFinite(t) && t >= events[evtIdx]) {
                currentKey = 'corp-' + eventType + '-' + events[evtIdx];
                evtIdx++;
            }
            keys[i] = currentKey;
        }
        return keys;
    }

    function vwapAnchorPeriodKey(bar, anchorPeriod) {
        const t = bar && bar.t != null ? Number(bar.t) : NaN;
        if (!Number.isFinite(t)) return '0';
        const d = new Date(t);
        const y = d.getUTCFullYear();
        const mo = d.getUTCMonth();
        const day = d.getUTCDate();
        const ap = normalizeVwapAnchorPeriod(anchorPeriod);
        if (ap === 'session') return vwapSessionAnchorKey(bar);
        if (ap === 'week') {
            const tmp = new Date(Date.UTC(y, mo, day));
            const dayNum = tmp.getUTCDay() || 7;
            tmp.setUTCDate(tmp.getUTCDate() + 4 - dayNum);
            const yearStart = new Date(Date.UTC(tmp.getUTCFullYear(), 0, 1));
            const weekNo = Math.ceil((((tmp - yearStart) / 86400000) + 1) / 7);
            return tmp.getUTCFullYear() + '-W' + weekNo;
        }
        if (ap === 'month') return y + '-' + mo;
        if (ap === 'quarter') return y + '-Q' + (Math.floor(mo / 3) + 1);
        if (ap === 'year') return String(y);
        if (ap === 'decade') return String(Math.floor(y / 10) * 10);
        if (ap === 'century') return String(Math.floor(y / 100) * 100);
        return y + '-' + mo + '-' + day;
    }

    function buildVwapAnchorKeys(data, anchorPeriod) {
        const ap = normalizeVwapAnchorPeriod(anchorPeriod);
        if (ap === 'earnings' || ap === 'dividends' || ap === 'splits') {
            return buildVwapCorporateEventKeys(data, ap);
        }
        return null;
    }

    // Mid-tick replay mutates OHLCV but keeps bar open `t` + length — reuse keys.
    let _vwapPeriodKeysCache = {
        dataRef: null,
        len: 0,
        lastT: null,
        firstT: null,
        ap: '',
        keys: null
    };

    /** One key per bar (session/week/… or corporate). Avoids a second Intl pass. */
    function buildVwapPeriodKeys(data, anchorPeriod) {
        if (!Array.isArray(data) || !data.length) return [];
        const ap = normalizeVwapAnchorPeriod(anchorPeriod);
        if (_vwapReplayPerfFixEnabled()) {
            const firstT = data[0] && data[0].t != null ? Number(data[0].t) : null;
            const lastT = data[data.length - 1] && data[data.length - 1].t != null
                ? Number(data[data.length - 1].t) : null;
            const c = _vwapPeriodKeysCache;
            if (c.keys && c.dataRef === data && c.len === data.length
                && c.lastT === lastT && c.firstT === firstT && c.ap === ap) {
                return c.keys;
            }
        }
        const corp = buildVwapAnchorKeys(data, ap);
        let keys;
        if (corp) {
            keys = corp;
        } else {
            keys = new Array(data.length);
            for (let i = 0; i < data.length; i++) {
                keys[i] = vwapAnchorPeriodKey(data[i], ap);
            }
        }
        if (_vwapReplayPerfFixEnabled()) {
            _vwapPeriodKeysCache = {
                dataRef: data,
                len: data.length,
                lastT: data[data.length - 1] && data[data.length - 1].t != null
                    ? Number(data[data.length - 1].t) : null,
                firstT: data[0] && data[0].t != null ? Number(data[0].t) : null,
                ap: ap,
                keys: keys
            };
        }
        return keys;
    }

    /** Bar indices where VWAP anchor period resets (session/week/etc.). */
    function buildVwapAnchorBarIndices(data, anchorPeriod, precomputedKeys) {
        if (!Array.isArray(data) || !data.length) return [];
        const anchorKeys = precomputedKeys || buildVwapPeriodKeys(data, anchorPeriod);
        const bars = [];
        let prevKey = null;
        for (let i = 0; i < data.length; i++) {
            const key = anchorKeys[i];
            if (i === 0 || key !== prevKey) bars.push(i);
            prevKey = key;
        }
        return bars;
    }

    /** VWAP with anchored periods, optional std-dev / % bands, and plot offset. */
    function calculateVWAPIndicatorData(data, params) {
        params = params || {};
        const source = params.source || 'hlc3';
        const mults = [
            { on: params.band1Enabled !== false, v: vwapParseNum(params.band1Mult, 1) },
            { on: params.band2Enabled === true, v: vwapParseNum(params.band2Mult, 2) },
            { on: params.band3Enabled === true, v: vwapParseNum(params.band3Mult, 3) }
        ];
        const offset = vwapParseNum(params.offset, 0) | 0;
        const bandsMode = params.bandsCalcMode === 'percentage' ? 'percentage' : 'standard_deviation';
        const n = data.length;
        const empty = function () {
            const a = new Array(n);
            for (let i = 0; i < n; i++) a[i] = null;
            return a;
        };
        const vwap = empty();
        // Only allocate enabled band series (defaults: band1 on → 3 lines, not 7).
        const upper1 = mults[0].on ? empty() : null;
        const lower1 = mults[0].on ? empty() : null;
        const upper2 = mults[1].on ? empty() : null;
        const lower2 = mults[1].on ? empty() : null;
        const upper3 = mults[2].on ? empty() : null;
        const lower3 = mults[2].on ? empty() : null;
        const periodKeys = buildVwapPeriodKeys(data, params.anchorPeriod);
        let cumPV = 0;
        let cumP2V = 0;
        let cumVol = 0;
        let prevKey = null;
        const anchorBars = buildVwapAnchorBarIndices(data, params.anchorPeriod, periodKeys);
        const needStdev = bandsMode !== 'percentage'
            && (mults[0].on || mults[1].on || mults[2].on);
        for (let i = 0; i < n; i++) {
            const key = periodKeys[i];
            if (prevKey !== null && key !== prevKey) {
                cumPV = 0;
                cumP2V = 0;
                cumVol = 0;
            }
            prevKey = key;
            const src = resolveOhlcSourceValue(data[i], source);
            const volRaw = Number(data[i].v);
            const vol = Number.isFinite(volRaw) ? Math.max(volRaw, 0) : 0;
            if (Number.isFinite(src) && vol > 0) {
                cumPV += src * vol;
                if (needStdev) cumP2V += src * src * vol;
                cumVol += vol;
            }
            if (cumVol > 0) {
                const v = cumPV / cumVol;
                vwap[i] = v;
                let stdev = 0;
                if (needStdev) {
                    const variance = Math.max(cumP2V / cumVol - v * v, 0);
                    stdev = Math.sqrt(variance);
                }
                const bands = [
                    { u: upper1, l: lower1, on: mults[0].on, m: mults[0].v },
                    { u: upper2, l: lower2, on: mults[1].on, m: mults[1].v },
                    { u: upper3, l: lower3, on: mults[2].on, m: mults[2].v }
                ];
                for (let bi = 0; bi < bands.length; bi++) {
                    if (!bands[bi].on || !bands[bi].u || !bands[bi].l) continue;
                    const mult = bands[bi].m;
                    if (bandsMode === 'percentage') {
                        bands[bi].u[i] = v * (1 + mult / 100);
                        bands[bi].l[i] = v * (1 - mult / 100);
                    } else {
                        bands[bi].u[i] = v + mult * stdev;
                        bands[bi].l[i] = v - mult * stdev;
                    }
                }
            }
        }
        // Disabled bands share one null series (read-only; shiftLineSeries is identity).
        const off = (upper1 && lower1 && upper2 && lower2 && upper3 && lower3)
            ? null
            : empty();
        return {
            vwap: shiftLineSeries(vwap, offset),
            upper1: shiftLineSeries(upper1 || off, offset),
            lower1: shiftLineSeries(lower1 || off, offset),
            upper2: shiftLineSeries(upper2 || off, offset),
            lower2: shiftLineSeries(lower2 || off, offset),
            upper3: shiftLineSeries(upper3 || off, offset),
            lower3: shiftLineSeries(lower3 || off, offset),
            anchorBars: anchorBars
        };
    }

    function calculateVWAP(data, params) {
        return calculateVWAPIndicatorData(data, params || { source: 'hlc3', anchorPeriod: 'session' }).vwap;
    }

    function vwapParseNum(raw, fallback) {
        const fn = typeof window !== 'undefined' ? window.__v9NormalizeIndicatorNumericString : null;
        const s = fn ? fn(raw) : String(raw != null ? raw : '');
        if (s === '' || s === '-' || s === '+' || s === '.' || s === '-.' || s === '+.') return fallback;
        const n = parseFloat(s);
        return Number.isFinite(n) ? n : fallback;
    }

    function applyVwapStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.params.source = params.source || 'hlc3';
        indicator.params.offset = vwapParseNum(params.offset, indicator.params.offset != null ? indicator.params.offset : 0);
        indicator.params.anchorPeriod = normalizeVwapAnchorPeriod(params.anchorPeriod);
        indicator.params.hideOn1DOrAbove = params.hideOn1DOrAbove === true;
        indicator.params.bandsCalcMode = params.bandsCalcMode === 'percentage' ? 'percentage' : 'standard_deviation';
        indicator.params.band1Enabled = params.band1Enabled !== false;
        indicator.params.band1Mult = vwapParseNum(params.band1Mult, 1);
        indicator.params.band2Enabled = params.band2Enabled === true;
        indicator.params.band2Mult = vwapParseNum(params.band2Mult, 2);
        indicator.params.band3Enabled = params.band3Enabled === true;
        indicator.params.band3Mult = vwapParseNum(params.band3Mult, 3);
        indicator.style.showVwap = params.showVwap !== false;
        indicator.style.color = params.color || '#2962ff';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : legacyW;
        indicator.style.showUpper1 = params.showUpper1 !== false;
        indicator.style.upperColor = params.upperColor || params.color || '#2962ff';
        indicator.style.upperOpacity = params.upperOpacity != null ? Number(params.upperOpacity) : 100;
        indicator.style.upperLineWidth = params.upperLineWidth != null ? params.upperLineWidth : 1;
        indicator.style.showLower1 = params.showLower1 !== false;
        indicator.style.lowerColor = params.lowerColor || params.color || '#2962ff';
        indicator.style.lowerOpacity = params.lowerOpacity != null ? Number(params.lowerOpacity) : 100;
        indicator.style.lowerLineWidth = params.lowerLineWidth != null ? params.lowerLineWidth : 1;
        indicator.style.showFill1 = params.showFill1 === true;
        indicator.style.fillColor = params.fillColor || 'rgba(41,98,255,0.12)';
        indicator.style.fillOpacity = params.fillOpacity != null ? Number(params.fillOpacity) : 12;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['lineStyle', 'lineDashStyle', legacyS],
            ['upperLineStyle', 'upperLineDashStyle', legacyS],
            ['lowerLineStyle', 'lowerLineDashStyle', legacyS]
        ]);
        indicator.overlay = true;
        indicator.separatePanel = false;
    }
    
    // Stochastic Oscillator
    function calculateStochastic(data, period, smoothK, smoothD) {
        const k = [];
        const d = [];
        
        for (let i = 0; i < data.length; i++) {
            if (i < period - 1) {
                k.push(null);
            } else {
                let highest = data[i].h;
                let lowest = data[i].l;
                
                for (let j = 1; j < period; j++) {
                    highest = Math.max(highest, data[i - j].h);
                    lowest = Math.min(lowest, data[i - j].l);
                }
                
                const range = highest - lowest;
                const kValue = range === 0 ? 50 : ((data[i].c - lowest) / range) * 100;
                k.push(kValue);
            }
        }

        const smoothedK = rollingSmaNullable(k, Math.max(1, smoothK));
        const smoothedD = rollingSmaNullable(smoothedK, Math.max(1, smoothD));

        return { k: smoothedK, d: smoothedD };
    }
    
    const ATR_DEFAULT_PERIOD = 14;

    function atrSmoothingTypeFromParams(params) {
        const t = String((params && params.smoothingType) || 'RMA').toUpperCase();
        if (t === 'SMMA') return 'RMA';
        if (t === 'SMA' || t === 'EMA' || t === 'WMA' || t === 'RMA') return t;
        return 'RMA';
    }

    function atrPeriodFromParams(params) {
        if (params && params.period != null) return Math.max(1, Number(params.period) | 0);
        return ATR_DEFAULT_PERIOD;
    }

    function calculateTrueRangeSeries(data) {
        const trs = [];
        for (let i = 0; i < data.length; i++) {
            let tr;
            if (i === 0) {
                tr = data[i].h - data[i].l;
            } else {
                const highLow = data[i].h - data[i].l;
                const highPrevClose = Math.abs(data[i].h - data[i - 1].c);
                const lowPrevClose = Math.abs(data[i].l - data[i - 1].c);
                tr = Math.max(highLow, highPrevClose, lowPrevClose);
            }
            trs.push(tr);
        }
        return trs;
    }

    // ATR (Average True Range) — smooth true range with RMA / SMA / EMA / WMA
    function calculateATR(data, period, smoothingType) {
        const p = Math.max(1, period | 0);
        const trs = calculateTrueRangeSeries(data);
        const st = atrSmoothingTypeFromParams({ smoothingType: smoothingType });
        if (st === 'SMA') return rollingSmaNullable(trs, p);
        if (st === 'EMA') return rollingEmaNullable(trs, p);
        if (st === 'WMA') return rollingWmaNullable(trs, p);
        return rollingRmaNullable(trs, p);
    }
    
    // ADX (Average Directional Index)
    function calculateADX(data, diLength, adxSmoothing) {
        if (adxSmoothing === undefined) {
            adxSmoothing = diLength;
        }
        diLength = Math.max(1, parseInt(diLength, 10) || 14);
        adxSmoothing = Math.max(1, parseInt(adxSmoothing, 10) || diLength);
        const trs = [];
        const plusDM = [];
        const minusDM = [];
        
        // Calculate True Range (TR), +DM, and -DM
        for (let i = 0; i < data.length; i++) {
            let tr;
            if (i === 0) {
                tr = data[i].h - data[i].l;
                plusDM.push(0);
                minusDM.push(0);
            } else {
                const highLow = data[i].h - data[i].l;
                const highPrevClose = Math.abs(data[i].h - data[i - 1].c);
                const lowPrevClose = Math.abs(data[i].l - data[i - 1].c);
                tr = Math.max(highLow, highPrevClose, lowPrevClose);
                
                const upMove = data[i].h - data[i - 1].h;
                const downMove = data[i - 1].l - data[i].l;
                
                let pDM = 0;
                let mDM = 0;
                
                if (upMove > downMove && upMove > 0) {
                    pDM = upMove;
                }
                if (downMove > upMove && downMove > 0) {
                    mDM = downMove;
                }
                
                plusDM.push(pDM);
                minusDM.push(mDM);
            }
            trs.push(tr);
        }
        
        // Calculate Smoothed TR, +DM, and -DM (using Wilders Smoothing)
        const wildersSmoothing = (arr, period) => {
            const smoothed = [];
            let currentAvg = 0;
            
            for (let i = 0; i < arr.length; i++) {
                if (i < period - 1) {
                    smoothed.push(null);
                } else if (i === period - 1) {
                    let sum = 0;
                    for (let j = 0; j < period; j++) {
                        sum += arr[j];
                    }
                    currentAvg = sum / period;
                    smoothed.push(currentAvg);
                } else {
                    currentAvg = (currentAvg * (period - 1) + arr[i]) / period;
                    smoothed.push(currentAvg);
                }
            }
            return smoothed;
        };
        
        const smoothedTR = wildersSmoothing(trs, diLength);
        const smoothedPlusDM = wildersSmoothing(plusDM, diLength);
        const smoothedMinusDM = wildersSmoothing(minusDM, diLength);
        
        const plusDI = [];
        const minusDI = [];
        const DX = [];
        const ADX = [];
        
        let currentADX = 0;
        const firstDxIdx = diLength - 1;
        const adxFirstIdx = firstDxIdx + adxSmoothing - 1;
        
        for (let i = 0; i < data.length; i++) {
            if (smoothedTR[i] === null || smoothedTR[i] === 0) {
                plusDI.push(null);
                minusDI.push(null);
                DX.push(null);
                ADX.push(null);
            } else {
                const pDI = (smoothedPlusDM[i] / smoothedTR[i]) * 100;
                const mDI = (smoothedMinusDM[i] / smoothedTR[i]) * 100;
                plusDI.push(pDI);
                minusDI.push(mDI);
                
                const sumDI = pDI + mDI;
                const DXValue = sumDI === 0 ? 0 : (Math.abs(pDI - mDI) / sumDI) * 100;
                DX.push(DXValue);
                
                if (i < adxFirstIdx) {
                    ADX.push(null);
                } else if (i === adxFirstIdx) {
                    let sumDX = 0;
                    for (let j = firstDxIdx; j <= adxFirstIdx; j++) {
                        sumDX += DX[j];
                    }
                    currentADX = sumDX / adxSmoothing;
                    ADX.push(currentADX);
                } else {
                    currentADX = (currentADX * (adxSmoothing - 1) + DX[i]) / adxSmoothing;
                    ADX.push(currentADX);
                }
            }
        }
        
        return { plusDI: plusDI, minusDI: minusDI, adx: ADX };
    }
    
    function adrCandleTimeMs(t) {
        const n = Number(t);
        if (!Number.isFinite(n)) return NaN;
        return Math.abs(n) < 1e11 ? n * 1000 : n;
    }

    function adrDayKey(t) {
        const ms = adrCandleTimeMs(t);
        if (!Number.isFinite(ms)) return '';
        return dayKeyInTimezone(ms, resolveChartWallTimezoneId());
    }

    // ADR (Average Daily Range) - average of daily high-low over N completed sessions
    function calculateADR(data, period) {
        const p = Math.max(1, parseInt(period, 10) || 14);
        if (!data || !data.length) return [];

        const tzId = resolveChartWallTimezoneId();
        const n = data.length;
        const result = new Array(n);
        const barDayIndex = new Array(n);
        const dailyRanges = [];

        let currentDay = null;
        let dayHigh = null;
        let dayLow = null;
        let currentDayIndex = -1;

        for (let i = 0; i < n; i++) {
            const ms = adrCandleTimeMs(data[i].t);
            const dayKey = Number.isFinite(ms) ? dayKeyInTimezone(ms, tzId) : '';
            if (!dayKey) {
                barDayIndex[i] = -1;
                continue;
            }

            if (currentDay !== dayKey) {
                if (currentDay !== null && dayHigh !== null && dayLow !== null) {
                    dailyRanges.push(dayHigh - dayLow);
                }
                currentDay = dayKey;
                currentDayIndex++;
                dayHigh = data[i].h;
                dayLow = data[i].l;
            } else {
                dayHigh = Math.max(dayHigh, data[i].h);
                dayLow = Math.min(dayLow, data[i].l);
            }
            barDayIndex[i] = currentDayIndex;
        }
        if (currentDay !== null && dayHigh !== null && dayLow !== null) {
            dailyRanges.push(dayHigh - dayLow);
        }

        const prefix = new Array(dailyRanges.length + 1);
        prefix[0] = 0;
        for (let d = 0; d < dailyRanges.length; d++) {
            prefix[d + 1] = prefix[d] + dailyRanges[d];
        }

        for (let i = 0; i < n; i++) {
            const di = barDayIndex[i];
            if (di < 0) {
                result[i] = null;
                continue;
            }
            const priorCount = di;
            if (priorCount < 1) {
                result[i] = null;
                continue;
            }
            const lookback = Math.min(p, priorCount);
            const sum = prefix[di] - prefix[di - lookback];
            result[i] = sum / lookback;
        }

        return result;
    }
    
    // ADR Bands - calculates upper/lower bands based on ADR from day's open
    function calculateADRBands(data, period) {
        const adrValues = calculateADR(data, period);
        const upper = [];
        const lower = [];
        
        let currentDay = null;
        let dayOpen = null;
        
        for (let i = 0; i < data.length; i++) {
            const dayKey = adrDayKey(data[i].t);
            
            // Track day open
            if (dayKey && currentDay !== dayKey) {
                currentDay = dayKey;
                dayOpen = data[i].o;
            }
            
            if (adrValues[i] === null || dayOpen === null) {
                upper.push(null);
                lower.push(null);
            } else {
                // ADR bands: day open +/- half of ADR
                const halfADR = adrValues[i] / 2;
                upper.push(dayOpen + halfADR);
                lower.push(dayOpen - halfADR);
            }
        }
        
        return { upper, lower, adr: adrValues };
    }
    
    // ATR Bands - calculates upper/lower bands based on ATR from close price
    function calculateATRBands(data, period, multiplier) {
        const atrValues = calculateATR(data, period);
        const upper = [];
        const lower = [];
        const middle = [];
        
        for (let i = 0; i < data.length; i++) {
            if (atrValues[i] === null) {
                upper.push(null);
                lower.push(null);
                middle.push(null);
            } else {
                const closePrice = data[i].c;
                const atrOffset = atrValues[i] * multiplier;
                middle.push(closePrice);
                upper.push(closePrice + atrOffset);
                lower.push(closePrice - atrOffset);
            }
        }
        
        return { upper, lower, middle, atr: atrValues };
    }
    
    function parseSessionTimeStr(timeStr) {
        if (!timeStr) return 0;
        const parts = String(timeStr).split(':');
        return parseInt(parts[0], 10) + (parseInt(parts[1] || 0, 10) / 60);
    }

    /** Reuse Intl formatters — creating one per bar freezes the UI on large datasets. */
    const _chartWallFmtCache = Object.create(null);
    const _chartWallDowFmtCache = Object.create(null);
    function chartCachedDateTimeFormat(locale, options) {
        const opts = options || {};
        const keys = Object.keys(opts).sort();
        let sig = String(locale) + '|';
        for (let ki = 0; ki < keys.length; ki++) {
            const k = keys[ki];
            sig += k + ':' + String(opts[k]) + ';';
        }
        if (!_chartWallFmtCache[sig]) {
            _chartWallFmtCache[sig] = new Intl.DateTimeFormat(locale, opts);
        }
        return _chartWallFmtCache[sig];
    }

    function chartWallClockDow(utcMs, tzId) {
        const key = tzId || 'UTC';
        if (!_chartWallDowFmtCache[key]) {
            _chartWallDowFmtCache[key] = chartCachedDateTimeFormat('en-US', { timeZone: key, weekday: 'short' });
        }
        try {
            const parts = _chartWallDowFmtCache[key].formatToParts(new Date(utcMs));
            const wd = parts.find(function (p) { return p.type === 'weekday'; });
            const map = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
            if (wd && map[wd.value] != null) return map[wd.value];
        } catch (e) { /* keep 0 */ }
        return 0;
    }

    function sessionWallDecimal(utcMs, tzId) {
        try {
            const parts = chartCachedDateTimeFormat('en-GB', {
                timeZone: tzId || 'Etc/UTC',
                hour: '2-digit',
                minute: '2-digit',
                hour12: false
            }).formatToParts(new Date(utcMs));
            const hPart = parts.find(function (p) { return p.type === 'hour'; });
            const mPart = parts.find(function (p) { return p.type === 'minute'; });
            const h = hPart ? parseInt(hPart.value, 10) : 0;
            const m = mPart ? parseInt(mPart.value, 10) : 0;
            return h + m / 60;
        } catch (e) {
            const d = new Date(utcMs);
            return d.getUTCHours() + d.getUTCMinutes() / 60;
        }
    }

    function isInSessionDecimal(timeDecimal, session) {
        if (session.start <= session.end) {
            return timeDecimal >= session.start && timeDecimal < session.end;
        }
        return timeDecimal >= session.start || timeDecimal < session.end;
    }

    function buildSessionBoxRuntimeDefs(params) {
        const defs = (typeof window !== 'undefined' && window.__v9SessionBoxSessionDefs) || [];
        const shownFn = (typeof window !== 'undefined' && window.__v9SessionBoxSessionShown) || null;
        const out = [];
        defs.forEach(function (sess) {
            const shown = shownFn ? shownFn(params, sess) : (params[sess.showId] !== false);
            if (!shown) return;
            out.push({
                key: sess.key,
                name: params[sess.nameId] != null ? String(params[sess.nameId]) : sess.defaultName,
                start: parseSessionTimeStr(params[sess.startId] != null ? params[sess.startId] : sess.defaultStart),
                end: parseSessionTimeStr(params[sess.endId] != null ? params[sess.endId] : sess.defaultEnd),
                color: params[sess.colorId] || sess.defaultColor
            });
        });
        if (!out.length) {
            defs.forEach(function (sess) {
                const shown = shownFn ? shownFn(params, sess) : (params[sess.showId] !== false);
                if (!shown) return;
                out.push({
                    key: sess.key,
                    name: params[sess.nameId] != null ? String(params[sess.nameId]) : sess.defaultName,
                    start: parseSessionTimeStr(params[sess.startId] != null ? params[sess.startId] : sess.defaultStart),
                    end: parseSessionTimeStr(params[sess.endId] != null ? params[sess.endId] : sess.defaultEnd),
                    color: params[sess.colorId] || sess.defaultColor
                });
            });
        }
        return out;
    }

    function sessionsCalcPayload(indicator) {
        const p = Object.assign({}, indicator.params || {}, indicator.style || {});
        const defs = (typeof window !== 'undefined' && window.__v9SessionBoxSessionDefs) || [];
        defs.forEach(function (sess) {
            if (indicator.style && indicator.style[sess.colorId] != null) {
                p[sess.colorId] = indicator.style[sess.colorId];
            }
        });
        return p;
    }

    function applySessionsFromParams(indicator, params) {
        const defs = (typeof window !== 'undefined' && window.__v9SessionBoxSessionDefs) || [];
        indicator.overlay = true;
        indicator.isSessions = true;
        indicator.name = 'Session Boxes';
        defs.forEach(function (sess) {
            if (params[sess.showId] !== undefined) {
                indicator.params[sess.showId] = params[sess.showId] !== false;
            } else if (indicator.params[sess.showId] === undefined) {
                indicator.params[sess.showId] = sess.defaultShow !== false;
            } else if (indicator.params[sess.showId] === false && sess.defaultShow !== false) {
                indicator.params[sess.showId] = true;
            }
            if (params[sess.nameId] != null) indicator.params[sess.nameId] = String(params[sess.nameId]);
            if (params[sess.startId] != null) indicator.params[sess.startId] = params[sess.startId];
            if (params[sess.endId] != null) indicator.params[sess.endId] = params[sess.endId];
            if (params[sess.colorId] != null) indicator.style[sess.colorId] = params[sess.colorId];
        });
        if (params.showAsian !== undefined) indicator.params.showAsian = params.showAsian !== false;
        if (params.showLondon !== undefined) indicator.params.showLondon = params.showLondon !== false;
        if (params.showNewYork !== undefined) indicator.params.showNewYork = params.showNewYork !== false;
        if (params.showFrankfurt !== undefined) indicator.params.showFrankfurt = params.showFrankfurt !== false;
        if (params.showSydney !== undefined) indicator.params.showSydney = params.showSydney !== false;
        if (params.asianStart != null) indicator.params.asianStart = params.asianStart;
        if (params.asianEnd != null) indicator.params.asianEnd = params.asianEnd;
        if (params.londonStart != null) indicator.params.londonStart = params.londonStart;
        if (params.londonEnd != null) indicator.params.londonEnd = params.londonEnd;
        if (params.newYorkStart != null) indicator.params.newYorkStart = params.newYorkStart;
        if (params.newYorkEnd != null) indicator.params.newYorkEnd = params.newYorkEnd;
        indicator.style.showSessionLabels = params.showSessionLabels !== false;
        indicator.params.maxTimeframeMinutes = params.maxTimeframeMinutes != null
            ? String(params.maxTimeframeMinutes) : (indicator.params.maxTimeframeMinutes || '240');
        indicator.params.sessionTimezone = params.sessionTimezone || indicator.params.sessionTimezone || 'Etc/UTC';
    }

    // Sessions indicator — session boxes with configurable TZ, names, and spans
    function calculateSessions(data, params) {
        const perCandle = [];
        const tz = params.sessionTimezone || 'Etc/UTC';
        const sessionDefs = buildSessionBoxRuntimeDefs(params);

        for (let i = 0; i < data.length; i++) {
            const dec = sessionWallDecimal(data[i].t, tz);
            const candleSessions = [];
            for (let d = 0; d < sessionDefs.length; d++) {
                const sd = sessionDefs[d];
                if (isInSessionDecimal(dec, sd)) {
                    candleSessions.push({
                        type: sd.key,
                        name: sd.name,
                        color: sd.color
                    });
                }
            }
            perCandle.push(candleSessions);
        }

        return { perCandle: perCandle, defs: sessionDefs, timezone: tz };
    }
    
    // ICT Kill Zones indicator - session boxes with high/low, NY midnight line, deviations
    function killzonesParseBoxTransparency(raw, fallback) {
        fallback = fallback != null ? fallback : 88;
        const fn = typeof window !== 'undefined' ? window.__v9NormalizeIndicatorNumericString : null;
        const s = fn ? fn(raw) : String(raw != null ? raw : '');
        const n = parseFloat(s);
        if (!Number.isFinite(n)) return fallback;
        return Math.min(100, Math.max(0, n));
    }

    function killzonesBoxFillAlpha(transparency) {
        const t = killzonesParseBoxTransparency(transparency, 88);
        return Math.min(0.92, Math.max(0.02, (100 - t) / 100));
    }

    const KILLZONES_TZ = 'America/New_York';

    function killzonesPad2(n) {
        return n < 10 ? '0' + n : String(n);
    }

    function killzonesNyDayKey(utcMs) {
        try {
            return chartCachedDateTimeFormat('en-CA', {
                timeZone: KILLZONES_TZ,
                year: 'numeric',
                month: '2-digit',
                day: '2-digit'
            }).format(new Date(utcMs));
        } catch (e) {
            return '0';
        }
    }

    function buildKillzonesWallClockSeries(data) {
        const n = data ? data.length : 0;
        const out = new Array(n);
        const tm = typeof window !== 'undefined' ? window.timezoneManager : null;
        const dayFmt = chartCachedDateTimeFormat('en-CA', {
            timeZone: KILLZONES_TZ,
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });
        for (let i = 0; i < n; i++) {
            const t = data[i].t;
            if (!Number.isFinite(t)) {
                out[i] = { hours: 0, minutes: 0, decimal: 0, dayKey: '0' };
                continue;
            }
            const dayKey = dayFmt.format(new Date(t));
            let hours = 0;
            let minutes = 0;
            if (tm && typeof tm._wallClockParts === 'function') {
                try {
                    const p = tm._wallClockParts(t, KILLZONES_TZ);
                    hours = Number.isFinite(p.hour) ? (p.hour % 24) : 0;
                    minutes = Number.isFinite(p.minute) ? p.minute : 0;
                } catch (e0) {
                    const dec = sessionWallDecimal(t, KILLZONES_TZ);
                    hours = Math.floor(dec);
                    minutes = Math.round((dec - hours) * 60) % 60;
                }
            } else {
                const dec = sessionWallDecimal(t, KILLZONES_TZ);
                hours = Math.floor(dec);
                minutes = Math.round((dec - hours) * 60) % 60;
            }
            out[i] = {
                hours: hours,
                minutes: minutes,
                decimal: hours + minutes / 60,
                dayKey: dayKey
            };
        }
        return out;
    }

    /** NY wall clock for a bar — matches chart axis when chart TZ is America/New_York (DST-aware). */
    function killzonesBarWallClock(utcMs) {
        if (!Number.isFinite(utcMs)) {
            return { hours: 0, minutes: 0, decimal: 0, dayKey: '0' };
        }
        const dayKey = killzonesNyDayKey(utcMs);
        const chart = typeof window !== 'undefined' ? window.chart : null;
        const tm = typeof window !== 'undefined' ? window.timezoneManager : null;
        const chartTzId = tm && tm.getTimezone ? (tm.getTimezone().id || 'UTC') : 'UTC';

        if (chartTzId === KILLZONES_TZ && chart && typeof chart.convertToTimezone === 'function') {
            try {
                const tzDate = chart.convertToTimezone(utcMs);
                const hours = tzDate.getUTCHours();
                const minutes = tzDate.getUTCMinutes();
                return {
                    hours: hours,
                    minutes: minutes,
                    decimal: hours + minutes / 60,
                    dayKey: dayKey
                };
            } catch (e0) { /* fall through */ }
        }

        if (tm && typeof tm._wallClockParts === 'function') {
            try {
                const p = tm._wallClockParts(utcMs, KILLZONES_TZ);
                if (Number.isFinite(p.hour) && Number.isFinite(p.minute)) {
                    const hours = p.hour % 24;
                    const minutes = p.minute;
                    return {
                        hours: hours,
                        minutes: minutes,
                        decimal: hours + minutes / 60,
                        dayKey: dayKey
                    };
                }
            } catch (e1) { /* fall through */ }
        }

        try {
            const dec = sessionWallDecimal(utcMs, KILLZONES_TZ);
            const hours = Math.floor(dec);
            const minutes = Math.round((dec - hours) * 60) % 60;
            return {
                hours: hours,
                minutes: minutes,
                decimal: hours + minutes / 60,
                dayKey: dayKey
            };
        } catch (e2) {
            return { hours: 0, minutes: 0, decimal: 0, dayKey: '0' };
        }
    }

    function killzonesFindMidnightBarIndex(data, dayKey) {
        const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(dayKey || ''));
        if (!m || !data || !data.length) return -1;
        const y = parseInt(m[1], 10);
        const mo = parseInt(m[2], 10);
        const d = parseInt(m[3], 10);
        const tm = typeof window !== 'undefined' ? window.timezoneManager : null;
        let targetMs = NaN;
        if (tm && typeof tm.wallClockToUtcMillis === 'function') {
            targetMs = tm.wallClockToUtcMillis(y, mo, d, 0, 0, 0, KILLZONES_TZ);
        }
        if (!Number.isFinite(targetMs)) return -1;
        let idx = -1;
        for (let i = 0; i < data.length; i++) {
            if (!Number.isFinite(data[i].t)) continue;
            if (data[i].t >= targetMs) {
                idx = i;
                break;
            }
        }
        if (idx < 0) return -1;
        let best = idx;
        let bestDist = Infinity;
        for (let j = Math.max(0, idx - 3); j <= Math.min(data.length - 1, idx + 3); j++) {
            const w = killzonesBarWallClock(data[j].t);
            if (w.dayKey !== dayKey) continue;
            const dist = w.hours * 60 + w.minutes;
            if (dist < bestDist) {
                bestDist = dist;
                best = j;
            }
        }
        return best;
    }

    function killzonesParseSessionTime(timeStr) {
        if (!timeStr) return 0;
        const fn = typeof window !== 'undefined' ? window.__v9NormalizeIndicatorNumericString : null;
        const s = fn ? fn(String(timeStr)) : String(timeStr);
        const parts = s.split(':');
        const h = parseInt(parts[0], 10);
        const m = parseInt(parts[1] || '0', 10);
        if (!Number.isFinite(h)) return 0;
        return h + (Number.isFinite(m) ? m : 0) / 60;
    }

    function calculateKillzones(data, params) {
        const result = {
            sessions: [],
            nyMidnight: [],
            boxes: []
        };
        
        // Session definitions (wall-clock times in America/New_York, DST-aware below)
        const sessionDefs = {
            cbdr: {
                name: 'CBDR',
                start: killzonesParseSessionTime(params.cbdrStart || '14:00'),
                end: killzonesParseSessionTime(params.cbdrEnd || '20:00'),
                color: params.cbdrColor || '#0064ff',
                enabled: params.showCBDR !== false
            },
            asia: {
                name: 'Asia',
                start: killzonesParseSessionTime(params.asiaStart || '20:00'),
                end: killzonesParseSessionTime(params.asiaEnd || '00:00'),
                color: params.asiaColor || '#7622ff',
                enabled: params.showAsia !== false
            },
            london: {
                name: 'London',
                start: killzonesParseSessionTime(params.londonStart || '02:00'),
                end: killzonesParseSessionTime(params.londonEnd || '05:00'),
                color: params.londonColor || '#e90000',
                enabled: params.showLondon !== false
            },
            nyam: {
                name: 'NY AM',
                start: killzonesParseSessionTime(params.nyamStart || '07:00'),
                end: killzonesParseSessionTime(params.nyamEnd || '10:00'),
                color: params.nyamColor || '#00acb8',
                enabled: params.showNYAM !== false
            },
            londonClose: {
                name: 'LC',
                start: killzonesParseSessionTime(params.lcStart || '10:00'),
                end: killzonesParseSessionTime(params.lcEnd || '12:00'),
                color: params.lcColor || '#434651',
                enabled: params.showLC !== false
            }
        };
        
        // Inclusive end on same-day windows so adjacent/overlapping sessions share the handoff candle.
        const isInSession = (decimal, session) => {
            if (session.start <= session.end) {
                return decimal >= session.start && decimal <= session.end;
            }
            // Overnight window: inclusive start, exclusive end at the wrap (e.g. 00:00).
            return decimal >= session.start || decimal < session.end;
        };
        
        const sessionOrder = ['cbdr', 'asia', 'london', 'nyam', 'londonClose'];
        const activeBoxes = {};
        const walls = buildKillzonesWallClockSeries(data);
        const midnightByDay = Object.create(null);

        for (let i = 0; i < data.length; i++) {
            const nyWall = walls[i];
            const nyTime = { hours: nyWall.hours, minutes: nyWall.minutes, decimal: nyWall.decimal };
            if (params.showNYMidnight !== false && nyWall.dayKey && nyWall.dayKey !== '0') {
                const dist = nyWall.hours * 60 + nyWall.minutes;
                const prevMid = midnightByDay[nyWall.dayKey];
                if (!prevMid || dist < prevMid.dist) {
                    midnightByDay[nyWall.dayKey] = {
                        index: i,
                        price: data[i].o,
                        time: data[i].t,
                        dist: dist
                    };
                }
            }
            
            sessionOrder.forEach(function(key) {
                const session = sessionDefs[key];
                if (!session.enabled) return;
                if (isInSession(nyTime.decimal, session)) {
                    if (!activeBoxes[key]) {
                        activeBoxes[key] = {
                            type: key,
                            name: session.name,
                            color: session.color,
                            startIndex: i,
                            startTime: data[i].t,
                            high: data[i].h,
                            low: data[i].l,
                            endIndex: i
                        };
                    } else {
                        activeBoxes[key].high = Math.max(activeBoxes[key].high, data[i].h);
                        activeBoxes[key].low = Math.min(activeBoxes[key].low, data[i].l);
                        activeBoxes[key].endIndex = i;
                    }
                } else if (activeBoxes[key]) {
                    const box = activeBoxes[key];
                    box.endTime = data[i - 1] ? data[i - 1].t : data[i].t;
                    box.range = box.high - box.low;
                    result.boxes.push({...box});
                    delete activeBoxes[key];
                }
            });
        }
        
        if (params.showNYMidnight !== false) {
            result.nyMidnight = Object.keys(midnightByDay).sort().map(function (dk) {
                const row = midnightByDay[dk];
                return { index: row.index, price: row.price, time: row.time };
            });
            const deduped = [];
            for (let mi = 0; mi < result.nyMidnight.length; mi++) {
                const cur = result.nyMidnight[mi];
                const prev = deduped[deduped.length - 1];
                if (prev && cur.index - prev.index < 4) continue;
                deduped.push(cur);
            }
            result.nyMidnight = deduped;
        }
        
        // Close any remaining active boxes
        Object.keys(activeBoxes).forEach(key => {
            const box = activeBoxes[key];
            box.endTime = data[data.length - 1].t;
            box.range = box.high - box.low;
            result.boxes.push({...box});
        });
        
        // Midnight open horizontal line spans until the bar before the next NY day (not only to chart edge)
        for (let j = 0; j < result.nyMidnight.length; j++) {
            const next = result.nyMidnight[j + 1];
            result.nyMidnight[j].endIndex = next ? next.index - 1 : data.length - 1;
        }
        
        // Store params for deviations
        result.showDeviations = params.showDeviations || false;
        result.deviationCount = params.deviationCount || 2;
        result.showMidline = params.showMidline !== false;
        result.showBoxInfo = params.showBoxInfo !== false;
        result.boxTransparency = killzonesParseBoxTransparency(params.boxTransparency, 88);
        result.showNYMidnight = params.showNYMidnight !== false;
        result.nyMidnightColor = params.nyMidnightColor || '#2d62b6';
        
        return result;
    }

    /** Local timezone offset in hours at instant `utcMs` (use per bar for DST correctness). */
    function _ictLocalOffsetHoursAt(utcMs) {
        return -new Date(utcMs).getTimezoneOffset() / 60;
    }

    function _ictParseTimeToDec(timeStr) {
        if (!timeStr) return 0;
        const p = String(timeStr).split(':');
        const h = parseInt(p[0], 10) || 0;
        const m = parseInt(p[1], 10) || 0;
        return h + m / 60;
    }

    function _ictPxWidthFromSelect(s) {
        const n = parseInt(String(s || '1').replace(/\D/g, ''), 10);
        return Math.min(5, Math.max(1, n || 1));
    }

    function _ictDashFromStyle(name) {
        if (name === 'Dotted') return [2, 4];
        if (name === 'Dashed') return [7, 5];
        return [];
    }

    function _ictMedianBarMinutes(data) {
        if (!data || data.length < 2) return 60;
        const n = Math.min(data.length - 1, 200);
        let acc = 0;
        let c = 0;
        for (let i = data.length - n; i < data.length; i++) {
            if (i <= 0) continue;
            const d = data[i].t - data[i - 1].t;
            if (d > 0 && d < 86400000) {
                acc += d;
                c++;
            }
        }
        if (!c) return 60;
        return (acc / c) / 60000;
    }

    function _ictWallFromUtc(utcMs, offsetHours) {
        const adj = utcMs + offsetHours * 3600000;
        const d = new Date(adj);
        const y = d.getUTCFullYear();
        const M = d.getUTCMonth() + 1;
        const D = d.getUTCDate();
        const h = d.getUTCHours();
        const m = d.getUTCMinutes();
        const dec = h + m / 60;
        const dayKey = y + '-' + (M < 10 ? '0' : '') + M + '-' + (D < 10 ? '0' : '') + D;
        return { y: y, M: M, D: D, hour: h, minute: m, dec: dec, dayKey: dayKey, dow: d.getUTCDay() };
    }

    /** Chart wall clock for ICT Everything — uses chart timezone (not browser local). */
    function _ictBarWallClock(utcMs) {
        return _ictBarWallClockInTz(utcMs, resolveChartWallTimezoneId());
    }

    function _ictBarWallClockInTz(utcMs, tzId) {
        if (!Number.isFinite(utcMs)) {
            return { y: 0, M: 0, D: 0, hour: 0, minute: 0, dec: 0, dayKey: '0', dow: 0, weekKey: '0-W00' };
        }
        const dayKey = dayKeyInTimezone(utcMs, tzId);
        const dm = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dayKey);
        const y = dm ? parseInt(dm[1], 10) : 0;
        const M = dm ? parseInt(dm[2], 10) : 0;
        const D = dm ? parseInt(dm[3], 10) : 0;
        const dec = sessionWallDecimal(utcMs, tzId);
        const hour = Math.floor(dec);
        const minute = Math.round((dec - hour) * 60) % 60;
        const dow = chartWallClockDow(utcMs, tzId);
        return {
            y: y, M: M, D: D, hour: hour, minute: minute, dec: dec,
            dayKey: dayKey, dow: dow, weekKey: _ictIsoWeekKey(y, M, D)
        };
    }

    function buildIctBarWallClockSeries(data, tzId) {
        const n = data ? data.length : 0;
        const id = tzId || resolveChartWallTimezoneId();
        const out = new Array(n);
        const tm = typeof window !== 'undefined' ? window.timezoneManager : null;
        const dayFmt = chartCachedDateTimeFormat('en-CA', {
            timeZone: id,
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });
        for (let i = 0; i < n; i++) {
            const t = data[i].t;
            if (!Number.isFinite(t)) {
                out[i] = { y: 0, M: 0, D: 0, hour: 0, minute: 0, dec: 0, dayKey: '0', dow: 0, weekKey: '0-W00' };
                continue;
            }
            const dayKey = dayFmt.format(new Date(t));
            const dm = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dayKey);
            const y = dm ? parseInt(dm[1], 10) : 0;
            const M = dm ? parseInt(dm[2], 10) : 0;
            const D = dm ? parseInt(dm[3], 10) : 0;
            let hour = 0;
            let minute = 0;
            if (tm && typeof tm._wallClockParts === 'function') {
                try {
                    const p = tm._wallClockParts(t, id);
                    hour = Number.isFinite(p.hour) ? (p.hour % 24) : 0;
                    minute = Number.isFinite(p.minute) ? p.minute : 0;
                } catch (e0) {
                    const dec = sessionWallDecimal(t, id);
                    hour = Math.floor(dec);
                    minute = Math.round((dec - hour) * 60) % 60;
                }
            } else {
                const dec = sessionWallDecimal(t, id);
                hour = Math.floor(dec);
                minute = Math.round((dec - hour) * 60) % 60;
            }
            const dec = hour + minute / 60;
            const dow = chartWallClockDow(t, id);
            out[i] = {
                y: y, M: M, D: D, hour: hour, minute: minute, dec: dec,
                dayKey: dayKey, dow: dow, weekKey: _ictIsoWeekKey(y, M, D)
            };
        }
        return out;
    }

    function _ictIsoWeekKey(y, M, D) {
        const t = Date.UTC(y, M - 1, D);
        const wd = new Date(t).getUTCDay() || 7;
        const t2 = t + (4 - wd) * 86400000;
        const y2 = new Date(t2).getUTCFullYear();
        const d0 = Date.UTC(y2, 0, 1);
        const wk = Math.ceil(((t2 - d0) / 86400000 + 1) / 7);
        return y2 + '-W' + (wk < 10 ? '0' : '') + wk;
    }

    function _ictInDecSession(dec, startDec, endDec) {
        if (startDec <= endDec) {
            return dec >= startDec && dec < endDec;
        }
        return dec >= startDec || dec < endDec;
    }

    function _ictDevCountFromInput(s) {
        if (s === '1 SD') return 1;
        if (s === '3 SD') return 3;
        if (s === '4 SD') return 4;
        return 2;
    }

    /**
     * ICT Everything — session strips, CBDR/Asia/FLOUT range boxes, verticals, opening lines (Pine-aligned inputs).
     * Range stats table (Auto_Select) is not drawn on canvas yet.
     */
    function calculateIctEverything(data, indicator) {
        const empty = {
            dom: false,
            sessionStrips: [],
            boxes: [],
            boxDeviations: [],
            verticals: [],
            horizontals: [],
            dowMarks: [],
            showMidline: false,
            showBoxInfo: true,
            boxTransparency: 88,
            showDeviations: false,
            deviationCount: 2,
            showNYMidnight: false,
            _ictMeta: {}
        };
        if (!data || data.length === 0) return empty;

        const P = Object.assign({}, indicator.params || {}, indicator.style || {});
        const barMin = _ictMedianBarMinutes(data);
        const maxIv = P.inputMaxInterval != null ? +P.inputMaxInterval : 31;
        const dom = barMin <= maxIv && barMin < 18 * 60;
        if (!dom) {
            return Object.assign(empty, { dom: false });
        }

        const n = data.length;
        const walls = buildIctBarWallClockSeries(data);
        const lastWall = walls[n - 1];
        const lastDayKey = lastWall.dayKey;
        const lastWeekKey = lastWall.weekKey;

        function passesTimeFilter(dayKey, weekKey, barT) {
            if (P.ShowTSO) {
                return dayKey === lastDayKey;
            }
            if (P.ShowTWO) {
                return weekKey === lastWeekKey;
            }
            if (P.SL4W) {
                if (!barT) return true;
                return barT >= data[n - 1].t - 35 * 86400000;
            }
            return true;
        }

        function allowMidnightVline(dayKey) {
            if (P.ShowMOP === false) return false;
            if (dayKey === lastDayKey) return true;
            return !!P.MOLHist;
        }

        function allowMidnightHline(dayKey) {
            if (dayKey === lastDayKey) return P.ShowMOPP !== false;
            return !!P.ShowMOPL;
        }

        function allowMiscHline(dayKey) {
            if (dayKey === lastDayKey) return true;
            return !!P.ShowPrev;
        }

        const sessionStrips = new Array(n);
        for (let i = 0; i < n; i++) sessionStrips[i] = [];

        const sessionDefs = [
            { key: 'london', show: P.ShowLondon !== false, start: _ictParseTimeToDec(P.LDNseshStart || '02:00'), end: _ictParseTimeToDec(P.LDNseshEnd || '05:00'), color: P.LSFC || 'rgba(120,123,134,0.12)' },
            { key: 'ny', show: P.ShowNY !== false, start: _ictParseTimeToDec(P.NYseshStart || '07:00'), end: _ictParseTimeToDec(P.NYseshEnd || '10:00'), color: P.NYSFC || 'rgba(120,123,134,0.12)' },
            { key: 'lc', show: P.ShowLC !== false, start: _ictParseTimeToDec(P.LCseshStart || '10:00'), end: _ictParseTimeToDec(P.LCseshEnd || '12:00'), color: P.LCSFC || 'rgba(120,123,134,0.12)' },
            { key: 'pm', show: P.ShowPM !== false, start: _ictParseTimeToDec(P.PMseshStart || '13:00'), end: _ictParseTimeToDec(P.PMseshEnd || '16:00'), color: P.PMSFC || 'rgba(120,123,134,0.12)' },
            { key: 'asia2', show: !!P.ShowAsian, start: _ictParseTimeToDec(P.ASIA2seshStart || '20:00'), end: _ictParseTimeToDec(P.ASIA2seshEnd || '23:59'), color: P.ASFC || 'rgba(120,123,134,0.12)' },
            { key: 'free', show: !!P.ShowFreeSesh && (Math.abs(_ictParseTimeToDec(P.FreeSeshEnd || '00:00') - _ictParseTimeToDec(P.FreeSeshStart || '00:00')) > 1e-3),
                start: _ictParseTimeToDec(P.FreeSeshStart || '00:00'), end: _ictParseTimeToDec(P.FreeSeshEnd || '00:00'), color: P.FSFC || 'rgba(120,123,134,0.12)' }
        ];

        const order = ['london', 'ny', 'lc', 'pm', 'asia2', 'free'];
        const sessionDefByKey = Object.create(null);
        sessionDefs.forEach(function (sd) { sessionDefByKey[sd.key] = sd; });
        const activeRun = {};
        order.forEach(function (k) { activeRun[k] = null; });

        for (let i = 0; i < n; i++) {
            const w = walls[i];
            if (!passesTimeFilter(w.dayKey, w.weekKey, data[i].t)) {
                order.forEach(function (key) {
                    if (activeRun[key]) {
                        activeRun[key] = null;
                    }
                });
                continue;
            }
            order.forEach(function (key) {
                const sd = sessionDefByKey[key];
                if (!sd || !sd.show) return;
                const inside = _ictInDecSession(w.dec, sd.start, sd.end);
                if (inside) {
                    if (!activeRun[key]) {
                        activeRun[key] = { start: i, color: sd.color };
                    }
                    if (P.ShowSFill) {
                        sessionStrips[i].push({ color: sd.color });
                    }
                } else if (activeRun[key]) {
                    activeRun[key] = null;
                }
            });
        }
        order.forEach(function (key) {
            if (activeRun[key]) {
                activeRun[key] = null;
            }
        });

        const boxes = [];
        const boxDeviations = [];

        function pushRangeBox(kind, startDec, endDec, color, name, useFloutStep) {
            let active = null;
            for (let i = 0; i < n; i++) {
                const w = walls[i];
                if (!passesTimeFilter(w.dayKey, w.weekKey, data[i].t)) {
                    if (active) {
                        boxes.push(active);
                        active = null;
                    }
                    continue;
                }
                const inside = _ictInDecSession(w.dec, startDec, endDec);
                if (inside) {
                    if (!active) {
                        active = {
                            type: kind,
                            name: name || kind,
                            color: color || '#787b86',
                            startIndex: i,
                            endIndex: i,
                            high: data[i].h,
                            low: data[i].l,
                            useFloutStep: !!useFloutStep
                        };
                    } else {
                        active.high = Math.max(active.high, data[i].h);
                        active.low = Math.min(active.low, data[i].l);
                        active.endIndex = i;
                    }
                } else if (active) {
                    active.range = active.high - active.low;
                    boxes.push(active);
                    active = null;
                }
            }
            if (active) {
                active.range = active.high - active.low;
                boxes.push(active);
            }
        }

        if (P.ShowCBDR !== false) {
            pushRangeBox('cbdr', _ictParseTimeToDec('16:00'), _ictParseTimeToDec('20:00'), P.CBDRBoxCol, P.txt0 || 'CBDR', false);
        }
        if (P.ShowASIA !== false) {
            pushRangeBox('asiaR', 20, 24, P.ASIABoxCol, P.txt1 || 'ASIA', false);
        }
        if (P.ShowFLOUT) {
            pushRangeBox('flout', 16, 24, P.FLOUTBoxCol, P.txt7 || 'FLOUT', true);
        }

        const verticals = [];
        const pushVline = function (idx, color, dashName, lwName) {
            if (idx < 0 || idx >= n) return;
            verticals.push({
                index: idx,
                color: color || '#787b86',
                dash: _ictDashFromStyle(dashName),
                lw: _ictPxWidthFromSelect(lwName)
            });
        };

        /** Vertical line at session start time (same wall clock as session shading). */
        const vlineSessionDefs = [
            {
                show: !!P.ShowLOP,
                start: _ictParseTimeToDec(P.LDNseshStart || '02:00'),
                color: P.LOPColor,
                dash: P.london_Open_LS,
                lw: P.London_Open_LW
            },
            {
                show: P.ShowNYOP !== false,
                start: _ictParseTimeToDec(P.NYseshStart || '07:00'),
                color: P.NYOPColor,
                dash: P.NY_Open_LS,
                lw: P.NY_Open_LW
            },
            {
                show: !!P.ShowEOP,
                start: _ictParseTimeToDec(P.EquitiesOpen || '09:30'),
                color: P.EOPColor,
                dash: P.Equities_Open_LS,
                lw: P.Equities_Open_LW
            }
        ];

        let prevWall = null;
        for (let i = 0; i < n; i++) {
            const w = walls[i];
            if (!passesTimeFilter(w.dayKey, w.weekKey, data[i].t)) {
                prevWall = w;
                continue;
            }
            if (prevWall) {
                if (w.dayKey !== prevWall.dayKey
                    && allowMidnightVline(w.dayKey)
                    && passesTimeFilter(w.dayKey, w.weekKey, data[i].t)) {
                    pushVline(i, P.MOPColor, P.Midnight_Open_LS, P.Midnight_Open_LW);
                }
                if (w.dayKey === prevWall.dayKey) {
                    vlineSessionDefs.forEach(function (def) {
                        if (!def.show) return;
                        if (prevWall.dec < def.start && w.dec >= def.start) {
                            pushVline(i, def.color, def.dash, def.lw);
                        }
                    });
                }
            }
            prevWall = w;
        }

        const horizontals = [];
        const devCount = _ictDevCountFromInput(P.DevInput);
        const devDir = P.DevDirection || 'Both';
        const showDev = !!P.ShowDev;

        boxes.forEach(function (box) {
            box.range = box.high - box.low;
            if (!box.range || box.range <= 0) return;
            const useFlout = box.useFloutStep;
            const allowPos = devDir !== 'Downside Only';
            const allowNeg = devDir !== 'Upside Only';
            const mults = [];
            if (useFlout) {
                for (let x = 0.5; x <= devCount; x += 0.5) mults.push(x);
            } else {
                for (let x = 1; x <= devCount; x++) mults.push(x);
            }
            if (showDev) {
                mults.forEach(function (mult) {
                    if (allowPos) {
                        const hi = box.high + box.range * mult;
                        boxDeviations.push({ startIndex: box.startIndex, endIndex: box.endIndex, price: hi, color: P.DevLNCol, dash: _ictDashFromStyle(P.DEVLS), lw: _ictPxWidthFromSelect(P.i_DEVLW) });
                    }
                    if (allowNeg) {
                        const lo = box.low - box.range * mult;
                        boxDeviations.push({ startIndex: box.startIndex, endIndex: box.endIndex, price: lo, color: P.DevLNCol, dash: _ictDashFromStyle(P.DEVLS), lw: _ictPxWidthFromSelect(P.i_DEVLW) });
                    }
                });
            }
        });

        let openMidnight = null;
        let midStart = null;
        let midDayKey = null;
        function pushMidnightHline(startIdx, endIdx, dayKey, price) {
            if (startIdx == null || endIdx == null || startIdx > endIdx || !Number.isFinite(price)) return;
            if (!allowMidnightHline(dayKey)) return;
            const w0 = walls[startIdx];
            if (!passesTimeFilter(dayKey, w0.weekKey, data[startIdx].t)) return;
            horizontals.push({
                startIndex: startIdx,
                endIndex: endIdx,
                price: price,
                color: P.MOPColP,
                dash: _ictDashFromStyle(P.MOPLS),
                lw: _ictPxWidthFromSelect(P.i_MOPLW),
                label: P.txt13 || 'MIDNIGHT',
                showLabel: P.ShowLabel !== false
            });
        }
        for (let i = 0; i < n; i++) {
            const w = walls[i];
            const newDay = midDayKey == null || w.dayKey !== midDayKey;
            if (newDay) {
                if (openMidnight != null && midStart != null && midDayKey != null) {
                    pushMidnightHline(midStart, i - 1, midDayKey, openMidnight);
                }
                openMidnight = data[i].o;
                midStart = i;
                midDayKey = w.dayKey;
            }
        }
        if (openMidnight != null && midStart != null && midDayKey != null) {
            pushMidnightHline(midStart, n - 1, midDayKey, openMidnight);
        }

        function pushOpenAtDec(targetDec, enabled, color, dashS, lwS, label) {
            if (!enabled) return;
            let prevW = walls[0];
            const seenDay = {};
            for (let i = 1; i < n; i++) {
                const w = walls[i];
                if (!passesTimeFilter(w.dayKey, w.weekKey, data[i].t)) {
                    prevW = w;
                    continue;
                }
                if (w.dayKey === prevW.dayKey && prevW.dec < targetDec && w.dec >= targetDec) {
                    if (!allowMiscHline(w.dayKey)) {
                        prevW = w;
                        continue;
                    }
                    const ukey = String(label) + '|' + w.dayKey + '|' + String(targetDec);
                    if (seenDay[ukey]) {
                        prevW = w;
                        continue;
                    }
                    seenDay[ukey] = true;
                    horizontals.push({
                        startIndex: i,
                        endIndex: Math.min(n - 1, i + Math.floor(240 / Math.max(barMin, 1))),
                        price: data[i].o,
                        color: color,
                        dash: _ictDashFromStyle(dashS),
                        lw: _ictPxWidthFromSelect(lwS),
                        label: label,
                        showLabel: P.ShowLabel !== false
                    });
                }
                prevW = w;
            }
        }
        pushOpenAtDec(_ictParseTimeToDec(P.NYseshStart || '07:00'), !!P.ShowNYOPP, P.NYOPColP, P.NYOPLS, P.i_NYOPLW, P.txt17);
        pushOpenAtDec(_ictParseTimeToDec(P.EquitiesOpen || '09:30'), !!P.ShowEOPP, P.EOPColP, P.EOPLS, P.i_EOPLW, P.txt18);
        pushOpenAtDec(_ictParseTimeToDec(P.PMseshStart || '13:00'), !!P.ShowAFTPP, P.AFTOPColP, P.AFTOPLS, P.i_AFTOPLW, P.txt1330);

        const dowMarks = [];
        if (P.showDOW) {
            const ht = P.DOWTime != null ? +P.DOWTime : 12;
            const names = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
            const seen = {};
            for (let i = 0; i < n; i++) {
                const w = walls[i];
                if (!passesTimeFilter(w.dayKey, w.weekKey, data[i].t)) continue;
                if (w.dow < 1 || w.dow > 5) continue;
                if (w.hour !== ht || w.minute !== 0) continue;
                const key = w.dayKey + '-' + w.dow;
                if (seen[key]) continue;
                seen[key] = true;
                dowMarks.push({ index: i, text: names[w.dow] || '', color: P.i_DOWCol || '#787b86', bottom: (P.DOWLoc_inpt || 'Bottom') === 'Bottom' });
            }
        }

        return {
            dom: true,
            sessionStrips: sessionStrips,
            boxes: boxes,
            boxDeviations: boxDeviations,
            verticals: verticals,
            horizontals: horizontals,
            dowMarks: dowMarks,
            showMidline: false,
            showBoxInfo: true,
            boxTransparency: 88,
            showDeviations: showDev,
            deviationCount: devCount,
            showNYMidnight: false,
            _params: P,
            _barMin: barMin,
            _chartTz: resolveChartWallTimezoneId()
        };
    }

    /** Previous UTC calendar day high / low / midpoint (PD reference for premium vs discount). */
    function calculateIctPrevDayPD(data) {
        const n = data.length;
        const upper = new Array(n).fill(null);
        const lower = new Array(n).fill(null);
        const middle = new Array(n).fill(null);
        let curDay = null;
        let dayH = -Infinity;
        let dayL = Infinity;
        let prevH = null;
        let prevL = null;
        for (let i = 0; i < n; i++) {
            const dk = new Date(data[i].t).toISOString().slice(0, 10);
            if (curDay !== dk) {
                if (curDay !== null) {
                    prevH = dayH;
                    prevL = dayL;
                }
                curDay = dk;
                dayH = data[i].h;
                dayL = data[i].l;
            } else {
                dayH = Math.max(dayH, data[i].h);
                dayL = Math.min(dayL, data[i].l);
            }
            if (prevH != null && prevL != null) {
                upper[i] = prevH;
                lower[i] = prevL;
                middle[i] = (prevH + prevL) / 2;
            }
        }
        return { upper: upper, lower: lower, middle: middle };
    }

    function _ictUtcDayMinute(t) {
        const d = new Date(t);
        return d.getUTCHours() * 60 + d.getUTCMinutes();
    }

    function _ictParseHmToMinutes(str) {
        const p = String(str != null ? str : '00:00').split(':');
        return parseInt(p[0], 10) * 60 + parseInt(p[1] || 0, 10);
    }

    function _ictMinuteInSession(m, sm, em) {
        if (sm <= em) {
            return m >= sm && m < em;
        }
        return m >= sm || m < em;
    }

    /**
     * Developing then fixed Asian range per UTC day (default 00:00–09:00 UTC).
     * Before the session: null; during: expanding H/L; after: fixed until midnight.
     */
    function calculateIctAsianRange(data, params) {
        const sm = _ictParseHmToMinutes(params.rangeStart != null ? params.rangeStart : '00:00');
        const em = _ictParseHmToMinutes(params.rangeEnd != null ? params.rangeEnd : '09:00');
        const n = data.length;
        const upper = new Array(n).fill(null);
        const lower = new Array(n).fill(null);
        const middle = new Array(n).fill(null);
        let dayKey = null;
        let accH = -Infinity;
        let accL = Infinity;
        let lockedU = null;
        let lockedL = null;
        let seenAsian = false;
        for (let i = 0; i < n; i++) {
            const dk = new Date(data[i].t).toISOString().slice(0, 10);
            const minute = _ictUtcDayMinute(data[i].t);
            if (dk !== dayKey) {
                dayKey = dk;
                accH = -Infinity;
                accL = Infinity;
                lockedU = null;
                lockedL = null;
                seenAsian = false;
            }
            const inA = _ictMinuteInSession(minute, sm, em);
            if (inA) {
                seenAsian = true;
                accH = accH === -Infinity ? data[i].h : Math.max(accH, data[i].h);
                accL = accL === Infinity ? data[i].l : Math.min(accL, data[i].l);
                upper[i] = accH;
                lower[i] = accL;
            } else if (seenAsian && lockedU === null) {
                lockedU = accH === -Infinity ? data[i].h : accH;
                lockedL = accL === Infinity ? data[i].l : accL;
                upper[i] = lockedU;
                lower[i] = lockedL;
            } else if (lockedU !== null) {
                upper[i] = lockedU;
                lower[i] = lockedL;
            }
            if (upper[i] != null && lower[i] != null) {
                middle[i] = (upper[i] + lower[i]) / 2;
            }
        }
        return { upper: upper, lower: lower, middle: middle };
    }

    /**
     * OTE-style zone: fibLow–fibHigh of the rolling range (lowest low → highest high in lookback).
     * Common defaults 0.62 / 0.79 (context tool, not a trade signal by itself).
     */
    function calculateIctOTE(data, lookback, fibLo, fibHi) {
        const lb = lookback != null && !isNaN(lookback) ? lookback : 24;
        const L = Math.max(5, Math.floor(lb));
        const lo = fibLo != null && !isNaN(fibLo) ? fibLo : 0.62;
        const hi = fibHi != null && !isNaN(fibHi) ? fibHi : 0.79;
        const n = data.length;
        const upper = new Array(n).fill(null);
        const lower = new Array(n).fill(null);
        const middle = new Array(n).fill(null);
        for (let i = 0; i < n; i++) {
            if (i < L - 1) {
                continue;
            }
            let sl = Infinity;
            let sh = -Infinity;
            for (let j = 0; j < L; j++) {
                const k = i - j;
                sl = Math.min(sl, data[k].l);
                sh = Math.max(sh, data[k].h);
            }
            const r = sh - sl;
            if (r <= 0) {
                continue;
            }
            lower[i] = sl + lo * r;
            upper[i] = sl + hi * r;
            middle[i] = (lower[i] + upper[i]) / 2;
        }
        return { upper: upper, lower: lower, middle: middle };
    }

    /** 3-candle fair value gaps; extends each box by extendBars for visibility. */
    function calculateFairValueGaps(data, params) {
        const extendBars = params.extendBars != null ? params.extendBars : 80;
        const maxBoxes = Math.min(400, Math.max(8, params.maxBoxes != null ? params.maxBoxes : 120));
        const minGapPct = params.minGapPct != null ? params.minGapPct : 0;
        const boxes = [];
        const n = data.length;
        for (let i = 2; i < n; i++) {
            if (data[i].l > data[i - 2].h) {
                const gap = data[i].l - data[i - 2].h;
                const ref = Math.abs(data[i].c) || 1;
                if (minGapPct > 0 && gap < ref * minGapPct) {
                    continue;
                }
                boxes.push({
                    startIndex: i - 2,
                    endIndex: Math.min(n - 1, i + extendBars),
                    top: data[i].l,
                    bottom: data[i - 2].h,
                    bullish: true
                });
            }
            if (data[i].h < data[i - 2].l) {
                const gap = data[i - 2].l - data[i].h;
                const ref = Math.abs(data[i].c) || 1;
                if (minGapPct > 0 && gap < ref * minGapPct) {
                    continue;
                }
                boxes.push({
                    startIndex: i - 2,
                    endIndex: Math.min(n - 1, i + extendBars),
                    top: data[i - 2].l,
                    bottom: data[i].h,
                    bullish: false
                });
            }
        }
        return { boxes: boxes.length > maxBoxes ? boxes.slice(-maxBoxes) : boxes };
    }

    function _applyIndicatorDefParams(indicator, typeKey, params) {
        var def = (typeof window !== 'undefined' && window.INDICATOR_DEFINITIONS)
            ? window.INDICATOR_DEFINITIONS[typeKey] : null;
        if (!def || !def.params) return;
        params = params || {};
        if (!indicator.params) indicator.params = {};
        def.params.forEach(function (p) {
            if (p.type === 'heading' || p.type === 'divider') return;
            // Prefer incoming payload → keep existing → fall back to def default.
            // (Partial updates must not wipe sibling keys back to defaults.)
            var raw = params[p.id] !== undefined ? params[p.id]
                : (indicator.params[p.id] !== undefined ? indicator.params[p.id] : p.default);
            if (p.type === 'checkbox') raw = !!raw;
            else if (p.type === 'number') {
                raw = parseFloat(raw);
                if (isNaN(raw)) {
                    raw = indicator.params[p.id] !== undefined ? indicator.params[p.id] : p.default;
                }
            }
            indicator.params[p.id] = raw;
        });
    }

    function calculateTalariaFvgIndicator(data, indicator, chartRef) {
        var mod = global.TalariaFvgIndicator;
        if (!mod || typeof mod.calculate !== 'function') return { boxes: [], dayLines: [], midLines: [] };
        return mod.calculate(data, indicator.params, {
            resample: chartRef && typeof chartRef.resampleData === 'function' ? chartRef.resampleData.bind(chartRef) : null,
            rawData: chartRef && Array.isArray(chartRef.rawData) ? chartRef.rawData : data,
            currentTimeframe: chartRef && chartRef.currentTimeframe
        });
    }

    function calculateTalariaRatioGapIndicator(data, indicator) {
        var mod = global.TalariaRatioGapIndicator;
        if (!mod || typeof mod.calculate !== 'function') return { lines: [], boxes: [], labels: [], infoCells: [] };
        return mod.calculate(data, indicator.params);
    }

    function calculateTalariaWeeklyMapIndicator(data, indicator, chartRef) {
        var mod = global.TalariaWeeklyMapIndicator;
        if (!mod || typeof mod.calculate !== 'function') return { lines: [], boxes: [], labels: [], infoCells: [] };
        return mod.calculate(data, indicator.params, {
            resample: chartRef && typeof chartRef.resampleData === 'function' ? chartRef.resampleData.bind(chartRef) : null,
            rawData: chartRef && Array.isArray(chartRef.rawData) ? chartRef.rawData : data,
            currentTimeframe: chartRef && chartRef.currentTimeframe
        });
    }

    function calculateTalariaSimpleSmcIndicator(data, indicator, chartRef) {
        var mod = global.TalariaSimpleSmcIndicator;
        if (!mod || typeof mod.calculate !== 'function') {
            return { bands: [], lines: [], boxes: [], markers: [], labels: [], lite: false };
        }
        var replay = chartRef && chartRef.replaySystem;
        var replayPlaying = !!(replay && replay.isActive
            && (replay.isPlaying || (chartRef && chartRef._multichartPassivePlayActive)));
        return mod.calculate(data, indicator.params, { replayPlaying: replayPlaying });
    }

    /**
     * Premium/discount vs previous completed session window (UTC), e.g. NY 13:00–21:00.
     * Looks back up to maxLookbackDays for the last day that had bars in that session (weekends).
     */
    function calculateIctSessionPrevDayPD(data, params) {
        const sm = _ictParseHmToMinutes(params.rangeStart != null ? params.rangeStart : '13:00');
        const em = _ictParseHmToMinutes(params.rangeEnd != null ? params.rangeEnd : '21:00');
        const maxLookback = Math.min(14, Math.max(1, Math.floor(params.maxLookbackDays != null ? params.maxLookbackDays : 6)));
        const n = data.length;
        const dayStats = {};
        for (let i = 0; i < n; i++) {
            const dk = new Date(data[i].t).toISOString().slice(0, 10);
            const minute = _ictUtcDayMinute(data[i].t);
            if (!_ictMinuteInSession(minute, sm, em)) {
                continue;
            }
            if (!dayStats[dk]) {
                dayStats[dk] = { sh: -Infinity, sl: Infinity, has: false };
            }
            const s = dayStats[dk];
            s.sh = Math.max(s.sh, data[i].h);
            s.sl = Math.min(s.sl, data[i].l);
            s.has = true;
        }
        function findPrevSessionStats(dk) {
            let d = new Date(dk + 'T12:00:00.000Z');
            for (let b = 0; b < maxLookback; b++) {
                d.setUTCDate(d.getUTCDate() - 1);
                const key = d.toISOString().slice(0, 10);
                const st = dayStats[key];
                if (st && st.has && st.sh > -Infinity && st.sl < Infinity) {
                    return st;
                }
            }
            return null;
        }
        const upper = new Array(n).fill(null);
        const lower = new Array(n).fill(null);
        const middle = new Array(n).fill(null);
        for (let i = 0; i < n; i++) {
            const dk = new Date(data[i].t).toISOString().slice(0, 10);
            const st = findPrevSessionStats(dk);
            if (st) {
                upper[i] = st.sh;
                lower[i] = st.sl;
                middle[i] = (st.sh + st.sl) / 2;
            }
        }
        return { upper: upper, lower: lower, middle: middle };
    }

    function _ictSwingHigh(data, i, w) {
        const h = data[i].h;
        for (let k = 1; k <= w; k++) {
            if (data[i - k].h >= h || data[i + k].h >= h) {
                return false;
            }
        }
        return true;
    }

    function _ictSwingLow(data, i, w) {
        const low = data[i].l;
        for (let k = 1; k <= w; k++) {
            if (data[i - k].l <= low || data[i + k].l <= low) {
                return false;
            }
        }
        return true;
    }

    function _ictClusterPrices1D(points, tolPct, minTouches) {
        if (points.length < minTouches) {
            return [];
        }
        const sorted = points.slice().sort(function(a, b) {
            return a.price - b.price;
        });
        const clusters = [];
        let cur = [sorted[0]];
        for (let i = 1; i < sorted.length; i++) {
            const mean = cur.reduce(function(s, p) {
                return s + p.price;
            }, 0) / cur.length;
            const tol = Math.max(mean * (tolPct / 100), mean * 1e-10);
            if (Math.abs(sorted[i].price - mean) <= tol) {
                cur.push(sorted[i]);
            } else {
                if (cur.length >= minTouches) {
                    clusters.push(cur);
                }
                cur = [sorted[i]];
            }
        }
        if (cur.length >= minTouches) {
            clusters.push(cur);
        }
        return clusters;
    }

    /**
     * Equal highs / equal lows from clustered swing points (fractal width w each side).
     */
    function calculateLiquidityEqualLevels(data, params) {
        const w = Math.max(1, Math.floor(params.fractalWidth != null ? params.fractalWidth : 2));
        const tolPct = params.tolerancePct != null ? params.tolerancePct : 0.03;
        const minTouches = Math.max(2, Math.floor(params.minTouches != null ? params.minTouches : 2));
        const maxSeg = Math.min(200, Math.max(8, params.maxSegments != null ? params.maxSegments : 80));
        const extendBars = Math.max(0, Math.floor(params.extendBars != null ? params.extendBars : 12));
        const n = data.length;
        const highs = [];
        const lows = [];
        let i = w;
        for (; i < n - w; i++) {
            if (_ictSwingHigh(data, i, w)) {
                highs.push({ idx: i, price: data[i].h });
            }
            if (_ictSwingLow(data, i, w)) {
                lows.push({ idx: i, price: data[i].l });
            }
        }
        const ch = _ictClusterPrices1D(highs, tolPct, minTouches);
        const cl = _ictClusterPrices1D(lows, tolPct, minTouches);
        const segments = [];
        ch.forEach(function(cluster) {
            const idxs = cluster.map(function(p) {
                return p.idx;
            });
            const i0 = Math.min.apply(null, idxs);
            const i1 = Math.min(n - 1, Math.max.apply(null, idxs) + extendBars);
            const price = cluster.reduce(function(s, p) {
                return s + p.price;
            }, 0) / cluster.length;
            segments.push({ kind: 'high', price: price, startIndex: i0, endIndex: i1 });
        });
        cl.forEach(function(cluster) {
            const idxs = cluster.map(function(p) {
                return p.idx;
            });
            const i0 = Math.min.apply(null, idxs);
            const i1 = Math.min(n - 1, Math.max.apply(null, idxs) + extendBars);
            const price = cluster.reduce(function(s, p) {
                return s + p.price;
            }, 0) / cluster.length;
            segments.push({ kind: 'low', price: price, startIndex: i0, endIndex: i1 });
        });
        segments.sort(function(a, b) {
            return a.startIndex - b.startIndex;
        });
        return { segments: segments.length > maxSeg ? segments.slice(0, maxSeg) : segments };
    }
    
    // CCI (Commodity Channel Index)
    function calculateCCI(data, period, source) {
        const p = Math.max(1, period | 0);
        source = source || 'hlc3';
        const result = [];
        const constant = 0.015;

        for (let i = 0; i < data.length; i++) {
            if (i < p - 1) {
                result.push(null);
            } else {
                const price = resolveOhlcSourceValue(data[i], source);
                if (!Number.isFinite(price)) {
                    result.push(null);
                    continue;
                }
                let sumP = 0;
                let ok = true;
                for (let j = 0; j < p; j++) {
                    const pv = resolveOhlcSourceValue(data[i - j], source);
                    if (!Number.isFinite(pv)) { ok = false; break; }
                    sumP += pv;
                }
                if (!ok) {
                    result.push(null);
                    continue;
                }
                const smaP = sumP / p;
                let sumMD = 0;
                for (let j = 0; j < p; j++) {
                    const prevP = resolveOhlcSourceValue(data[i - j], source);
                    if (!Number.isFinite(prevP)) { ok = false; break; }
                    sumMD += Math.abs(prevP - smaP);
                }
                if (!ok) {
                    result.push(null);
                    continue;
                }
                const meanDeviation = sumMD / p;
                if (meanDeviation === 0) {
                    result.push(0);
                } else {
                    result.push((price - smaP) / (constant * meanDeviation));
                }
            }
        }
        return result;
    }

    function calculateCCIIndicatorData(data, params) {
        params = params || {};
        const period = params.period != null ? params.period : 20;
        const source = params.source || 'hlc3';
        const cci = calculateCCI(data, period, source);
        const type = String(params.smoothingType || 'None');
        const len = Math.max(1, params.smoothingLength != null ? Number(params.smoothingLength) : 14);
        const bbStd = params.bbStdDev != null ? Number(params.bbStdDev) : 2;
        let ma = null;
        let bbUpper = null;
        let bbLower = null;
        if (type === 'SMA') {
            ma = rollingSmaNullable(cci, len);
        } else if (type === 'SMA+BB') {
            const bb = rollingBbOnSeries(cci, len, bbStd);
            ma = bb.middle;
            bbUpper = bb.upper;
            bbLower = bb.lower;
        } else if (type === 'EMA') {
            ma = rollingEmaNullable(cci, len);
        } else if (type === 'RMA') {
            ma = rollingRmaNullable(cci, len);
        } else if (type === 'WMA') {
            ma = rollingWmaNullable(cci, len);
        } else if (type === 'VWMA') {
            ma = rollingVwmaOnSeries(data, cci, len);
        }
        return { cci: cci, ma: ma, bbUpper: bbUpper, bbLower: bbLower };
    }

    function calculateDEMA(data, period, source) {
        source = source || 'close';
        const ema1 = calculateEMA(data, period, source);
        const pseudo = data.map(function(d, i) {
            const v = ema1[i];
            const fallback = resolveOhlcSourceValue(d, source);
            const val = v != null ? v : fallback;
            return {
                h: val,
                l: val,
                c: val,
                o: val,
                v: d.v,
                t: d.t
            };
        });
        const ema2 = calculateEMA(pseudo, period, 'close');
        return ema1.map(function(e1, i) {
            const e2 = ema2[i];
            if (e1 == null || e2 == null) return null;
            return 2 * e1 - e2;
        });
    }

    function calculateDEMAOverlayData(data, params) {
        params = params || {};
        const period = params.period != null ? params.period : 20;
        const source = params.source || 'close';
        const offsetRaw = params.offset != null ? Number(params.offset) : 0;
        const offset = Number.isFinite(offsetRaw) ? (offsetRaw | 0) : 0;
        let line = calculateDEMA(data, period, source);
        if (offset) line = shiftLineSeries(line, offset);
        return line;
    }

    function calculateTEMA(data, period, source) {
        source = source || 'close';
        const e1 = calculateEMA(data, period, source);
        const p2 = data.map(function(d, i) {
            const v = e1[i];
            const fb = resolveOhlcSourceValue(d, source);
            const val = v != null ? v : fb;
            return { h: val, l: val, c: val, o: val, v: d.v, t: d.t };
        });
        const e2 = calculateEMA(p2, period, 'close');
        const p3 = data.map(function(d, i) {
            const v = e2[i];
            const fb = resolveOhlcSourceValue(d, source);
            const val = v != null ? v : fb;
            return { h: val, l: val, c: val, o: val, v: d.v, t: d.t };
        });
        const e3 = calculateEMA(p3, period, 'close');
        return e1.map(function(a, i) {
            const b = e2[i], c = e3[i];
            if (a == null || b == null || c == null) return null;
            return 3 * a - 3 * b + c;
        });
    }

    function calculateTEMAOverlayData(data, params) {
        params = params || {};
        const period = params.period != null ? params.period : 20;
        const source = params.source || 'close';
        const offsetRaw = params.offset != null ? Number(params.offset) : 0;
        const offset = Number.isFinite(offsetRaw) ? (offsetRaw | 0) : 0;
        let line = calculateTEMA(data, period, source);
        if (offset) line = shiftLineSeries(line, offset);
        return line;
    }

    function calculateHMA(data, period, source) {
        source = source || 'close';
        const n = Math.max(2, Math.floor(period));
        const half = Math.max(1, Math.floor(n / 2));
        const sqrtN = Math.max(1, Math.round(Math.sqrt(n)));
        const w1 = calculateWMA(data, half, source);
        const w2 = calculateWMA(data, n, source);
        const pseudo = data.map(function(d, i) {
            const v = (w1[i] == null || w2[i] == null) ? null : (2 * w1[i] - w2[i]);
            return { h: v, l: v, c: v, o: v, v: d.v, t: d.t };
        });
        return calculateWMA(pseudo, sqrtN, 'c');
    }

    function calculateHMAOverlayData(data, params) {
        params = params || {};
        const period = params.period != null ? params.period : 20;
        const source = params.source || 'close';
        const offsetRaw = params.offset != null ? Number(params.offset) : 0;
        const offset = Number.isFinite(offsetRaw) ? (offsetRaw | 0) : 0;
        let line = calculateHMA(data, period, source);
        if (offset) line = shiftLineSeries(line, offset);
        return line;
    }

    function calculateROC(data, period, source) {
        source = source || 'close';
        const out = [];
        const p = Math.max(2, period);
        for (let i = 0; i < data.length; i++) {
            if (i < p) {
                out.push(null);
                continue;
            }
            const prev = resolveOhlcSourceValue(data[i - p], source);
            const cur = resolveOhlcSourceValue(data[i], source);
            if (!Number.isFinite(prev) || !Number.isFinite(cur) || prev === 0) { out.push(null); continue; }
            out.push((cur / prev - 1) * 100);
        }
        return out;
    }

    function calculateMomentum(data, period, source) {
        source = source || 'close';
        const out = [];
        const p = Math.max(1, period);
        for (let i = 0; i < data.length; i++) {
            if (i < p) out.push(null);
            else {
                const cur = resolveOhlcSourceValue(data[i], source);
                const prev = resolveOhlcSourceValue(data[i - p], source);
                out.push(Number.isFinite(cur) && Number.isFinite(prev) ? cur - prev : null);
            }
        }
        return out;
    }

    function calculateOBV(data) {
        const out = [];
        let obv = 0;
        for (let i = 0; i < data.length; i++) {
            if (i === 0) {
                out.push(0);
                continue;
            }
            const c0 = data[i].c, c1 = data[i - 1].c;
            const v = data[i].v || 0;
            if (c0 > c1) obv += v;
            else if (c0 < c1) obv -= v;
            out.push(obv);
        }
        return out;
    }

    function calculateOBVIndicatorData(data, params) {
        params = params || {};
        const obv = calculateOBV(data);
        const sm = applySmoothedOverlayMaSmoothing(obv, data, params);
        return { obv: sm.line, ma: sm.ma, bbUpper: sm.bbUpper, bbLower: sm.bbLower };
    }

    function applyObvStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.params.smoothingType = params.smoothingType || 'None';
        indicator.params.smoothingLength = params.smoothingLength != null
            ? safeIndicatorNumber(params.smoothingLength, 14)
            : 14;
        indicator.params.bbStdDev = params.bbStdDev != null
            ? safeIndicatorNumber(params.bbStdDev, 2)
            : 2;
        indicator.style.showObv = params.showObv !== false;
        indicator.style.showLine = indicator.style.showObv;
        indicator.params.showObv = indicator.style.showObv;
        indicator.params.showLine = indicator.style.showLine;
        indicator.style.color = params.color || '#78909c';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = legacyW;
        applyPlotDashFieldsFromParams(indicator.style, params, [['lineStyle', 'lineDashStyle', legacyS]]);
        const hasSmoothing = String(indicator.params.smoothingType || 'None') !== 'None';
        indicator.style.showMa = hasSmoothing;
        indicator.style.maColor = '#ff9800';
        indicator.style.maOpacity = 100;
        indicator.style.maLineWidth = 1;
        indicator.style.maLineStyle = 'Line';
        indicator.style.maLineDashStyle = 'Solid';
        indicator.hidePlot = params.hideFromContainer === true;
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    function applyCotNetStyleFromParams(indicator, params) {
        indicator.params.cftcCode = params.cftcCode != null ? String(params.cftcCode).trim() : 'auto';
        indicator.params.dataUrl = params.dataUrl != null ? String(params.dataUrl) : '';
        indicator.params.showCommercial = params.showCommercial !== false;
        indicator.params.showLarge = params.showLarge !== false;
        indicator.style.bullColor = '#26a69a';
        indicator.style.bullOpacity = 100;
        indicator.style.bearColor = '#ef5350';
        indicator.style.bearOpacity = 100;
        indicator.style.lineWidth = 2;
        indicator.style.lineStyle = 'Line';
        indicator.style.lineDashStyle = 'Solid';
        indicator.overlay = false;
        indicator.separatePanel = true;
        indicator.isCotNet = true;
        indicator.hideValues = true;
    }

    function calculateWilliamsR(data, period, source) {
        const p = Math.max(1, period);
        source = source || 'close';
        const out = [];
        for (let i = 0; i < data.length; i++) {
            if (i < p - 1) {
                out.push(null);
                continue;
            }
            let hh = -Infinity, ll = Infinity;
            for (let j = 0; j < p; j++) {
                const bar = data[i - j];
                hh = Math.max(hh, bar.h);
                ll = Math.min(ll, bar.l);
            }
            const range = hh - ll;
            const src = resolveOhlcSourceValue(data[i], source);
            if (!range || !Number.isFinite(src)) out.push(null);
            else out.push(-100 * (hh - src) / range);
        }
        return out;
    }

    function calculateMFI(data, period) {
        const p = Math.max(2, period);
        const out = [];
        const tp = data.map(function(d) { return (d.h + d.l + d.c) / 3; });
        for (let i = 0; i < data.length; i++) {
            if (i < p) {
                out.push(null);
                continue;
            }
            let pos = 0, neg = 0;
            for (let j = 0; j < p; j++) {
                const idx = i - j;
                if (idx <= 0) continue;
                const rawMF = tp[idx] * (data[idx].v || 0);
                const dir = tp[idx] - tp[idx - 1];
                if (dir > 0) pos += rawMF;
                else if (dir < 0) neg += rawMF;
            }
            if (neg === 0) out.push(pos === 0 ? 50 : 100);
            else {
                const ratio = pos / neg;
                out.push(100 - 100 / (1 + ratio));
            }
        }
        return out;
    }

  /** Offset is applied at draw time — band arrays stay aligned to bar indices. */
    function shiftBandSeries(bands, offset) {
        return bands;
    }

    function calculateDonchian(data, period, offset) {
        const p = Math.max(1, period | 0);
        const upper = [], lower = [], middle = [];
        for (let i = 0; i < data.length; i++) {
            if (i < p - 1) {
                upper.push(null); lower.push(null); middle.push(null);
                continue;
            }
            let hh = -Infinity, ll = Infinity;
            for (let j = 0; j < p; j++) {
                hh = Math.max(hh, data[i - j].h);
                ll = Math.min(ll, data[i - j].l);
            }
            upper.push(hh);
            lower.push(ll);
            middle.push((hh + ll) / 2);
        }
        return shiftBandSeries({ upper: upper, lower: lower, middle: middle }, offset);
    }

    function calculateTrueRangeSeries(data) {
        const trs = [];
        for (let i = 0; i < data.length; i++) {
            let tr;
            if (i === 0) {
                tr = data[i].h - data[i].l;
            } else {
                const highLow = data[i].h - data[i].l;
                const highPrevClose = Math.abs(data[i].h - data[i - 1].c);
                const lowPrevClose = Math.abs(data[i].l - data[i - 1].c);
                tr = Math.max(highLow, highPrevClose, lowPrevClose);
            }
            trs.push(tr);
        }
        return trs;
    }

    /** TradingView Keltner "Range": SMA(high - low, length) — not Donchian channel width. */
    function calculateBarRangeSMA(data, period) {
        period = Math.max(1, period);
        const out = [];
        for (let i = 0; i < data.length; i++) {
            if (i < period - 1) {
                out.push(null);
                continue;
            }
            let sum = 0;
            for (let j = 0; j < period; j++) {
                sum += data[i - j].h - data[i - j].l;
            }
            out.push(sum / period);
        }
        return out;
    }

    function resolveKeltnerCalcParams(params) {
        params = params || {};
        const lengthRaw = params.length != null ? Number(params.length) : (params.emaPeriod != null ? Number(params.emaPeriod) : 20);
        const atrLengthRaw = params.atrLength != null ? Number(params.atrLength) : (params.atrPeriod != null ? Number(params.atrPeriod) : 10);
        const multiplierRaw = params.multiplier != null ? Number(params.multiplier) : 2;
        let bandsStyle = params.bandsStyle || 'Average True Range';
        if (bandsStyle === 'ATR' || bandsStyle === 'atr') bandsStyle = 'Average True Range';
        return {
            length: Number.isFinite(lengthRaw) ? lengthRaw : 20,
            atrLength: Number.isFinite(atrLengthRaw) ? atrLengthRaw : 10,
            multiplier: Number.isFinite(multiplierRaw) ? multiplierRaw : 2,
            source: params.source || 'close',
            useExponentialMa: params.useExponentialMa !== false,
            bandsStyle: bandsStyle
        };
    }

    function applyKeltnerCalcParams(indicator, params) {
        const calc = resolveKeltnerCalcParams(params);
        indicator.params.length = calc.length;
        indicator.params.atrLength = calc.atrLength;
        indicator.params.multiplier = calc.multiplier;
        indicator.params.source = calc.source;
        indicator.params.useExponentialMa = calc.useExponentialMa;
        indicator.params.bandsStyle = calc.bandsStyle;
        indicator.params.emaPeriod = calc.length;
        indicator.params.atrPeriod = calc.atrLength;
        return calc;
    }

    function calculateKeltner(data, calcOrEmaPeriod, atrPeriod, mult, source) {
        let calc;
        if (typeof calcOrEmaPeriod === 'object' && calcOrEmaPeriod !== null && !Array.isArray(calcOrEmaPeriod)) {
            calc = resolveKeltnerCalcParams(calcOrEmaPeriod);
        } else {
            calc = resolveKeltnerCalcParams({
                emaPeriod: calcOrEmaPeriod,
                atrPeriod: atrPeriod,
                multiplier: mult,
                source: source
            });
        }
        const mid = calc.useExponentialMa
            ? calculateEMA(data, calc.length, calc.source)
            : calculateSMA(data, calc.length, calc.source);
        let bandWidth;
        if (calc.bandsStyle === 'True Range') {
            bandWidth = calculateTrueRangeSeries(data);
        } else if (calc.bandsStyle === 'Range') {
            bandWidth = calculateBarRangeSMA(data, calc.length);
        } else {
            bandWidth = calculateATR(data, calc.atrLength);
        }
        const upper = [];
        const lower = [];
        for (let i = 0; i < data.length; i++) {
            if (mid[i] == null || bandWidth[i] == null) {
                upper.push(null);
                lower.push(null);
            } else {
                upper.push(mid[i] + calc.multiplier * bandWidth[i]);
                lower.push(mid[i] - calc.multiplier * bandWidth[i]);
            }
        }
        return { upper: upper, middle: mid, lower: lower };
    }

    function calculateAroon(data, period) {
        const p = Math.max(1, period);
        const up = [], down = [];
        for (let i = 0; i < data.length; i++) {
            if (i < p - 1) {
                up.push(null); down.push(null);
                continue;
            }
            let highIdx = 0, lowIdx = 0, hh = -Infinity, ll = Infinity;
            for (let j = 0; j < p; j++) {
                const bar = data[i - j];
                if (bar.h >= hh) { hh = bar.h; highIdx = j; }
                if (bar.l <= ll) { ll = bar.l; lowIdx = j; }
            }
            up.push(100 * (p - 1 - highIdx) / (p - 1));
            down.push(100 * (p - 1 - lowIdx) / (p - 1));
        }
        return { up: up, down: down };
    }

    function calculateCMF(data, period) {
        const p = Math.max(1, period);
        const out = [];
        for (let i = 0; i < data.length; i++) {
            if (i < p - 1) {
                out.push(null);
                continue;
            }
            let adSum = 0, volSum = 0;
            for (let j = 0; j < p; j++) {
                const d = data[i - j];
                const range = d.h - d.l;
                const mfm = range ? ((d.c - d.l) - (d.h - d.c)) / range : 0;
                const v = d.v || 0;
                adSum += mfm * v;
                volSum += v;
            }
            out.push(volSum ? adSum / volSum : 0);
        }
        return out;
    }

    function calculateTRIX(data, period) {
        const p = Math.max(1, period | 0);
        const close = data.map(function(d) {
            return resolveOhlcSourceValue(d, 'close');
        });
        const e1 = rollingEmaNullable(close, p);
        const e2 = rollingEmaNullable(e1, p);
        const e3 = rollingEmaNullable(e2, p);
        const out = [];
        for (let i = 0; i < e3.length; i++) {
            if (i === 0 || e3[i] == null || e3[i - 1] == null) {
                out.push(null);
                continue;
            }
            const prev = e3[i - 1];
            if (!Number.isFinite(prev) || Math.abs(prev) < 1e-12) {
                out.push(null);
                continue;
            }
            out.push(100 * (e3[i] - prev) / prev);
        }
        return out;
    }

    function calculatePSAR(data, params) {
        const resolved = resolvePsarCalcParams(params);
        const start = resolved.start;
        const increment = resolved.increment;
        const maxStep = resolved.maxStep;
        const n = data.length;
        const sar = new Array(n).fill(null);
        if (n < 2) return sar;

        let isLong = data[1].c >= data[0].c;
        let af = start;
        let ep = isLong ? data[0].h : data[0].l;
        let sarVal = isLong ? data[0].l : data[0].h;
        sar[0] = sarVal;

        for (let i = 1; i < n; i++) {
            const prevSar = sarVal;
            sarVal = prevSar + af * (ep - prevSar);
            const h = data[i].h, l = data[i].l;

            if (isLong) {
                sarVal = Math.min(sarVal, data[i - 1].l, i > 1 ? data[i - 2].l : data[i - 1].l);
                if (l < sarVal) {
                    isLong = false;
                    sarVal = ep;
                    ep = l;
                    af = start;
                } else {
                    if (h > ep) {
                        ep = h;
                        af = Math.min(af + increment, maxStep);
                    }
                }
            } else {
                sarVal = Math.max(sarVal, data[i - 1].h, i > 1 ? data[i - 2].h : data[i - 1].h);
                if (h > sarVal) {
                    isLong = true;
                    sarVal = ep;
                    ep = h;
                    af = start;
                } else {
                    if (l < ep) {
                        ep = l;
                        af = Math.min(af + increment, maxStep);
                    }
                }
            }
            sar[i] = sarVal;
        }
        return sar;
    }

    /** Extended forex session backgrounds (UTC). Reuses drawSessions. */
    function calculateSessionsPlus(data, params) {
        const parseTime = function(timeStr) {
            if (!timeStr) return 0;
            const parts = String(timeStr).split(':');
            return parseInt(parts[0], 10) + (parseInt(parts[1] || 0, 10) / 60);
        };
        const isInSession = function(hour, minute, session) {
            const timeDecimal = hour + (minute / 60);
            if (session.start <= session.end) {
                return timeDecimal >= session.start && timeDecimal < session.end;
            }
            return timeDecimal >= session.start || timeDecimal < session.end;
        };
        const defs = [];
        if (params.showSydney !== false) {
            defs.push({
                key: 'sydney',
                start: parseTime(params.sydneyStart != null ? params.sydneyStart : '21:00'),
                end: parseTime(params.sydneyEnd != null ? params.sydneyEnd : '06:00'),
                color: params.sydneyColor || 'rgba(156, 39, 176, 0.14)'
            });
        }
        if (params.showTokyo !== false) {
            defs.push({
                key: 'tokyo',
                start: parseTime(params.tokyoStart != null ? params.tokyoStart : '00:00'),
                end: parseTime(params.tokyoEnd != null ? params.tokyoEnd : '09:00'),
                color: params.tokyoColor || 'rgba(255, 152, 0, 0.14)'
            });
        }
        if (params.showAsian !== false) {
            defs.push({
                key: 'asian',
                start: parseTime(params.asianStart != null ? params.asianStart : '00:00'),
                end: parseTime(params.asianEnd != null ? params.asianEnd : '09:00'),
                color: params.asianColor || 'rgba(255, 193, 7, 0.12)'
            });
        }
        if (params.showFrankfurt !== false) {
            defs.push({
                key: 'frankfurt',
                start: parseTime(params.frankfurtStart != null ? params.frankfurtStart : '07:00'),
                end: parseTime(params.frankfurtEnd != null ? params.frankfurtEnd : '10:00'),
                color: params.frankfurtColor || 'rgba(3, 169, 244, 0.14)'
            });
        }
        if (params.showLondon !== false) {
            defs.push({
                key: 'london',
                start: parseTime(params.londonStart != null ? params.londonStart : '08:00'),
                end: parseTime(params.londonEnd != null ? params.londonEnd : '16:00'),
                color: params.londonColor || 'rgba(33, 150, 243, 0.14)'
            });
        }
        if (params.showNewYork !== false) {
            defs.push({
                key: 'newyork',
                start: parseTime(params.newYorkStart != null ? params.newYorkStart : '13:00'),
                end: parseTime(params.newYorkEnd != null ? params.newYorkEnd : '21:00'),
                color: params.newYorkColor || 'rgba(76, 175, 80, 0.14)'
            });
        }
        const sessions = [];
        for (let i = 0; i < data.length; i++) {
            const date = new Date(data[i].t);
            const hour = date.getUTCHours();
            const minute = date.getUTCMinutes();
            const candleSessions = [];
            for (let d = 0; d < defs.length; d++) {
                const s = defs[d];
                if (isInSession(hour, minute, s)) {
                    candleSessions.push({ type: s.key, color: s.color });
                }
            }
            sessions.push(candleSessions);
        }
        return sessions;
    }

    function resolveChartWallTimezoneId() {
        if (typeof window !== 'undefined' && window.timezoneManager) {
            const tz = window.timezoneManager.getTimezone && window.timezoneManager.getTimezone();
            if (tz && tz.id) return tz.id;
        }
        let label = null;
        if (typeof window !== 'undefined' && window.chart && window.chart.chartSettings) {
            label = window.chart.chartSettings.timezone;
        }
        if (label != null && label !== '' && typeof window !== 'undefined' && window.chart
            && typeof window.chart.mapV9TimezoneLabelToId === 'function') {
            const mapped = window.chart.mapV9TimezoneLabelToId(String(label).trim());
            if (mapped) return mapped;
        }
        const legacy = {
            'UTC': 'UTC',
            'UTC+3 (Riyadh)': 'Europe/Moscow',
            'UTC+4 (Dubai)': 'Asia/Dubai',
            'UTC+5:30 (IST)': 'Asia/Kolkata',
            'UTC+8 (Asia)': 'Asia/Singapore',
            'UTC-5 (EST)': 'America/New_York',
            'UTC-8 (PST)': 'America/Los_Angeles',
            '(UTC-5) Toronto': 'America/Toronto',
            '(UTC-8) Los Angeles': 'America/Los_Angeles',
            '(UTC) London': 'Europe/London',
            '(UTC+1) Paris': 'Europe/Paris'
        };
        if (label == null || label === '') return 'UTC';
        const v = String(label).trim();
        if (Object.prototype.hasOwnProperty.call(legacy, v)) return legacy[v];
        if (v === 'UTC') return 'UTC';
        if (/^[A-Za-z_]+\/.+$/.test(v)) {
            try {
                new Intl.DateTimeFormat('en-US', { timeZone: v });
                return v;
            } catch (e0) { /* invalid */ }
        }
        const ianaTail = v.match(/\)\s*([A-Za-z][A-Za-z0-9_]*(?:\/[A-Za-z0-9_]+)+)\s*$/);
        if (ianaTail && ianaTail[1]) {
            try {
                new Intl.DateTimeFormat('en-US', { timeZone: ianaTail[1] });
                return ianaTail[1];
            } catch (e1) { /* invalid */ }
        }
        return 'UTC';
    }

    function dayKeyInTimezone(utcMs, tzId) {
        try {
            return chartCachedDateTimeFormat('en-CA', {
                timeZone: tzId || 'UTC',
                year: 'numeric',
                month: '2-digit',
                day: '2-digit'
            }).format(new Date(utcMs));
        } catch (e) {
            return new Date(utcMs).toISOString().slice(0, 10);
        }
    }

    function resolveOpeningRangeParams(params) {
        params = params || {};
        let rangeStart = params.rangeStart || '09:30';
        let rangeEnd = params.rangeEnd || '10:00';
        if ((!params.rangeStart && params.minutes != null) || (rangeStart === '09:30' && rangeEnd === '10:00' && params.minutes != null)) {
            const mins = Math.max(1, Math.floor(Number(params.minutes) || 30));
            const startH = 0;
            const endTotal = mins;
            const endH = Math.floor(endTotal / 60);
            const endM = endTotal % 60;
            rangeStart = String(startH).padStart(2, '0') + ':00';
            rangeEnd = String(endH).padStart(2, '0') + ':' + String(endM).padStart(2, '0');
        }
        return {
            rangeStart: rangeStart,
            rangeEnd: rangeEnd,
            timezone: params.rangeTimezone || resolveChartWallTimezoneId()
        };
    }

    /** Per-day opening range in chart wall-clock window; bands appear only after the window closes (flat final high/low). */
    function calculateOpeningRange(data, params) {
        const resolved = typeof params === 'number'
            ? { rangeStart: '00:00', rangeEnd: (function (m) {
                const mins = Math.max(1, Math.floor(m));
                return String(Math.floor(mins / 60)).padStart(2, '0') + ':' + String(mins % 60).padStart(2, '0');
            })(params), timezone: resolveChartWallTimezoneId() }
            : resolveOpeningRangeParams(params);
        const tz = resolved.timezone;
        const startDec = parseSessionTimeStr(resolved.rangeStart);
        const endDec = parseSessionTimeStr(resolved.rangeEnd);
        const session = { start: startDec, end: endDec };
        const n = data.length;
        const upper = new Array(n).fill(null);
        const lower = new Array(n).fill(null);
        const middle = new Array(n).fill(null);

        let dayKey = null;
        let rangeStartIdx = null;
        let dayHigh = null;
        let dayLow = null;
        let settledStartIdx = null;
        let settledHigh = null;
        let settledLow = null;
        let dayEndIdx = -1;

        function flushDayExtension(endIdx) {
            if (settledStartIdx == null || settledHigh == null || settledLow == null) return;
            const mid = (settledHigh + settledLow) / 2;
            for (let j = settledStartIdx; j <= endIdx; j++) {
                upper[j] = settledHigh;
                lower[j] = settledLow;
                middle[j] = mid;
            }
        }

        for (let i = 0; i < n; i++) {
            const dk = dayKeyInTimezone(data[i].t, tz);
            const dec = sessionWallDecimal(data[i].t, tz);
            if (dk !== dayKey) {
                if (dayKey != null) flushDayExtension(dayEndIdx);
                dayKey = dk;
                rangeStartIdx = null;
                dayHigh = null;
                dayLow = null;
                settledStartIdx = null;
                settledHigh = null;
                settledLow = null;
            }
            dayEndIdx = i;

            const inWin = isInSessionDecimal(dec, session);
            if (inWin) {
                if (rangeStartIdx == null) rangeStartIdx = i;
                if (dayHigh == null) {
                    dayHigh = data[i].h;
                    dayLow = data[i].l;
                } else {
                    dayHigh = Math.max(dayHigh, data[i].h);
                    dayLow = Math.min(dayLow, data[i].l);
                }
            } else if (rangeStartIdx != null && dayHigh != null && settledHigh == null) {
                settledHigh = dayHigh;
                settledLow = dayLow;
                settledStartIdx = rangeStartIdx;
            }
        }
        if (dayKey != null) flushDayExtension(dayEndIdx);

        return { upper: upper, lower: lower, middle: middle };
    }

    function applyOpeningRangeStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 1;
        const legacyS = params.lineStyle || 'Line';
        const resolved = resolveOpeningRangeParams(params);
        indicator.params.rangeStart = resolved.rangeStart;
        indicator.params.rangeEnd = resolved.rangeEnd;
        indicator.params.rangeTimezone = resolveChartWallTimezoneId();
        // Keep legend / settings title in sync whenever the session window changes
        // (not only inside needsDataRecalc recalc branches).
        indicator.name = 'Opening Range(' + resolved.rangeStart + '-' + resolved.rangeEnd + ')';
        indicator.overlay = true;
        indicator.style.showUpper = params.showUpper !== false;
        indicator.style.upperColor = params.upperColor || '#2962ff';
        indicator.style.upperOpacity = params.upperOpacity != null ? Number(params.upperOpacity) : 100;
        indicator.style.upperLineWidth = params.upperLineWidth != null ? params.upperLineWidth : legacyW;
        indicator.style.upperLineStyle = params.upperLineStyle || legacyS;
        indicator.style.showMiddle = params.showMiddle !== false;
        indicator.style.middleColor = params.middleColor || '#787b86';
        indicator.style.middleOpacity = params.middleOpacity != null ? Number(params.middleOpacity) : 100;
        indicator.style.middleLineWidth = params.middleLineWidth != null ? params.middleLineWidth : legacyW;
        indicator.style.middleLineStyle = params.middleLineStyle || legacyS;
        indicator.style.showLower = params.showLower !== false;
        indicator.style.lowerColor = params.lowerColor || '#2962ff';
        indicator.style.lowerOpacity = params.lowerOpacity != null ? Number(params.lowerOpacity) : 100;
        indicator.style.lowerLineWidth = params.lowerLineWidth != null ? params.lowerLineWidth : legacyW;
        indicator.style.lowerLineStyle = params.lowerLineStyle || legacyS;
        indicator.style.showFill = false;
        indicator.style.showLabel = params.showLabel !== false;
        indicator.style.showTimeLabel = false;
        applyPlotDashFieldsFromParams(indicator.style, params, [
            ['upperLineStyle', 'upperLineDashStyle', legacyS],
            ['middleLineStyle', 'middleLineDashStyle', legacyS],
            ['lowerLineStyle', 'lowerLineDashStyle', legacyS]
        ]);
    }

    function calculateSupertrend(data, period, multiplier) {
        const mult = multiplier != null ? multiplier : 3;
        const p = Math.max(1, period || 10);
        const atr = calculateATR(data, p);
        const n = data.length;
        const finalUpper = new Array(n).fill(null);
        const finalLower = new Array(n).fill(null);
        const line = new Array(n).fill(null);
        const direction = new Array(n).fill(1);
        const body = new Array(n).fill(null);
        for (let i = 0; i < n; i++) {
            const hl2 = resolveOhlcSourceValue(data[i], 'hl2');
            body[i] = Number.isFinite(hl2) ? hl2 : null;
            const close = resolveOhlcSourceValue(data[i], 'close');
            const a = atr[i];
            if (a == null || isNaN(a) || !Number.isFinite(hl2)) continue;
            const basicUpper = hl2 + mult * a;
            const basicLower = hl2 - mult * a;
            if (i === 0) {
                finalUpper[i] = basicUpper;
                finalLower[i] = basicLower;
                line[i] = finalLower[i];
                direction[i] = 1;
                continue;
            }
            const pU = finalUpper[i - 1];
            const pL = finalLower[i - 1];
            const pC = resolveOhlcSourceValue(data[i - 1], 'close');
            finalUpper[i] = (basicUpper < pU || pC > pU) ? basicUpper : pU;
            finalLower[i] = (basicLower > pL || pC < pL) ? basicLower : pL;
            if (direction[i - 1] === 1) {
                if (close < finalLower[i - 1]) {
                    direction[i] = -1;
                    line[i] = finalUpper[i];
                } else {
                    direction[i] = 1;
                    line[i] = finalLower[i];
                }
            } else {
                if (close > finalUpper[i - 1]) {
                    direction[i] = 1;
                    line[i] = finalLower[i];
                } else {
                    direction[i] = -1;
                    line[i] = finalUpper[i];
                }
            }
        }
        return { line: line, direction: direction, upper: finalUpper, lower: finalLower, body: body };
    }

    function calculateStdDevLine(data, period, source) {
        source = source || 'close';
        const p = Math.max(2, period);
        const out = [];
        for (let i = 0; i < data.length; i++) {
            if (i < p - 1) {
                out.push(null);
                continue;
            }
            let sum = 0;
            let sumSq = 0;
            let ok = true;
            for (let j = 0; j < p; j++) {
                const v = resolveOhlcSourceValue(data[i - j], source);
                if (!Number.isFinite(v)) { ok = false; break; }
                sum += v;
                sumSq += v * v;
            }
            if (!ok) { out.push(null); continue; }
            const mean = sum / p;
            const variance = Math.max(0, sumSq / p - mean * mean);
            out.push(Math.sqrt(variance));
        }
        return out;
    }

    function smaMedianPrice(data, len) {
        const med = data.map(function(d) {
            return (d.h + d.l) / 2;
        });
        const out = med.map(function() {
            return null;
        });
        let sum = 0;
        for (let i = 0; i < med.length; i++) {
            sum += med[i];
            if (i >= len) sum -= med[i - len];
            if (i >= len - 1) out[i] = sum / len;
        }
        return out;
    }

    function calculateAO(data, fastLen, slowLen) {
        let fastPeriod = Math.max(1, Number(fastLen) | 0) || 5;
        let slowPeriod = Math.max(2, Number(slowLen) | 0) || 34;
        if (slowPeriod <= fastPeriod) slowPeriod = fastPeriod + 1;
        const fast = smaMedianPrice(data, fastPeriod);
        const slow = smaMedianPrice(data, slowPeriod);
        return fast.map(function(f, i) {
            if (f == null || slow[i] == null) return null;
            return f - slow[i];
        });
    }

    function calculateUltimateOscillator(data, p1, p2, p3) {
        const n = data.length;
        const bp = [];
        const tr = [];
        for (let i = 0; i < n; i++) {
            if (i === 0) {
                bp.push(data[i].c - data[i].l);
                tr.push(data[i].h - data[i].l);
            } else {
                const pc = data[i - 1].c;
                bp.push(data[i].c - Math.min(data[i].l, pc));
                tr.push(Math.max(data[i].h, pc) - Math.min(data[i].l, pc));
            }
        }
        const maxP = Math.max(p1, p2, p3);
        const out = [];
        function windowRatio(idx, len) {
            let sb = 0;
            let st = 0;
            for (let k = 0; k < len; k++) {
                const j = idx - k;
                if (j < 0) return null;
                sb += bp[j];
                st += tr[j];
            }
            return st ? sb / st : null;
        }
        for (let i = 0; i < n; i++) {
            if (i < maxP - 1) {
                out.push(null);
                continue;
            }
            const a1 = windowRatio(i, p1);
            const a2 = windowRatio(i, p2);
            const a3 = windowRatio(i, p3);
            if (a1 == null || a2 == null || a3 == null) {
                out.push(null);
            } else {
                out.push(100 * (4 * a1 + 2 * a2 + a3) / 7);
            }
        }
        return out;
    }

    function calculateVortex(data, period) {
        const n = data.length;
        const p = Math.max(2, period);
        const vmPlus = [0];
        const vmMinus = [0];
        const trArr = [data[0].h - data[0].l];
        for (let i = 1; i < n; i++) {
            vmPlus.push(Math.abs(data[i].h - data[i - 1].l));
            vmMinus.push(Math.abs(data[i].l - data[i - 1].h));
            trArr.push(Math.max(data[i].h, data[i - 1].c) - Math.min(data[i].l, data[i - 1].c));
        }
        const viPlus = [];
        const viMinus = [];
        for (let i = 0; i < n; i++) {
            if (i < p - 1) {
                viPlus.push(null);
                viMinus.push(null);
                continue;
            }
            let sp = 0;
            let sm = 0;
            let str = 0;
            for (let j = 0; j < p; j++) {
                sp += vmPlus[i - j];
                sm += vmMinus[i - j];
                str += trArr[i - j];
            }
            viPlus.push(str ? sp / str : null);
            viMinus.push(str ? sm / str : null);
        }
        return { viPlus: viPlus, viMinus: viMinus };
    }

    function calculateDPO(data, period, centered) {
        const p = Math.max(3, period);
        const shift = Math.floor(p / 2) + 1;
        const sma = calculateSMA(data, p, 'close');
        const out = [];
        for (let i = 0; i < data.length; i++) {
            if (centered) {
                const j = i - shift;
                const srcBack = j >= 0 ? resolveOhlcSourceValue(data[j], 'close') : null;
                const smaNow = sma[i];
                if (j < 0 || smaNow === null || !Number.isFinite(srcBack)) {
                    out.push(null);
                } else {
                    out.push(srcBack - smaNow);
                }
            } else {
                const j = i - shift;
                const src = resolveOhlcSourceValue(data[i], 'close');
                if (j < 0 || sma[j] === null || !Number.isFinite(src)) {
                    out.push(null);
                } else {
                    out.push(src - sma[j]);
                }
            }
        }
        return out;
    }

    /** Stochastic RSI — %K / %D in 0–100 panel (same shape as Stochastic). */
    function calculateStochRSI(data, rsiPeriod, stochLen, smoothK, smoothD, source) {
        const rp = Math.max(2, rsiPeriod | 0);
        const sl = Math.max(2, stochLen | 0);
        const sk = Math.max(1, smoothK | 0);
        const sd = Math.max(1, smoothD | 0);
        const rsi = calculateRSI(data, rp, source || 'close');
        const raw = data.map(function() { return null; });
        for (let i = 0; i < data.length; i++) {
            let lo = Infinity;
            let hi = -Infinity;
            let ok = true;
            for (let j = 0; j < sl; j++) {
                const idx = i - j;
                if (idx < 0) { ok = false; break; }
                const v = rsi[idx];
                if (v === null || v === undefined || isNaN(v)) { ok = false; break; }
                lo = Math.min(lo, v);
                hi = Math.max(hi, v);
            }
            if (!ok) continue;
            const rv = rsi[i];
            if (rv === null || rv === undefined || isNaN(rv)) continue;
            raw[i] = hi === lo ? 50 : ((rv - lo) / (hi - lo)) * 100;
        }
        const k = rollingSmaNullable(raw, sk);
        const d = rollingSmaNullable(k, sd);
        return { k: k, d: d };
    }

    /** Mass Index — sum of EMA(H−L ratio) over sumPeriod (reversal squeeze indicator). */
    function calculateMassIndex(data, emaPeriod, sumPeriod) {
        const ep = Math.max(2, emaPeriod | 0);
        const sp = Math.max(2, sumPeriod | 0);
        const rangeSeries = data.map(function(d) {
            const r = d.h - d.l;
            return { h: r, l: r, c: r, o: r, v: d.v, t: d.t };
        });
        const ema1 = calculateEMA(rangeSeries, ep, 'c');
        const doubleInput = data.map(function(d, i) {
            const v = ema1[i];
            const x = v != null && !isNaN(v) ? v : 0;
            return { h: x, l: x, c: x, o: x, v: d.v, t: d.t };
        });
        const ema2 = calculateEMA(doubleInput, ep, 'c');
        const ratio = data.map(function(_, i) {
            if (ema1[i] == null || ema2[i] == null || ema2[i] === 0) return null;
            return ema1[i] / ema2[i];
        });
        const out = data.map(function() { return null; });
        for (let i = 0; i < data.length; i++) {
            if (i < sp - 1) continue;
            let s = 0;
            let ok = true;
            for (let j = 0; j < sp; j++) {
                const r = ratio[i - j];
                if (r === null || r === undefined || isNaN(r)) { ok = false; break; }
                s += r;
            }
            if (ok) out[i] = s;
        }
        return out;
    }

    const COPPOCK_WMA_PERIOD = 10;

    function coppockCalcParams(params) {
        params = params || {};
        return {
            longRoc: params.longRocLength != null
                ? Math.max(1, Number(params.longRocLength) | 0)
                : 14,
            shortRoc: params.shortRocLength != null
                ? Math.max(1, Number(params.shortRocLength) | 0)
                : 11,
            wmaPeriod: params.wmaPeriod != null
                ? Math.max(2, Number(params.wmaPeriod) | 0)
                : COPPOCK_WMA_PERIOD
        };
    }

    /** Coppock curve — WMA of ROC(short) + ROC(long). */
    function calculateCoppock(data, paramsOrWma) {
        const calc = typeof paramsOrWma === 'number'
            ? { longRoc: 14, shortRoc: 11, wmaPeriod: Math.max(2, paramsOrWma | 0) }
            : coppockCalcParams(paramsOrWma);
        const rocShort = calculateROC(data, calc.shortRoc);
        const rocLong = calculateROC(data, calc.longRoc);
        const sum = data.map(function(_, i) {
            if (rocShort[i] == null || rocLong[i] == null) return null;
            return rocShort[i] + rocLong[i];
        });
        return rollingWmaNullable(sum, calc.wmaPeriod);
    }

    function applyCoppockStyleFromParams(indicator, params) {
        const legacyW = params.lineWidth != null ? params.lineWidth : 2;
        const legacyS = params.lineStyle || 'Line';
        indicator.params.longRocLength = coppockCalcParams(params).longRoc;
        indicator.params.shortRocLength = coppockCalcParams(params).shortRoc;
        indicator.params.wmaPeriod = coppockCalcParams(params).wmaPeriod;
        indicator.style.showCoppock = params.showCoppock !== false;
        indicator.style.showLine = indicator.style.showCoppock;
        indicator.params.showCoppock = indicator.style.showCoppock;
        indicator.params.showLine = indicator.style.showLine;
        indicator.style.color = params.color || '#8e24aa';
        indicator.style.lineOpacity = params.lineOpacity != null ? Number(params.lineOpacity) : 100;
        indicator.style.lineWidth = legacyW;
        applyPlotDashFieldsFromParams(indicator.style, params, [['lineStyle', 'lineDashStyle', legacyS]]);
        indicator.hidePlot = params.hideFromContainer === true;
        indicator.overlay = false;
        indicator.separatePanel = true;
    }

    /** Relative Vigor Index — RVGI + signal (SMA of RVGI, default length 4). */
    function calculateRVI(data, period, signalPeriod) {
        const p = Math.max(2, period | 0);
        const sp = Math.max(2, signalPeriod != null ? signalPeriod | 0 : 4);
        const ratio = data.map(function() { return null; });
        for (let i = 3; i < data.length; i++) {
            const c = data[i].c, o = data[i].o, h = data[i].h, l = data[i].l;
            const c1 = data[i - 1].c, o1 = data[i - 1].o, h1 = data[i - 1].h, l1 = data[i - 1].l;
            const c2 = data[i - 2].c, o2 = data[i - 2].o, h2 = data[i - 2].h, l2 = data[i - 2].l;
            const c3 = data[i - 3].c, o3 = data[i - 3].o, h3 = data[i - 3].h, l3 = data[i - 3].l;
            const num = ((c - o) + 2 * (c1 - o1) + 2 * (c2 - o2) + (c3 - o3)) / 6;
            const den = ((h - l) + 2 * (h1 - l1) + 2 * (h2 - l2) + (h3 - l3)) / 6;
            if (!den) ratio[i] = null;
            else ratio[i] = num / den;
        }
        const rvi = rollingSmaNullable(ratio, p);
        const signal = rollingSmaNullable(rvi, sp);
        return { rvi: rvi, signal: signal };
    }

    function rviSeriesAtPlotOffset(arr, barIndex, plotOffset) {
        return seriesValueAtPlotOffset(arr, barIndex, plotOffset);
    }

    /** Elder Ray — bull power (H−EMA), bear power (L−EMA). */
    function calculateElderRay(data, period) {
        const p = Math.max(2, period | 0);
        const ema = calculateEMA(data, p, 'c');
        const bull = data.map(function(d, i) {
            return ema[i] == null ? null : d.h - ema[i];
        });
        const bear = data.map(function(d, i) {
            return ema[i] == null ? null : d.l - ema[i];
        });
        return { bull: bull, bear: bear };
    }

    /** CFTC Public Reporting — Legacy Combined (futures + options), same family as TV “Legacy” COT. */
    var COTNET_CFTC_LEGACY_COMBINED = 'jun7-fc8e';
    var COTNET_CFTC_API = 'https://publicreporting.cftc.gov/resource/';

    function sanitizeCftcContractCode(code) {
        const s = String(code == null ? '' : code).trim();
        if (!/^[0-9A-Za-z+]{1,16}$/.test(s)) {
            throw new Error('Invalid CFTC contract code (use digits/letters/+, e.g. 13874A or 085692)');
        }
        return s;
    }

    function cotNetCftcRowsToPoints(rows) {
        const pts = [];
        let marketName = '';
        for (let i = 0; i < rows.length; i++) {
            const r = rows[i];
            if (!marketName && r.market_and_exchange_names) marketName = String(r.market_and_exchange_names);
            const oi = parseInt(r.open_interest_all, 10);
            if (!oi || isNaN(oi)) continue;
            const cl = parseInt(r.comm_positions_long_all, 10);
            const cs = parseInt(r.comm_positions_short_all, 10);
            const nl = parseInt(r.noncomm_positions_long_all, 10);
            const ns = parseInt(r.noncomm_positions_short_all, 10);
            if (isNaN(cl) || isNaN(cs) || isNaN(nl) || isNaN(ns)) continue;
            const t = Date.parse(r.report_date_as_yyyy_mm_dd);
            if (!Number.isFinite(t)) continue;
            pts.push({
                t: t,
                commercialNet: (cl - cs) / oi,
                noncommNet: (nl - ns) / oi
            });
        }
        return { points: pts, marketName: marketName };
    }

    function cotNetBuildCftcLegacyUrl(cftcCode) {
        const code = sanitizeCftcContractCode(cftcCode);
        const where = "cftc_contract_market_code='" + code.replace(/'/g, "''") + "'";
        return COTNET_CFTC_API + COTNET_CFTC_LEGACY_COMBINED + '.json?' + [
            '$where=' + encodeURIComponent(where),
            '$order=' + encodeURIComponent('report_date_as_yyyy_mm_dd ASC'),
            '$limit=10000'
        ].join('&');
    }

    /**
     * Normalized chart root symbol → CFTC Legacy Combined contract code (jun7-fc8e).
     * When the chart symbol is unknown, caller falls back to ES (13874A).
     */
    var COTNET_SYMBOL_TO_CFTC = {
        ES: '13874A',
        MES: '13874U',
        SPX: '13874A',
        NQ: '209741',
        MNQ: '209747',
        GC: '088691',
        MGC: '088691',
        CL: '067651',
        MCL: '067651',
        '6E': '099741',
        EURUSD: '099741',
        RTY: '239742',
        M2K: '239747',
        YM: '124603',
        MYM: '124603',
        '6B': '096742',
        GBPUSD: '096742',
        '6J': '097741',
        USDJPY: '097741',
        '6A': '232741',
        AUDUSD: '232741',
        '6N': '112741',
        NZDUSD: '112741',
        '6C': '090741',
        USDCAD: '090741',
        '6S': '092741',
        USDCHF: '092741',
        SI: '084691',
        SIL: '084691',
        HG: '085692',
        XAUUSD: '088691',
        XAGUSD: '084691',
        ZB: '020601',
        ZN: '042601',
        ZF: '044601',
        ZT: '043601'
    };

    var COTNET_FX_CCYS = new Set(['USD', 'EUR', 'GBP', 'JPY', 'AUD', 'NZD', 'CAD', 'CHF', 'HKD', 'SGD', 'SEK', 'NOK', 'DKK', 'ZAR', 'TRY', 'MXN', 'BTC', 'ETH', 'XAU', 'XAG']);

    /** Same idea as Chart._formatPairTicker: EUR/USD → EURUSD; then futures roots ESZ4 → ES. */
    function cotNetNormalizeSymbolKey(raw) {
        if (raw == null || raw === '') return '';
        const clean = String(raw).replace(/\.(csv|CSV)$/i, '').replace(/^\d{8}_\d{6}_/, '');
        const flat = clean.toUpperCase().replace(/[\s\-_\/\.]/g, '');
        const m6 = flat.match(/^([A-Z]{6})/);
        if (m6) {
            const pair = m6[1];
            const base = pair.substring(0, 3);
            const quote = pair.substring(3, 6);
            if (COTNET_FX_CCYS.has(base) && COTNET_FX_CCYS.has(quote)) {
                return pair;
            }
        }
        let s = flat.replace(/^=/, '');
        s = s.replace(/(\.[A-Z0-9]+)+$/i, '');
        const fm = s.match(/^([A-Z0-9]{1,6})([FGHJKMNQUVZ])(\d{2,4})$/);
        if (fm) return fm[1];
        return s;
    }

    function cotNetLooksLikeForexSix(key) {
        return /^[A-Z]{6}$/.test(key) && COTNET_FX_CCYS.has(key.slice(0, 3)) && COTNET_FX_CCYS.has(key.slice(3, 6));
    }

    /**
     * @returns {{ code: string, auto: boolean, root: string }}
     */
    function cotNetResolveCftcCode(chart, params) {
        const symKey = cotNetNormalizeSymbolKey(chart && chart.currentSymbol);
        const explicit = params && params.cftcCode != null ? String(params.cftcCode).trim() : '';

        if (explicit && explicit.toLowerCase() !== 'auto') {
            return { code: sanitizeCftcContractCode(explicit), auto: false, root: explicit };
        }

        if (symKey && COTNET_SYMBOL_TO_CFTC[symKey]) {
            return { code: COTNET_SYMBOL_TO_CFTC[symKey], auto: true, root: symKey };
        }
        if (cotNetLooksLikeForexSix(symKey)) {
            throw new Error('No CFTC Legacy mapping for ' + symKey + ' — set cftcCode in indicator settings (see cftc.gov Public Reporting)');
        }
        return { code: '13874A', auto: true, root: symKey || '' };
    }

    function normalizeCotNetPoint(p) {
        if (!p || typeof p !== 'object') return null;
        const t = p.t != null ? Number(p.t) : (p.time != null ? Number(p.time) : NaN);
        const c = p.commercialNet != null ? Number(p.commercialNet) : (p.c != null ? Number(p.c) : NaN);
        const n = p.noncommNet != null ? Number(p.noncommNet) : (p.n != null ? Number(p.n) : NaN);
        if (!Number.isFinite(t) || !Number.isFinite(c) || !Number.isFinite(n)) return null;
        return { t: t, commercialNet: c, noncommNet: n };
    }

    function mergeCotNetPointsToBars(candles, points) {
        const sorted = points.filter(Boolean).slice().sort(function(a, b) { return a.t - b.t; });
        const n = candles.length;
        const bull = new Array(n).fill(null);
        const bear = new Array(n).fill(null);
        let j = 0;
        let lastC = null;
        let lastN = null;
        for (let i = 0; i < n; i++) {
            const bt = candles[i].t;
            while (j < sorted.length && sorted[j].t <= bt) {
                lastC = sorted[j].commercialNet;
                lastN = sorted[j].noncommNet;
                j++;
            }
            bull[i] = lastC;
            bear[i] = lastN;
        }
        return { bull: bull, bear: bear };
    }

    /**
     * Calendar seasonality: mean close-to-close % return for each month/day (UTC) across all years in the series.
     * Uses the same bars as the chart (same instrument as the open dataset). Requires enough history per date.
     */
    function calculateSeasonality(data, minSamples) {
        const n = data ? data.length : 0;
        const out = new Array(n).fill(null);
        if (n < 2) return out;
        const msParsed = minSamples != null ? parseInt(minSamples, 10) : 2;
        const ms = Math.max(1, isNaN(msParsed) ? 2 : msParsed);

        function calKey(t) {
            const d = new Date(t);
            return (d.getUTCMonth() + 1) * 100 + d.getUTCDate();
        }

        const buckets = {};
        for (let i = 1; i < n; i++) {
            const pc = data[i - 1].c;
            if (pc == null || pc === 0 || isNaN(pc)) continue;
            const ret = (data[i].c - pc) / pc * 100;
            if (!isFinite(ret)) continue;
            const k = calKey(data[i].t);
            if (!buckets[k]) buckets[k] = [];
            buckets[k].push(ret);
        }

        const mean = {};
        Object.keys(buckets).forEach(function(k) {
            const arr = buckets[k];
            if (arr.length >= ms) {
                let s = 0;
                for (let j = 0; j < arr.length; j++) s += arr[j];
                mean[k] = s / arr.length;
            }
        });

        for (let i = 0; i < n; i++) {
            const k = calKey(data[i].t);
            out[i] = mean[k] != null ? mean[k] : null;
        }
        return out;
    }

    /** SMA envelope — % distance from SMA(close). */
    function calculateEnvelope(data, period, percent, source) {
        const mid = calculateSMA(data, Math.max(1, period), source || 'close');
        const pct = Math.max(0.01, percent) / 100;
        const upper = [];
        const lower = [];
        for (let i = 0; i < data.length; i++) {
            if (mid[i] == null) {
                upper.push(null);
                lower.push(null);
            } else {
                upper.push(mid[i] * (1 + pct));
                lower.push(mid[i] * (1 - pct));
            }
        }
        return { upper: upper, middle: mid, lower: lower };
    }

    // ===== Chart Integration =====
    
    Chart.prototype.initIndicators = function() {
        this.indicators = {
            active: [],
            data: {}
        };
        if (isRc6IndicatorLifecycleStoreEnabled()) {
            getIndicatorLifecycleStore(this);
        }
    };

    Chart.prototype._installIndicatorLifecycleStoreSubscribers = function() {
        const store = this._indicatorLifecycleStore;
        if (!store || this._indicatorLifecycleSubsInstalled) return;
        this._indicatorLifecycleSubsInstalled = true;
        const self = this;
        store.on('indicatorVisibilityChanged', function() {
            if (!store.isEnabled()) return;
            if (typeof self.scheduleRender === 'function') {
                self.scheduleRender();
            } else if (typeof self.render === 'function') {
                self.render();
            }
        });
        store.on('indicatorSettingsApplied', function() {
            if (!store.isEnabled()) return;
            if (typeof self.updateOHLCIndicators === 'function') {
                self.updateOHLCIndicators();
            }
            if (typeof self.scheduleRender === 'function') {
                self.scheduleRender();
            } else if (typeof self.render === 'function') {
                self.render();
            }
        });
        store.on('indicatorRehydrated', function() {
            if (!store.isEnabled()) return;
            if (typeof self.recalculateIndicators === 'function') {
                self.recalculateIndicators();
            }
            if (typeof self.updateOHLCIndicators === 'function') {
                self.updateOHLCIndicators();
            }
            if (typeof self.scheduleRender === 'function') {
                self.scheduleRender();
            } else if (typeof self.render === 'function') {
                self.render();
            }
        });
    };

    Chart.prototype._emitIndicatorRehydrateComplete = function() {
        if (!isRc6IndicatorPersistRehydrateV2Enabled()) return;
        const active = this.indicators && Array.isArray(this.indicators.active)
            ? this.indicators.active.slice()
            : [];
        const pending = Array.isArray(this._indicatorRehydratePending)
            ? this._indicatorRehydratePending.slice()
            : [];
        if (typeof global.endIndicatorRehydrate === 'function') {
            global.endIndicatorRehydrate(this);
        }
        if (isRc6IndicatorLifecycleStoreEnabled()) {
            const store = getIndicatorLifecycleStore(this);
            if (store && store.isEnabled()) {
                store.emit('indicatorRehydrated', {
                    chart: this,
                    action: 'rehydrate',
                    indicator: null,
                    indicators: active,
                    pendingCount: pending.length,
                    restoredCount: active.length,
                });
                return;
            }
        }
        emitIndicatorsChanged(this, 'rehydrate', null);
    };

    function installIndicatorPersistRehydrateWrappers() {
        if (typeof Chart === 'undefined' || Chart.prototype._indicatorPersistRehydrateWrapped) return;
        const origApply = Chart.prototype._applyPersistedIndicators;
        const origQueue = Chart.prototype._queuePersistedIndicatorsRestore;
        if (typeof origApply !== 'function' && typeof origQueue !== 'function') return;

        if (typeof origQueue === 'function') {
            Chart.prototype._queuePersistedIndicatorsRestore = function(list) {
                if (isRc6IndicatorPersistRehydrateV2Enabled()
                    && typeof global.beginIndicatorRehydrate === 'function') {
                    global.beginIndicatorRehydrate(this, list);
                }
                return origQueue.call(this, list);
            };
        }

        if (typeof origApply === 'function') {
            Chart.prototype._applyPersistedIndicators = function() {
                if (!isRc6IndicatorPersistRehydrateV2Enabled()) {
                    return origApply.call(this);
                }
                const out = origApply.call(this);
                if (typeof this._emitIndicatorRehydrateComplete === 'function') {
                    this._emitIndicatorRehydrateComplete();
                }
                return out;
            };
        }

        Chart.prototype._indicatorPersistRehydrateWrapped = true;
    }

    Chart.prototype._indicatorDataMatchesBars = function(indicator) {
        if (typeof global.indicatorDataMatchesBarCount === 'function') {
            return global.indicatorDataMatchesBarCount(this, indicator);
        }
        if (!indicator || !this.indicators || !this.indicators.data) return false;
        const barCount = Array.isArray(this.data) ? this.data.length : 0;
        const store = this.indicators.data[indicator.id];
        if (!store || !barCount) return !barCount;
        if (Array.isArray(store)) return store.length === barCount;
        return true;
    };

    Chart.prototype._recalcIndicatorDataForSettings = function(indicator) {
        if (!indicator || !this.data || !this.data.length) return;
        const type = String(indicator.type || '').toLowerCase();
        if (!this.indicators.data) this.indicators.data = {};
        switch (type) {
            case 'rsi':
                indicator.name = 'RSI(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateRSIIndicatorData(this.data, indicator.params);
                break;
            case 'sma':
                indicator.name = 'SMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateSMAIndicatorData(this.data, indicator.params);
                break;
            case 'ema':
                indicator.name = 'EMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateEMAIndicatorData(this.data, indicator.params);
                break;
            default:
                if (typeof this.recalculateIndicators === 'function') {
                    this.recalculateIndicators();
                }
                break;
        }
    };

    Chart.prototype._finalizeIndicatorSettingsApply = function(indicator, ctx) {
        ctx = ctx || {};
        const needsDataRecalc = !!ctx.needsDataRecalc;
        const newParams = ctx.newParams || {};

        if (isRc6IndicatorSettingsApplyV2Enabled()) {
            if (typeof global.applyIndicatorSettingsInvalidation === 'function') {
                global.applyIndicatorSettingsInvalidation(this, indicator, {
                    needsDataRecalc: needsDataRecalc,
                    newParams: newParams,
                }, {
                    recalcFn: function(chart, ind) {
                        if (typeof chart._recalcIndicatorDataForSettings === 'function') {
                            chart._recalcIndicatorDataForSettings(ind);
                        } else if (typeof chart.recalculateIndicators === 'function') {
                            chart.recalculateIndicators();
                        }
                    },
                });
            } else if (needsDataRecalc && !this._indicatorDataMatchesBars(indicator)) {
                this._recalcIndicatorDataForSettings(indicator);
            }

            clampIndicatorStyleLineWidths(indicator.style);
            if (typeof this.bumpIndicatorRenderVersion === 'function') {
                this.bumpIndicatorRenderVersion();
            } else if (typeof this._invalidateIndicatorLayerCache === 'function') {
                this._invalidateIndicatorLayerCache();
            }
            if (typeof this.updateOHLCIndicators === 'function') {
                this.updateOHLCIndicators();
            }
            if (typeof this.persistIndicators === 'function') {
                this.persistIndicators({ force: true });
            }
            if (isRc6IndicatorLifecycleStoreEnabled()) {
                this._emitIndicatorLifecycle('settings', indicator, { needsDataRecalc: needsDataRecalc });
            } else {
                emitIndicatorsChanged(this, 'update', indicator);
            }
            if (typeof this.scheduleRender === 'function') {
                this.scheduleRender();
            } else if (typeof this.render === 'function') {
                this.render();
            }
            return indicator;
        }

        clampIndicatorStyleLineWidths(indicator.style);
        if (typeof this.bumpIndicatorRenderVersion === 'function') {
            this.bumpIndicatorRenderVersion();
        }
        if (typeof this.scheduleRender === 'function') {
            this.scheduleRender();
        } else if (typeof this.render === 'function') {
            this.render();
        }
        if (typeof this.updateOHLCIndicators === 'function') {
            this.updateOHLCIndicators();
        }
        if (typeof this.persistIndicators === 'function') {
            this.persistIndicators({ force: true });
        }
        emitIndicatorsChanged(this, 'update', indicator);
        return indicator;
    };

    Chart.prototype.applyIndicatorSettings = function(id, newParams, opts) {
        opts = opts || {};
        if (typeof this.updateIndicator !== 'function') return null;
        return this.updateIndicator(id, newParams, opts);
    };

    Chart.prototype.setIndicatorVisible = function(idOrIndicator, show, opts) {
        opts = opts || {};
        let indicator = idOrIndicator;
        if (indicator != null && (typeof indicator === 'string' || typeof indicator === 'number')) {
            const id = String(indicator);
            indicator = this.indicators && Array.isArray(this.indicators.active)
                ? this.indicators.active.find(function(ind) {
                    return ind && String(ind.id) === id;
                })
                : null;
        }
        if (!indicator) return false;

        const applyFn = (isRc6IndicatorVisibilityV2Enabled() && typeof global.applyIndicatorVisibility === 'function')
            ? global.applyIndicatorVisibility
            : (typeof global.applyIndicatorVisibilityLegacy === 'function'
                ? global.applyIndicatorVisibilityLegacy
                : null);
        const result = applyFn
            ? applyFn(indicator, show, opts, this.chartSettings)
            : { shown: show !== false, applied: true };

        if (typeof this.bumpIndicatorRenderVersion === 'function') {
            this.bumpIndicatorRenderVersion();
        } else if (typeof this._invalidateIndicatorLayerCache === 'function') {
            this._invalidateIndicatorLayerCache();
        }

        if (result.shown && typeof global.shouldRecalcIndicatorOnShow === 'function'
            && global.shouldRecalcIndicatorOnShow(this, indicator, true)
            && typeof this.recalculateIndicators === 'function') {
            this.recalculateIndicators();
        }

        if (isRc6IndicatorLifecycleStoreEnabled()) {
            if (typeof this._emitIndicatorLifecycle === 'function') {
                this._emitIndicatorLifecycle('visibility', indicator, { visible: result.shown });
            }
        } else if (typeof this.scheduleRender === 'function') {
            this.scheduleRender();
        } else if (typeof this.render === 'function') {
            this.render();
        }

        return result.shown;
    };

    Chart.prototype._emitIndicatorLifecycle = function(action, indicator, opts) {
        opts = opts || {};
        const act = action || 'update';
        if (act === 'visibility') {
            if (!isRc6IndicatorLifecycleStoreEnabled()) return;
            const store = getIndicatorLifecycleStore(this);
            if (!store || !store.isEnabled()) return;
            store.emit('indicatorVisibilityChanged', {
                chart: this,
                action: 'visibility',
                indicator: indicator || null,
                visible: opts.visible,
                indicators: this.indicators && Array.isArray(this.indicators.active)
                    ? this.indicators.active.slice()
                    : []
            });
            return;
        }
        if (act === 'settings') {
            if (!isRc6IndicatorLifecycleStoreEnabled()) return;
            const store = getIndicatorLifecycleStore(this);
            if (!store || !store.isEnabled()) return;
            store.emit('indicatorSettingsApplied', {
                chart: this,
                action: 'settings',
                indicator: indicator || null,
                needsDataRecalc: !!opts.needsDataRecalc,
                indicators: this.indicators && Array.isArray(this.indicators.active)
                    ? this.indicators.active.slice()
                    : []
            });
            return;
        }
        emitIndicatorsChanged(this, act, indicator);
    };
    
    Chart.prototype.addIndicator = function(type, params) {
    params = params || {};
    params = sanitizeIndicatorRuntimePayload({ type: String(type || '').toLowerCase() }, params);
    
    // Auto-initialize indicators if not done
    if (!this.indicators) {
        this.initIndicators();
    }

    if (this.indicators.active && this.indicators.active.length >= MAX_ACTIVE_INDICATORS) {
        if (typeof this.showNotification === 'function') {
            this.showNotification('Maximum ' + MAX_ACTIVE_INDICATORS + ' indicators allowed');
        }
        return null;
    }
    
    if (!this.data || this.data.length === 0) {
        alert('Please load chart data first before adding indicators.');
        return;
    }

    const normalizedType = String(type || '').toLowerCase();
    if (this.indicators.active && this.indicators.active.length) {
        const existingSameType = this.indicators.active.find(function (ind) {
            return ind && String(ind.type || '').toLowerCase() === normalizedType;
        });
        if (existingSameType) {
            return existingSameType;
        }
    }
        
        const indicator = {
        id: 'ind_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
        type: type.toLowerCase(),
        params: {},
        style: {},
        visible: true,
        name: ''
    };

        const chartRef = this;
        indicator._calculating = true;
        indicator.name = String(type || '').toUpperCase();
        chartRef.indicators.active.push(indicator);
        if (typeof chartRef._primeSeparatePanelForNewIndicator === 'function') {
            chartRef._primeSeparatePanelForNewIndicator(indicator, normalizedType);
        }
        if (typeof chartRef._restoreEvictedIndicatorSettingsForNewIndicator === 'function') {
            chartRef._restoreEvictedIndicatorSettingsForNewIndicator(indicator);
        }
        if (typeof chartRef.updateOHLCIndicators === 'function') chartRef.updateOHLCIndicators();
        if (typeof chartRef.scheduleRender === 'function') chartRef.scheduleRender();

        (function finishAddIndicator() {
            if (!chartRef.indicators || !chartRef.indicators.active
                || !chartRef.indicators.active.some(function(i) { return i && i.id === indicator.id; })) {
                return;
            }
            var addAborted = false;
        
        // Configure indicator based on type
        (function() {
        switch (indicator.type) {
            case 'sma':
                applySmaStyleFromParams(indicator, params);
                indicator.name = 'SMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateSMAIndicatorData(this.data, indicator.params);
                break;
                
            case 'ema':
                applyEmaStyleFromParams(indicator, params);
                indicator.name = 'EMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateEMAIndicatorData(this.data, indicator.params);
                break;
                
            case 'wma':
                applyWmaStyleFromParams(indicator, params);
                indicator.name = 'WMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateWMAOverlayData(this.data, indicator.params);
                break;
                
            case 'bb':
            case 'bollinger':
                applyBbCalcParams(indicator, params);
                applyBollingerStyleFromParams(indicator, params);
                indicator.name = 'BB(' + indicator.params.period + ',' + indicator.params.stdDev + ')';
                this.indicators.data[indicator.id] = calculateBollingerBands(this.data, indicator.params);
                break;

            case 'envelope':
            case 'smaenvelope':
                indicator.params.period = params.period || 20;
                indicator.params.source = params.source || 'close';
                indicator.params.percent = params.percent != null ? params.percent : 2.5;
                indicator.style.upperColor = params.upperColor || '#2962ff';
                indicator.style.middleColor = params.middleColor || '#787b86';
                indicator.style.lowerColor = params.lowerColor || '#2962ff';
                indicator.style.fillColor = params.fillColor || 'rgba(41, 98, 255, 0.05)';
                indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : 1;
                indicator.style.lineStyle = params.lineStyle || 'Line';
                indicator.style.showLabel = params.showLabel !== false;
                indicator.overlay = true;
                indicator.name = 'Envelope(' + indicator.params.period + ',' + indicator.params.percent + '%)';
                this.indicators.data[indicator.id] = calculateEnvelope(this.data, indicator.params.period, indicator.params.percent, indicator.params.source);
                break;
                
            case 'vwap':
                applyVwapStyleFromParams(indicator, params);
                indicator.name = 'VWAP';
                this.indicators.data[indicator.id] = calculateVWAPIndicatorData(this.data, indicator.params);
                break;
                
            case 'atr':
                applyAtrStyleFromParams(indicator, params);
                indicator.name = 'ATR(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateATR(
                    this.data,
                    indicator.params.period,
                    indicator.params.smoothingType
                );
                break;

            case 'cci':
                applyCciStyleFromParams(indicator, params);
                indicator.name = 'CCI(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateCCIIndicatorData(this.data, indicator.params);
                break;

            case 'adx':
                applyAdxStyleFromParams(indicator, params);
                indicator.overlay = false;
                indicator.separatePanel = true;
                indicator.name = 'ADX(' + indicator.params.diLength + ',' + indicator.params.adxSmoothing + ')';
                this.indicators.data[indicator.id] = calculateADX(this.data, indicator.params.diLength, indicator.params.adxSmoothing);
                break;

            case 'rsi':
                indicator.params.period = params.period || 14;
                indicator.params.source = params.source || 'close';
                indicator.overlay = false;
                indicator.separatePanel = true;
                applyRsiStyleFromParams(indicator, params);
                indicator.name = 'RSI(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateRSIIndicatorData(this.data, indicator.params);
                break;
                
            case 'macd':
            case 'ppo':
                indicator.type = 'macd';
                indicator.overlay = false;
                indicator.separatePanel = true;
                applyMacdStyleFromParams(indicator, params);
                indicator.name = 'MACD(' + indicator.params.fast + ',' + indicator.params.slow + ',' + indicator.params.signal + ')';
                this.indicators.data[indicator.id] = calculateMACD(
                    this.data,
                    indicator.params.fast,
                    indicator.params.slow,
                    indicator.params.signal,
                    indicator.params.source,
                    {
                        oscillatorMaType: indicator.params.oscillatorMaType,
                        signalMaType: indicator.params.signalMaType
                    }
                );
                break;
                
            case 'stoch':
            case 'stochastic':
                indicator.params.period = params.period || 14;
                indicator.params.smoothK = params.smoothK || 3;
                indicator.params.smoothD = params.smoothD || 3;
                indicator.overlay = false;
                applyStochasticStyleFromParams(indicator, params);
                indicator.name = 'Stoch(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateStochastic(this.data, indicator.params.period, indicator.params.smoothK, indicator.params.smoothD);
                break;
            
            case 'adr':
                indicator.params.period = Math.max(1, parseInt(params.period, 10) || 14);
                applyAdrStyleFromParams(indicator, params);
                indicator.name = 'ADR(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateADR(this.data, indicator.params.period);
                break;
            
            case 'volume':
                applyVolumeStyleFromParams(indicator, params);
                indicator.name = 'Volume';
                this.indicators.data[indicator.id] = { active: true };
                syncVolumeChartSettings(this, indicator);
                this.chartSettings.showVolume = true;
                if (typeof this._normalizeVolumeIndicatorLayout === 'function') {
                    this._normalizeVolumeIndicatorLayout();
                }
                // Show and setup volume indicator line in OHLC area
                this.setupVolumeIndicatorLine(indicator);
                break;
            
            case 'sessions':
                applySessionsFromParams(indicator, params);
                this.indicators.data[indicator.id] = calculateSessions(this.data, sessionsCalcPayload(indicator));
                break;
            
            case 'killzones':
            case 'ictkz':
                // Session visibility
                indicator.params.showCBDR = params.showCBDR !== false;
                indicator.params.showAsia = params.showAsia !== false;
                indicator.params.showLondon = params.showLondon !== false;
                indicator.params.showNYAM = params.showNYAM !== false;
                indicator.params.showLC = params.showLC !== false;
                indicator.params.showNYMidnight = params.showNYMidnight !== false;
                indicator.params.showMidline = params.showMidline !== false;
                indicator.params.showBoxInfo = params.showBoxInfo !== false;
                indicator.params.showDeviations = params.showDeviations || false;
                indicator.params.deviationCount = params.deviationCount || 2;
                indicator.params.boxTransparency = killzonesParseBoxTransparency(
                    params.boxTransparency,
                    indicator.params.boxTransparency != null ? indicator.params.boxTransparency : 88
                );
                // Session times (NY timezone)
                indicator.params.cbdrStart = params.cbdrStart || '14:00';
                indicator.params.cbdrEnd = params.cbdrEnd || '20:00';
                indicator.params.asiaStart = params.asiaStart || '20:00';
                indicator.params.asiaEnd = params.asiaEnd || '00:00';
                indicator.params.londonStart = params.londonStart || '02:00';
                indicator.params.londonEnd = params.londonEnd || '05:00';
                indicator.params.nyamStart = params.nyamStart || '07:00';
                indicator.params.nyamEnd = params.nyamEnd || '10:00';
                indicator.params.lcStart = params.lcStart || '10:00';
                indicator.params.lcEnd = params.lcEnd || '12:00';
                // Session colors
                indicator.style.cbdrColor = params.cbdrColor || '#0064ff';
                indicator.style.asiaColor = params.asiaColor || '#7622ff';
                indicator.style.londonColor = params.londonColor || '#e90000';
                indicator.style.nyamColor = params.nyamColor || '#00acb8';
                indicator.style.lcColor = params.lcColor || '#434651';
                indicator.style.nyMidnightColor = params.nyMidnightColor || '#2d62b6';
                indicator.style.textColor = params.textColor || '#5c71af';
                indicator.overlay = true;
                indicator.isKillzones = true;
                indicator.name = 'ICT Kill Zones';
                this.indicators.data[indicator.id] = calculateKillzones(this.data, {
                    showCBDR: indicator.params.showCBDR,
                    showAsia: indicator.params.showAsia,
                    showLondon: indicator.params.showLondon,
                    showNYAM: indicator.params.showNYAM,
                    showLC: indicator.params.showLC,
                    showNYMidnight: indicator.params.showNYMidnight,
                    showMidline: indicator.params.showMidline,
                    showBoxInfo: indicator.params.showBoxInfo,
                    showDeviations: indicator.params.showDeviations,
                    deviationCount: indicator.params.deviationCount,
                    boxTransparency: indicator.params.boxTransparency,
                    cbdrStart: indicator.params.cbdrStart,
                    cbdrEnd: indicator.params.cbdrEnd,
                    asiaStart: indicator.params.asiaStart,
                    asiaEnd: indicator.params.asiaEnd,
                    londonStart: indicator.params.londonStart,
                    londonEnd: indicator.params.londonEnd,
                    nyamStart: indicator.params.nyamStart,
                    nyamEnd: indicator.params.nyamEnd,
                    lcStart: indicator.params.lcStart,
                    lcEnd: indicator.params.lcEnd,
                    cbdrColor: indicator.style.cbdrColor,
                    asiaColor: indicator.style.asiaColor,
                    londonColor: indicator.style.londonColor,
                    nyamColor: indicator.style.nyamColor,
                    lcColor: indicator.style.lcColor,
                    nyMidnightColor: indicator.style.nyMidnightColor
                });
                break;

            case 'dema':
                applyDemaStyleFromParams(indicator, params);
                indicator.name = 'DEMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateDEMAOverlayData(this.data, indicator.params);
                break;
            case 'tema':
                applyTemaStyleFromParams(indicator, params);
                indicator.name = 'TEMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateTEMAOverlayData(this.data, indicator.params);
                break;
            case 'hma':
                applyHmaStyleFromParams(indicator, params);
                indicator.name = 'HMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateHMAOverlayData(this.data, indicator.params);
                break;
            case 'roc':
                indicator.overlay = false;
                indicator.separatePanel = true;
                applyRocStyleFromParams(indicator, params);
                indicator.name = 'ROC(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateROC(this.data, indicator.params.period, indicator.params.source);
                break;
            case 'mom':
            case 'momentum':
                indicator.type = 'mom';
                indicator.overlay = false;
                indicator.separatePanel = true;
                applyMomStyleFromParams(indicator, params);
                indicator.name = 'Mom(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateMomentum(this.data, indicator.params.period, indicator.params.source);
                break;
            case 'obv':
                applyObvStyleFromParams(indicator, params);
                indicator.name = 'OBV';
                this.indicators.data[indicator.id] = calculateOBVIndicatorData(this.data, indicator.params);
                break;
            case 'willr':
            case 'williams':
                indicator.type = 'willr';
                indicator.overlay = false;
                indicator.separatePanel = true;
                applyWillrStyleFromParams(indicator, params);
                indicator.name = 'Williams %R(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateWilliamsR(this.data, indicator.params.period, indicator.params.source);
                break;
            case 'mfi':
                applyMfiStyleFromParams(indicator, params);
                indicator.name = 'MFI(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateMFI(this.data, indicator.params.period);
                break;
            case 'donchian':
                indicator.params.period = params.period || 20;
                indicator.params.offset = params.offset != null ? Number(params.offset) : 0;
                indicator.overlay = true;
                applyDonchianStyleFromParams(indicator, params);
                indicator.name = 'Donchian(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateDonchian(this.data, indicator.params.period, indicator.params.offset);
                break;
            case 'keltner':
                applyKeltnerCalcParams(indicator, params);
                applyKeltnerStyleFromParams(indicator, params);
                indicator.name = 'Keltner(' + indicator.params.length + ')';
                this.indicators.data[indicator.id] = calculateKeltner(this.data, indicator.params);
                break;
            case 'aroon':
                indicator.params.period = params.period || 14;
                indicator.overlay = false;
                applyAroonStyleFromParams(indicator, params);
                indicator.name = 'Aroon(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateAroon(this.data, indicator.params.period);
                break;
            case 'cmf':
                applyCmfStyleFromParams(indicator, params);
                indicator.name = 'CMF(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateCMF(this.data, indicator.params.period);
                break;
            case 'trix':
                applyTrixStyleFromParams(indicator, params);
                indicator.name = 'TRIX(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateTRIX(this.data, indicator.params.period);
                break;
            case 'psar':
                applyPsarStyleFromParams(indicator, params);
                indicator.name = 'PSAR';
                this.indicators.data[indicator.id] = calculatePSAR(this.data, indicator.params);
                break;

            case 'sessionsplus':
                indicator.params.showSydney = params.showSydney !== false;
                indicator.params.showTokyo = params.showTokyo !== false;
                indicator.params.showAsian = params.showAsian !== false;
                indicator.params.showFrankfurt = params.showFrankfurt !== false;
                indicator.params.showLondon = params.showLondon !== false;
                indicator.params.showNewYork = params.showNewYork !== false;
                indicator.params.sydneyStart = params.sydneyStart || '21:00';
                indicator.params.sydneyEnd = params.sydneyEnd || '06:00';
                indicator.params.tokyoStart = params.tokyoStart || '00:00';
                indicator.params.tokyoEnd = params.tokyoEnd || '09:00';
                indicator.params.asianStart = params.asianStart || '00:00';
                indicator.params.asianEnd = params.asianEnd || '09:00';
                indicator.params.frankfurtStart = params.frankfurtStart || '07:00';
                indicator.params.frankfurtEnd = params.frankfurtEnd || '10:00';
                indicator.params.londonStart = params.londonStart || '08:00';
                indicator.params.londonEnd = params.londonEnd || '16:00';
                indicator.params.newYorkStart = params.newYorkStart || '13:00';
                indicator.params.newYorkEnd = params.newYorkEnd || '21:00';
                indicator.style.sydneyColor = params.sydneyColor || 'rgba(156, 39, 176, 0.14)';
                indicator.style.tokyoColor = params.tokyoColor || 'rgba(255, 152, 0, 0.14)';
                indicator.style.asianColor = params.asianColor || 'rgba(255, 193, 7, 0.12)';
                indicator.style.frankfurtColor = params.frankfurtColor || 'rgba(3, 169, 244, 0.14)';
                indicator.style.londonColor = params.londonColor || 'rgba(33, 150, 243, 0.14)';
                indicator.style.newYorkColor = params.newYorkColor || 'rgba(76, 175, 80, 0.14)';
                indicator.overlay = true;
                indicator.isSessionsPlus = true;
                indicator.name = 'Sessions+';
                this.indicators.data[indicator.id] = calculateSessionsPlus(this.data, {
                    showSydney: indicator.params.showSydney,
                    showTokyo: indicator.params.showTokyo,
                    showAsian: indicator.params.showAsian,
                    showFrankfurt: indicator.params.showFrankfurt,
                    showLondon: indicator.params.showLondon,
                    showNewYork: indicator.params.showNewYork,
                    sydneyStart: indicator.params.sydneyStart,
                    sydneyEnd: indicator.params.sydneyEnd,
                    tokyoStart: indicator.params.tokyoStart,
                    tokyoEnd: indicator.params.tokyoEnd,
                    asianStart: indicator.params.asianStart,
                    asianEnd: indicator.params.asianEnd,
                    frankfurtStart: indicator.params.frankfurtStart,
                    frankfurtEnd: indicator.params.frankfurtEnd,
                    londonStart: indicator.params.londonStart,
                    londonEnd: indicator.params.londonEnd,
                    newYorkStart: indicator.params.newYorkStart,
                    newYorkEnd: indicator.params.newYorkEnd,
                    sydneyColor: indicator.style.sydneyColor,
                    tokyoColor: indicator.style.tokyoColor,
                    asianColor: indicator.style.asianColor,
                    frankfurtColor: indicator.style.frankfurtColor,
                    londonColor: indicator.style.londonColor,
                    newYorkColor: indicator.style.newYorkColor
                });
                break;

            case 'openingrange':
            case 'or':
                applyOpeningRangeStyleFromParams(indicator, params);
                indicator.type = 'openingrange';
                indicator.name = 'Opening Range(' + indicator.params.rangeStart + '-' + indicator.params.rangeEnd + ')';
                this.indicators.data[indicator.id] = calculateOpeningRange(this.data, indicator.params);
                break;

            case 'supertrend':
                indicator.params.period = params.period != null ? params.period : 10;
                indicator.params.multiplier = params.multiplier != null ? params.multiplier : 3;
                applySupertrendStyleFromParams(indicator, params);
                indicator.overlay = true;
                indicator.name = 'Supertrend(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateSupertrend(this.data, indicator.params.period, indicator.params.multiplier);
                break;

            case 'stddev':
                applyStddevStyleFromParams(indicator, params);
                indicator.name = 'StdDev(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateStdDevLine(this.data, indicator.params.period, indicator.params.source);
                break;

            case 'ao':
                applyAoStyleFromParams(indicator, params);
                indicator.name = 'AO(' + indicator.params.fastLength + ',' + indicator.params.slowLength + ')';
                this.indicators.data[indicator.id] = calculateAO(this.data, indicator.params.fastLength, indicator.params.slowLength);
                break;

            case 'uo':
                applyUoStyleFromParams(indicator, params);
                indicator.name = 'Ultimate Oscillator';
                this.indicators.data[indicator.id] = calculateUltimateOscillator(this.data, indicator.params.period1, indicator.params.period2, indicator.params.period3);
                break;

            case 'vortex':
                applyVortexStyleFromParams(indicator, params);
                indicator.name = 'Vortex(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateVortex(this.data, indicator.params.period);
                break;

            case 'ppo':
                indicator.type = 'macd';
                indicator.overlay = false;
                indicator.separatePanel = true;
                applyMacdStyleFromParams(indicator, params);
                indicator.name = 'MACD(' + indicator.params.fast + ',' + indicator.params.slow + ',' + indicator.params.signal + ')';
                this.indicators.data[indicator.id] = calculateMACD(
                    this.data,
                    indicator.params.fast,
                    indicator.params.slow,
                    indicator.params.signal,
                    indicator.params.source,
                    {
                        oscillatorMaType: indicator.params.oscillatorMaType,
                        signalMaType: indicator.params.signalMaType
                    }
                );
                break;

            case 'dpo':
                indicator.overlay = false;
                indicator.separatePanel = true;
                applyDpoStyleFromParams(indicator, params);
                indicator.name = 'DPO(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateDPO(this.data, indicator.params.period, indicator.params.centered === true);
                break;

            case 'stochrsi':
                indicator.params.rsiPeriod = params.rsiPeriod != null ? params.rsiPeriod : 14;
                indicator.params.source = params.source || 'close';
                indicator.params.stochLen = params.stochLen != null ? params.stochLen : 14;
                indicator.params.smoothK = params.smoothK != null ? params.smoothK : 3;
                indicator.params.smoothD = params.smoothD != null ? params.smoothD : 3;
                indicator.overlay = false;
                applyStochasticStyleFromParams(indicator, params);
                indicator.name = 'Stoch RSI(' + indicator.params.rsiPeriod + ',' + indicator.params.stochLen + ')';
                this.indicators.data[indicator.id] = calculateStochRSI(
                    this.data,
                    indicator.params.rsiPeriod,
                    indicator.params.stochLen,
                    indicator.params.smoothK,
                    indicator.params.smoothD,
                    indicator.params.source
                );
                break;

            case 'massindex':
                indicator.params.period = massIndexPeriodFromParams(params);
                applyMassIndexStyleFromParams(indicator, params);
                indicator.name = 'Mass Index(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateMassIndex(
                    this.data,
                    MASS_INDEX_EMA_PERIOD,
                    indicator.params.period
                );
                break;

            case 'coppock':
                applyCoppockStyleFromParams(indicator, params);
                indicator.name = 'Coppock Curve';
                this.indicators.data[indicator.id] = calculateCoppock(this.data, indicator.params);
                break;

            case 'rvi':
                applyRviStyleFromParams(indicator, params);
                indicator.name = 'RVI(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateRVI(this.data, indicator.params.period);
                break;

            case 'elderray':
                indicator.params.period = params.period || 13;
                applyElderRayStyleFromParams(indicator, params);
                indicator.name = 'Elder Ray(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateElderRay(this.data, indicator.params.period);
                break;

            case 'seasonality':
                indicator.params.minSamples = params.minSamples != null ? Math.max(1, parseInt(params.minSamples, 10) || 2) : 2;
                indicator.style.color = params.color || '#ff9800';
                indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : 2;
                indicator.overlay = false;
                indicator.separatePanel = true;
                indicator.name = 'Seasonality (avg % by date)';
                this.indicators.data[indicator.id] = calculateSeasonality(this.data, indicator.params.minSamples);
                break;

            case 'cotnet':
                applyCotNetStyleFromParams(indicator, params);
                indicator.name = 'COT net comm vs non-comm';
                this.indicators.data[indicator.id] = { loading: true, error: null };
                break;

            case 'ictpd':
                indicator.style.upperColor = params.upperColor || '#2962ff';
                indicator.style.middleColor = params.middleColor || '#787b86';
                indicator.style.lowerColor = params.lowerColor || '#2962ff';
                indicator.style.fillColor = params.fillColor || 'rgba(41, 98, 255, 0.04)';
                indicator.style.lineWidth = params.lineWidth || 1;
                indicator.overlay = true;
                indicator.name = 'ICT Prev Day PD';
                this.indicators.data[indicator.id] = calculateIctPrevDayPD(this.data);
                break;

            case 'ictasian':
                indicator.params.rangeStart = params.rangeStart || '00:00';
                indicator.params.rangeEnd = params.rangeEnd || '09:00';
                indicator.style.upperColor = params.upperColor || '#ff9800';
                indicator.style.middleColor = params.middleColor || '#787b86';
                indicator.style.lowerColor = params.lowerColor || '#ff9800';
                indicator.style.fillColor = params.fillColor || 'rgba(255, 152, 0, 0.06)';
                indicator.style.lineWidth = params.lineWidth || 1;
                indicator.overlay = true;
                indicator.name = 'ICT Asian Range';
                this.indicators.data[indicator.id] = calculateIctAsianRange(this.data, {
                    rangeStart: indicator.params.rangeStart,
                    rangeEnd: indicator.params.rangeEnd
                });
                break;

            case 'ictote':
                indicator.params.lookback = params.lookback != null ? params.lookback : 24;
                indicator.params.fibLow = params.fibLow != null ? params.fibLow : 0.62;
                indicator.params.fibHigh = params.fibHigh != null ? params.fibHigh : 0.79;
                indicator.style.upperColor = params.upperColor || '#7c4dff';
                indicator.style.middleColor = params.middleColor || '#787b86';
                indicator.style.lowerColor = params.lowerColor || '#7c4dff';
                indicator.style.fillColor = params.fillColor || 'rgba(124, 77, 255, 0.08)';
                indicator.style.lineWidth = params.lineWidth || 1;
                indicator.overlay = true;
                indicator.name = 'ICT OTE Zone';
                this.indicators.data[indicator.id] = calculateIctOTE(
                    this.data,
                    indicator.params.lookback,
                    indicator.params.fibLow,
                    indicator.params.fibHigh
                );
                break;

            case 'ictfvg':
                indicator.params.extendBars = params.extendBars != null ? params.extendBars : 80;
                indicator.params.maxBoxes = params.maxBoxes != null ? params.maxBoxes : 120;
                indicator.params.minGapPct = params.minGapPct != null ? params.minGapPct : 0;
                indicator.style.bullColor = params.bullColor || 'rgba(38, 166, 154, 0.22)';
                indicator.style.bearColor = params.bearColor || 'rgba(239, 83, 80, 0.22)';
                indicator.style.lineWidth = params.lineWidth || 1;
                indicator.overlay = true;
                indicator.isIctFvg = true;
                indicator.name = 'ICT Fair Value Gaps';
                this.indicators.data[indicator.id] = calculateFairValueGaps(this.data, {
                    extendBars: indicator.params.extendBars,
                    maxBoxes: indicator.params.maxBoxes,
                    minGapPct: indicator.params.minGapPct
                });
                break;

            case 'ictsesspd':
                indicator.params.rangeStart = params.rangeStart || '13:00';
                indicator.params.rangeEnd = params.rangeEnd || '21:00';
                indicator.params.maxLookbackDays = params.maxLookbackDays != null ? params.maxLookbackDays : 6;
                indicator.style.upperColor = params.upperColor || '#00e676';
                indicator.style.middleColor = params.middleColor || '#787b86';
                indicator.style.lowerColor = params.lowerColor || '#f23645';
                indicator.style.fillColor = params.fillColor || 'rgba(0, 230, 118, 0.05)';
                indicator.style.lineWidth = params.lineWidth || 1;
                indicator.overlay = true;
                indicator.name = 'ICT Session PD';
                this.indicators.data[indicator.id] = calculateIctSessionPrevDayPD(this.data, {
                    rangeStart: indicator.params.rangeStart,
                    rangeEnd: indicator.params.rangeEnd,
                    maxLookbackDays: indicator.params.maxLookbackDays
                });
                break;

            case 'ictliquidity':
                indicator.params.fractalWidth = params.fractalWidth != null ? params.fractalWidth : 2;
                indicator.params.tolerancePct = params.tolerancePct != null ? params.tolerancePct : 0.03;
                indicator.params.minTouches = params.minTouches != null ? params.minTouches : 2;
                indicator.params.maxSegments = params.maxSegments != null ? params.maxSegments : 80;
                indicator.params.extendBars = params.extendBars != null ? params.extendBars : 12;
                indicator.style.highColor = params.highColor || '#f23645';
                indicator.style.lowColor = params.lowColor || '#2962ff';
                indicator.style.lineWidth = params.lineWidth != null ? params.lineWidth : 1;
                indicator.overlay = true;
                indicator.isLiquidityEq = true;
                indicator.name = 'ICT Equal L/H Liquidity';
                this.indicators.data[indicator.id] = calculateLiquidityEqualLevels(this.data, {
                    fractalWidth: indicator.params.fractalWidth,
                    tolerancePct: indicator.params.tolerancePct,
                    minTouches: indicator.params.minTouches,
                    maxSegments: indicator.params.maxSegments,
                    extendBars: indicator.params.extendBars
                });
                break;

            case 'icteverything':
                indicator.overlay = true;
                indicator.isIctEverything = true;
                indicator.name = 'ICT Everything';
                indicator.params = indicator.params || {};
                var ieDefAdd = (typeof window !== 'undefined' && window.INDICATOR_DEFINITIONS && window.INDICATOR_DEFINITIONS.icteverything)
                    ? window.INDICATOR_DEFINITIONS.icteverything
                    : null;
                if (ieDefAdd && ieDefAdd.params) {
                    ieDefAdd.params.forEach(function(p) {
                        if (p.type === 'heading' || p.type === 'divider') return;
                        var raw = params[p.id] !== undefined ? params[p.id] : p.default;
                        if (p.type === 'checkbox') raw = !!raw;
                        else if (p.type === 'number') {
                            raw = parseFloat(raw);
                            if (isNaN(raw)) raw = p.default;
                        }
                        indicator.params[p.id] = raw;
                    });
                }
                this.indicators.data[indicator.id] = calculateIctEverything(this.data, indicator);
                break;

            case 'talariafvg':
                indicator.overlay = true;
                indicator.isTalariaFvg = true;
                indicator.name = 'Talaria — FVG';
                indicator.params = indicator.params || {};
                _applyIndicatorDefParams(indicator, 'talariafvg', params);
                this.indicators.data[indicator.id] = calculateTalariaFvgIndicator(this.data, indicator, this);
                break;

            case 'talariaratiogap':
                indicator.overlay = true;
                indicator.isTalariaRatioGap = true;
                indicator.name = 'Talaria — Ratio + Gap';
                indicator.params = indicator.params || {};
                _applyIndicatorDefParams(indicator, 'talariaratiogap', params);
                this.indicators.data[indicator.id] = calculateTalariaRatioGapIndicator(this.data, indicator);
                break;

            case 'talariaweeklymap':
                indicator.overlay = true;
                indicator.isTalariaWeeklyMap = true;
                indicator.name = 'Talaria — Weekly Map';
                indicator.params = indicator.params || {};
                _applyIndicatorDefParams(indicator, 'talariaweeklymap', params);
                this.indicators.data[indicator.id] = calculateTalariaWeeklyMapIndicator(this.data, indicator, this);
                break;

            case 'talariasmc':
                indicator.overlay = true;
                indicator.isTalariaSimpleSmc = true;
                indicator.name = 'Talaria — Simple SMC';
                indicator.params = indicator.params || {};
                _applyIndicatorDefParams(indicator, 'talariasmc', params);
                this.indicators.data[indicator.id] = calculateTalariaSimpleSmcIndicator(this.data, indicator, this);
                break;

            case 'custom': {
                const TC = global.TalariaCustomIndicators;
                if (!TC) {
                    if (typeof this.showNotification === 'function') {
                        this.showNotification('Custom indicators runtime not loaded');
                    }
                    addAborted = true;
                    return;
                }
                const script = params.script;
                if (!script || typeof script !== 'string') {
                    if (typeof this.showNotification === 'function') {
                        this.showNotification('Custom indicator: script required');
                    }
                    addAborted = true;
                    return;
                }
                if (script.length > TC.MAX_SCRIPT_CHARS) {
                    if (typeof this.showNotification === 'function') {
                        this.showNotification('Custom script exceeds size limit (' + TC.MAX_SCRIPT_CHARS + ' chars)');
                    }
                    addAborted = true;
                    return;
                }
                if (typeof TC.validateCustomScriptSource === 'function') {
                    const check = TC.validateCustomScriptSource(script);
                    if (!check.ok) {
                        if (typeof this.showNotification === 'function') {
                            this.showNotification(check.error || 'Invalid script');
                        }
                        addAborted = true;
                        return;
                    }
                }
                indicator.isCustomScript = true;
                indicator.params.script = script;
                indicator.params.customParams = params.customParams && typeof params.customParams === 'object' ? params.customParams : {};
                indicator.params.customApiVersion = params.customApiVersion != null ? params.customApiVersion : TC.API_VERSION;
                indicator.params.timeoutMs = params.timeoutMs != null ? params.timeoutMs : TC.DEFAULT_TIMEOUT_MS;
                indicator.name = params.name || 'Custom';
                const overlayOn = params.overlay !== false && params.separatePanel !== true;
                indicator.overlay = overlayOn;
                indicator.separatePanel = params.separatePanel === true || !overlayOn;
                this.indicators.data[indicator.id] = {
                    loading: true,
                    plots: [],
                    error: null,
                    overlay: overlayOn
                };
                break;
            }
                
            default:
                addAborted = true;
                return;
        }
        }).call(chartRef);

        if (addAborted) {
            chartRef.indicators.active = chartRef.indicators.active.filter(function(i) {
                return i && i.id !== indicator.id;
            });
            if (chartRef.indicators.data) delete chartRef.indicators.data[indicator.id];
            indicator._calculating = false;
            if (typeof chartRef.updateOHLCIndicators === 'function') chartRef.updateOHLCIndicators();
            if (typeof chartRef._updateIndicatorPanelHeight === 'function') chartRef._updateIndicatorPanelHeight();
            return;
        }
        
        if (indicator.type === 'custom' && typeof chartRef._scheduleCustomIndicatorCompute === 'function') {
            chartRef._scheduleCustomIndicatorCompute(indicator);
        }
        if (indicator.type === 'cotnet' && typeof chartRef._scheduleCotNetLoad === 'function') {
            chartRef._scheduleCotNetLoad(indicator);
        }
        chartRef._updateIndicatorPanelHeight();
        clampIndicatorStyleLineWidths(indicator.style);
        if (indicator.type !== 'custom' && indicator.type !== 'cotnet') {
            indicator._calculating = false;
        }

        if (typeof chartRef.bumpIndicatorRenderVersion === 'function') {
            chartRef.bumpIndicatorRenderVersion();
        }
        if (typeof chartRef.scheduleRender === 'function') {
            chartRef.scheduleRender();
        } else if (typeof chartRef.render === 'function') {
            chartRef.render();
        }

        chartRef.updateOHLCIndicators();
        chartRef.persistIndicators();
        emitIndicatorsChanged(chartRef, 'add', indicator);
        })();
        
        return indicator;
    };

    Chart.prototype.persistIndicators = function(options) {
        options = options || {};
        if (!this.indicators || !Array.isArray(this.indicators.active)) return;
        const TC = global.TalariaCustomIndicators;
        const maxScript = TC && TC.MAX_SCRIPT_CHARS ? TC.MAX_SCRIPT_CHARS : 48000;
        const snapshot = this.indicators.active.map(function(ind) {
            const base = {
                type: ind.type,
                name: ind.name,
                params: Object.assign({}, ind.params || {}),
                style: Object.assign({}, ind.style || {}),
                visible: ind.visible !== false,
                overlay: ind.overlay,
                separatePanel: ind.separatePanel,
                isVolume: ind.isVolume || false,
            };
            if (ind.visibility && typeof ind.visibility === 'object') {
                try {
                    base.visibility = JSON.parse(JSON.stringify(ind.visibility));
                } catch (_) {}
            }
            if (ind.type === 'custom' && base.params && typeof base.params.script === 'string') {
                if (base.params.script.length > maxScript) {
                    base.params.script = base.params.script.slice(0, maxScript);
                    base.params.customScriptTruncated = true;
                }
                base.isCustomScript = true;
            }
            return base;
        });
        if (typeof global.shouldBlockIndicatorPersistSnapshot === 'function'
            && global.shouldBlockIndicatorPersistSnapshot(this, snapshot, options)) {
            return;
        }
        // During session restore, an empty in-memory list must not wipe saved indicators
        // before _applyPersistedIndicators runs — unless the user explicitly cleared them.
        if (!options.force && snapshot.length === 0) {
            if (this._pendingIndicatorsState
                && Array.isArray(this._pendingIndicatorsState)
                && this._pendingIndicatorsState.length > 0) {
                return;
            }
            if (this._sessionIndicatorsRestoreGuardUntil
                && Date.now() < this._sessionIndicatorsRestoreGuardUntil) {
                return;
            }
        }
        if (typeof this.scheduleSessionStateSave === 'function') {
            this.scheduleSessionStateSave({ indicators: snapshot });
        }
        if (options.force) {
            if (snapshot.length === 0) {
                this._indicatorsClearedAt = Date.now();
            } else {
                this._indicatorsClearedAt = null;
            }
            if (typeof this.queueCriticalSessionStateSave === 'function') {
                this.queueCriticalSessionStateSave({ indicators: snapshot });
            }
            if (typeof this._writeTradingSessionLocalBackupThrottled === 'function') {
                this._writeTradingSessionLocalBackupThrottled({ force: true });
            }
        } else if (snapshot.length > 0) {
            this._indicatorsClearedAt = null;
            if (typeof this._writeTradingSessionLocalBackupThrottled === 'function') {
                this._writeTradingSessionLocalBackupThrottled({ force: true });
            }
        } else if (typeof this._writeTradingSessionLocalBackupThrottled === 'function') {
            this._writeTradingSessionLocalBackupThrottled();
        }
    };

    Chart.prototype.addCustomIndicator = function(opts) {
        opts = opts || {};
        return this.addIndicator('custom', opts);
    };

    Chart.prototype._scheduleCustomIndicatorCompute = function(indicator) {
        const self = this;
        const TC = global.TalariaCustomIndicators;
        if (!TC || !indicator || indicator.type !== 'custom') return;
        const script = indicator.params && indicator.params.script;
        if (!script || typeof script !== 'string') {
            this.indicators.data[indicator.id] = {
                loading: false,
                plots: [],
                error: 'No script',
                overlay: indicator.overlay !== false
            };
            return;
        }
        if (typeof TC.validateCustomScriptSource === 'function') {
            const check = TC.validateCustomScriptSource(script);
            if (!check.ok) {
                this.indicators.data[indicator.id] = {
                    loading: false,
                    plots: [],
                    error: check.error || 'Invalid script',
                    overlay: indicator.overlay !== false
                };
                indicator._calculating = false;
                if (typeof self._commitIndicatorVisualChange === 'function') self._commitIndicatorVisualChange();
                else if (typeof self.render === 'function') self.render();
                return;
            }
        }
        const bars = TC.serializeBarsFromChartData(this.data);
        const userParams = indicator.params.customParams && typeof indicator.params.customParams === 'object'
            ? indicator.params.customParams
            : {};
        const timeoutMs = indicator.params.timeoutMs != null ? indicator.params.timeoutMs : TC.DEFAULT_TIMEOUT_MS;
        this.indicators.data[indicator.id] = {
            loading: true,
            plots: [],
            error: null,
            overlay: indicator.overlay !== false
        };
        TC.runCompute(script, bars, userParams, timeoutMs).then(function(result) {
            if (!self.indicators || !self.indicators.active) return;
            const still = self.indicators.active.some(function(i) {
                return i.id === indicator.id;
            });
            if (!still) return;
            const wantPanel = indicator.params && indicator.params.separatePanel === true;
            if (wantPanel) {
                indicator.overlay = false;
                indicator.separatePanel = true;
            } else {
                indicator.overlay = result.overlay !== false;
                indicator.separatePanel = result.overlay === false;
            }
            self.indicators.data[indicator.id] = {
                loading: false,
                plots: result.plots,
                error: null,
                overlay: indicator.overlay !== false
            };
            if (typeof self._updateIndicatorPanelHeight === 'function') {
                self._updateIndicatorPanelHeight();
            }
            if (typeof self.bumpIndicatorRenderVersion === 'function') self.bumpIndicatorRenderVersion();
            if (typeof self.updateOHLCIndicators === 'function') self.updateOHLCIndicators();
            if (typeof self.scheduleRender === 'function') self.scheduleRender();
            else if (typeof self.render === 'function') self.render();
            self.persistIndicators();
        }).catch(function(err) {
            if (!self.indicators || !self.indicators.active) return;
            const still = self.indicators.active.some(function(i) {
                return i.id === indicator.id;
            });
            if (!still) return;
            self.indicators.data[indicator.id] = {
                loading: false,
                plots: [],
                error: err && err.message ? err.message : String(err),
                overlay: indicator.overlay !== false
            };
            indicator._calculating = false;
            if (typeof self._commitIndicatorVisualChange === 'function') self._commitIndicatorVisualChange();
            else if (typeof self.render === 'function') self.render();
            if (typeof self.updateOHLCIndicators === 'function') self.updateOHLCIndicators();
            if (typeof self.showNotification === 'function') {
                self.showNotification('Custom indicator: ' + (err && err.message ? err.message : 'error'));
            }
        });
    };

    Chart.prototype._scheduleCotNetLoad = function(indicator) {
        const self = this;
        const params = indicator.params || {};
        const url = (params.dataUrl && String(params.dataUrl).trim()) || '';

        function applyMerged(merged, note, marketName, resolvedMeta) {
            if (!self.indicators || !self.indicators.active) return;
            const still = self.indicators.active.some(function(i) { return i.id === indicator.id; });
            if (!still) return;
            const rm = resolvedMeta || {};
            self.indicators.data[indicator.id] = {
                loading: false,
                error: null,
                bull: merged.bull,
                bear: merged.bear,
                _cotNote: note || '',
                _cotMarket: marketName || '',
                _cotRoot: rm.root || '',
                _cotCodeUsed: rm.code || ''
            };
            if (typeof self._updateIndicatorPanelHeight === 'function') self._updateIndicatorPanelHeight();
            indicator._calculating = false;
            if (typeof self._commitIndicatorVisualChange === 'function') self._commitIndicatorVisualChange();
            else if (typeof self.render === 'function') self.render();
            if (typeof self.updateOHLCIndicators === 'function') self.updateOHLCIndicators();
            if (typeof self.persistIndicators === 'function') self.persistIndicators();
        }

        function fail(msg) {
            if (!self.indicators || !self.indicators.active) return;
            const still = self.indicators.active.some(function(i) { return i.id === indicator.id; });
            if (!still) return;
            self.indicators.data[indicator.id] = { loading: false, error: msg, bull: null, bear: null };
            indicator._calculating = false;
            if (typeof self._commitIndicatorVisualChange === 'function') self._commitIndicatorVisualChange();
            else if (typeof self.render === 'function') self.render();
            if (typeof self.updateOHLCIndicators === 'function') self.updateOHLCIndicators();
        }

        if (!this.data || this.data.length === 0) {
            fail('No chart data');
            return;
        }

        if (url) {
            fetch(url, { credentials: 'same-origin', mode: 'cors' })
                .then(function(r) {
                    if (!r.ok) throw new Error('HTTP ' + r.status);
                    return r.json();
                })
                .then(function(json) {
                    const raw = json && json.points != null ? json.points : json;
                    if (!Array.isArray(raw)) throw new Error('JSON must be an array or { points: [] }');
                    const pts = [];
                    for (let i = 0; i < raw.length; i++) {
                        const np = normalizeCotNetPoint(raw[i]);
                        if (np) pts.push(np);
                    }
                    if (pts.length === 0) throw new Error('No valid COT points');
                    applyMerged(mergeCotNetPointsToBars(self.data, pts), 'file', '');
                })
                .catch(function(e) {
                    fail(e && e.message ? e.message : String(e));
                    if (typeof self.showNotification === 'function') {
                        self.showNotification('COT: ' + (e && e.message ? e.message : 'load failed'));
                    }
                });
            return;
        }

        let apiUrl;
        let resolvedCot;
        try {
            resolvedCot = cotNetResolveCftcCode(self, params);
            apiUrl = cotNetBuildCftcLegacyUrl(resolvedCot.code);
        } catch (e) {
            fail(e && e.message ? e.message : String(e));
            return;
        }

        fetch(apiUrl, { mode: 'cors' })
            .then(function(r) {
                if (!r.ok) throw new Error('CFTC API HTTP ' + r.status);
                return r.json();
            })
            .then(function(rows) {
                if (!Array.isArray(rows) || rows.length === 0) {
                    throw new Error('No COT rows for cftcCode — check code at cftc.gov Public Reporting');
                }
                const parsed = cotNetCftcRowsToPoints(rows);
                if (!parsed.points.length) throw new Error('Could not parse COT positions');
                applyMerged(mergeCotNetPointsToBars(self.data, parsed.points), 'cftc', parsed.marketName, resolvedCot);
            })
            .catch(function(e) {
                fail(e && e.message ? e.message : String(e));
                if (typeof self.showNotification === 'function') {
                    self.showNotification('COT: ' + (e && e.message ? e.message : 'CFTC fetch failed'));
                }
            });
    };
    
    Chart.prototype.updateIndicator = function(id, newParams) {
        const indicator = this.indicators.active.find(function(ind) {
            return ind.id === id;
        });
        
        if (!indicator) {
            return;
        }

        indicator.type = String(indicator.type || '').toLowerCase();

        const prevMerged = Object.assign({}, indicator.style || {}, indicator.params || {});

        newParams = newParams || {};
        newParams = sanitizeIndicatorRuntimePayload(indicator, Object.assign({}, newParams));

        const needsDataRecalc = typeof window.__v9IndicatorUpdateNeedsDataRecalc === 'function'
            ? window.__v9IndicatorUpdateNeedsDataRecalc(indicator.type, newParams, prevMerged)
            : true;

        if (typeof window.__v9IndicatorPanelReferenceLevelChanged === 'function'
            && window.__v9IndicatorPanelReferenceLevelChanged(newParams, prevMerged)
            && typeof this._resetIndicatorPanelAutoscale === 'function') {
            this._resetIndicatorPanelAutoscale(indicator);
        }
        
        if (newParams.visible !== undefined) {
            indicator.visible = newParams.visible !== false;
        }
        
        if (newParams.visibility !== undefined && newParams.visibility !== null) {
            indicator.visibility = newParams.visibility;
        }
        
        // Update parameters
        if (newParams.period !== undefined) indicator.params.period = newParams.period;
        if (newParams.multiplier !== undefined) {
            const mult = Number(newParams.multiplier);
            indicator.params.multiplier = Number.isFinite(mult) ? mult : 3;
        }
        if (newParams.stdDev !== undefined) indicator.params.stdDev = newParams.stdDev;
        if (newParams.offset !== undefined) indicator.params.offset = Number(newParams.offset) || 0;
        if (newParams.maType !== undefined) indicator.params.maType = newParams.maType;
        if (newParams.fast !== undefined) indicator.params.fast = newParams.fast;
        if (newParams.slow !== undefined) indicator.params.slow = newParams.slow;
        if (newParams.signal !== undefined) indicator.params.signal = newParams.signal;
        if (newParams.smoothK !== undefined) indicator.params.smoothK = newParams.smoothK;
        if (newParams.smoothD !== undefined) indicator.params.smoothD = newParams.smoothD;
        
        // Update colors
        if (newParams.color !== undefined) indicator.style.color = newParams.color;
        if (newParams.upperColor !== undefined) indicator.style.upperColor = newParams.upperColor;
        if (newParams.middleColor !== undefined) indicator.style.middleColor = newParams.middleColor;
        if (newParams.lowerColor !== undefined) indicator.style.lowerColor = newParams.lowerColor;
        if (newParams.fillColor !== undefined) indicator.style.fillColor = newParams.fillColor;
        if (newParams.fillOpacity !== undefined) indicator.style.fillOpacity = newParams.fillOpacity;
        if (newParams.showMiddle !== undefined) indicator.style.showMiddle = newParams.showMiddle !== false;
        if (newParams.showUpper !== undefined) indicator.style.showUpper = newParams.showUpper !== false;
        if (newParams.showLower !== undefined) indicator.style.showLower = newParams.showLower !== false;
        if (newParams.showFill !== undefined) indicator.style.showFill = newParams.showFill !== false;
        if (newParams.showBg !== undefined) indicator.style.showBg = newParams.showBg === true;
        if (newParams.bgColor !== undefined) indicator.style.bgColor = newParams.bgColor;
        if (newParams.showSmoothMa !== undefined) indicator.style.showSmoothMa = newParams.showSmoothMa === true;
        if (newParams.showSmoothEma !== undefined) indicator.style.showSmoothEma = newParams.showSmoothEma === true;
        if (newParams.smoothColor !== undefined) indicator.style.smoothColor = newParams.smoothColor;
        if (newParams.smoothLineWidth !== undefined) indicator.style.smoothLineWidth = newParams.smoothLineWidth;
        if (newParams.smoothLineStyle !== undefined) indicator.style.smoothLineStyle = newParams.smoothLineStyle;
        if (newParams.middleLineWidth !== undefined) indicator.style.middleLineWidth = newParams.middleLineWidth;
        if (newParams.upperLineWidth !== undefined) indicator.style.upperLineWidth = newParams.upperLineWidth;
        if (newParams.lowerLineWidth !== undefined) indicator.style.lowerLineWidth = newParams.lowerLineWidth;
        if (newParams.middleLineStyle !== undefined) indicator.style.middleLineStyle = newParams.middleLineStyle;
        if (newParams.upperLineStyle !== undefined) indicator.style.upperLineStyle = newParams.upperLineStyle;
        if (newParams.lowerLineStyle !== undefined) indicator.style.lowerLineStyle = newParams.lowerLineStyle;
        if (newParams.macdColor !== undefined) indicator.style.macdColor = newParams.macdColor;
        if (newParams.signalColor !== undefined) indicator.style.signalColor = newParams.signalColor;
        if (newParams.histogramColor !== undefined) indicator.style.histogramColor = newParams.histogramColor;
        if (newParams.kColor !== undefined) indicator.style.kColor = newParams.kColor;
        if (newParams.dColor !== undefined) indicator.style.dColor = newParams.dColor;
        if (newParams.upColor !== undefined) indicator.style.upColor = newParams.upColor;
        if (newParams.downColor !== undefined) indicator.style.downColor = newParams.downColor;
        if (newParams.lineWidth !== undefined) indicator.style.lineWidth = newParams.lineWidth;
        if (newParams.lineStyle !== undefined) indicator.style.lineStyle = newParams.lineStyle;
        if (newParams.showLine !== undefined) {
            indicator.style.showLine = newParams.showLine !== false;
            if (indicator.style.showLine === false
                && this.selectedOverlayIndicatorId != null
                && String(this.selectedOverlayIndicatorId) === String(indicator.id)) {
                this.clearOverlayIndicatorSelection();
            }
            if (typeof this.bumpIndicatorRenderVersion === 'function') {
                this.bumpIndicatorRenderVersion();
            }
        }
        if (newParams.hideFromContainer !== undefined) {
            indicator.hidePlot = newParams.hideFromContainer === true;
            if (typeof this.bumpIndicatorRenderVersion === 'function') {
                this.bumpIndicatorRenderVersion();
            }
        }
        if (newParams.showLabel !== undefined) indicator.style.showLabel = newParams.showLabel !== false;
        if (newParams.source !== undefined) indicator.params.source = newParams.source;
        if (newParams.smoothingType !== undefined) indicator.params.smoothingType = newParams.smoothingType;
        if (newParams.smoothingLength !== undefined) {
            indicator.params.smoothingLength = safeIndicatorNumber(newParams.smoothingLength, 14);
        }
        if (newParams.bbStdDev !== undefined) {
            indicator.params.bbStdDev = safeIndicatorNumber(newParams.bbStdDev, 2);
        }
        if (newParams.length !== undefined) indicator.params.length = newParams.length;
        if (newParams.atrLength !== undefined) indicator.params.atrLength = newParams.atrLength;
        if (newParams.useExponentialMa !== undefined) indicator.params.useExponentialMa = newParams.useExponentialMa !== false;
        if (newParams.bandsStyle !== undefined) indicator.params.bandsStyle = newParams.bandsStyle;
        if (newParams.emaPeriod !== undefined) indicator.params.emaPeriod = newParams.emaPeriod;
        if (newParams.atrPeriod !== undefined) indicator.params.atrPeriod = newParams.atrPeriod;
        if (newParams.offset !== undefined) indicator.params.offset = Number(newParams.offset) || 0;
        if (newParams.start !== undefined) indicator.params.start = newParams.start;
        if (newParams.increment !== undefined) indicator.params.increment = newParams.increment;
        if (newParams.maxStep !== undefined) indicator.params.maxStep = newParams.maxStep;
        if (newParams.step !== undefined) indicator.params.start = newParams.step;
        if (newParams.bullColor !== undefined) indicator.style.bullColor = newParams.bullColor;
        if (newParams.bearColor !== undefined) indicator.style.bearColor = newParams.bearColor;
        if (newParams.plusColor !== undefined) indicator.style.plusColor = newParams.plusColor;
        if (newParams.minusColor !== undefined) indicator.style.minusColor = newParams.minusColor;
        if (newParams.bullColor !== undefined) indicator.style.bullColor = newParams.bullColor;
        if (newParams.bearColor !== undefined) indicator.style.bearColor = newParams.bearColor;
        if (newParams.minutes !== undefined) indicator.params.minutes = newParams.minutes;
        if (newParams.period1 !== undefined) indicator.params.period1 = newParams.period1;
        if (newParams.period2 !== undefined) indicator.params.period2 = newParams.period2;
        if (newParams.period3 !== undefined) indicator.params.period3 = newParams.period3;
        if (newParams.rsiPeriod !== undefined) indicator.params.rsiPeriod = newParams.rsiPeriod;
        if (newParams.stochLen !== undefined) indicator.params.stochLen = newParams.stochLen;
        if (newParams.oscillatorMaType !== undefined) indicator.params.oscillatorMaType = newParams.oscillatorMaType;
        if (newParams.signalMaType !== undefined) indicator.params.signalMaType = newParams.signalMaType;
        if (newParams.percent !== undefined) indicator.params.percent = newParams.percent;
        if (newParams.emaPeriod !== undefined) indicator.params.emaPeriod = newParams.emaPeriod;
        if (newParams.sumPeriod !== undefined) indicator.params.sumPeriod = newParams.sumPeriod;
        if (newParams.wmaPeriod !== undefined) indicator.params.wmaPeriod = newParams.wmaPeriod;
        if (newParams.rangeStart !== undefined) indicator.params.rangeStart = newParams.rangeStart;
        if (newParams.rangeEnd !== undefined) indicator.params.rangeEnd = newParams.rangeEnd;
        if (newParams.lookback !== undefined) indicator.params.lookback = newParams.lookback;
        if (newParams.fibLow !== undefined) indicator.params.fibLow = newParams.fibLow;
        if (newParams.fibHigh !== undefined) indicator.params.fibHigh = newParams.fibHigh;
        if (newParams.extendBars !== undefined) indicator.params.extendBars = newParams.extendBars;
        if (newParams.maxBoxes !== undefined) indicator.params.maxBoxes = newParams.maxBoxes;
        if (newParams.minGapPct !== undefined) indicator.params.minGapPct = newParams.minGapPct;
        if (newParams.maxLookbackDays !== undefined) indicator.params.maxLookbackDays = newParams.maxLookbackDays;
        if (newParams.fractalWidth !== undefined) indicator.params.fractalWidth = newParams.fractalWidth;
        if (newParams.tolerancePct !== undefined) indicator.params.tolerancePct = newParams.tolerancePct;
        if (newParams.minTouches !== undefined) indicator.params.minTouches = newParams.minTouches;
        if (newParams.maxSegments !== undefined) indicator.params.maxSegments = newParams.maxSegments;
        if (newParams.highColor !== undefined) indicator.style.highColor = newParams.highColor;
        if (newParams.lowColor !== undefined) indicator.style.lowColor = newParams.lowColor;
        if (indicator.type === 'sessionsplus') {
            ['showSydney', 'showTokyo', 'showAsian', 'showFrankfurt', 'showLondon', 'showNewYork',
                'sydneyStart', 'sydneyEnd', 'tokyoStart', 'tokyoEnd', 'asianStart', 'asianEnd',
                'frankfurtStart', 'frankfurtEnd', 'londonStart', 'londonEnd', 'newYorkStart', 'newYorkEnd'].forEach(function(k) {
                if (newParams[k] !== undefined) indicator.params[k] = newParams[k];
            });
            ['sydneyColor', 'tokyoColor', 'asianColor', 'frankfurtColor', 'londonColor', 'newYorkColor'].forEach(function(k) {
                if (newParams[k] !== undefined) indicator.style[k] = newParams[k];
            });
        }
        if (indicator.type === 'custom') {
            if (newParams.script !== undefined) indicator.params.script = newParams.script;
            if (newParams.customParams !== undefined) indicator.params.customParams = newParams.customParams;
            if (newParams.name !== undefined) indicator.name = newParams.name;
            if (newParams.timeoutMs !== undefined) indicator.params.timeoutMs = newParams.timeoutMs;
            if (newParams.separatePanel !== undefined) {
                indicator.params.separatePanel = newParams.separatePanel === true;
                indicator.separatePanel = indicator.params.separatePanel;
                if (indicator.separatePanel) indicator.overlay = false;
            }
            if (newParams.overlay !== undefined) {
                indicator.overlay = newParams.overlay !== false;
                if (!indicator.overlay) {
                    indicator.separatePanel = true;
                    indicator.params.separatePanel = true;
                } else {
                    indicator.separatePanel = false;
                    indicator.params.separatePanel = false;
                }
            }
        }
        if (indicator.type === 'cotnet') {
            const merged = Object.assign({}, indicator.style, indicator.params, newParams);
            applyCotNetStyleFromParams(indicator, merged);
            if (needsDataRecalc) {
                this.indicators.data[indicator.id] = { loading: true, error: null };
                if (typeof this._scheduleCotNetLoad === 'function') this._scheduleCotNetLoad(indicator);
            }
        }
        if (indicator.type === 'seasonality') {
            if (newParams.minSamples !== undefined) indicator.params.minSamples = Math.max(1, parseInt(newParams.minSamples, 10) || 2);
            if (newParams.color !== undefined) indicator.style.color = newParams.color;
            if (newParams.lineWidth !== undefined) indicator.style.lineWidth = newParams.lineWidth;
        }
        if (indicator.type === 'icteverything') {
            var ieDefUp = (typeof window !== 'undefined' && window.INDICATOR_DEFINITIONS && window.INDICATOR_DEFINITIONS.icteverything)
                ? window.INDICATOR_DEFINITIONS.icteverything
                : null;
            if (ieDefUp && ieDefUp.params) {
                ieDefUp.params.forEach(function(p) {
                    if (p.type === 'heading' || p.type === 'divider') return;
                    if (newParams[p.id] === undefined) return;
                    var raw = newParams[p.id];
                    if (p.type === 'checkbox') raw = !!raw;
                    else if (p.type === 'number') {
                        raw = parseFloat(raw);
                        if (isNaN(raw)) return;
                    }
                    indicator.params[p.id] = raw;
                });
            }
        }
        // Talaria overlays: bake all UI fields into indicator.params before recalc.
        // Without this, Apply Changes recalculates against stale add-time defaults.
        if (indicator.type === 'talariafvg'
            || indicator.type === 'talariaratiogap'
            || indicator.type === 'talariaweeklymap'
            || indicator.type === 'talariasmc') {
            _applyIndicatorDefParams(indicator, indicator.type, newParams);
        }

        if (indicator.type === 'aroon') {
            applyAroonStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'rsi') {
            const mergedRsi = Object.assign({}, indicator.style, indicator.params, newParams);
            applyRsiStyleFromParams(indicator, mergedRsi);
            if (needsDataRecalc) {
                indicator.name = 'RSI(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateRSIIndicatorData(this.data, indicator.params);
            }
        }
        if (indicator.type === 'psar') {
            applyPsarStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'keltner') {
            applyKeltnerCalcParams(indicator, Object.assign({}, indicator.params, newParams));
            applyKeltnerStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'donchian') {
            const mergedDc = Object.assign({}, indicator.style, indicator.params, newParams);
            if (newParams.period !== undefined) {
                indicator.params.period = Math.max(1, Number(mergedDc.period) | 0) || 20;
            }
            if (newParams.offset !== undefined) {
                indicator.params.offset = Number.isFinite(Number(mergedDc.offset)) ? Number(mergedDc.offset) : 0;
            }
            applyDonchianStyleFromParams(indicator, mergedDc);
            if (needsDataRecalc) {
                indicator.name = 'Donchian(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateDonchian(
                    this.data,
                    indicator.params.period,
                    indicator.params.offset
                );
            }
        }
        if (indicator.type === 'bb' || indicator.type === 'bollinger') {
            indicator.type = 'bb';
            const mergedBb = Object.assign({}, indicator.style, indicator.params, newParams);
            applyBbCalcParams(indicator, mergedBb);
            applyBollingerStyleFromParams(indicator, mergedBb);
            if (needsDataRecalc) {
                indicator.name = 'BB(' + indicator.params.period + ',' + indicator.params.stdDev + ')';
                this.indicators.data[indicator.id] = calculateBollingerBands(this.data, indicator.params);
            }
        }
        if (indicator.type === 'stoch' || indicator.type === 'stochastic' || indicator.type === 'stochrsi') {
            applyStochasticStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'cci') {
            applyCciStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'mfi') {
            applyMfiStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'cmf') {
            applyCmfStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'ao') {
            const merged = Object.assign({}, indicator.style, indicator.params, newParams);
            applyAoStyleFromParams(indicator, merged);
            if (needsDataRecalc) {
                indicator.name = 'AO(' + indicator.params.fastLength + ',' + indicator.params.slowLength + ')';
                this.indicators.data[indicator.id] = calculateAO(this.data, indicator.params.fastLength, indicator.params.slowLength);
            }
        }
        if (indicator.type === 'uo') {
            applyUoStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'vortex') {
            const merged = Object.assign({}, indicator.style, indicator.params, newParams);
            applyVortexStyleFromParams(indicator, merged);
            if (needsDataRecalc) {
                indicator.name = 'Vortex(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateVortex(this.data, indicator.params.period);
            }
        }
        if (indicator.type === 'vwap') {
            const merged = Object.assign({}, indicator.style, indicator.params, newParams);
            applyVwapStyleFromParams(indicator, merged);
            if (needsDataRecalc) {
                this.indicators.data[indicator.id] = calculateVWAPIndicatorData(this.data, indicator.params);
            }
        }
        if (indicator.type === 'obv') {
            const merged = Object.assign({}, indicator.style, indicator.params, newParams);
            applyObvStyleFromParams(indicator, merged);
            if (needsDataRecalc) {
                this.indicators.data[indicator.id] = calculateOBVIndicatorData(this.data, indicator.params);
            }
        }
        if (indicator.type === 'volume' || indicator.isVolume) {
            applyVolumeStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
            syncVolumeChartSettings(this, indicator);
            const volumeLine = document.getElementById('volumeIndicatorLine');
            if (volumeLine) {
                const colorBox = volumeLine.querySelector('.volume-color-box');
                if (colorBox) {
                    colorBox.style.background = indicator.style.growingColor || indicator.style.upColor || 'rgba(8, 153, 129, 0.5)';
                }
                const label = volumeLine.querySelector('.volume-label');
                if (label) {
                    label.textContent = (indicator.params.showMa || indicator.params.showMA)
                        ? 'Volume MA(' + (indicator.params.maPeriod || 20) + ')'
                        : 'Volume';
                }
            }
        }
        if (indicator.type === 'trix') {
            const merged = Object.assign({}, indicator.style, indicator.params, newParams);
            applyTrixStyleFromParams(indicator, merged);
            if (needsDataRecalc) {
                indicator.name = 'TRIX(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateTRIX(this.data, indicator.params.period);
            }
        }
        if (indicator.type === 'rvi') {
            applyRviStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'elderray') {
            const merged = Object.assign({}, indicator.style, indicator.params, newParams);
            if (needsDataRecalc) indicator.params.period = Math.max(2, Number(merged.period) | 0) || 13;
            applyElderRayStyleFromParams(indicator, merged);
            if (needsDataRecalc) {
                indicator.name = 'Elder Ray(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateElderRay(this.data, indicator.params.period);
            }
        }
        if (indicator.type === 'massindex') {
            const merged = Object.assign({}, indicator.style, indicator.params, newParams);
            if (needsDataRecalc) indicator.params.period = massIndexPeriodFromParams(merged);
            applyMassIndexStyleFromParams(indicator, merged);
            if (needsDataRecalc) {
                indicator.name = 'Mass Index(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateMassIndex(this.data, MASS_INDEX_EMA_PERIOD, indicator.params.period);
            }
        }
        if (indicator.type === 'coppock') {
            const merged = Object.assign({}, indicator.style, indicator.params, newParams);
            applyCoppockStyleFromParams(indicator, merged);
            if (needsDataRecalc) {
                this.indicators.data[indicator.id] = calculateCoppock(this.data, indicator.params);
            }
        }
        if (indicator.type === 'atr') {
            const merged = Object.assign({}, indicator.style, indicator.params, newParams);
            applyAtrStyleFromParams(indicator, merged);
            if (needsDataRecalc) {
                indicator.name = 'ATR(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateATR(
                    this.data,
                    indicator.params.period,
                    indicator.params.smoothingType
                );
            }
        }
        if (indicator.type === 'mom' || indicator.type === 'momentum') {
            indicator.type = 'mom';
            indicator.overlay = false;
            indicator.separatePanel = true;
            applyMomStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'roc') {
            indicator.overlay = false;
            indicator.separatePanel = true;
            applyRocStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'willr' || indicator.type === 'williams') {
            indicator.type = 'willr';
            indicator.overlay = false;
            indicator.separatePanel = true;
            applyWillrStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'macd' || indicator.type === 'ppo') {
            indicator.type = 'macd';
            indicator.overlay = false;
            indicator.separatePanel = true;
            applyMacdStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'adx') {
            indicator.overlay = false;
            indicator.separatePanel = true;
            applyAdxStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'dpo') {
            indicator.overlay = false;
            indicator.separatePanel = true;
            applyDpoStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'stddev') {
            const merged = Object.assign({}, indicator.style, indicator.params, newParams);
            applyStddevStyleFromParams(indicator, merged);
            if (needsDataRecalc) {
                indicator.name = 'StdDev(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateStdDevLine(
                    this.data,
                    indicator.params.period,
                    indicator.params.source || 'close'
                );
            }
        }
        if (indicator.type === 'supertrend') {
            const mergedSt = Object.assign({}, indicator.style, indicator.params, newParams);
            applySupertrendStyleFromParams(indicator, mergedSt);
            if (needsDataRecalc) {
                indicator.name = 'Supertrend(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateSupertrend(
                    this.data,
                    indicator.params.period,
                    indicator.params.multiplier
                );
            }
        }
        if (indicator.type === 'dema') {
            const mergedDema = Object.assign({}, indicator.style, indicator.params, newParams);
            applyDemaStyleFromParams(indicator, mergedDema);
            if (needsDataRecalc) {
                indicator.name = 'DEMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateDEMAOverlayData(this.data, indicator.params);
            }
        }
        if (indicator.type === 'tema') {
            const mergedTema = Object.assign({}, indicator.style, indicator.params, newParams);
            applyTemaStyleFromParams(indicator, mergedTema);
            if (needsDataRecalc) {
                indicator.name = 'TEMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateTEMAOverlayData(this.data, indicator.params);
            }
        }
        if (indicator.type === 'hma') {
            const mergedHma = Object.assign({}, indicator.style, indicator.params, newParams);
            applyHmaStyleFromParams(indicator, mergedHma);
            if (needsDataRecalc) {
                indicator.name = 'HMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateHMAOverlayData(this.data, indicator.params);
            }
        }
        if (indicator.type === 'wma') {
            const mergedWma = Object.assign({}, indicator.style, indicator.params, newParams);
            applyWmaStyleFromParams(indicator, mergedWma);
            if (needsDataRecalc) {
                indicator.name = 'WMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateWMAOverlayData(this.data, indicator.params);
            }
        }
        if (indicator.type === 'sma' || indicator.type === 'ema') {
            const mergedMa = Object.assign({}, indicator.style, indicator.params, newParams);
            if (indicator.type === 'sma') {
                applySmaStyleFromParams(indicator, mergedMa);
            } else {
                applyEmaStyleFromParams(indicator, mergedMa);
            }
            if (needsDataRecalc) {
                if (indicator.type === 'sma') {
                    indicator.name = 'SMA(' + indicator.params.period + ')';
                    this.indicators.data[indicator.id] = calculateSMAIndicatorData(this.data, indicator.params);
                } else {
                    indicator.name = 'EMA(' + indicator.params.period + ')';
                    this.indicators.data[indicator.id] = calculateEMAIndicatorData(this.data, indicator.params);
                }
            }
        }
        if (indicator.type === 'sessions') {
            applySessionsFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }
        if (indicator.type === 'openingrange' || indicator.type === 'or') {
            applyOpeningRangeStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
        }

        // Recalculate data only when input/calc settings changed (style/thickness edits preview immediately).
        if (needsDataRecalc) switch (indicator.type) {
            case 'sma':
                indicator.name = 'SMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateSMAIndicatorData(this.data, indicator.params);
                break;
            case 'ema':
                indicator.name = 'EMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateEMAIndicatorData(this.data, indicator.params);
                break;
            case 'wma':
                indicator.name = 'WMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateWMAOverlayData(this.data, indicator.params);
                break;
            case 'bb':
            case 'bollinger':
                applyBbCalcParams(indicator, indicator.params);
                indicator.name = 'BB(' + indicator.params.period + ',' + indicator.params.stdDev + ')';
                this.indicators.data[indicator.id] = calculateBollingerBands(this.data, indicator.params);
                break;
            case 'envelope':
            case 'smaenvelope':
                indicator.name = 'Envelope(' + indicator.params.period + ',' + indicator.params.percent + '%)';
                this.indicators.data[indicator.id] = calculateEnvelope(this.data, indicator.params.period, indicator.params.percent, indicator.params.source || 'close');
                break;
            case 'vwap':
                applyVwapStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                this.indicators.data[indicator.id] = calculateVWAPIndicatorData(this.data, indicator.params);
                break;
            case 'atr':
                indicator.params.period = atrPeriodFromParams(indicator.params);
                indicator.params.smoothingType = atrSmoothingTypeFromParams(indicator.params);
                indicator.name = 'ATR(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateATR(
                    this.data,
                    indicator.params.period,
                    indicator.params.smoothingType
                );
                break;

            case 'cci':
                applyCciStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                indicator.name = 'CCI(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateCCIIndicatorData(this.data, indicator.params);
                break;

            case 'adx':
                indicator.name = 'ADX(' + indicator.params.diLength + ',' + indicator.params.adxSmoothing + ')';
                this.indicators.data[indicator.id] = calculateADX(this.data, indicator.params.diLength, indicator.params.adxSmoothing);
                break;

            case 'rsi':
                indicator.name = 'RSI(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateRSIIndicatorData(this.data, indicator.params);
                break;
            case 'macd':
            case 'ppo':
                indicator.type = 'macd';
                indicator.name = 'MACD(' + indicator.params.fast + ',' + indicator.params.slow + ',' + indicator.params.signal + ')';
                this.indicators.data[indicator.id] = calculateMACD(
                    this.data,
                    indicator.params.fast,
                    indicator.params.slow,
                    indicator.params.signal,
                    indicator.params.source || 'close',
                    {
                        oscillatorMaType: indicator.params.oscillatorMaType,
                        signalMaType: indicator.params.signalMaType
                    }
                );
                break;
            case 'stoch':
            case 'stochastic':
                indicator.name = 'Stoch(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateStochastic(this.data, indicator.params.period, indicator.params.smoothK, indicator.params.smoothD);
                break;
            case 'adr':
                indicator.params.period = Math.max(1, parseInt(indicator.params.period, 10) || 14);
                indicator.name = 'ADR(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateADR(this.data, indicator.params.period);
                break;
            case 'volume':
                applyVolumeStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params, newParams));
                syncVolumeChartSettings(this, indicator);
                break;
            case 'sessions':
                this.indicators.data[indicator.id] = calculateSessions(this.data, sessionsCalcPayload(indicator));
                break;
            case 'killzones':
            case 'ictkz':
                // Update visibility
                if (newParams.showCBDR !== undefined) indicator.params.showCBDR = newParams.showCBDR;
                if (newParams.showAsia !== undefined) indicator.params.showAsia = newParams.showAsia;
                if (newParams.showLondon !== undefined) indicator.params.showLondon = newParams.showLondon;
                if (newParams.showNYAM !== undefined) indicator.params.showNYAM = newParams.showNYAM;
                if (newParams.showLC !== undefined) indicator.params.showLC = newParams.showLC;
                if (newParams.showNYMidnight !== undefined) indicator.params.showNYMidnight = newParams.showNYMidnight;
                if (newParams.showMidline !== undefined) indicator.params.showMidline = newParams.showMidline;
                if (newParams.showBoxInfo !== undefined) indicator.params.showBoxInfo = newParams.showBoxInfo;
                if (newParams.showDeviations !== undefined) indicator.params.showDeviations = newParams.showDeviations;
                if (newParams.deviationCount !== undefined) indicator.params.deviationCount = newParams.deviationCount;
                if (newParams.boxTransparency !== undefined) {
                    indicator.params.boxTransparency = killzonesParseBoxTransparency(
                        newParams.boxTransparency,
                        indicator.params.boxTransparency
                    );
                }
                // Update times
                if (newParams.cbdrStart !== undefined) indicator.params.cbdrStart = newParams.cbdrStart;
                if (newParams.cbdrEnd !== undefined) indicator.params.cbdrEnd = newParams.cbdrEnd;
                if (newParams.asiaStart !== undefined) indicator.params.asiaStart = newParams.asiaStart;
                if (newParams.asiaEnd !== undefined) indicator.params.asiaEnd = newParams.asiaEnd;
                if (newParams.londonStart !== undefined) indicator.params.londonStart = newParams.londonStart;
                if (newParams.londonEnd !== undefined) indicator.params.londonEnd = newParams.londonEnd;
                if (newParams.nyamStart !== undefined) indicator.params.nyamStart = newParams.nyamStart;
                if (newParams.nyamEnd !== undefined) indicator.params.nyamEnd = newParams.nyamEnd;
                if (newParams.lcStart !== undefined) indicator.params.lcStart = newParams.lcStart;
                if (newParams.lcEnd !== undefined) indicator.params.lcEnd = newParams.lcEnd;
                // Update colors
                if (newParams.cbdrColor !== undefined) indicator.style.cbdrColor = newParams.cbdrColor;
                if (newParams.asiaColor !== undefined) indicator.style.asiaColor = newParams.asiaColor;
                if (newParams.londonColor !== undefined) indicator.style.londonColor = newParams.londonColor;
                if (newParams.nyamColor !== undefined) indicator.style.nyamColor = newParams.nyamColor;
                if (newParams.lcColor !== undefined) indicator.style.lcColor = newParams.lcColor;
                if (newParams.nyMidnightColor !== undefined) indicator.style.nyMidnightColor = newParams.nyMidnightColor;
                if (newParams.textColor !== undefined) indicator.style.textColor = newParams.textColor;
                this.indicators.data[indicator.id] = calculateKillzones(this.data, {
                    showCBDR: indicator.params.showCBDR,
                    showAsia: indicator.params.showAsia,
                    showLondon: indicator.params.showLondon,
                    showNYAM: indicator.params.showNYAM,
                    showLC: indicator.params.showLC,
                    showNYMidnight: indicator.params.showNYMidnight,
                    showMidline: indicator.params.showMidline,
                    showBoxInfo: indicator.params.showBoxInfo,
                    showDeviations: indicator.params.showDeviations,
                    deviationCount: indicator.params.deviationCount,
                    boxTransparency: indicator.params.boxTransparency,
                    cbdrStart: indicator.params.cbdrStart,
                    cbdrEnd: indicator.params.cbdrEnd,
                    asiaStart: indicator.params.asiaStart,
                    asiaEnd: indicator.params.asiaEnd,
                    londonStart: indicator.params.londonStart,
                    londonEnd: indicator.params.londonEnd,
                    nyamStart: indicator.params.nyamStart,
                    nyamEnd: indicator.params.nyamEnd,
                    lcStart: indicator.params.lcStart,
                    lcEnd: indicator.params.lcEnd,
                    cbdrColor: indicator.style.cbdrColor,
                    asiaColor: indicator.style.asiaColor,
                    londonColor: indicator.style.londonColor,
                    nyamColor: indicator.style.nyamColor,
                    lcColor: indicator.style.lcColor,
                    nyMidnightColor: indicator.style.nyMidnightColor
                });
                break;
            case 'dema':
                indicator.name = 'DEMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateDEMAOverlayData(this.data, indicator.params);
                break;
            case 'tema':
                indicator.name = 'TEMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateTEMAOverlayData(this.data, indicator.params);
                break;
            case 'hma':
                indicator.name = 'HMA(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateHMAOverlayData(this.data, indicator.params);
                break;
            case 'roc':
                indicator.name = 'ROC(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateROC(this.data, indicator.params.period, indicator.params.source || 'close');
                break;
            case 'mom':
            case 'momentum':
                indicator.name = 'Mom(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateMomentum(this.data, indicator.params.period, indicator.params.source || 'close');
                break;
            case 'obv':
                applyObvStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                this.indicators.data[indicator.id] = calculateOBVIndicatorData(this.data, indicator.params);
                break;
            case 'willr':
                indicator.name = 'Williams %R(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateWilliamsR(this.data, indicator.params.period, indicator.params.source || 'close');
                break;
            case 'mfi':
                indicator.name = 'MFI(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateMFI(this.data, indicator.params.period);
                break;
            case 'donchian':
                indicator.params.period = indicator.params.period || 20;
                indicator.params.offset = indicator.params.offset != null ? Number(indicator.params.offset) : 0;
                applyDonchianStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                indicator.name = 'Donchian(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateDonchian(this.data, indicator.params.period, indicator.params.offset);
                break;
            case 'keltner':
                applyKeltnerCalcParams(indicator, indicator.params);
                indicator.name = 'Keltner(' + indicator.params.length + ')';
                this.indicators.data[indicator.id] = calculateKeltner(this.data, indicator.params);
                break;
            case 'aroon':
                indicator.name = 'Aroon(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateAroon(this.data, indicator.params.period);
                break;
            case 'cmf':
                applyCmfStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                indicator.name = 'CMF(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateCMF(this.data, indicator.params.period);
                break;
            case 'ao':
                applyAoStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                indicator.name = 'AO(' + indicator.params.fastLength + ',' + indicator.params.slowLength + ')';
                this.indicators.data[indicator.id] = calculateAO(this.data, indicator.params.fastLength, indicator.params.slowLength);
                break;
            case 'uo':
                applyUoStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                this.indicators.data[indicator.id] = calculateUltimateOscillator(this.data, indicator.params.period1, indicator.params.period2, indicator.params.period3);
                break;
            case 'trix':
                applyTrixStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                indicator.name = 'TRIX(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateTRIX(this.data, indicator.params.period);
                break;
            case 'psar':
                this.indicators.data[indicator.id] = calculatePSAR(this.data, indicator.params);
                break;
            case 'sessionsplus':
                indicator.name = 'Sessions+';
                this.indicators.data[indicator.id] = calculateSessionsPlus(this.data, {
                    showSydney: indicator.params.showSydney,
                    showTokyo: indicator.params.showTokyo,
                    showAsian: indicator.params.showAsian,
                    showFrankfurt: indicator.params.showFrankfurt,
                    showLondon: indicator.params.showLondon,
                    showNewYork: indicator.params.showNewYork,
                    sydneyStart: indicator.params.sydneyStart,
                    sydneyEnd: indicator.params.sydneyEnd,
                    tokyoStart: indicator.params.tokyoStart,
                    tokyoEnd: indicator.params.tokyoEnd,
                    asianStart: indicator.params.asianStart,
                    asianEnd: indicator.params.asianEnd,
                    frankfurtStart: indicator.params.frankfurtStart,
                    frankfurtEnd: indicator.params.frankfurtEnd,
                    londonStart: indicator.params.londonStart,
                    londonEnd: indicator.params.londonEnd,
                    newYorkStart: indicator.params.newYorkStart,
                    newYorkEnd: indicator.params.newYorkEnd,
                    sydneyColor: indicator.style.sydneyColor,
                    tokyoColor: indicator.style.tokyoColor,
                    asianColor: indicator.style.asianColor,
                    frankfurtColor: indicator.style.frankfurtColor,
                    londonColor: indicator.style.londonColor,
                    newYorkColor: indicator.style.newYorkColor
                });
                break;
            case 'openingrange':
            case 'or':
                applyOpeningRangeStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                indicator.name = 'Opening Range(' + indicator.params.rangeStart + '-' + indicator.params.rangeEnd + ')';
                this.indicators.data[indicator.id] = calculateOpeningRange(this.data, indicator.params);
                break;
            case 'supertrend':
                indicator.name = 'Supertrend(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateSupertrend(this.data, indicator.params.period, indicator.params.multiplier);
                break;
            case 'stddev':
                indicator.name = 'StdDev(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateStdDevLine(this.data, indicator.params.period, indicator.params.source || 'close');
                break;
            case 'ao':
                applyAoStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                indicator.name = 'AO(' + indicator.params.fastLength + ',' + indicator.params.slowLength + ')';
                this.indicators.data[indicator.id] = calculateAO(this.data, indicator.params.fastLength, indicator.params.slowLength);
                break;
            case 'uo':
                this.indicators.data[indicator.id] = calculateUltimateOscillator(this.data, indicator.params.period1, indicator.params.period2, indicator.params.period3);
                break;
            case 'vortex':
                indicator.name = 'Vortex(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateVortex(this.data, indicator.params.period);
                break;
            case 'ppo':
                indicator.type = 'macd';
                indicator.name = 'MACD(' + indicator.params.fast + ',' + indicator.params.slow + ',' + indicator.params.signal + ')';
                this.indicators.data[indicator.id] = calculateMACD(
                    this.data,
                    indicator.params.fast,
                    indicator.params.slow,
                    indicator.params.signal,
                    indicator.params.source || 'close',
                    {
                        oscillatorMaType: indicator.params.oscillatorMaType,
                        signalMaType: indicator.params.signalMaType
                    }
                );
                break;
            case 'dpo':
                indicator.name = 'DPO(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateDPO(this.data, indicator.params.period, indicator.params.centered === true);
                break;
            case 'stochrsi':
                indicator.name = 'Stoch RSI(' + indicator.params.rsiPeriod + ',' + indicator.params.stochLen + ')';
                this.indicators.data[indicator.id] = calculateStochRSI(
                    this.data,
                    indicator.params.rsiPeriod,
                    indicator.params.stochLen,
                    indicator.params.smoothK,
                    indicator.params.smoothD,
                    indicator.params.source || 'close'
                );
                break;
            case 'massindex':
                indicator.params.period = massIndexPeriodFromParams(indicator.params);
                indicator.name = 'Mass Index(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateMassIndex(
                    this.data,
                    MASS_INDEX_EMA_PERIOD,
                    indicator.params.period
                );
                break;
            case 'coppock':
                applyCoppockStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                indicator.name = 'Coppock Curve';
                this.indicators.data[indicator.id] = calculateCoppock(this.data, indicator.params);
                break;
            case 'rvi':
                applyRviStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                indicator.name = 'RVI(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateRVI(this.data, indicator.params.period);
                break;
            case 'elderray':
                indicator.name = 'Elder Ray(' + indicator.params.period + ')';
                this.indicators.data[indicator.id] = calculateElderRay(this.data, indicator.params.period);
                break;
            case 'seasonality':
                indicator.name = 'Seasonality (avg % by date)';
                this.indicators.data[indicator.id] = calculateSeasonality(
                    this.data,
                    indicator.params.minSamples != null ? indicator.params.minSamples : 2
                );
                break;
            case 'cotnet':
                this.indicators.data[indicator.id] = { loading: true, error: null };
                if (typeof this._scheduleCotNetLoad === 'function') this._scheduleCotNetLoad(indicator);
                break;
            case 'ictpd':
                indicator.name = 'ICT Prev Day PD';
                this.indicators.data[indicator.id] = calculateIctPrevDayPD(this.data);
                break;
            case 'ictasian':
                indicator.name = 'ICT Asian Range';
                this.indicators.data[indicator.id] = calculateIctAsianRange(this.data, {
                    rangeStart: indicator.params.rangeStart,
                    rangeEnd: indicator.params.rangeEnd
                });
                break;
            case 'ictote':
                indicator.name = 'ICT OTE Zone';
                this.indicators.data[indicator.id] = calculateIctOTE(
                    this.data,
                    indicator.params.lookback,
                    indicator.params.fibLow,
                    indicator.params.fibHigh
                );
                break;
            case 'ictfvg':
                indicator.name = 'ICT Fair Value Gaps';
                this.indicators.data[indicator.id] = calculateFairValueGaps(this.data, {
                    extendBars: indicator.params.extendBars,
                    maxBoxes: indicator.params.maxBoxes,
                    minGapPct: indicator.params.minGapPct
                });
                break;
            case 'ictsesspd':
                indicator.name = 'ICT Session PD';
                this.indicators.data[indicator.id] = calculateIctSessionPrevDayPD(this.data, {
                    rangeStart: indicator.params.rangeStart,
                    rangeEnd: indicator.params.rangeEnd,
                    maxLookbackDays: indicator.params.maxLookbackDays
                });
                break;
            case 'ictliquidity':
                indicator.name = 'ICT Equal L/H Liquidity';
                this.indicators.data[indicator.id] = calculateLiquidityEqualLevels(this.data, {
                    fractalWidth: indicator.params.fractalWidth,
                    tolerancePct: indicator.params.tolerancePct,
                    minTouches: indicator.params.minTouches,
                    maxSegments: indicator.params.maxSegments,
                    extendBars: indicator.params.extendBars
                });
                break;
            case 'icteverything':
                indicator.name = 'ICT Everything';
                this.indicators.data[indicator.id] = calculateIctEverything(this.data, indicator);
                break;
            case 'talariafvg':
                indicator.name = 'Talaria — FVG';
                this.indicators.data[indicator.id] = calculateTalariaFvgIndicator(this.data, indicator, this);
                break;
            case 'talariaratiogap':
                indicator.name = 'Talaria — Ratio + Gap';
                this.indicators.data[indicator.id] = calculateTalariaRatioGapIndicator(this.data, indicator);
                break;
            case 'talariaweeklymap':
                indicator.name = 'Talaria — Weekly Map';
                this.indicators.data[indicator.id] = calculateTalariaWeeklyMapIndicator(this.data, indicator, this);
                break;
            case 'talariasmc':
                indicator.name = 'Talaria — Simple SMC';
                this.indicators.data[indicator.id] = calculateTalariaSimpleSmcIndicator(this.data, indicator, this);
                break;
            case 'custom':
                if (typeof this._scheduleCustomIndicatorCompute === 'function') {
                    this._scheduleCustomIndicatorCompute(indicator);
                }
                break;
        }

        clampIndicatorStyleLineWidths(indicator.style);
        return this._finalizeIndicatorSettingsApply(indicator, {
            needsDataRecalc: needsDataRecalc,
            newParams: newParams,
        });
    };

    // ── Indicator Web Worker manager ──────────────────────────────────────
    // Singleton: first chart instance to call recalculateIndicators spins up
    // the worker; all subsequent chart instances share it.
    var _indicatorWorkerSingleton = null;
    var _workerLoadFailed = false;
    var _workerPending = new Map(); // id → { resolve, reject }
    var _workerNextId = 0;

    function _getIndicatorWorker() {
        if (_workerLoadFailed) return null;
        if (_indicatorWorkerSingleton) return _indicatorWorkerSingleton;
        if (typeof Worker === 'undefined') { _workerLoadFailed = true; return null; }
        try {
            var w = new Worker('/chart/workers/indicator-worker.js');
            w.onmessage = function(e) {
                var msg = e.data;
                var pending = _workerPending.get(msg.id);
                if (!pending) return;
                _workerPending.delete(msg.id);
                if (msg.type === 'ERROR') {
                    pending.reject(new Error(msg.error || 'worker error'));
                } else if (msg.type === 'ALL_RESULTS') {
                    pending.resolve(msg.results);
                }
            };
            w.onerror = function(err) {
                console.warn('[indicator-worker] load/runtime error — falling back to sync', err);
                _workerLoadFailed = true;
                _indicatorWorkerSingleton = null;
                // Reject all pending
                _workerPending.forEach(function(p) { p.reject(new Error('worker failed')); });
                _workerPending.clear();
            };
            _indicatorWorkerSingleton = w;
            return w;
        } catch (e) {
            _workerLoadFailed = true;
            return null;
        }
    }

    /**
     * REALM-TEARDOWN-RELEASE CUT 4: terminate the per-realm indicator worker
     * singleton and reject/clear _workerPending (continuations capture chart).
     */
    Chart.prototype._disposeIndicatorWorker = function() {
        try {
            if (_indicatorWorkerSingleton) {
                try { _indicatorWorkerSingleton.terminate(); } catch (_) {}
            }
        } catch (_) {}
        _indicatorWorkerSingleton = null;
        try {
            _workerPending.forEach(function(p) {
                try { p.reject(new Error('worker disposed')); } catch (_) {}
            });
            _workerPending.clear();
        } catch (_) {}
    };

    function recalcMultiPassOverlayMa(chart, indicator) {
        if (!chart || !indicator || !Array.isArray(chart.data) || !chart.data.length) return;
        if (!chart.indicators.data) chart.indicators.data = {};
        const indType = String(indicator.type || '').toLowerCase();
        indicator.type = indType;
        const period = indicator.params && indicator.params.period != null
            ? Math.max(1, Number(indicator.params.period) | 0)
            : 20;
        indicator.overlay = true;
        indicator.separatePanel = false;
        if (indType === 'dema') {
            indicator.name = 'DEMA(' + period + ')';
            chart.indicators.data[indicator.id] = calculateDEMAOverlayData(
                chart.data,
                indicator.params || { period: period, source: 'close' }
            );
        } else if (indType === 'tema') {
            indicator.name = 'TEMA(' + period + ')';
            chart.indicators.data[indicator.id] = calculateTEMAOverlayData(
                chart.data,
                indicator.params || { period: period, source: 'close' }
            );
        } else if (indType === 'hma') {
            indicator.name = 'HMA(' + period + ')';
            chart.indicators.data[indicator.id] = calculateHMAOverlayData(
                chart.data,
                indicator.params || { period: period, source: 'close' }
            );
        }
    }

    function recalcSupertrendOverlay(chart, indicator) {
        if (!chart || !indicator || !Array.isArray(chart.data) || !chart.data.length) return;
        if (!chart.indicators.data) chart.indicators.data = {};
        indicator.type = 'supertrend';
        indicator.overlay = true;
        indicator.separatePanel = false;
        const period = indicator.params && indicator.params.period != null ? indicator.params.period : 10;
        const multiplier = indicator.params && indicator.params.multiplier != null ? indicator.params.multiplier : 3;
        indicator.name = 'Supertrend(' + period + ')';
        // M19-I(c): exact O(delta) continuation instead of a full-history scan.
        chart.indicators.data[indicator.id] = (typeof _m19iWorkerPortEnabled === 'function' && _m19iWorkerPortEnabled())
            ? _m19iSupertrendIncremental(chart, indicator)
            : calculateSupertrend(chart.data, period, multiplier);
    }

    /** ADR requires timezone-aware daily session keys — always recalc on the main thread. */
    function recalcAdrIndicator(chart, indicator) {
        if (!chart || !indicator || !Array.isArray(chart.data) || !chart.data.length) return;
        if (!chart.indicators.data) chart.indicators.data = {};
        indicator.type = 'adr';
        indicator.overlay = false;
        indicator.separatePanel = true;
        indicator.params.period = Math.max(1, parseInt(indicator.params && indicator.params.period, 10) || 14);
        indicator.name = 'ADR(' + indicator.params.period + ')';
        // M19-I(c): exact O(delta + current day) continuation on the main thread.
        chart.indicators.data[indicator.id] = (typeof _m19iWorkerPortEnabled === 'function' && _m19iWorkerPortEnabled())
            ? _m19iAdrIncremental(chart, indicator)
            : calculateADR(chart.data, indicator.params.period);
    }

    /**
     * Calculate all active indicators in a background Web Worker.
     * Falls back to synchronous recalculateIndicators() if worker is unavailable.
     * Safe to call fire-and-forget (scheduleRender called on completion).
     */
    Chart.prototype.recalculateIndicatorsAsync = function() {
        if (!this.indicators || !this.indicators.active || !this.indicators.active.length) return;
        if (!Array.isArray(this.data) || !this.data.length) return;
        if (_b70ShadowEnabled() && _b70Stage5DeferPanelCalculation(this)) return;
        if (_b70ShadowEnabled() && _b70Stage3RejectInRenderWork(this)) return;

        var chart = this;

        // Coalesce rapid replay/live-tick requests — do not bump seq while a worker pass is in flight.
        if (chart._indicatorWorkerBusy) {
            chart._indicatorWorkerCoalesce = true;
            // M19-I: a full pass was requested — a coalesced tail rerun is not enough.
            chart._m19iCoalesceFullAsync = true;
            return;
        }
        chart._indicatorWorkerBusy = true;
        chart._indicatorWorkerCoalesce = false;

        var worker = _getIndicatorWorker();
        var b70WorkerTickets = null;
        var b70WorkerIds = null;
        if (typeof window !== 'undefined'
            && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true) {
            var b70WorkerCandidates = chart.indicators.active.filter(function(indicator) {
                return _b70Stage2InstanceOwner(indicator) === 'worker';
            });
            b70WorkerTickets = _b70Stage2Claim(
                chart, 'worker', b70WorkerCandidates,
                'recalculateIndicatorsAsync', false
            );
            if (!b70WorkerTickets.length) {
                chart._indicatorWorkerBusy = false;
                return;
            }
            b70WorkerIds = _b70Stage2TicketIds(b70WorkerTickets);
        }

        // If worker unavailable or already mid-sync fallback, run sync
        if (!worker) {
            chart._indicatorWorkerBusy = false;
            var coalesceSync = chart._indicatorWorkerCoalesce;
            chart._indicatorWorkerCoalesce = false;
            if (b70WorkerTickets) {
                var b70FallbackIndicators = _b70Stage2ReleaseWorkerFailure(
                    chart, b70WorkerTickets
                );
                if (b70FallbackIndicators.length) {
                    chart._b70Stage2FallbackIndicators = b70FallbackIndicators;
                    try { chart.recalculateIndicators(); } catch (_) {}
                }
            } else {
                try { chart.recalculateIndicators(); } catch (_) {}
            }
            if (coalesceSync) {
                try { chart.recalculateIndicatorsAsync(); } catch (_) {}
            }
            return;
        }

        if (typeof window !== 'undefined'
            && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true) {
            _b70ShadowRecordCalculation(this, 'recalculateIndicatorsAsync', 'worker');
        }
        if (chart._indicatorWorkerSeq == null) chart._indicatorWorkerSeq = 0;
        var mySeq = ++chart._indicatorWorkerSeq;
        var calcToken = _indicatorAsyncDataToken(chart);

        function finishWorkerPass() {
            chart._indicatorWorkerBusy = false;
            if (_m19iExactTailPaintEnabled() && chart._m19iB62PendingFreshFp != null) {
                // B62-2: a fresh request riding on this FULL pass has concluded
                // (applied, failed, or superseded). Retire the pending memo so
                // a later draw can re-request — bounded retry, never a freeze.
                chart._m19iB62PendingFreshFp = null;
            }
            var again = chart._indicatorWorkerCoalesce;
            chart._indicatorWorkerCoalesce = false;
            if (again) {
                // Full rerun below also satisfies any pending full-pass request.
                chart._m19iCoalesceFullAsync = false;
                try { chart.recalculateIndicatorsAsync(); } catch (_) {}
            }
        }

        // Build indicator config map for worker
        var indicators = {};
        var didSyncOverlayRecalc = false;
        chart.indicators.active.forEach(function(ind) {
            // Multi-pass MAs (I-c OFF), Supertrend, + ICT/session types stay on main thread.
            var workerSkip = M19I_LEGACY_WORKER_SKIP;
            var indType = String(ind.type || '').toLowerCase();
            ind.type = indType;
            if (b70WorkerIds && !b70WorkerIds[String(ind.id)]) return;
            if (indType === 'supertrend') {
                try { recalcSupertrendOverlay(chart, ind); } catch (_) {}
                didSyncOverlayRecalc = true;
                return;
            }
            if (indType === 'adr') {
                try { recalcAdrIndicator(chart, ind); } catch (_) {}
                didSyncOverlayRecalc = true;
                return;
            }
            if (['dema', 'tema', 'hma'].indexOf(indType) >= 0) {
                if (_m19iWorkerPortEnabled()) {
                    // I-c: pure series math — computed off-thread by the worker.
                    ind.overlay = true;
                    ind.separatePanel = false;
                    var mp = ind.params && ind.params.period != null ? Math.max(1, Number(ind.params.period) | 0) : 20;
                    ind.name = indType.toUpperCase() + '(' + mp + ')';
                    indicators[ind.id] = { type: indType, params: ind.params || {} };
                    return;
                }
                try { recalcMultiPassOverlayMa(chart, ind); } catch (_) {}
                didSyncOverlayRecalc = true;
                return;
            }
            if (workerSkip.indexOf(indType) >= 0) return;
            indicators[ind.id] = { type: indType, params: ind.params || {} };
        });

        if (didSyncOverlayRecalc && typeof chart.scheduleRender === 'function') {
            chart.scheduleRender();
        }

        // Run sync fallback for skipped indicators immediately
        var syncOnlyTypes = ['cotnet', 'sessions', 'killzones', 'ictkz', 'sessionsplus', 'openingrange', 'or', 'ictpd', 'ictasian', 'ictote', 'ictfvg', 'ictsesspd', 'icteverything', 'talariafvg', 'talariaratiogap', 'talariaweeklymap', 'talariasmc'];
        var needsSyncOnly = !b70WorkerIds && chart.indicators.active.some(function(ind) {
            return syncOnlyTypes.indexOf(String(ind.type || '').toLowerCase()) >= 0;
        });
        if (needsSyncOnly) {
            try {
                chart._recalcOnlyTypes = syncOnlyTypes;
                chart.recalculateIndicators();
            } catch (_) {}
            chart._recalcOnlyTypes = null;
        }

        if (Object.keys(indicators).length === 0) {
            // All indicators were sync-only
            finishWorkerPass();
            if (typeof chart.scheduleRender === 'function') chart.scheduleRender();
            return;
        }

        Object.keys(indicators).forEach(function(indId) {
            chart.indicators.active.forEach(function(ind) {
                if (ind && ind.id === indId) ind._calculating = true;
            });
        });
        if (typeof chart.updateOHLCIndicators === 'function') chart.updateOHLCIndicators();

        var id = _workerNextId++;
        var perf = _indicatorPerf();
        var packed = perf && typeof perf.packBarsCompact === 'function'
            ? perf.packBarsCompact(chart.data)
            : null;
        new Promise(function(resolve, reject) {
            _workerPending.set(id, { resolve: resolve, reject: reject });
            var message = {
                type: 'CALCULATE_ALL',
                id: id,
                payload: {
                    bars: packed ? null : chart.data,
                    barsPacked: packed,
                    indicators: indicators
                }
            };
            if (packed && packed.buffer) {
                worker.postMessage(message, [packed.buffer]);
            } else {
                worker.postMessage(message);
            }
        }).then(function(results) {
            if (chart._indicatorWorkerSeq !== mySeq
                || !_indicatorAsyncTokenMatches(chart, calcToken)) {
                chart._indicatorWorkerCoalesce = true;
                finishWorkerPass();
                return;
            }
            if (b70WorkerTickets
                && !_b70Stage2AuthorizeWorkerApply(chart, b70WorkerTickets, results)) {
                finishWorkerPass();
                return;
            }
            var b70WorkerEnvelopeTx = b70WorkerTickets
                ? _b70Stage4BeginBuild(chart, b70WorkerTickets) : null;
            if (b70WorkerTickets && !b70WorkerEnvelopeTx) {
                finishWorkerPass();
                return;
            }
            if (typeof chart._applyIndicatorWorkerResults === 'function') {
                var b70Applied = b70WorkerEnvelopeTx
                    ? _b70Stage4ApplyWorkerResults(
                        chart, b70WorkerEnvelopeTx, results, mySeq, calcToken, null
                    )
                    : chart._applyIndicatorWorkerResults(results, mySeq, calcToken);
            } else {
                if (!chart.indicators.data) chart.indicators.data = {};
                Object.assign(chart.indicators.data, results);
                if (!_b70ShadowEnabled()
                    && typeof chart.scheduleRender === 'function') chart.scheduleRender();
            }
            if (b70WorkerTickets) {
                var b70EnvelopeAccepted = false;
                if (b70Applied === false) {
                    _b70Stage4AbortBuild(chart, b70WorkerEnvelopeTx);
                } else {
                    var b70WorkerPublished = _b70Stage4CommitBuild(
                        chart, b70WorkerEnvelopeTx
                    );
                    var b70WorkerPartial = !b70WorkerPublished
                        && b70WorkerEnvelopeTx.partial;
                    b70EnvelopeAccepted = b70WorkerPublished || b70WorkerPartial;
                    if ((b70WorkerPublished || b70WorkerPartial)
                        && _b70Stage2Commit(chart, b70WorkerTickets)
                        && b70WorkerPublished) {
                        chart.bumpIndicatorRenderVersion();
                    }
                    if (b70WorkerPublished
                    && typeof chart.scheduleRender === 'function') {
                        chart._b70IndicatorGenerationShadow.metrics.workerCommitRenderSchedules++;
                        chart.scheduleRender();
                    }
                }
                if (!b70EnvelopeAccepted) {
                    var b70InvalidFallback = _b70Stage2ReleaseWorkerFailure(
                        chart, b70WorkerTickets
                    );
                    if (b70InvalidFallback.length) {
                        chart._b70Stage2FallbackIndicators = b70InvalidFallback;
                        try { chart.recalculateIndicators(); } catch (_) {}
                    }
                }
            }
            finishWorkerPass();
        }).catch(function(err) {
            if (chart._indicatorWorkerSeq !== mySeq
                || !_indicatorAsyncTokenMatches(chart, calcToken)) {
                chart._indicatorWorkerCoalesce = true;
                finishWorkerPass();
                return;
            }
            console.warn('[indicator-worker] async calc failed, falling back to sync:', err);
            if (b70WorkerTickets) {
                var fallbackIndicators = _b70Stage2ReleaseWorkerFailure(
                    chart, b70WorkerTickets
                );
                if (fallbackIndicators.length) {
                    chart._b70Stage2FallbackIndicators = fallbackIndicators;
                    try { chart.recalculateIndicators(); } catch (_) {}
                }
            } else {
                try { chart.recalculateIndicators(); } catch (_) {}
            }
            finishWorkerPass();
        });
    };

    Chart.prototype._getIndicatorDrawBuffer = function() {
        const base = 24;
        const spacing = typeof this.getCandleSpacing === 'function' ? this.getCandleSpacing() : 8;
        const interaction = typeof this._isInteractionFastRender === 'function' && this._isInteractionFastRender();
        if (!interaction) return base;
        const zoomFactor = spacing > 0 ? Math.min(12, Math.max(1, 8 / spacing)) : 1;
        return Math.min(512, Math.ceil(base * zoomFactor + 48));
    };

    Chart.prototype._indicatorParamsHash = function() {
        const perf = _indicatorPerf();
        if (perf && typeof perf.hashIndicatorParams === 'function') {
            return perf.hashIndicatorParams(this.indicators && this.indicators.active);
        }
        return this._indicatorVisibilityKey();
    };

    Chart.prototype._indicatorVisibilityKey = function() {
        const active = this.indicators && this.indicators.active;
        if (!active || !active.length) return '';
        try {
            return active.map(function(ind) {
                if (!ind) return '';
                const v = ind.visible === false ? '0' : '1';
                const h = ind.hidePlot === true ? '1' : '0';
                const sl = (ind.style && ind.style.showLine === false) ? '0' : '1';
                return String(ind.id) + ':' + v + h + sl;
            }).join('|');
        } catch (_) {
            return '';
        }
    };

    Chart.prototype._hasHiddenOverlayIndicator = function() {
        const active = this.indicators && this.indicators.active;
        if (!active || !active.length) return false;
        for (let i = 0; i < active.length; i++) {
            const ind = active[i];
            if (!ind || ind.overlay === false || ind.type === 'volume' || ind.isVolume) continue;
            if (ind.visible === false || ind.hidePlot === true) return true;
            if (ind.style && ind.style.showLine === false) return true;
        }
        return false;
    };

    Chart.prototype.bumpIndicatorRenderVersion = function() {
        if (typeof window !== 'undefined'
            && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true) {
            var b70State = this._b70IndicatorGenerationShadow;
            if (b70State && b70State.renderTransaction
                && b70State.renderTransaction.depth > 0) {
                b70State.metrics.paintVersionBumps++;
                return;
            }
            var b70VersionKey = _b70IndicatorGenerationKey(this);
            if (!b70State || !b70VersionKey || !b70VersionKey.id
                || !b70State.currentEnvelope
                || b70State.currentEnvelope.metadata.generationId !== b70VersionKey.id
                || b70State.lastVersionGenerationId === b70VersionKey.id) return;
            b70State.lastVersionGenerationId = b70VersionKey.id;
            _b70ShadowObserveRender(this);
        }
        this._indicatorRenderVersion = (this._indicatorRenderVersion || 0) + 1;
        if (typeof this._invalidateIndicatorLayerCache === 'function') {
            this._invalidateIndicatorLayerCache();
        }
    };

    Chart.prototype._invalidateIndicatorLayerCache = function() {
        this._indLayerCacheKey = null;
    };

    Chart.prototype._ensureIndicatorLayerCache = function() {
        if (!this._indLayerCanvas) {
            this._indLayerCanvas = document.createElement('canvas');
            // Prefer crisp compositing when blitting onto the HiDPI main canvas.
            this._indLayerCtx = this._indLayerCanvas.getContext('2d', {
                alpha: true,
                desynchronized: true,
                willReadFrequently: false
            });
        }
    };

    function _indicatorLayerDevicePixelRatio() {
        try {
            var dpr = (typeof window !== 'undefined') ? Number(window.devicePixelRatio) : 1;
            return (Number.isFinite(dpr) && dpr > 0) ? dpr : 1;
        } catch (_) {
            return 1;
        }
    }

    /**
     * Size the idle indicator cache at physical pixels and scale its ctx like the
     * main chart canvas. Previously the cache was CSS-pixel sized (1×); on HiDPI
     * idle frames looked soft while pan (direct draw) stayed sharp.
     */
    Chart.prototype._syncIndicatorLayerCanvasSize = function() {
        this._ensureIndicatorLayerCache();
        var dpr = _indicatorLayerDevicePixelRatio();
        var cssW = Math.max(1, Math.floor(Number(this.w) || 1));
        var cssH = Math.max(1, Math.floor(Number(this.h) || 1));
        var physW = Math.max(1, Math.floor(cssW * dpr));
        var physH = Math.max(1, Math.floor(cssH * dpr));
        var canvas = this._indLayerCanvas;
        var ctx = this._indLayerCtx;
        if (canvas.width !== physW || canvas.height !== physH || this._indLayerDpr !== dpr) {
            canvas.width = physW;
            canvas.height = physH;
            this._indLayerDpr = dpr;
            this._indLayerCssW = cssW;
            this._indLayerCssH = cssH;
            this._indLayerCacheKey = null;
        }
        // Logical coords match main chart (CSS pixels); DPR scale applied below.
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        return { dpr: dpr, cssW: cssW, cssH: cssH, physW: physW, physH: physH };
    };

    function _indicatorDataFingerprint(chart) {
        var data = chart && chart.data;
        if (!Array.isArray(data) || !data.length) return '0';
        var last = data[data.length - 1] || {};
        return [
            data.length,
            last.t, last.o, last.h, last.l, last.c, last.v
        ].join('|');
    }

    // ─── b70 Stages 1–5: owner, pure-paint, immutable envelope + panel bridge ───
    // Default OFF. When disabled these helpers return before allocating state
    // or adding fields to Chart/global objects. Stage 2 arbitrates calculation
    // ownership only; panel ownership and the paint bridge remain unchanged.
    function _b70ShadowEnabled() {
        return typeof window !== 'undefined'
            && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true;
    }

    function _b70SafeNext(value) {
        if (!Number.isSafeInteger(value) || value < 0
            || value >= Number.MAX_SAFE_INTEGER - 1) return null;
        return value + 1;
    }

    function _b70CanonicalValue(value, seen) {
        var type = typeof value;
        if (value === null) return 'null';
        if (type === 'string') return 's' + value.length + ':' + value;
        if (type === 'number') {
            if (Number.isNaN(value)) return 'n:NaN';
            if (value === Infinity) return 'n:+Infinity';
            if (value === -Infinity) return 'n:-Infinity';
            if (Object.is(value, -0)) return 'n:-0';
            return 'n:' + String(value);
        }
        if (type === 'boolean') return value ? 'b:1' : 'b:0';
        if (type === 'undefined') return 'u:';
        if (type === 'bigint') return 'i:' + String(value);
        if (type !== 'object') return type.charAt(0) + ':' + String(value);
        if (seen.indexOf(value) >= 0) throw new TypeError('cyclic indicator params');
        seen.push(value);
        var text;
        if (Array.isArray(value)) {
            text = 'a' + value.length + '[' + value.map(function(item) {
                return _b70CanonicalValue(item, seen);
            }).join('') + ']';
        } else {
            var keys = Object.keys(value).sort();
            text = 'o' + keys.length + '{' + keys.map(function(key) {
                return _b70CanonicalValue(key, seen)
                    + _b70CanonicalValue(value[key], seen);
            }).join('') + '}';
        }
        seen.pop();
        return text;
    }

    function _b70StableIndicatorSetHash(chart) {
        var active = chart && chart.indicators && chart.indicators.active;
        if (!Array.isArray(active)) return '';
        try {
            // Active order is calculation-significant. Length-framed canonical
            // values avoid delimiter/type collisions and nested key-order churn.
            return _b70CanonicalValue(active.map(function(ind) {
                if (!ind) return null;
                return {
                    id: String(ind.id || ''),
                    type: String(ind.type || '').toLowerCase(),
                    params: ind.params || {}
                };
            }), []);
        } catch (_) {
            return 'invalid-indicator-set';
        }
    }

    function _b70SessionIdentity() {
        var origin = '';
        try {
            origin = (typeof performance !== 'undefined'
                && Number.isFinite(performance.timeOrigin))
                ? String(performance.timeOrigin) : String(Date.now());
        } catch (_) { origin = String(Date.now()); }
        return origin;
    }

    var _b70Stage4PrivateBuilds = new WeakMap();
    var _b70Stage5Hosts = new WeakMap();
    var _b70Stage5Panels = new WeakMap();

    function _b70Stage5Now() {
        return _b70Stage4Now();
    }

    function _b70Stage5ChartIdentity(chart) {
        if (!chart) return '';
        return String(
            chart.multichartPanelId != null ? chart.multichartPanelId
                : chart.panelId != null ? chart.panelId
                    : chart.panelIndex != null ? chart.panelIndex : 'host'
        );
    }

    function _b70Stage5InstrumentIdentity(chart) {
        return [
            String(chart && chart.currentSymbol || ''),
            String(chart && chart.currentFileId || ''),
            String(chart && chart.masterGeneration || '')
        ].join('¦');
    }

    function _b70Stage5HostState(chart) {
        var value = _b70Stage5Hosts.get(chart);
        if (!value) {
            value = {
                publicationSeq: 0,
                panels: new Set(),
                disposed: false
            };
            _b70Stage5Hosts.set(chart, value);
        }
        return value;
    }

    function _b70Stage5PanelState(chart) {
        var value = _b70Stage5Panels.get(chart);
        if (!value) {
            value = {
                host: null,
                hostChartId: null,
                hostSessionEpoch: null,
                generationId: null,
                mode: 'idle',
                timer: null,
                lastPublicationSeq: 0,
                accepting: false,
                pending: null,
                disposed: false
            };
            _b70Stage5Panels.set(chart, value);
        }
        return value;
    }

    function _b70Stage5ResolveHost(chart) {
        if (!chart) return null;
        var panelState = _b70Stage5Panels.get(chart);
        if (panelState && panelState.host) return panelState.host;
        try {
            if (typeof window !== 'undefined' && window.parent
                && window.parent !== window && window.parent.location
                && window.location
                && window.parent.location.origin === window.location.origin) {
                return window.parent.chart || window.parent.mainChart || null;
            }
        } catch (_) {
            return null;
        }
        return null;
    }

    function _b70Stage5Comparable(chart, host) {
        if (!chart || !host || chart === host) return false;
        var localKey = _b70IndicatorGenerationKey(chart);
        var hostKey = _b70IndicatorGenerationKey(host);
        return !!(localKey && hostKey && localKey.id && hostKey.id
            && _b70Stage5InstrumentIdentity(chart) === _b70Stage5InstrumentIdentity(host)
            && localKey.timeframe === hostKey.timeframe
            && localKey.dataVersion === hostKey.dataVersion
            && localKey.barCount === hostKey.barCount
            && localKey.tailBarFingerprint === hostKey.tailBarFingerprint
            && localKey.indicatorSetHash === hostKey.indicatorSetHash);
    }

    function _b70Stage5ClearPanelWait(panelState) {
        if (panelState && panelState.timer != null) {
            clearTimeout(panelState.timer);
            panelState.timer = null;
        }
    }

    function _b70Stage5UnregisterPanel(chart) {
        var panelState = _b70Stage5Panels.get(chart);
        if (!panelState) return;
        _b70Stage5ClearPanelWait(panelState);
        if (panelState.host
            && typeof panelState.host._b70Stage5UnregisterPanelBridge === 'function') {
            panelState.host._b70Stage5UnregisterPanelBridge(chart);
        } else if (panelState.host) {
            _b70Stage5UnregisterHostPanel(panelState.host, chart);
        }
        panelState.disposed = true;
        panelState.pending = null;
        _b70Stage5Panels.delete(chart);
    }

    function _b70Stage5UnregisterHostPanel(host, panel) {
        var hostState = _b70Stage5Hosts.get(host);
        if (!hostState) return;
        hostState.panels.forEach(function(record) {
            if (record.chart === panel) hostState.panels.delete(record);
        });
    }

    function _b70Stage5Invalidate(chart, dispose) {
        var panelState = _b70Stage5Panels.get(chart);
        if (panelState) {
            _b70Stage5ClearPanelWait(panelState);
            if (panelState.host
                && typeof panelState.host._b70Stage5UnregisterPanelBridge === 'function') {
                panelState.host._b70Stage5UnregisterPanelBridge(chart);
            } else if (panelState.host) {
                _b70Stage5UnregisterHostPanel(panelState.host, chart);
            }
            panelState.host = null;
            panelState.hostChartId = null;
            panelState.hostSessionEpoch = null;
            panelState.generationId = null;
            panelState.mode = 'idle';
            panelState.pending = null;
            panelState.lastPublicationSeq = 0;
            if (dispose) _b70Stage5UnregisterPanel(chart);
        }
        var hostState = _b70Stage5Hosts.get(chart);
        if (hostState && dispose) {
            hostState.disposed = true;
            hostState.panels.clear();
            _b70Stage5Hosts.delete(chart);
        }
    }

    function _b70Stage5Origin() {
        try {
            return String(window.location && window.location.origin || '');
        } catch (_) {
            return '';
        }
    }

    function _b70Stage5RegisterPanel(host, panel, receiver) {
        if (!host || !panel || host === panel || typeof receiver !== 'function') return false;
        if (!_b70Stage5Comparable(panel, host)) return false;
        var hostState = _b70Stage5HostState(host);
        if (hostState.disposed) return false;
        var existing = null;
        hostState.panels.forEach(function(record) {
            if (record.chart === panel) existing = record;
        });
        if (!existing) {
            existing = { chart: panel, receive: receiver };
            hostState.panels.add(existing);
        } else {
            existing.receive = receiver;
        }
        var panelState = _b70Stage5PanelState(panel);
        panelState.host = host;
        panelState.hostChartId = _b70Stage5ChartIdentity(host);
        var hostShadow = _b70ShadowState(host);
        panelState.hostSessionEpoch = hostShadow && hostShadow.sessionEpoch;
        return true;
    }

    function _b70Stage5BuildMessage(host, tickets, publicationSeq) {
        // IndicatorResultEnvelope v1: immutable calculation payload plus all
        // identities and publication authority required for panel admission.
        var state = host && host._b70IndicatorGenerationShadow;
        var envelope = state && state.currentEnvelope;
        var key = _b70IndicatorGenerationKey(host);
        if (!state || !envelope || !envelope.metadata || !key || !key.id
            || envelope.metadata.generationId !== key.id) return null;
        var requestedIds = (host.indicators.active || []).filter(Boolean)
            .map(function(indicator) { return String(indicator.id); });
        var committed = [];
        state.ownerTickets.forEach(function(ticket) {
            if (ticket && ticket.status === 'committed'
                && ticket.generationId === key.id) committed.push(ticket);
        });
        var authorities = committed.map(function(ticket) {
            return {
                generationId: ticket.generationId,
                instanceId: ticket.instanceId,
                ownerKind: ticket.ownerKind,
                ownerId: ticket.ownerId,
                claimSeq: ticket.claimSeq,
                status: ticket.status
            };
        });
        if (authorities.length !== requestedIds.length
            || authorities.some(function(ticket) {
                return ticket.status !== 'committed'
                    || ticket.generationId !== key.id
                    || requestedIds.indexOf(ticket.instanceId) < 0;
            })) return null;
        return {
            type: 'talaria:b70-indicator-envelope',
            envelopeType: 'IndicatorResultEnvelope',
            contractVersion: 1,
            origin: _b70Stage5Origin(),
            sessionEpoch: state.sessionEpoch,
            hostChartId: _b70Stage5ChartIdentity(host),
            instrumentIdentity: _b70Stage5InstrumentIdentity(host),
            timeframe: key.timeframe,
            dataGeneration: {
                datasetEpoch: key.datasetEpoch,
                timelineEpoch: key.timelineEpoch,
                dataVersion: key.dataVersion,
                barCount: key.barCount,
                tailBarFingerprint: key.tailBarFingerprint
            },
            indicatorConfigIdentity: key.indicatorSetHash,
            calculationRevision: key.calculationRevision,
            hostGenerationId: key.id,
            publicationSeq: publicationSeq,
            ownerTickets: authorities,
            requestedSet: {
                instanceIds: requestedIds,
                count: requestedIds.length,
                complete: true
            },
            payload: envelope.data,
            payloadBytes: envelope.metadata.byteLength
        };
    }

    function _b70Stage5PublishHostEnvelope(host, tickets) {
        var state = host && host._b70IndicatorGenerationShadow;
        var hostState = _b70Stage5Hosts.get(host);
        if (!state || !hostState || hostState.disposed || !hostState.panels.size) return;
        var next = _b70SafeNext(hostState.publicationSeq);
        if (next == null) {
            state.metrics.bridgeFailClosed++;
            hostState.disposed = true;
            hostState.panels.clear();
            return;
        }
        var message = _b70Stage5BuildMessage(host, tickets, next);
        if (!message) {
            state.metrics.bridgePublicationRejects++;
            return;
        }
        hostState.publicationSeq = next;
        state.metrics.bridgePublications++;
        state.metrics.bridgeBytes += message.payloadBytes || 0;
        hostState.panels.forEach(function(record) {
            var started = _b70Stage5Now();
            try {
                if (typeof structuredClone !== 'function') throw new Error('structuredClone unavailable');
                var clone = structuredClone(message);
                state.metrics.bridgeCloneTimeMs += _b70Stage5Now() - started;
                record.receive(clone);
                state.metrics.bridgeDeliveries++;
            } catch (_) {
                state.metrics.bridgeDeliveryFailures++;
            }
        });
    }

    function _b70Stage5Reject(panel, metric) {
        var state = panel && panel._b70IndicatorGenerationShadow;
        if (state && state.metrics[metric] != null) state.metrics[metric]++;
        if (state) state.metrics.bridgeRejects++;
        return false;
    }

    function _b70Stage5ValidateMessage(panel, message, panelState) {
        var state = panel && panel._b70IndicatorGenerationShadow;
        var key = _b70IndicatorGenerationKey(panel);
        if (!state || !key || !key.id || !message || typeof message !== 'object'
            || message.type !== 'talaria:b70-indicator-envelope'
            || message.envelopeType !== 'IndicatorResultEnvelope'
            || message.contractVersion !== 1) return _b70Stage5Reject(panel, 'bridgeSchemaRejects');
        if (message.origin !== _b70Stage5Origin()
            || message.hostChartId !== panelState.hostChartId
            || message.sessionEpoch !== panelState.hostSessionEpoch) {
            return _b70Stage5Reject(panel, 'bridgeForeignRejects');
        }
        if (!Number.isSafeInteger(message.publicationSeq)
            || message.publicationSeq <= panelState.lastPublicationSeq) {
            return _b70Stage5Reject(panel, 'bridgeOrderRejects');
        }
        if (panelState.mode === 'bridged'
            && panelState.generationId === key.id) {
            return _b70Stage5Reject(panel, 'bridgeOrderRejects');
        }
        if (panelState.mode === 'fallback'
            && panelState.generationId === key.id) {
            return _b70Stage5Reject(panel, 'bridgeLateRejects');
        }
        var generation = message.dataGeneration || {};
        if (message.instrumentIdentity !== _b70Stage5InstrumentIdentity(panel)
            || message.timeframe !== key.timeframe
            || generation.datasetEpoch !== key.datasetEpoch
            || generation.timelineEpoch !== key.timelineEpoch
            || generation.dataVersion !== key.dataVersion
            || generation.barCount !== key.barCount
            || generation.tailBarFingerprint !== key.tailBarFingerprint
            || message.indicatorConfigIdentity !== key.indicatorSetHash
            || message.calculationRevision !== key.calculationRevision) {
            return _b70Stage5Reject(panel, 'bridgeStaleRejects');
        }
        var active = panel.indicators.active || [];
        var requested = message.requestedSet;
        var expectedIds = active.filter(Boolean)
            .map(function(indicator) { return String(indicator.id); });
        var requestedSeen = Object.create(null);
        var authoritySeen = Object.create(null);
        if (!requested || requested.complete !== true
            || requested.count !== expectedIds.length
            || !Array.isArray(requested.instanceIds)
            || requested.instanceIds.length !== expectedIds.length
            || expectedIds.some(function(id) {
                return requested.instanceIds.indexOf(id) < 0;
            })
            || requested.instanceIds.some(function(id) {
                id = String(id);
                if (requestedSeen[id]) return true;
                requestedSeen[id] = true;
                return expectedIds.indexOf(id) < 0;
            })) return _b70Stage5Reject(panel, 'bridgePartialRejects');
        if (!Array.isArray(message.ownerTickets)
            || message.ownerTickets.length !== expectedIds.length) {
            return _b70Stage5Reject(panel, 'bridgePartialRejects');
        }
        for (var authorityIndex = 0;
            authorityIndex < message.ownerTickets.length; authorityIndex++) {
            var ticket = message.ownerTickets[authorityIndex];
            var instanceId = ticket && String(ticket.instanceId);
            if (ticket && authoritySeen[instanceId]) {
                return _b70Stage5Reject(
                    panel, 'bridgeDuplicateAuthorityRejects'
                );
            }
            if (ticket) authoritySeen[instanceId] = true;
            if (!ticket || ticket.status !== 'committed'
                    || ticket.generationId !== message.hostGenerationId
                    || expectedIds.indexOf(instanceId) < 0
                    || (ticket.ownerKind !== 'sync' && ticket.ownerKind !== 'worker')
                    || typeof ticket.ownerId !== 'string' || !ticket.ownerId
                    || !Number.isSafeInteger(ticket.claimSeq) || ticket.claimSeq <= 0) {
                return _b70Stage5Reject(
                    panel, 'bridgeMalformedAuthorityRejects'
                );
            }
        }
        if (!message.payload || typeof message.payload !== 'object'
            || active.some(function(indicator) {
                var id = String(indicator.id);
                return !Object.prototype.hasOwnProperty.call(message.payload, id)
                    || !_b70Stage4ValidateIndicatorResult(
                        indicator, message.payload[id], key.barCount
                    );
            })) return _b70Stage5Reject(panel, 'bridgeSchemaRejects');
        return { key: key, active: active };
    }

    function _b70Stage5ReceivePanelEnvelope(panel, message) {
        var panelState = _b70Stage5PanelState(panel);
        if (panelState.disposed) return false;
        if (panelState.accepting) {
            if (!panelState.pending
                || message.publicationSeq > panelState.pending.publicationSeq) {
                panelState.pending = message;
            }
            var queuedState = panel._b70IndicatorGenerationShadow;
            if (queuedState) queuedState.metrics.bridgeCoalesced++;
            return false;
        }
        panelState.accepting = true;
        var accepted = false;
        try {
            var validation = _b70Stage5ValidateMessage(panel, message, panelState);
            if (!validation) return false;
            var state = panel._b70IndicatorGenerationShadow;
            var metadata = {
                envelopeType: message.envelopeType,
                contractVersion: message.contractVersion,
                generationId: validation.key.id,
                generationKey: validation.key,
                hostGenerationId: message.hostGenerationId,
                publicationSeq: message.publicationSeq,
                byteLength: message.payloadBytes || 0,
                ownerTickets: message.ownerTickets,
                bridgeInstanceIds: message.requestedSet.instanceIds.slice()
            };
            var envelope = {
                data: message.payload,
                metadata: metadata
            };
            if (typeof window !== 'undefined'
                && window.__TALARIA_B70_DEV_FREEZE_ENVELOPES === true) {
                _b70Stage4DeepFreeze(envelope, new Set());
            }
            if (state.retiredEnvelope) state.metrics.envelopeReleases++;
            state.retiredEnvelope = state.currentEnvelope;
            state.currentEnvelope = envelope;
            panel.indicators.data = envelope.data;
            panelState.lastPublicationSeq = message.publicationSeq;
            panelState.generationId = validation.key.id;
            panelState.mode = 'bridged';
            _b70Stage5ClearPanelWait(panelState);
            state.metrics.bridgeAccepts++;
            state.metrics.bridgeRetainedBytes = message.payloadBytes || 0;
            if (state.metrics.bridgeRetainedBytes > state.metrics.bridgePeakRetainedBytes) {
                state.metrics.bridgePeakRetainedBytes = state.metrics.bridgeRetainedBytes;
            }
            panel.bumpIndicatorRenderVersion();
            if (typeof panel.scheduleRender === 'function') panel.scheduleRender();
            accepted = true;
            return true;
        } finally {
            panelState.accepting = false;
            if (panelState.pending) {
                var pending = panelState.pending;
                panelState.pending = null;
                _b70Stage5ReceivePanelEnvelope(panel, pending);
            }
        }
    }

    function _b70Stage5DeferPanelCalculation(panel) {
        var host = _b70Stage5ResolveHost(panel);
        if (!host || !_b70Stage5Comparable(panel, host)) return false;
        var panelState = _b70Stage5PanelState(panel);
        var key = _b70IndicatorGenerationKey(panel);
        if (!key || !key.id || panelState.disposed) return false;
        if (panelState.mode === 'fallback' && panelState.generationId === key.id) {
            return false;
        }
        if (panelState.mode === 'bridged' && panelState.generationId === key.id
            && _b70Stage3CommittedForCurrentGeneration(panel, key)) return true;
        if (panelState.generationId !== key.id) {
            _b70Stage5ClearPanelWait(panelState);
            panelState.generationId = key.id;
            panelState.mode = 'waiting';
        }
        var receiver = function(message) {
            _b70Stage5ReceivePanelEnvelope(panel, message);
        };
        var registered = typeof host._b70Stage5RegisterPanelBridge === 'function'
            ? host._b70Stage5RegisterPanelBridge(panel, receiver)
            : _b70Stage5RegisterPanel(host, panel, receiver);
        if (!registered) return false;
        panelState.host = host;
        panelState.hostChartId = _b70Stage5ChartIdentity(host);
        panelState.hostSessionEpoch =
            host._b70IndicatorGenerationShadow
            && host._b70IndicatorGenerationShadow.sessionEpoch;
        var state = panel._b70IndicatorGenerationShadow;
        state.metrics.bridgePanelRequests++;
        var hostState = host._b70IndicatorGenerationShadow;
        if (hostState && hostState.currentEnvelope
            && _b70Stage3CommittedForCurrentGeneration(
                host, _b70IndicatorGenerationKey(host)
            )) {
            var committedTickets = [];
            hostState.ownerTickets.forEach(function(ticket) {
                if (ticket.status === 'committed'
                    && ticket.generationId ===
                        hostState.currentEnvelope.metadata.generationId) {
                    committedTickets.push(ticket);
                }
            });
            _b70Stage5PublishHostEnvelope(host, committedTickets);
        } else if (typeof host.recalculateIndicators === 'function') {
            try { host.recalculateIndicators(); } catch (_) {}
        }
        if (panelState.mode === 'bridged') return true;
        if (panelState.timer == null) {
            panelState.timer = setTimeout(function() {
                panelState.timer = null;
                if (panelState.disposed || panelState.mode !== 'waiting'
                    || panelState.generationId !== key.id) return;
                panelState.mode = 'fallback';
                state.metrics.bridgeFallbacks++;
                try { panel.recalculateIndicators(); } catch (_) {}
            }, typeof window !== 'undefined'
                && Number.isFinite(window.__TALARIA_B70_BRIDGE_TIMEOUT_MS)
                ? Math.max(0, window.__TALARIA_B70_BRIDGE_TIMEOUT_MS) : 2000);
        }
        return true;
    }

    function _b70Stage5BindPanelForTest(panel, host) {
        var panelState = _b70Stage5PanelState(panel);
        panelState.host = host;
        return _b70Stage5RegisterPanel(
            host, panel, function(message) {
                _b70Stage5ReceivePanelEnvelope(panel, message);
            }
        );
    }

    if (_b70ShadowEnabled() && typeof window !== 'undefined') {
        window.__TALARIA_B70_CONNECT_INDICATOR_PANEL_V1 = function(panel, host) {
            var state = _b70ShadowState(panel);
            if (!state || !panel._b70Stage5ConnectIndicatorHost) return false;
            return panel._b70Stage5ConnectIndicatorHost(host);
        };
    }

    function _b70Stage4PrivateState(chart) {
        var value = _b70Stage4PrivateBuilds.get(chart);
        if (!value) {
            value = { active: null, pending: null, disposed: false };
            _b70Stage4PrivateBuilds.set(chart, value);
        }
        return value;
    }

    function _b70Stage4InvalidatePrivate(chart, dispose) {
        var value = _b70Stage4PrivateBuilds.get(chart);
        if (!value) return;
        if (value.active) value.active.invalidated = true;
        value.active = null;
        value.pending = null;
        if (dispose) {
            value.disposed = true;
            _b70Stage4PrivateBuilds.delete(chart);
        }
    }

    function _b70ShadowState(chart) {
        if (!_b70ShadowEnabled() || !chart) return null;
        if (chart._b70IndicatorGenerationShadow) {
            return chart._b70IndicatorGenerationShadow;
        }
        var state = {
            schemaVersion: 1,
            calculationRevision: 'b70-stage5-v1',
            sessionEpoch: _b70SessionIdentity(),
            datasetEpoch: 1,
            timelineEpoch: 1,
            exhausted: false,
            lastDataRef: chart.data,
            lastDataVersion: chart.dataVersion != null ? chart.dataVersion : 0,
            lastDatasetIdentity: null,
            lastKey: null,
            registry: new Map(),
            ownerTickets: new Map(),
            latestByInstance: new Map(),
            fallbackGenerations: new Set(),
            nextClaimSeq: 0,
            currentEnvelope: null,
            retiredEnvelope: null,
            lastVersionGenerationId: null,
            renderTransaction: {
                depth: 0,
                ownerSeq: 0,
                owner: null,
                deferredGenerationId: null,
                deferredScheduled: false,
                disposed: false
            },
            metrics: {
                requestedGenerations: 0,
                uniqueRequestedGenerations: 0,
                wouldBeOwnerClaims: { sync: 0, worker: 0, paint: 0, unknown: 0 },
                calculationStarts: 0,
                duplicateCalculations: 0,
                calculationsBySource: {},
                sessionInvalidations: 0,
                datasetInvalidations: 0,
                timelineInvalidations: 0,
                timeframeInvalidations: 0,
                removalInvalidations: 0,
                renderStable: 0,
                renderUnexpectedChanges: 0,
                legacyTokenComparisons: 0,
                legacyTokenAgreement: 0,
                legacyTokenDisagreement: 0,
                failClosed: 0,
                ownerClaims: { sync: 0, worker: 0 },
                ownerCommits: { sync: 0, worker: 0 },
                ownerDenied: 0,
                lateWorkerRejects: 0,
                duplicateWorkerRejects: 0,
                workerFailures: 0,
                fallbackClaims: 0,
                fallbackDenied: 0,
                supersededPending: 0,
                ownerFailClosed: 0,
                paintTransactions: 0,
                paintReentries: 0,
                paintExceptions: 0,
                maxPaintDepth: 0,
                paintConsumerHits: 0,
                paintMissingGenerations: 0,
                paintDeferredRequests: 0,
                paintCalculations: 0,
                paintPublications: 0,
                paintVersionBumps: 0,
                paintRenderSchedules: 0,
                successfulCommits: 0,
                workerCommitRenderSchedules: 0,
                envelopeBuilds: 0,
                envelopeCommits: 0,
                envelopeRejects: 0,
                envelopeCopyBytes: 0,
                envelopeCopyTimeMs: 0,
                envelopeRetainedBytes: 0,
                envelopePeakRetainedBytes: 0,
                envelopeReleases: 0,
                envelopeConsumerMutations: 0,
                envelopeAliasRejects: 0,
                bridgePublications: 0,
                bridgePublicationRejects: 0,
                bridgeDeliveries: 0,
                bridgeDeliveryFailures: 0,
                bridgeAccepts: 0,
                bridgeRejects: 0,
                bridgeSchemaRejects: 0,
                bridgeForeignRejects: 0,
                bridgeOrderRejects: 0,
                bridgeStaleRejects: 0,
                bridgePartialRejects: 0,
                bridgeDuplicateAuthorityRejects: 0,
                bridgeMalformedAuthorityRejects: 0,
                bridgeLateRejects: 0,
                bridgePanelRequests: 0,
                bridgeFallbacks: 0,
                bridgeCoalesced: 0,
                bridgeFailClosed: 0,
                bridgeBytes: 0,
                bridgeCloneTimeMs: 0,
                bridgeRetainedBytes: 0,
                bridgePeakRetainedBytes: 0
            }
        };
        chart._b70IndicatorGenerationShadow = state;
        chart._b70ShadowInvalidateIndicatorGeneration = function(reason) {
            _b70ShadowInvalidate(chart, reason);
        };
        chart._b70HasCommittedIndicatorGeneration = function() {
            var key = _b70IndicatorGenerationKey(chart);
            return _b70Stage3CommittedForCurrentGeneration(chart, key);
        };
        chart._b70Stage5RegisterPanelBridge = function(panel, receiver) {
            return _b70Stage5RegisterPanel(chart, panel, receiver);
        };
        chart._b70Stage5UnregisterPanelBridge = function(panel) {
            _b70Stage5UnregisterHostPanel(chart, panel);
        };
        chart._b70Stage5AcceptIndicatorEnvelope = function(message) {
            return _b70Stage5ReceivePanelEnvelope(chart, message);
        };
        chart._b70Stage5ConnectIndicatorHost = function(host) {
            var panelState = _b70Stage5PanelState(chart);
            panelState.host = host;
            return _b70Stage5RegisterPanel(
                host, chart, chart._b70Stage5AcceptIndicatorEnvelope
            );
        };
        chart._b70ShadowDisposeIndicatorGeneration = function() {
            _b70Stage4InvalidatePrivate(chart, true);
            _b70Stage5Invalidate(chart, true);
            state.renderTransaction.disposed = true;
            state.renderTransaction.depth = 0;
            state.renderTransaction.owner = null;
            state.renderTransaction.deferredGenerationId = null;
            state.renderTransaction.deferredScheduled = false;
            state.currentEnvelope = null;
            state.retiredEnvelope = null;
            state.lastVersionGenerationId = null;
            state.registry.clear();
            state.ownerTickets.clear();
            state.latestByInstance.clear();
            state.fallbackGenerations.clear();
            try { delete chart._b70Stage5RegisterPanelBridge; } catch (_) {}
            try { delete chart._b70Stage5UnregisterPanelBridge; } catch (_) {}
            try { delete chart._b70Stage5AcceptIndicatorEnvelope; } catch (_) {}
            try { delete chart._b70Stage5ConnectIndicatorHost; } catch (_) {}
            state.lastKey = null;
            delete chart._b70ShadowInvalidateIndicatorGeneration;
            delete chart._b70ShadowDisposeIndicatorGeneration;
            delete chart._b70HasCommittedIndicatorGeneration;
            delete chart._b70IndicatorGenerationShadow;
        };
        return state;
    }

    function _b70DatasetIdentity(chart) {
        return [
            _m19iB62ChartPairIdentity(chart),
            String(chart && chart.currentFileId != null ? chart.currentFileId : ''),
            _m19iB62MasterGeneration(chart)
        ].join('|');
    }

    function _b70ShadowAdvance(state, field, metric) {
        var next = _b70SafeNext(state[field]);
        if (next == null) {
            state.exhausted = true;
            state.metrics.failClosed++;
            state.registry.clear();
            state.ownerTickets.clear();
            state.latestByInstance.clear();
            state.fallbackGenerations.clear();
            state.lastKey = null;
            return false;
        }
        state[field] = next;
        if (metric) state.metrics[metric]++;
        state.registry.clear();
        state.ownerTickets.clear();
        state.latestByInstance.clear();
        state.fallbackGenerations.clear();
        if (state.retiredEnvelope) state.metrics.envelopeReleases++;
        state.retiredEnvelope = null;
        state.lastKey = null;
        return true;
    }

    function _b70ObserveDataset(chart, state) {
        var identity = _b70DatasetIdentity(chart);
        var replaced = state.lastDataRef !== chart.data;
        var dataVersion = chart.dataVersion != null ? chart.dataVersion : 0;
        var identityChanged = state.lastDatasetIdentity != null
            && state.lastDatasetIdentity !== identity;
        // A normal replay resample replaces chart.data while dataVersion also
        // advances; that is a calculation generation, not a dataset epoch.
        // Same-version reference replacement remains a fail-closed dataset swap.
        if ((replaced && dataVersion === state.lastDataVersion) || identityChanged) {
            _b70ShadowAdvance(state, 'datasetEpoch', 'datasetInvalidations');
        }
        state.lastDataRef = chart.data;
        state.lastDataVersion = dataVersion;
        state.lastDatasetIdentity = identity;
    }

    function _b70IndicatorGenerationKey(chart) {
        var state = _b70ShadowState(chart);
        if (!state) return null;
        _b70ObserveDataset(chart, state);
        var data = Array.isArray(chart.data) ? chart.data : [];
        var key = {
            schemaVersion: 1,
            sessionEpoch: state.sessionEpoch,
            datasetEpoch: state.datasetEpoch,
            timelineEpoch: state.timelineEpoch,
            timeframe: String(chart.currentTimeframe || ''),
            dataVersion: chart.dataVersion != null ? chart.dataVersion : 0,
            barCount: data.length,
            tailBarFingerprint: _indicatorDataFingerprint(chart),
            indicatorSetHash: _b70StableIndicatorSetHash(chart),
            calculationRevision: state.calculationRevision,
            failClosed: state.exhausted
        };
        key.id = key.failClosed ? null : [
            key.sessionEpoch, key.datasetEpoch, key.timelineEpoch,
            key.timeframe, key.dataVersion, key.barCount,
            key.tailBarFingerprint, key.indicatorSetHash,
            key.calculationRevision
        ].join('¦');
        return key;
    }

    function _b70ShadowRecordRequest(chart, source) {
        var key = _b70IndicatorGenerationKey(chart);
        if (!key || !key.id) return;
        var state = chart._b70IndicatorGenerationShadow;
        var row = state.registry.get(key.id);
        state.metrics.requestedGenerations++;
        if (!row) {
            row = { key: key, requests: 0, calculations: 0, sources: {}, wouldBeOwner: null };
            state.registry.set(key.id, row);
            state.metrics.uniqueRequestedGenerations++;
        }
        row.requests++;
        row.sources[source] = (row.sources[source] || 0) + 1;
        var active = chart.indicators && chart.indicators.active;
        if (Array.isArray(active)) {
            active.forEach(function(indicator) {
                if (!indicator || indicator.id == null) return;
                var latest = state.latestByInstance.get(String(indicator.id));
                if (!latest || latest.status !== 'claimed'
                    || latest.generationId === key.id) return;
                if (latest.pendingGenerationId
                    && latest.pendingGenerationId !== key.id) {
                    state.metrics.supersededPending++;
                }
                latest.pendingGenerationId = key.id;
            });
        }
        state.lastKey = key;
    }

    function _b70ShadowRecordCalculation(chart, source, ownerKind) {
        var key = _b70IndicatorGenerationKey(chart);
        if (!key || !key.id) return;
        var state = chart._b70IndicatorGenerationShadow;
        var row = state.registry.get(key.id);
        if (!row) {
            row = { key: key, requests: 0, calculations: 0, sources: {}, wouldBeOwner: null };
            state.registry.set(key.id, row);
        }
        state.metrics.calculationStarts++;
        state.metrics.calculationsBySource[source] =
            (state.metrics.calculationsBySource[source] || 0) + 1;
        if (row.calculations > 0) state.metrics.duplicateCalculations++;
        row.calculations++;
        row.sources[source] = (row.sources[source] || 0) + 1;
        if (!row.wouldBeOwner) {
            var owner = ownerKind || 'unknown';
            if (!(owner in state.metrics.wouldBeOwnerClaims)) owner = 'unknown';
            row.wouldBeOwner = owner;
            state.metrics.wouldBeOwnerClaims[owner]++;
        }
        state.lastKey = key;
    }

    function _b70ShadowInvalidate(chart, reason) {
        var state = _b70ShadowState(chart);
        if (!state) return;
        // Reentrant invalidation revokes only closure-private build state.
        _b70Stage4InvalidatePrivate(chart, false);
        _b70Stage5Invalidate(chart, false);
        var text = String(reason || '');
        if (text.indexOf('session') >= 0 || text.indexOf('reload') >= 0) {
            state.metrics.sessionInvalidations++;
            state.sessionEpoch = _b70SessionIdentity() + ':' + state.metrics.sessionInvalidations;
            state.registry.clear();
            state.ownerTickets.clear();
            state.latestByInstance.clear();
            state.fallbackGenerations.clear();
            if (state.currentEnvelope) state.metrics.envelopeReleases++;
            if (state.retiredEnvelope) state.metrics.envelopeReleases++;
            state.currentEnvelope = null;
            state.retiredEnvelope = null;
            state.lastKey = null;
            _b70Stage4UpdateRetainedBytes(
                state, _b70Stage4PrivateState(chart), 0
            );
            return;
        }
        if (text.indexOf('seek') >= 0 || text.indexOf('timeline') >= 0
            || text.indexOf('go-back') >= 0) {
            _b70ShadowAdvance(state, 'timelineEpoch', 'timelineInvalidations');
            _b70Stage4UpdateRetainedBytes(
                state, _b70Stage4PrivateState(chart), 0
            );
            return;
        }
        if (text.indexOf('timeframe') >= 0) {
            state.metrics.timeframeInvalidations++;
            _b70ShadowAdvance(state, 'timelineEpoch', null);
            _b70Stage4UpdateRetainedBytes(
                state, _b70Stage4PrivateState(chart), 0
            );
            return;
        }
        if (text.indexOf('remove') >= 0 || text.indexOf('clear') >= 0) {
            state.metrics.removalInvalidations++;
            state.registry.clear();
            state.ownerTickets.clear();
            state.latestByInstance.clear();
            state.fallbackGenerations.clear();
            if (state.currentEnvelope) state.metrics.envelopeReleases++;
            if (state.retiredEnvelope) state.metrics.envelopeReleases++;
            state.currentEnvelope = null;
            state.retiredEnvelope = null;
            state.lastKey = null;
            _b70Stage4UpdateRetainedBytes(
                state, _b70Stage4PrivateState(chart), 0
            );
            return;
        }
        _b70ShadowAdvance(state, 'datasetEpoch', 'datasetInvalidations');
        _b70Stage4UpdateRetainedBytes(
            state, _b70Stage4PrivateState(chart), 0
        );
    }

    function _b70Stage2InstanceOwner(indicator) {
        if (!indicator) return 'sync';
        var type = String(indicator.type || '').toLowerCase();
        if (type === 'volume' || type === 'custom'
            || M19I_SYNC_ONLY_TYPES.indexOf(type) >= 0
            || type === 'supertrend' || type === 'adr') return 'sync';
        if (_m19iB62SyncFamily(indicator)) return 'sync';
        if (typeof _m19iB66Proof === 'function' && _m19iB66Proof(indicator)) return 'sync';
        return 'worker';
    }

    function _b70Stage2TicketKey(generationId, instanceId) {
        return generationId + '§' + String(instanceId);
    }

    function _b70Stage2Claim(chart, requestedOwner, indicators, source, fallback) {
        var state = _b70ShadowState(chart);
        var key = _b70IndicatorGenerationKey(chart);
        if (!state || !key || !key.id || state.exhausted) return [];
        var claimUpperBound = Array.isArray(indicators) ? indicators.length : 0;
        if (!Number.isSafeInteger(state.nextClaimSeq)
            || state.nextClaimSeq < 0
            || state.nextClaimSeq > Number.MAX_SAFE_INTEGER - 1 - claimUpperBound) {
            state.exhausted = true;
            state.metrics.ownerFailClosed++;
            state.ownerTickets.clear();
            state.latestByInstance.clear();
            return [];
        }
        var tickets = [];
        (indicators || []).forEach(function(indicator) {
            if (!indicator || indicator.id == null) return;
            var instanceId = String(indicator.id);
            var expected = fallback ? requestedOwner : _b70Stage2InstanceOwner(indicator);
            if (expected !== requestedOwner) return;
            var ticketKey = _b70Stage2TicketKey(key.id, instanceId);
            if (!fallback && requestedOwner === 'worker'
                && state.fallbackGenerations.has(ticketKey)) {
                state.metrics.ownerDenied++;
                return;
            }
            var existing = state.ownerTickets.get(ticketKey);
            if (existing) {
                state.metrics.ownerDenied++;
                return;
            }
            var latest = state.latestByInstance.get(instanceId);
            if (latest && latest.generationId !== key.id
                && latest.status === 'claimed') {
                if (latest.pendingGenerationId
                    && latest.pendingGenerationId !== key.id) {
                    state.metrics.supersededPending++;
                }
                latest.pendingGenerationId = key.id;
            }
            if (latest && latest.generationId !== key.id) {
                state.ownerTickets.delete(
                    _b70Stage2TicketKey(latest.generationId, instanceId)
                );
                state.fallbackGenerations.delete(
                    _b70Stage2TicketKey(latest.generationId, instanceId)
                );
            }
            state.nextClaimSeq = _b70SafeNext(state.nextClaimSeq);
            if (state.nextClaimSeq == null) {
                state.exhausted = true;
                state.metrics.ownerFailClosed++;
                return;
            }
            var ticket = {
                generationId: key.id,
                instanceId: instanceId,
                ownerKind: requestedOwner,
                ownerId: 'chart',
                claimSeq: state.nextClaimSeq,
                sessionEpoch: key.sessionEpoch,
                indicatorSetHash: key.indicatorSetHash,
                source: source,
                status: 'claimed',
                fallback: !!fallback,
                fallbackUsed: !!fallback,
                pendingGenerationId: null
            };
            state.ownerTickets.set(ticketKey, ticket);
            state.latestByInstance.set(instanceId, ticket);
            state.metrics.ownerClaims[requestedOwner]++;
            if (fallback) state.metrics.fallbackClaims++;
            tickets.push(ticket);
        });
        return tickets;
    }

    function _b70Stage2Commit(chart, tickets) {
        var state = chart && chart._b70IndicatorGenerationShadow;
        if (!state || !Array.isArray(tickets)) return false;
        var valid = tickets.length > 0 && tickets.every(function(ticket) {
            return state.ownerTickets.get(
                _b70Stage2TicketKey(ticket.generationId, ticket.instanceId)
            ) === ticket && ticket.status === 'claimed';
        });
        if (!valid) return false;
        tickets.forEach(function(ticket) {
            ticket.status = 'committed';
            state.metrics.ownerCommits[ticket.ownerKind]++;
        });
        state.metrics.successfulCommits++;
        _b70Stage5PublishHostEnvelope(chart, tickets);
        return true;
    }

    function _b70Stage2AuthorizeWorkerApply(chart, tickets, results) {
        var state = chart && chart._b70IndicatorGenerationShadow;
        if (!state || !Array.isArray(tickets) || !tickets.length) return false;
        var key = _b70IndicatorGenerationKey(chart);
        var valid = !!key && !!key.id && tickets.every(function(ticket) {
            var current = state.ownerTickets.get(
                _b70Stage2TicketKey(ticket.generationId, ticket.instanceId)
            );
            return current === ticket
                && ticket.ownerKind === 'worker'
                && ticket.status === 'claimed'
                && ticket.generationId === key.id
                && ticket.sessionEpoch === key.sessionEpoch
                && ticket.indicatorSetHash === key.indicatorSetHash;
        });
        if (valid && results != null) {
            valid = typeof results === 'object' && tickets.every(function(ticket) {
                return Object.prototype.hasOwnProperty.call(results, ticket.instanceId);
            });
        }
        if (!valid) {
            var duplicate = tickets.some(function(ticket) {
                return ticket && ticket.status === 'committed';
            });
            if (duplicate) state.metrics.duplicateWorkerRejects++;
            else state.metrics.lateWorkerRejects++;
            return false;
        }
        return true;
    }

    function _b70Stage2ReleaseWorkerFailure(chart, tickets) {
        var state = chart && chart._b70IndicatorGenerationShadow;
        if (!state || !Array.isArray(tickets)) return [];
        var fallbackIndicators = [];
        tickets.forEach(function(ticket) {
            var current = state.ownerTickets.get(
                _b70Stage2TicketKey(ticket.generationId, ticket.instanceId)
            );
            if (current !== ticket || ticket.status !== 'claimed' || ticket.fallbackUsed) {
                state.metrics.fallbackDenied++;
                return;
            }
            var failedKey = _b70Stage2TicketKey(ticket.generationId, ticket.instanceId);
            if (state.fallbackGenerations.has(failedKey)) {
                state.metrics.fallbackDenied++;
                return;
            }
            state.fallbackGenerations.add(failedKey);
            ticket.status = 'failed';
            ticket.fallbackUsed = true;
            state.ownerTickets.delete(failedKey);
            var active = chart.indicators && chart.indicators.active;
            var indicator = Array.isArray(active) && active.find(function(item) {
                return item && String(item.id) === ticket.instanceId;
            });
            if (indicator) fallbackIndicators.push(indicator);
        });
        if (fallbackIndicators.length) state.metrics.workerFailures++;
        return fallbackIndicators;
    }

    function _b70Stage2ReleaseSyncFailure(chart, tickets) {
        var state = chart && chart._b70IndicatorGenerationShadow;
        if (!state || !Array.isArray(tickets)) return;
        tickets.forEach(function(ticket) {
            if (state.ownerTickets.get(
                _b70Stage2TicketKey(ticket.generationId, ticket.instanceId)
            ) === ticket && ticket.status === 'claimed') {
                ticket.status = 'failed';
                state.ownerTickets.delete(
                    _b70Stage2TicketKey(ticket.generationId, ticket.instanceId)
                );
            }
        });
    }

    function _b70Stage2TicketIds(tickets) {
        var ids = {};
        (tickets || []).forEach(function(ticket) { ids[ticket.instanceId] = true; });
        return ids;
    }

    function _b70Stage2SnapshotResults(chart, tickets) {
        var data = chart && chart.indicators && chart.indicators.data;
        if (!data || !Array.isArray(tickets)) return null;
        return tickets.map(function(ticket) {
            return {
                id: ticket.instanceId,
                had: Object.prototype.hasOwnProperty.call(data, ticket.instanceId),
                value: data[ticket.instanceId]
            };
        });
    }

    function _b70Stage2RestoreResults(chart, snapshot) {
        var data = chart && chart.indicators && chart.indicators.data;
        if (!data || !Array.isArray(snapshot)) return;
        snapshot.forEach(function(entry) {
            if (entry.had) data[entry.id] = entry.value;
            else delete data[entry.id];
        });
    }

    function _b70Stage3CommittedForCurrentGeneration(chart, key) {
        var state = chart && chart._b70IndicatorGenerationShadow;
        var active = chart && chart.indicators && chart.indicators.active;
        if (!state || !key || !key.id || !Array.isArray(active) || !active.length) {
            return false;
        }
        if (!state.currentEnvelope
            || state.currentEnvelope.metadata.generationId !== key.id
            || chart.indicators.data !== state.currentEnvelope.data) return false;
        if (Array.isArray(state.currentEnvelope.metadata.bridgeInstanceIds)) {
            return active.every(function(indicator) {
                return !indicator || indicator.id == null
                    || state.currentEnvelope.metadata.bridgeInstanceIds.indexOf(
                        String(indicator.id)
                    ) >= 0;
            });
        }
        return active.every(function(indicator) {
            if (!indicator || indicator.id == null) return true;
            var ticket = state.ownerTickets.get(
                _b70Stage2TicketKey(key.id, String(indicator.id))
            );
            return !!ticket && ticket.status === 'committed';
        });
    }

    function _b70Stage3RunDeferredOwner(chart, state, generationId) {
        var tx = state && state.renderTransaction;
        if (!tx || tx.disposed || chart._b70IndicatorGenerationShadow !== state) return;
        tx.deferredScheduled = false;
        if (tx.depth > 0 || tx.deferredGenerationId !== generationId) return;
        var key = _b70IndicatorGenerationKey(chart);
        if (!key || key.id !== generationId
            || _b70Stage3CommittedForCurrentGeneration(chart, key)) {
            tx.deferredGenerationId = null;
            return;
        }
        tx.deferredGenerationId = null;
        state.metrics.paintDeferredRequests++;
        _b70ShadowRecordRequest(chart, 'paint-missing-generation');
        if (typeof chart._runIndicatorRecalc === 'function') {
            try { chart._runIndicatorRecalc({ force: false }); } catch (_) {}
        } else if (typeof chart.scheduleIndicatorRecalc === 'function') {
            try {
                chart.scheduleIndicatorRecalc(
                    'paint-missing-generation', { immediate: true, force: false }
                );
            } catch (_) {}
        }
    }

    function _b70Stage3ScheduleDeferredOwner(chart, state) {
        var tx = state && state.renderTransaction;
        if (!tx || tx.disposed || tx.depth > 0 || tx.deferredScheduled
            || !tx.deferredGenerationId) return;
        tx.deferredScheduled = true;
        var generationId = tx.deferredGenerationId;
        var run = function() {
            _b70Stage3RunDeferredOwner(chart, state, generationId);
        };
        if (typeof queueMicrotask === 'function') queueMicrotask(run);
        else Promise.resolve().then(run);
    }

    function _b70Stage3ConsumePaint(chart) {
        var state = _b70ShadowState(chart);
        var key = _b70IndicatorGenerationKey(chart);
        if (!state || !key || !key.id) return false;
        if (_b70Stage3CommittedForCurrentGeneration(chart, key)) {
            state.metrics.paintConsumerHits++;
            if (state.retiredEnvelope) {
                state.retiredEnvelope = null;
                state.metrics.envelopeReleases++;
                _b70Stage4UpdateRetainedBytes(
                    state, _b70Stage4PrivateState(chart), 0
                );
            }
            return true;
        }
        state.metrics.paintMissingGenerations++;
        state.renderTransaction.deferredGenerationId = key.id;
        _b70Stage3ScheduleDeferredOwner(chart, state);
        return false;
    }

    function _b70Stage3RejectInRenderWork(chart) {
        var state = chart && chart._b70IndicatorGenerationShadow;
        var tx = state && state.renderTransaction;
        if (!tx || tx.depth <= 0) return false;
        state.metrics.paintCalculations++;
        var key = _b70IndicatorGenerationKey(chart);
        if (key && key.id) tx.deferredGenerationId = key.id;
        return true;
    }

    function _b70Stage3BeginRender(chart, owner) {
        var state = _b70ShadowState(chart);
        if (!state || state.renderTransaction.disposed) return null;
        var tx = state.renderTransaction;
        if (tx.depth === 0) {
            var next = _b70SafeNext(tx.ownerSeq);
            if (next == null) {
                state.exhausted = true;
                state.metrics.ownerFailClosed++;
                return null;
            }
            tx.ownerSeq = next;
            tx.owner = { id: next, source: String(owner || 'render') };
            state.metrics.paintTransactions++;
        } else {
            state.metrics.paintReentries++;
        }
        tx.depth++;
        if (tx.depth > state.metrics.maxPaintDepth) {
            state.metrics.maxPaintDepth = tx.depth;
        }
        return { state: state, ownerId: tx.owner && tx.owner.id };
    }

    function _b70Stage3EndRender(chart, token, error) {
        if (!token || !token.state) return;
        var state = token.state;
        var tx = state.renderTransaction;
        if (error) state.metrics.paintExceptions++;
        if (tx.depth > 0) tx.depth--;
        if (tx.depth === 0) {
            tx.owner = null;
            _b70Stage3ScheduleDeferredOwner(chart, state);
        }
    }

    function _b70Stage4Now() {
        try {
            return typeof performance !== 'undefined' && performance.now
                ? performance.now() : Date.now();
        } catch (_) { return Date.now(); }
    }

    function _b70Stage4CloneValue(value, seen) {
        if (value == null || typeof value === 'string' || typeof value === 'boolean') {
            return { ok: true, value: value, bytes: typeof value === 'string' ? value.length * 2 : 8 };
        }
        if (typeof value === 'number') {
            return { ok: Number.isFinite(value), value: value, bytes: 8 };
        }
        if (typeof value !== 'object' || seen.has(value)) {
            return { ok: false, value: null, bytes: 0 };
        }
        seen.add(value);
        var out;
        var bytes = 0;
        if (Array.isArray(value)) {
            out = new Array(value.length);
            for (var i = 0; i < value.length; i++) {
                var item = _b70Stage4CloneValue(value[i], seen);
                if (!item.ok) { seen.delete(value); return item; }
                out[i] = item.value;
                bytes += item.bytes;
            }
        } else if (typeof ArrayBuffer !== 'undefined'
            && ArrayBuffer.isView && ArrayBuffer.isView(value)
            && typeof value.slice === 'function') {
            out = value.slice();
            bytes = value.byteLength || 0;
        } else {
            var proto = Object.getPrototypeOf(value);
            if (proto !== Object.prototype && proto !== null
                && Object.prototype.toString.call(value) !== '[object Object]') {
                seen.delete(value);
                return { ok: false, value: null, bytes: 0 };
            }
            out = {};
            var keys = Object.keys(value);
            for (var k = 0; k < keys.length; k++) {
                var key = keys[k];
                var child = _b70Stage4CloneValue(value[key], seen);
                if (!child.ok) { seen.delete(value); return child; }
                out[key] = child.value;
                bytes += key.length * 2 + child.bytes;
            }
        }
        seen.delete(value);
        return { ok: true, value: out, bytes: bytes };
    }

    function _b70Stage4ValidateValue(value, barCount, seen) {
        if (value == null || typeof value === 'string' || typeof value === 'boolean') return true;
        if (typeof value === 'number') return Number.isFinite(value);
        if (typeof value !== 'object' || seen.has(value)) return false;
        seen.add(value);
        if (Array.isArray(value)
            || (typeof ArrayBuffer !== 'undefined'
                && ArrayBuffer.isView && ArrayBuffer.isView(value))) {
            var numericSeries = true;
            for (var i = 0; i < value.length; i++) {
                if (Array.isArray(value) && !Object.prototype.hasOwnProperty.call(value, i)) {
                    seen.delete(value);
                    return false;
                }
                if (value[i] != null && typeof value[i] !== 'number') numericSeries = false;
                if (!_b70Stage4ValidateValue(value[i], barCount, seen)) {
                    seen.delete(value);
                    return false;
                }
            }
            if (numericSeries && barCount > 0 && value.length > barCount) {
                seen.delete(value);
                return false;
            }
        } else {
            var proto = Object.getPrototypeOf(value);
            if (proto !== Object.prototype && proto !== null
                && Object.prototype.toString.call(value) !== '[object Object]') {
                seen.delete(value);
                return false;
            }
            var keys = Object.keys(value);
            for (var k = 0; k < keys.length; k++) {
                var key = keys[k];
                var item = value[key];
                if ((key === 'index' || key === 'startIndex' || key === 'endIndex')
                    && (!Number.isSafeInteger(item) || item < 0
                        || (barCount > 0 && item >= barCount))) {
                    seen.delete(value);
                    return false;
                }
                if (!_b70Stage4ValidateValue(item, barCount, seen)) {
                    seen.delete(value);
                    return false;
                }
            }
        }
        seen.delete(value);
        return true;
    }

    var _b70Stage4SeriesSchemas = {
        bb: ['middle', 'upper', 'lower'],
        bbands: ['middle', 'upper', 'lower'],
        bollinger: ['middle', 'upper', 'lower'],
        macd: ['macd', 'signal', 'histogram'],
        macd2: ['macd', 'signal', 'histogram'],
        stoch: ['k', 'd'],
        stochastic: ['k', 'd'],
        stochrsi: ['k', 'd'],
        adx: ['plusDI', 'minusDI', 'adx'],
        adr: ['upper', 'lower', 'adr'],
        donchian: ['upper', 'lower', 'middle'],
        keltner: ['upper', 'middle', 'lower'],
        aroon: ['up', 'down'],
        vortex: ['viPlus', 'viMinus'],
        envelope: ['upper', 'lower', 'middle'],
        smaenvelope: ['upper', 'lower', 'middle'],
        supertrend: ['line', 'direction', 'upper', 'lower', 'body'],
        rvi: ['rvi', 'signal'],
        elderray: ['bull', 'bear'],
        vwap: ['vwap']
    };

    var _b70Stage4SingleSeriesTypes = new Set([
        'wma', 'dema', 'tema', 'hma', 'atr',
        'cci', 'roc', 'mom', 'momentum', 'obv', 'willr', 'mfi', 'cmf',
        'trix', 'psar', 'stddev', 'ao', 'uo', 'dpo', 'massindex', 'coppock'
    ]);

    function _b70Stage4ValidateIndicatorResult(indicator, value, barCount) {
        var type = String(indicator && indicator.type || '').toLowerCase();
        if (type === 'sma' || type === 'ema') {
            if (!value || typeof value !== 'object' || Array.isArray(value)
                || !Array.isArray(value.line)) return false;
            for (var smoothedKey of ['line', 'ma', 'bbUpper', 'bbLower']) {
                if (value[smoothedKey] != null
                    && (!Array.isArray(value[smoothedKey])
                        || value[smoothedKey].length !== value.line.length)) return false;
            }
            return value.line.length <= barCount
                && _b70Stage4ValidateValue(value, barCount, new Set());
        }
        if (type === 'rsi') {
            if (!value || typeof value !== 'object' || Array.isArray(value)
                || !Array.isArray(value.rsi)) return false;
            for (var rsiKey of ['ma', 'bbUpper', 'bbLower']) {
                if (value[rsiKey] != null
                    && (!Array.isArray(value[rsiKey])
                        || value[rsiKey].length !== value.rsi.length)) return false;
            }
            return value.rsi.length <= barCount
                && _b70Stage4ValidateValue(value, barCount, new Set());
        }
        var required = _b70Stage4SeriesSchemas[type];
        if (required) {
            if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
            var length = null;
            for (var i = 0; i < required.length; i++) {
                var series = value[required[i]];
                if (!Array.isArray(series)
                    && !(typeof ArrayBuffer !== 'undefined'
                        && ArrayBuffer.isView && ArrayBuffer.isView(series))) return false;
                if (length == null) length = series.length;
                if (series.length !== length || (barCount > 0 && series.length > barCount)
                    || !_b70Stage4ValidateValue(series, barCount, new Set())) return false;
            }
            return _b70Stage4ValidateValue(value, barCount, new Set());
        }
        if (_b70Stage4SingleSeriesTypes.has(type)) {
            if (!Array.isArray(value)
                && !(typeof ArrayBuffer !== 'undefined'
                    && ArrayBuffer.isView && ArrayBuffer.isView(value))) return false;
            return value.length <= barCount
                && _b70Stage4ValidateValue(value, barCount, new Set());
        }
        // Drawing-object families have heterogeneous records, but still require
        // an object root and recursively finite, dense, acyclic content.
        return !!value && typeof value === 'object'
            && _b70Stage4ValidateValue(value, barCount, new Set());
    }

    function _b70Stage4DeepFreeze(value, seen) {
        if (!value || typeof value !== 'object' || seen.has(value)) return value;
        seen.add(value);
        Object.keys(value).forEach(function(key) {
            _b70Stage4DeepFreeze(value[key], seen);
        });
        try { Object.freeze(value); } catch (_) {}
        return value;
    }

    function _b70Stage4BeginBuild(chart, tickets) {
        var state = chart && chart._b70IndicatorGenerationShadow;
        var key = _b70IndicatorGenerationKey(chart);
        if (!state || !key || !key.id || !Array.isArray(tickets) || !tickets.length) return null;
        var privateState = _b70Stage4PrivateState(chart);
        if (privateState.disposed || privateState.active) {
            state.metrics.envelopeRejects++;
            return null;
        }
        var started = _b70Stage4Now();
        var base = privateState.pending && privateState.pending.generationId === key.id
            ? privateState.pending.data
            : state.currentEnvelope
                && chart.indicators.data === state.currentEnvelope.data
                ? state.currentEnvelope.data
                : (chart.indicators && chart.indicators.data) || {};
        var cloned = _b70Stage4CloneValue(base, new Set());
        if (!cloned.ok) {
            state.metrics.envelopeAliasRejects++;
            return null;
        }
        state.metrics.envelopeBuilds++;
        state.metrics.envelopeCopyBytes += cloned.bytes;
        state.metrics.envelopeCopyTimeMs += _b70Stage4Now() - started;
        var guard = { invalidated: false, generationId: key.id };
        var transaction = {
            state: state,
            privateState: privateState,
            guard: guard,
            key: key,
            tickets: tickets,
            publicData: chart.indicators.data,
            stagingData: cloned.value,
            copiedBytes: cloned.bytes,
            completedIds: privateState.pending
                && privateState.pending.generationId === key.id
                ? new Set(privateState.pending.completedIds) : new Set(),
            partial: false
        };
        privateState.active = guard;
        _b70Stage4UpdateRetainedBytes(state, privateState, cloned.bytes);
        return transaction;
    }

    function _b70Stage4AbortBuild(chart, transaction) {
        if (!transaction) return;
        if (transaction.privateState.active === transaction.guard) {
            transaction.privateState.active = null;
        }
        _b70Stage4UpdateRetainedBytes(
            transaction.state, transaction.privateState, 0
        );
        transaction.state.metrics.envelopeRejects++;
    }

    function _b70Stage4UpdateRetainedBytes(state, privateState, activeBytes) {
        var retained = activeBytes || 0;
        if (privateState && privateState.pending) retained += privateState.pending.bytes || 0;
        if (state.currentEnvelope) retained += state.currentEnvelope.metadata.byteLength || 0;
        if (state.retiredEnvelope) retained += state.retiredEnvelope.metadata.byteLength || 0;
        state.metrics.envelopeRetainedBytes = retained;
        if (retained > state.metrics.envelopePeakRetainedBytes) {
            state.metrics.envelopePeakRetainedBytes = retained;
        }
    }

    function _b70Stage4ApplyWorkerResults(
        chart, transaction, results, mySeq, calcToken, tailMeta
    ) {
        var facade = _b70Stage4BuildFacade(chart, transaction);
        return Chart.prototype._applyIndicatorWorkerResults.call(
            facade, results, mySeq, calcToken, tailMeta
        );
    }

    function _b70Stage4BuildFacade(chart, transaction) {
        var facade = Object.create(chart);
        facade._b70PrivateEnvelopeBuild = true;
        facade.indicators = {
            active: chart.indicators.active,
            data: transaction.stagingData
        };
        facade.bumpIndicatorRenderVersion = function() {};
        facade.scheduleRender = function() {};
        facade.updateOHLCIndicators = function() {};
        facade._markIndicatorRecalcComplete = function() {};
        facade._clearIndicatorCalculatingFlags = function() {};
        return facade;
    }

    function _b70Stage4CommitBuild(chart, transaction) {
        if (!transaction || !chart || !chart.indicators) return false;
        var state = transaction.state;
        var privateState = transaction.privateState;
        var key = _b70IndicatorGenerationKey(chart);
        var validOwner = !transaction.guard.invalidated
            && privateState.active === transaction.guard
            && chart.indicators.data === transaction.publicData
            && key && key.id === transaction.key.id
            && transaction.tickets.every(function(ticket) {
                return state.ownerTickets.get(
                    _b70Stage2TicketKey(ticket.generationId, ticket.instanceId)
                ) === ticket && ticket.status === 'claimed';
            });
        transaction.tickets.forEach(function(ticket) {
            transaction.completedIds.add(ticket.instanceId);
        });
        var active = chart.indicators.active || [];
        var complete = active.every(function(indicator) {
            return !indicator || indicator.id == null
                || transaction.completedIds.has(String(indicator.id));
        });
        var validShape = validOwner && transaction.tickets.every(function(ticket) {
            var indicator = active.find(function(item) {
                return item && String(item.id) === ticket.instanceId;
            });
            return Object.prototype.hasOwnProperty.call(
                transaction.stagingData, ticket.instanceId
            ) && _b70Stage4ValidateIndicatorResult(
                indicator,
                transaction.stagingData[ticket.instanceId],
                transaction.key.barCount
            );
        });
        if (privateState.active === transaction.guard) privateState.active = null;
        if (!validShape) {
            state.metrics.envelopeRejects++;
            _b70Stage4UpdateRetainedBytes(state, privateState, 0);
            return false;
        }
        var sealStarted = _b70Stage4Now();
        var sealed = _b70Stage4CloneValue(transaction.stagingData, new Set());
        if (!sealed.ok) {
            state.metrics.envelopeAliasRejects++;
            state.metrics.envelopeRejects++;
            _b70Stage4UpdateRetainedBytes(state, privateState, 0);
            return false;
        }
        state.metrics.envelopeCopyBytes += sealed.bytes;
        state.metrics.envelopeCopyTimeMs += _b70Stage4Now() - sealStarted;
        // Sealing is a second private copy. Until this function returns, both
        // stagingData and sealed.value are retained alongside pending/current/
        // retired envelopes; include that real transient peak.
        _b70Stage4UpdateRetainedBytes(
            state, privateState, transaction.copiedBytes + sealed.bytes
        );
        if (!complete) {
            privateState.pending = {
                generationId: transaction.key.id,
                data: sealed.value,
                completedIds: Array.from(transaction.completedIds),
                bytes: sealed.bytes
            };
            transaction.partial = true;
            _b70Stage4UpdateRetainedBytes(state, privateState, 0);
            return false;
        }
        var metadata = Object.freeze({
            schemaVersion: 1,
            generationId: transaction.key.id,
            generationKey: Object.freeze(Object.assign({}, transaction.key)),
            instanceIds: Object.freeze(active.filter(Boolean).map(function(indicator) {
                return String(indicator.id);
            })),
            byteLength: sealed.bytes,
            committedAt: Date.now()
        });
        if (typeof window !== 'undefined'
            && window.__TALARIA_B70_DEV_FREEZE_ENVELOPES === true) {
            _b70Stage4DeepFreeze(sealed.value, new Set());
        }
        var envelope = Object.freeze({ metadata: metadata, data: sealed.value });
        if (state.retiredEnvelope) state.metrics.envelopeReleases++;
        state.retiredEnvelope = state.currentEnvelope;
        state.currentEnvelope = envelope;
        privateState.pending = null;
        // The only public write in the transaction: atomic envelope data swap.
        chart.indicators.data = envelope.data;
        state.metrics.envelopeCommits++;
        _b70Stage4UpdateRetainedBytes(state, privateState, 0);
        return true;
    }

    function _b70ShadowObserveRender(chart) {
        var state = _b70ShadowState(chart);
        if (!state) return;
        var before = state.lastKey;
        var after = _b70IndicatorGenerationKey(chart);
        if (!after || !after.id) return;
        if (!before || before.id === after.id) state.metrics.renderStable++;
        else state.metrics.renderUnexpectedChanges++;
        state.lastKey = after;
    }

    function _b70ShadowCompareLegacyToken(chart, token) {
        var state = _b70ShadowState(chart);
        if (!state || !token) return;
        var key = _b70IndicatorGenerationKey(chart);
        if (!key) return;
        state.metrics.legacyTokenComparisons++;
        var agree = token.dataVersion === key.dataVersion
            && token.timeframe === key.timeframe
            && token.barCount === key.barCount
            && token.dataFp === key.tailBarFingerprint
            && token.paramsHash === (chart && typeof chart._indicatorParamsHash === 'function'
                ? chart._indicatorParamsHash() : '');
        if (agree) state.metrics.legacyTokenAgreement++;
        else state.metrics.legacyTokenDisagreement++;
    }

    function _m19iB62SafeNonnegativeInteger(value) {
        if (typeof value === 'number' && Number.isSafeInteger(value) && value >= 0) return value;
        return null;
    }

    function _m19iB62ChartPairIdentity(chart) {
        if (!chart) return '';
        return String(
            chart.currentPair != null ? chart.currentPair
                : chart.pair != null ? chart.pair
                    : chart.symbol != null ? chart.symbol
                        : chart.currentSymbol != null ? chart.currentSymbol
                            : chart.instrument != null ? chart.instrument
                                : ''
        );
    }

    function _m19iB62MasterGeneration(chart) {
        if (!chart) return '';
        var g = chart.masterGeneration != null ? chart.masterGeneration
            : chart.dataGeneration != null ? chart.dataGeneration
                : chart.datasetGeneration != null ? chart.datasetGeneration
                    : chart._masterDataGeneration != null ? chart._masterDataGeneration
                        : chart._dataGeneration != null ? chart._dataGeneration
                            : '';
        return String(g);
    }

    function _indicatorAsyncDataToken(chart) {
        var data = chart && chart.data;
        var len = Array.isArray(data) ? data.length : 0;
        var b62On = chart && _m19iExactTailPaintEnabled();
        if (b62On) _m19iB62ObserveData(chart);
        var datasetGen = b62On ? _m19iB62GenOf(chart) : null;
        var token = {
            dataVersion: chart && chart.dataVersion != null ? chart.dataVersion : 0,
            timeframe: String((chart && chart.currentTimeframe) || ''),
            dataFp: _indicatorDataFingerprint(chart),
            barCount: len,
            paramsHash: chart && typeof chart._indicatorParamsHash === 'function'
                ? chart._indicatorParamsHash() : '',
            pairIdentity: _m19iB62ChartPairIdentity(chart),
            masterGeneration: _m19iB62MasterGeneration(chart),
            datasetGen: datasetGen,
            windowFp: b62On ? _m19iB62WindowFp(data, 0, len) : null,
            failClosed: b62On && datasetGen >= Number.MAX_SAFE_INTEGER
        };
        if (typeof window !== 'undefined'
            && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true) {
            _b70ShadowCompareLegacyToken(chart, token);
        }
        return token;
    }

    function _indicatorAsyncTokenMatches(chart, token) {
        if (!token) return true;
        const current = _indicatorAsyncDataToken(chart);
        return current.dataVersion === token.dataVersion
            && current.timeframe === token.timeframe
            && current.dataFp === token.dataFp
            && current.barCount === token.barCount
            && current.paramsHash === token.paramsHash
            && current.pairIdentity === token.pairIdentity
            && current.masterGeneration === token.masterGeneration
            && current.datasetGen === token.datasetGen
            && current.windowFp === token.windowFp
            && !current.failClosed
            && !token.failClosed;
    }

    /**
     * M19-H: invalidate every delayed indicator result when a timeframe transaction
     * starts. Workers may finish, but their sequence/token can no longer commit.
     */
    Chart.prototype._invalidateIndicatorAsyncWork = function() {
        if (typeof window !== 'undefined'
            && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true) {
            _b70ShadowInvalidate(this, arguments[0] || 'dataset');
        }
        if (this._indicatorWorkerSeq == null) this._indicatorWorkerSeq = 0;
        this._indicatorWorkerSeq++;
        // B62-1: explicit monotonic dataset/master generation — every path
        // that invalidates async indicator work advances it, so a tail token
        // can never match across a replacement even if length/TF/fp collide.
        // KILL-EXACT: every b62 state write is gated on the switch, so a
        // disabled product leaves chart object state byte-for-byte b61 (no
        // generation creation/bump, no memo/fingerprint clears). OFF→ON
        // safety is provided by the render-version witness on the paint
        // memos and the data-reference observation, not by OFF-time writes.
        if (_m19iExactTailPaintEnabled()) {
            this._m19iB62DatasetGen = _m19iB62NextGen(this._m19iB62DatasetGen);
            this._m19iExactTailLastFp = null;
            this._m19iExactTailLastRv = null;
            this._m19iExactTailFailFp = null;
            this._m19iExactTailFailRv = null;
            this._m19iB62PendingFreshFp = null;
        }
        this._indicatorWorkerCoalesce = false;
        this._m19iCoalesceFullAsync = false;
        this._indicatorPendingResults = null;
        this._sessionIndReplayFp = null;
        if (this._replayIndRecalcRaf != null) {
            cancelAnimationFrame(this._replayIndRecalcRaf);
            this._replayIndRecalcRaf = null;
        }
        if (this._indRecalcTimer) {
            clearTimeout(this._indRecalcTimer);
            this._indRecalcTimer = null;
        }
        if (this._tfIndicatorRefreshRaf != null) {
            cancelAnimationFrame(this._tfIndicatorRefreshRaf);
            this._tfIndicatorRefreshRaf = null;
        }
        this._tfIndicatorRefreshScheduled = false;
    };

    Chart.prototype._markIndicatorRecalcComplete = function() {
        if (!Array.isArray(this.data)) return;
        this._indCalcSnapshot = {
            barCount: this.data.length,
            dataVersion: this.dataVersion != null ? this.dataVersion : 0,
            paramsHash: this._indicatorParamsHash(),
            timeframe: String(this.currentTimeframe || ''),
            // Forming-bar OHLC can change without a barCount bump; FVG/Ratio need that.
            dataFp: _indicatorDataFingerprint(this)
        };
    };

    Chart.prototype._setAllIndicatorsCalculating = function(on) {
        if (!this.indicators || !Array.isArray(this.indicators.active)) return;
        this.indicators.active.forEach(function(ind) {
            if (ind) ind._calculating = !!on;
        });
        if (typeof this.updateOHLCIndicators === 'function') this.updateOHLCIndicators();
    };

    Chart.prototype._clearIndicatorCalculatingFlags = function() {
        if (!this.indicators || !Array.isArray(this.indicators.active)) return;
        this.indicators.active.forEach(function(ind) {
            if (!ind) return;
            const data = this.indicators.data && this.indicators.data[ind.id];
            if (data && data.loading === true) return;
            ind._calculating = false;
        }, this);
        if (typeof this.updateOHLCIndicators === 'function') this.updateOHLCIndicators();
    };

    // ─── M19-I: indicator replay compute budget ─────────────────────────────
    // Five independently switchable fixes. Each disable flag restores the
    // prior (b57/b58) legacy behavior for its own scope only.
    //   I-a  __TALARIA_DISABLE_M19I_TAIL_SEND_V1      — O(history) pack + clone
    //   I-b  __TALARIA_DISABLE_M19I_SYNCONLY_TAIL_V1  — sync-only full rescans
    //   I-c  __TALARIA_DISABLE_M19I_WORKER_PORT_V1    — dema/tema/hma sync + supertrend/adr O(n)
    //   I-d  __TALARIA_DISABLE_M19I_FORCE_DEDUPE_V1   — force:true bypasses dedupe
    //   I-f  __TALARIA_DISABLE_M19I_FRAME_COHERENT_V1 — b58 price-first paint +
    //        rAF-deferred pass + worker-RTT indicator catch-up during play
    //   I-g  __TALARIA_DISABLE_M19I_TICK_COHERENT_V1  — forming-candle tick
    //        animation freezes MA tips until the bar commits (skip OHLC)
    //   b62  __TALARIA_DISABLE_M19I_EXACT_TAIL_PAINT_V1 — b61 stale-overwrite/
    //        stale-blit behavior (see _m19iExactTailPaintEnabled below)

    function _m19iTailSendEnabled() {
        return typeof window === 'undefined' || !window.__TALARIA_DISABLE_M19I_TAIL_SEND_V1;
    }
    function _m19iSyncOnlyTailEnabled() {
        return typeof window === 'undefined' || !window.__TALARIA_DISABLE_M19I_SYNCONLY_TAIL_V1;
    }
    function _m19iWorkerPortEnabled() {
        return typeof window === 'undefined' || !window.__TALARIA_DISABLE_M19I_WORKER_PORT_V1;
    }
    function _m19iForceDedupeEnabled() {
        return typeof window === 'undefined' || !window.__TALARIA_DISABLE_M19I_FORCE_DEDUPE_V1;
    }
    function _m19ifFrameCoherentEnabled() {
        return typeof window === 'undefined' || !window.__TALARIA_DISABLE_M19I_FRAME_COHERENT_V1;
    }
    /** I-g: refresh indicator tips while tick-mode forming OHLC mutates. */
    function _m19igTickCoherentEnabled() {
        return _m19ifFrameCoherentEnabled()
            && (typeof window === 'undefined' || !window.__TALARIA_DISABLE_M19I_TICK_COHERENT_V1);
    }

    /**
     * B62-0 (M19-I exact painted tail) — ONE toggle for the whole b62 package,
     * default ON when unset. Kill switch:
     *   window.__TALARIA_DISABLE_M19I_EXACT_TAIL_PAINT_V1 = true
     * restores exact b61 behavior for one-toggle A/B:
     *   - a same-length/same-TF worker tail reply computed from an OLDER
     *     forming close commits again and overwrites the fresher bridge tip
     *     (B62-1 rejection off);
     *   - no paint-time forming-tail bridge before the indicator layer cache
     *     decision, so a paint can blit an endpoint older than the forming
     *     close it presents (B62-2 off).
     */
    function _m19iExactTailPaintEnabled() {
        return typeof window === 'undefined' || !window.__TALARIA_DISABLE_M19I_EXACT_TAIL_PAINT_V1;
    }

    /**
     * B62-1 (corrected): COMPLETE post-time identity/generation token. Object
     * identity is never serialized — every field is an explicit value or a
     * monotonic generation, so stale replies cannot cross ANY replacement:
     *   - dataFp        length + last bar t|o|h|l|c|v (volume included; a
     *                    volume-only forming mutation changes MFI/CMF tails)
     *   - dataVersion   dataset/master replacement counter (pair/file/seek)
     *   - timeframe     TF string at post time
     *   - paramsHash    active-indicator set + parameter generation
     *                    (add/remove/param-edit all change the hash)
     *   - datasetGen    explicit monotonic generation bumped by
     *                    _invalidateIndicatorAsyncWork (TF transactions and
     *                    every path that already invalidates async work)
     * The worker seq (mySeq) remains the outer cancellation layer.
     */
    /**
     * B62-1 generation discipline (corrected): positive safe-integer
     * monotonic, NO signed 32-bit coercion anywhere, no wrap, no reuse. At
     * exhaustion the generation freezes at MAX_SAFE_INTEGER and the token
     * comparison fails CLOSED (permanently stale) so the tail path stops
     * accepting and the full async pipeline owns freshness — never a reset
     * or a collision.
     */
    function _m19iB62GenOf(chart) {
        var g = chart._m19iB62DatasetGen;
        return (typeof g === 'number' && Number.isSafeInteger(g) && g >= 0) ? g : 0;
    }

    function _m19iB62NextGen(cur) {
        var n = (typeof cur === 'number' && Number.isSafeInteger(cur) && cur >= 0) ? cur : 0;
        if (n >= Number.MAX_SAFE_INTEGER - 1) return Number.MAX_SAFE_INTEGER;
        return n + 1;
    }

    /**
     * B62-1 replacement observation (corrected): a multichart-style
     * `this.data = parent.data` swap can present the SAME length, timeframe
     * and final bar while the owner of dataVersion failed to bump. The chart
     * remembers the last data array it tokenized; seeing a different array
     * mints a NEW monotonic generation BEFORE any token comparison. The
     * reference is only a local bump trigger — the token serializes the
     * resulting monotonic generation, never raw object identity.
     * ON-path only (kill-exact: zero writes while disabled).
     */
    function _m19iB62ObserveData(chart) {
        if (chart._m19iB62SeenData !== chart.data) {
            if (chart._m19iB62SeenData !== undefined) {
                chart._m19iB62DatasetGen = _m19iB62NextGen(chart._m19iB62DatasetGen);
            }
            chart._m19iB62SeenData = chart.data;
        }
    }

    /**
     * B62-1 window fingerprint (corrected): FNV-1a content hash over exactly
     * the bars [tailStart..totalLength) the worker computed from — a
     * same-reference middle or volume mutation INSIDE the window invalidates
     * the reply even when length/TF/final-bar/dataVersion all collide. Bars
     * OUTSIDE the window never entered the worker's computation, so they
     * cannot invalidate the merge itself; full-history freshness for those
     * remains owned by dataVersion / full recalcs. Cost is one bounded pass,
     * the same order as the pack the post already performs. (The 32-bit
     * space here is a content HASH, not a counter — no wrap/reuse concern.)
     */
    function _m19iB62WindowFp(data, tailStart, totalLength) {
        var h = 0x811c9dc5;
        if (!Array.isArray(data)) return null;
        var safeTailStart = _m19iB62SafeNonnegativeInteger(tailStart);
        var safeTotalLength = _m19iB62SafeNonnegativeInteger(totalLength);
        if (safeTailStart == null || safeTotalLength == null) return null;
        var from = Math.max(0, safeTailStart);
        var to = Math.min(safeTotalLength, data.length);
        for (var i = from; i < to; i++) {
            var b = data[i] || {};
            var s = b.t + '|' + b.o + '|' + b.h + '|' + b.l + '|' + b.c + '|' + b.v + ';';
            for (var j = 0; j < s.length; j++) {
                h ^= s.charCodeAt(j);
                h = Math.imul(h, 0x01000193) >>> 0;
            }
        }
        return h >>> 0;
    }

    function _m19iB62TailToken(chart, tailStart, totalLength) {
        var safeTailStart = _m19iB62SafeNonnegativeInteger(tailStart);
        var safeTotalLength = _m19iB62SafeNonnegativeInteger(totalLength);
        var windowFp = safeTailStart == null || safeTotalLength == null
            ? null
            : _m19iB62WindowFp(chart.data, safeTailStart, safeTotalLength);
        return {
            dataFp: _indicatorDataFingerprint(chart),
            windowFp: windowFp,
            tailStart: safeTailStart,
            totalLength: safeTotalLength,
            dataVersion: chart.dataVersion != null ? chart.dataVersion : 0,
            timeframe: String(chart.currentTimeframe || ''),
            paramsHash: typeof chart._indicatorParamsHash === 'function'
                ? chart._indicatorParamsHash() : '',
            pairIdentity: _m19iB62ChartPairIdentity(chart),
            masterGeneration: _m19iB62MasterGeneration(chart),
            datasetGen: _m19iB62GenOf(chart),
            safe: safeTailStart != null && safeTotalLength != null && windowFp != null
        };
    }

    function _m19iB62TailTokenStale(chart, token) {
        if (!token) return false;
        // Fail closed at generation exhaustion: the tail path stops accepting.
        if (!token.safe || token.datasetGen >= Number.MAX_SAFE_INTEGER) return true;
        return token.dataFp !== _indicatorDataFingerprint(chart)
            || token.dataVersion !== (chart.dataVersion != null ? chart.dataVersion : 0)
            || token.timeframe !== String(chart.currentTimeframe || '')
            || token.paramsHash !== (typeof chart._indicatorParamsHash === 'function'
                ? chart._indicatorParamsHash() : '')
            || token.pairIdentity !== _m19iB62ChartPairIdentity(chart)
            || token.masterGeneration !== _m19iB62MasterGeneration(chart)
            || token.datasetGen !== _m19iB62GenOf(chart)
            || token.windowFp !== _m19iB62WindowFp(chart.data, token.tailStart, token.totalLength);
    }

    /** B62-3: observability counters only — no control flow reads these. */
    function _m19iB62Stats(chart) {
        return chart._m19iB62Stats || (chart._m19iB62Stats = {
            staleTailRejects: 0,
            exactTailPaints: 0,
            exactTailSkips: 0,
            exactTailBudgetSkips: 0,
            atomicRollbacks: 0,
            freshAsyncRequests: 0
        });
    }

    /**
     * B62 atomic tail commit (corrected): mergeIndicatorTailWindow mutates
     * series in place and an object-pack merge can fail AFTER patching some
     * keys, so a naive loop can leave a mixed-generation partial commit.
     * This helper snapshots the bounded patch region ([fromIndex..) values +
     * original length + replaced object keys) for EVERY affected series
     * BEFORE any merge, then commits the whole set; on ANY failure it
     * restores every snapshot, so either all series advance to the new
     * generation or none do. Snapshot cost is O(series × keys × (len-fromIndex)),
     * i.e. a few slots per series.
     */
    function _m19iB62SnapshotValue(existing, fromIndex) {
        if (existing == null) return { kind: 'absent' };
        if (Array.isArray(existing)) {
            return {
                kind: 'array',
                ref: existing,
                origLen: existing.length,
                tail: existing.slice(Math.min(fromIndex, existing.length))
            };
        }
        if (typeof existing === 'object') {
            var keys = {};
            Object.keys(existing).forEach(function(k) {
                var v = existing[k];
                keys[k] = Array.isArray(v)
                    ? { kind: 'array', ref: v, origLen: v.length, tail: v.slice(Math.min(fromIndex, v.length)) }
                    : { kind: 'value', value: v };
            });
            return { kind: 'object', ref: existing, keys: keys };
        }
        return { kind: 'value', value: existing };
    }

    function _m19iB62RestoreArray(snap) {
        var arr = snap.ref;
        arr.length = snap.origLen;
        var start = snap.origLen - snap.tail.length;
        for (var i = 0; i < snap.tail.length; i++) arr[start + i] = snap.tail[i];
    }

    function _m19iB62RestoreValue(chart, id, snap) {
        if (snap.kind === 'absent') {
            delete chart.indicators.data[id];
            return;
        }
        if (snap.kind === 'array') {
            _m19iB62RestoreArray(snap);
            chart.indicators.data[id] = snap.ref;
            return;
        }
        if (snap.kind === 'object') {
            var obj = snap.ref;
            var current = Object.keys(obj);
            for (var c = 0; c < current.length; c++) {
                if (!(current[c] in snap.keys)) delete obj[current[c]];
            }
            Object.keys(snap.keys).forEach(function(k) {
                var ks = snap.keys[k];
                if (ks.kind === 'array') {
                    _m19iB62RestoreArray(ks);
                    obj[k] = ks.ref;
                } else {
                    obj[k] = ks.value;
                }
            });
            chart.indicators.data[id] = obj;
            return;
        }
        chart.indicators.data[id] = snap.value;
    }

    /**
     * Commits fresh tail windows for a set of series ATOMICALLY.
     * @returns true when every series merged; false after a complete rollback.
     */
    function _m19iB62AtomicMergeSet(chart, freshById, tailStart, fromIndex, totalLength) {
        var perf = _indicatorPerf();
        var merge = perf && typeof perf.mergeIndicatorTailWindow === 'function'
            ? perf.mergeIndicatorTailWindow : null;
        var ids = Object.keys(freshById);
        if (!merge || !ids.length) return false;
        var snapshots = {};
        for (var s = 0; s < ids.length; s++) {
            snapshots[ids[s]] = _m19iB62SnapshotValue(chart.indicators.data[ids[s]], fromIndex);
        }
        for (var i = 0; i < ids.length; i++) {
            var id = ids[i];
            var merged = null;
            try {
                merged = merge(chart.indicators.data[id], freshById[id], tailStart, fromIndex, totalLength);
            } catch (_) { merged = null;
            }
            if (merged == null) {
                // Restore every series touched so far INCLUDING the failing
                // one (an object-pack merge can partially patch before null).
                for (var r = 0; r <= i; r++) {
                    _m19iB62RestoreValue(chart, ids[r], snapshots[ids[r]]);
                }
                return false;
            }
            chart.indicators.data[id] = merged;
        }
        return true;
    }

    /**
     * B62 (mechanism correction): families the synchronous exact-tail bridge
     * may publish. STRICTLY finite-window math — every value inside the
     * merge window is EXACTLY recomputable from a bounded slice, so a bridge
     * candidate equals a fresh full-history computation (no seed
     * dependence). Recursive / seed-dependent families (ema, dema, tema,
     * macd, ppo, rsi, atr, adx, keltner, trix, …) and every tail-safe family
     * without a bridge case (massindex, stochrsi, coppock, …) are NEVER
     * bridged synchronously: an approximate main-thread candidate is never
     * published; those transactions take the safe async fresh-worker path
     * (_m19iB62EnsureFreshAsync) with stale rejection plus guaranteed
     * eventual paint. seriesCount is the per-family output-array count that
     * drives the cumulative staged-point budget.
     */
    var M19I_B62_SYNC_FAMILIES = {
        sma: { seriesCount: 1 }, wma: { seriesCount: 1 }, hma: { seriesCount: 1 },
        bb: { seriesCount: 3 }, bollinger: { seriesCount: 3 },
        envelope: { seriesCount: 3 }, smaenvelope: { seriesCount: 3 },
        stddev: { seriesCount: 1 }, roc: { seriesCount: 1 },
        mom: { seriesCount: 1 }, momentum: { seriesCount: 1 },
        willr: { seriesCount: 1 }, mfi: { seriesCount: 1 }, cmf: { seriesCount: 1 },
        donchian: { seriesCount: 3 },
        stoch: { seriesCount: 2 }, stochastic: { seriesCount: 2 },
        ao: { seriesCount: 1 }
        // cci and aroon are EXCLUDED: the independent full-structure probe
        // (reproduced by the S6 matrix) shows the main-thread CCI formula
        // diverges from the worker/full-history by up to ~30.76 at the tip,
        // and the main-thread aroon pack emits different keys than the
        // worker pack (up/down vs aroonUp/aroonDown) — both are classified
        // to the safe async fresh-worker fallback rather than shipped as
        // approximate/incompatible synchronous candidates.
    };

    function _m19iB62SyncFamily(ind) {
        if (!ind || !_m19iIndicatorTailSafe(ind)) return null;
        var t = String(ind.type || '').toLowerCase();
        // Shape classification: donchian with a non-zero offset misaligns the
        // derived middle band between the main bridge and the worker/full
        // history — only the offset-0 shape is synchronous.
        if (t === 'donchian' && ind.params && Number(ind.params.offset)) return null;
        return M19I_B62_SYNC_FAMILIES[t] || null;
    }

    /**
     * B62-2 (mechanism correction): eventual fresh paint. Whenever the
     * synchronous bridge cannot run (budget skip, unsupported family in the
     * transaction, merge failure/rollback), stale worker tails STAY rejected
     * and this requests exactly ONE fresh worker recomputation for the
     * current complete identity: repeated pre-reply draws are absorbed by
     * the pending-identity memo, an in-flight pass absorbs the request as
     * one boolean coalesce, and finishIncrementalPass clears the memo so a
     * failed or superseded pass stays bounded-retryable. Correctness never
     * rests on a suppression memo — when the fresh reply lands, the real
     * apply path commits and paints it.
     */
    function _m19iB62EnsureFreshAsync(chart, fp) {
        if (chart._m19iB62PendingFreshFp === fp) return;
        _m19iB62Stats(chart).freshAsyncRequests++;
        chart._m19iB62PendingFreshFp = fp;
        if (chart._indicatorWorkerBusy) {
            chart._indicatorWorkerCoalesce = true;
            return;
        }
        try {
            if (typeof chart._runIndicatorRecalc === 'function') {
                chart._runIndicatorRecalc({ force: false });
            } else if (Array.isArray(chart.data) && chart.data.length
                && typeof chart.recalculateIndicatorsIncremental === 'function') {
                chart.recalculateIndicatorsIncremental(chart.data.length);
            }
            if (!chart._indicatorWorkerBusy
                && chart._m19iB62PendingFreshFp === fp
                && chart._m19iExactTailLastFp === fp) {
                chart._m19iB62PendingFreshFp = null;
            }
        } catch (_) {
            // Bounded-retryable: a failed request must never freeze freshness.
            chart._m19iB62PendingFreshFp = null;
        }
    }

    /** Single source for the sync-only (main-thread structural) indicator types. */
    var M19I_SYNC_ONLY_TYPES = [
        'cotnet', 'sessions', 'killzones', 'ictkz', 'sessionsplus', 'openingrange', 'or',
        'ictpd', 'ictasian', 'ictote', 'ictfvg', 'ictsesspd', 'ictliquidity', 'icteverything',
        'talariafvg', 'talariaratiogap', 'talariaweeklymap', 'talariasmc'
    ];

    /** Legacy worker-skip list (b57) — used verbatim when I-c is disabled. */
    var M19I_LEGACY_WORKER_SKIP = ['dema', 'tema', 'hma', 'supertrend', 'adr']
        .concat(M19I_SYNC_ONLY_TYPES, ['volume', 'custom']);

    /**
     * I-c: dema/tema/hma are pure series math and go to the worker; supertrend
     * and adr stay on the main thread but run as exact O(delta) continuations.
     * volume is O(1); custom keeps its own scheduled compute path.
     */
    var M19I_PORTED_WORKER_SKIP = ['supertrend', 'adr']
        .concat(M19I_SYNC_ONLY_TYPES, ['volume', 'custom']);

    function _m19iWorkerSkipTypes() {
        return _m19iWorkerPortEnabled() ? M19I_PORTED_WORKER_SKIP : M19I_LEGACY_WORKER_SKIP;
    }

    /**
     * Types whose worker results are safe for windowed tail recompute:
     * FIR/windowed math or convergent IIR smoothing that a lookback window
     * (estimateTailLookback) re-seeds within numeric noise. Cumulative or
     * whole-history types (obv, vwap, psar, seasonality) are excluded — they
     * always take the full CALCULATE_ALL path.
     */
    var M19I_TAIL_SAFE_WORKER_TYPES = [
        'sma', 'ema', 'wma', 'bb', 'bollinger', 'envelope', 'smaenvelope', 'atr',
        'cci', 'adx', 'rsi', 'macd', 'ppo', 'stoch', 'stochastic', 'roc',
        'mom', 'momentum', 'willr', 'mfi', 'donchian', 'keltner', 'aroon',
        'cmf', 'trix', 'stochrsi', 'massindex', 'coppock', 'rvi', 'elderray',
        'ao', 'uo', 'vortex', 'dpo', 'stddev', 'dema', 'tema', 'hma'
    ];

    function _m19iIndicatorTailSafe(ind) {
        if (!ind) return false;
        var t = String(ind.type || '').toLowerCase();
        if (M19I_TAIL_SAFE_WORKER_TYPES.indexOf(t) < 0) return false;
        // dema/tema/hma tail only when they are worker-ported (I-c on).
        if ((t === 'dema' || t === 'tema' || t === 'hma') && !_m19iWorkerPortEnabled()) return false;
        // RSI divergence enrichment is index-based over full history.
        if (t === 'rsi' && ind.params && ind.params.divergenceEnabled) return false;
        return true;
    }

    /** Per-chart M19-I stateful continuation caches (cleared with async work). */
    function _m19iState(chart) {
        if (!chart._m19iIndState) chart._m19iIndState = {};
        return chart._m19iIndState;
    }

    Chart.prototype._m19iInvalidateIndicatorTailState = function() {
        this._m19iIndState = null;
    };

    /**
     * I-c: exact O(delta) supertrend continuation. State checkpoints at the
     * last CONFIRMED bar (n-2); the forming bar is recomputed every pass so
     * its provisional OHLC never poisons the recursion. Falls back to the
     * full calculateSupertrend scan whenever the prefix/params changed.
     */
    function _m19iSupertrendKey(chart, indicator) {
        var p = indicator.params || {};
        return [
            String(chart.currentTimeframe || ''),
            Number(p.period != null ? p.period : 10),
            Number(p.multiplier != null ? p.multiplier : 3)
        ].join('|');
    }

    function _m19iSupertrendFull(chart, indicator) {
        var data = chart.data;
        var n = data.length;
        var p = Math.max(1, (indicator.params && indicator.params.period) || 10);
        var result = calculateSupertrend(data, indicator.params && indicator.params.period, indicator.params && indicator.params.multiplier);
        chart.indicators.data[indicator.id] = result;
        if (n < 2) return result;
        // Rebuild the RMA ATR state at n-2 (calculateSupertrend does not expose it).
        var atr = calculateATR(data, p);
        var j = n - 2;
        _m19iState(chart)['st:' + indicator.id] = {
            key: _m19iSupertrendKey(chart, indicator),
            j: j,
            tJ: data[j].t,
            atr: atr[j],
            close: resolveOhlcSourceValue(data[j], 'close'),
            fU: result.upper[j],
            fL: result.lower[j],
            dir: result.direction[j],
            result: result
        };
        return result;
    }

    function _m19iSupertrendStep(cur, bar, mult, p) {
        var hl2 = resolveOhlcSourceValue(bar, 'hl2');
        var close = resolveOhlcSourceValue(bar, 'close');
        var tr = Math.max(
            bar.h - bar.l,
            Math.max(Math.abs(bar.h - cur.close), Math.abs(bar.l - cur.close))
        );
        var atr = cur.atr == null || isNaN(cur.atr)
            ? null
            : (cur.atr * (p - 1) + tr) / p;
        var out = {
            atr: atr,
            close: close,
            body: Number.isFinite(hl2) ? hl2 : null,
            fU: cur.fU,
            fL: cur.fL,
            dir: cur.dir,
            line: null
        };
        if (atr == null || isNaN(atr) || !Number.isFinite(hl2)) return out;
        var basicUpper = hl2 + mult * atr;
        var basicLower = hl2 - mult * atr;
        var pU = cur.fU;
        var pL = cur.fL;
        var pC = cur.close;
        out.fU = (basicUpper < pU || pC > pU) ? basicUpper : pU;
        out.fL = (basicLower > pL || pC < pL) ? basicLower : pL;
        if (cur.dir === 1) {
            if (close < pL) { out.dir = -1; out.line = out.fU; }
            else { out.dir = 1; out.line = out.fL; }
        } else {
            if (close > pU) { out.dir = 1; out.line = out.fL; }
            else { out.dir = -1; out.line = out.fU; }
        }
        return out;
    }

    function _m19iSupertrendIncremental(chart, indicator) {
        var data = chart.data;
        var n = Array.isArray(data) ? data.length : 0;
        if (n < 3) return _m19iSupertrendFull(chart, indicator);
        var key = _m19iSupertrendKey(chart, indicator);
        var st = _m19iState(chart)['st:' + indicator.id];
        var result = chart.indicators.data[indicator.id];
        if (!st || st.key !== key || !result || result !== st.result
            || st.j == null || st.j > n - 2 || !data[st.j] || data[st.j].t !== st.tJ
            || st.atr == null || isNaN(st.atr)
            || st.fU == null || st.fL == null) {
            return _m19iSupertrendFull(chart, indicator);
        }
        var p = Math.max(1, (indicator.params && indicator.params.period) || 10);
        var mult = indicator.params && indicator.params.multiplier != null
            ? indicator.params.multiplier : 3;
        var arrays = [result.line, result.direction, result.upper, result.lower, result.body];
        for (var a = 0; a < arrays.length; a++) {
            if (!Array.isArray(arrays[a])) return _m19iSupertrendFull(chart, indicator);
            while (arrays[a].length < n) arrays[a].push(null);
            if (arrays[a].length > n) arrays[a].length = n;
        }
        var cur = { atr: st.atr, close: st.close, fU: st.fU, fL: st.fL, dir: st.dir };
        for (var i = st.j + 1; i < n; i++) {
            var step = _m19iSupertrendStep(cur, data[i], mult, p);
            result.body[i] = step.body;
            result.line[i] = step.line;
            result.direction[i] = step.line != null ? step.dir : (result.direction[i] != null ? result.direction[i] : 1);
            result.upper[i] = step.line != null ? step.fU : null;
            result.lower[i] = step.line != null ? step.fL : null;
            if (step.line != null) {
                cur = step;
            } else {
                cur = { atr: step.atr, close: step.close, fU: cur.fU, fL: cur.fL, dir: cur.dir };
            }
            if (i === n - 2) {
                st.j = i;
                st.tJ = data[i].t;
                st.atr = cur.atr;
                st.close = cur.close;
                st.fU = cur.fU;
                st.fL = cur.fL;
                st.dir = cur.dir;
            }
        }
        st.result = result;
        return result;
    }

    /** I-c: exact O(delta + currentDay) ADR continuation (same checkpoint rule). */
    function _m19iAdrKey(chart, indicator, tzId) {
        return [
            String(chart.currentTimeframe || ''),
            Math.max(1, parseInt(indicator.params && indicator.params.period, 10) || 14),
            String(tzId || '')
        ].join('|');
    }

    function _m19iAdrFull(chart, indicator) {
        var data = chart.data;
        var n = data.length;
        var p = Math.max(1, parseInt(indicator.params && indicator.params.period, 10) || 14);
        var tzId = resolveChartWallTimezoneId();
        var result = calculateADR(data, p);
        chart.indicators.data[indicator.id] = result;
        if (n < 2) return result;
        // Rebuild day aggregation state at n-2.
        var j = n - 2;
        var dailyRanges = [];
        var currentDay = null;
        var dayHigh = null;
        var dayLow = null;
        for (var i = 0; i <= j; i++) {
            var ms = adrCandleTimeMs(data[i].t);
            var dayKey = Number.isFinite(ms) ? dayKeyInTimezone(ms, tzId) : '';
            if (!dayKey) continue;
            if (currentDay !== dayKey) {
                if (currentDay !== null && dayHigh !== null && dayLow !== null) {
                    dailyRanges.push(dayHigh - dayLow);
                }
                currentDay = dayKey;
                dayHigh = data[i].h;
                dayLow = data[i].l;
            } else {
                dayHigh = Math.max(dayHigh, data[i].h);
                dayLow = Math.min(dayLow, data[i].l);
            }
        }
        _m19iState(chart)['adr:' + indicator.id] = {
            key: _m19iAdrKey(chart, indicator, tzId),
            j: j,
            tJ: data[j].t,
            currentDay: currentDay,
            dayHigh: dayHigh,
            dayLow: dayLow,
            dailyRanges: dailyRanges,
            result: result
        };
        return result;
    }

    function _m19iAdrValue(dailyRanges, p) {
        var priorCount = dailyRanges.length;
        if (priorCount < 1) return null;
        var lookback = Math.min(p, priorCount);
        var sum = 0;
        for (var d = priorCount - lookback; d < priorCount; d++) sum += dailyRanges[d];
        return sum / lookback;
    }

    function _m19iAdrIncremental(chart, indicator) {
        var data = chart.data;
        var n = Array.isArray(data) ? data.length : 0;
        if (n < 3) return _m19iAdrFull(chart, indicator);
        var tzId = resolveChartWallTimezoneId();
        var key = _m19iAdrKey(chart, indicator, tzId);
        var st = _m19iState(chart)['adr:' + indicator.id];
        var result = chart.indicators.data[indicator.id];
        if (!st || st.key !== key || !Array.isArray(result) || result !== st.result
            || st.j == null || st.j > n - 2 || !data[st.j] || data[st.j].t !== st.tJ) {
            return _m19iAdrFull(chart, indicator);
        }
        var p = Math.max(1, parseInt(indicator.params && indicator.params.period, 10) || 14);
        while (result.length < n) result.push(null);
        if (result.length > n) result.length = n;
        var cur = {
            currentDay: st.currentDay,
            dayHigh: st.dayHigh,
            dayLow: st.dayLow,
            ranges: st.dailyRanges
        };
        for (var i = st.j + 1; i < n; i++) {
            var ms = adrCandleTimeMs(data[i].t);
            var dayKey = Number.isFinite(ms) ? dayKeyInTimezone(ms, tzId) : '';
            var committed = i <= n - 2;
            if (!dayKey) {
                result[i] = null;
            } else if (cur.currentDay !== dayKey) {
                var rangesAfterRoll = cur.ranges;
                if (cur.currentDay !== null && cur.dayHigh !== null && cur.dayLow !== null) {
                    rangesAfterRoll = cur.ranges.concat([cur.dayHigh - cur.dayLow]);
                }
                result[i] = _m19iAdrValue(rangesAfterRoll, p);
                if (committed) {
                    cur.ranges = rangesAfterRoll;
                    cur.currentDay = dayKey;
                    cur.dayHigh = data[i].h;
                    cur.dayLow = data[i].l;
                }
            } else {
                result[i] = _m19iAdrValue(cur.ranges, p);
                if (committed) {
                    cur.dayHigh = Math.max(cur.dayHigh, data[i].h);
                    cur.dayLow = Math.min(cur.dayLow, data[i].l);
                }
            }
            if (i === n - 2) {
                st.j = i;
                st.tJ = data[i].t;
                st.currentDay = cur.currentDay;
                st.dayHigh = cur.dayHigh;
                st.dayLow = cur.dayLow;
                st.dailyRanges = cur.ranges;
            }
        }
        st.result = result;
        return result;
    }

    /**
     * I-b: sessions is pure per-bar (depends only on bar.t), so an append-only
     * pass computes ONLY the new bars and reuses the prior perCandle prefix.
     */
    function _m19iSessionsCalc(chart, indicator) {
        var payload = sessionsCalcPayload(indicator);
        if (!_m19iSyncOnlyTailEnabled()) {
            return calculateSessions(chart.data, payload);
        }
        var data = chart.data;
        var n = data.length;
        var sig;
        try { sig = JSON.stringify(payload); } catch (_) { sig = null; }
        var stMap = _m19iState(chart);
        var st = sig ? stMap['sess:' + indicator.id] : null;
        var prev = chart.indicators.data[indicator.id];
        if (st && st.sig === sig && prev && st.result === prev
            && Array.isArray(prev.perCandle)
            && st.len <= n && st.len > 0
            && data[st.len - 1] && data[st.len - 1].t === st.lastT) {
            var defs = prev.defs;
            for (var i = st.len; i < n; i++) {
                var dec = sessionWallDecimal(data[i].t, prev.timezone);
                var candleSessions = [];
                for (var d = 0; d < defs.length; d++) {
                    var sd = defs[d];
                    if (isInSessionDecimal(dec, sd)) {
                        candleSessions.push({ type: sd.key, name: sd.name, color: sd.color });
                    }
                }
                prev.perCandle.push(candleSessions);
            }
            if (prev.perCandle.length > n) prev.perCandle.length = n;
            st.len = n;
            st.lastT = n ? data[n - 1].t : null;
            return prev;
        }
        var full = calculateSessions(data, payload);
        if (sig) {
            stMap['sess:' + indicator.id] = {
                sig: sig,
                len: n,
                lastT: n ? data[n - 1].t : null,
                result: full
            };
        }
        return full;
    }

    /**
     * I-b: ictfvg boxes are stateless 3-candle detections extended by a fixed
     * bar count. Recompute only the window that new bars can affect and keep
     * earlier (provably stable) boxes from the prior result.
     */
    function _m19iIctFvgCalc(chart, indicator) {
        var params = {
            extendBars: indicator.params.extendBars,
            maxBoxes: indicator.params.maxBoxes,
            minGapPct: indicator.params.minGapPct
        };
        if (!_m19iSyncOnlyTailEnabled()) {
            return calculateFairValueGaps(chart.data, params);
        }
        var data = chart.data;
        var n = data.length;
        var extendBars = params.extendBars != null ? params.extendBars : 80;
        var maxBoxes = Math.min(400, Math.max(8, params.maxBoxes != null ? params.maxBoxes : 120));
        var sig;
        try { sig = JSON.stringify(params); } catch (_) { sig = null; }
        var stMap = _m19iState(chart);
        var st = sig ? stMap['ictfvg:' + indicator.id] : null;
        var prev = chart.indicators.data[indicator.id];
        var w0 = st ? Math.max(0, st.len - extendBars - 3) : 0;
        if (st && st.sig === sig && prev && st.result === prev
            && Array.isArray(prev.boxes)
            && st.len >= 3 && st.len <= n
            && data[st.len - 1] && data[st.len - 1].t === st.lastT
            && data[st.len - 1].c === st.lastC
            && w0 > 0) {
            var tailBoxes = calculateFairValueGaps(data.slice(w0), params).boxes;
            var merged = [];
            var pb = prev.boxes;
            for (var i = 0; i < pb.length; i++) {
                if (pb[i].startIndex < w0) merged.push(pb[i]);
            }
            for (var j = 0; j < tailBoxes.length; j++) {
                var b = tailBoxes[j];
                merged.push({
                    startIndex: b.startIndex + w0,
                    endIndex: Math.min(n - 1, b.endIndex + w0),
                    top: b.top,
                    bottom: b.bottom,
                    bullish: b.bullish
                });
            }
            var out = { boxes: merged.length > maxBoxes ? merged.slice(-maxBoxes) : merged };
            stMap['ictfvg:' + indicator.id] = {
                sig: sig,
                len: n,
                lastT: data[n - 1].t,
                lastC: data[n - 1].c,
                result: out
            };
            return out;
        }
        var full = calculateFairValueGaps(data, params);
        if (sig && n >= 3) {
            stMap['ictfvg:' + indicator.id] = {
                sig: sig,
                len: n,
                lastT: data[n - 1].t,
                lastC: data[n - 1].c,
                result: full
            };
        }
        return full;
    }

    /** I-b: talariafvg via the module's checkpoint/resume engine. */
    function _m19iTalariaFvgCalc(chart, indicator) {
        var mod = global.TalariaFvgIndicator;
        if (!_m19iSyncOnlyTailEnabled()
            || !mod || typeof mod.calculateResumable !== 'function') {
            return calculateTalariaFvgIndicator(chart.data, indicator, chart);
        }
        var ctx = {
            resample: typeof chart.resampleData === 'function' ? chart.resampleData.bind(chart) : null,
            rawData: Array.isArray(chart.rawData) ? chart.rawData : chart.data,
            currentTimeframe: chart.currentTimeframe
        };
        var stMap = _m19iState(chart);
        var prevCp = stMap['fvg:' + indicator.id] || null;
        var rr = mod.calculateResumable(chart.data, indicator.params, ctx, prevCp);
        stMap['fvg:' + indicator.id] = rr.checkpoint;
        return rr.result;
    }

    /**
     * M19-I(d): reasons whose force:true must bypass the identical-state
     * dedupe. These change indicator OUTPUT without changing the snapshot
     * fields (timezone) or replace data wholesale where a fingerprint of the
     * last bar is not proof enough. Everything else dedupes on identical
     * state: TF / params / data replacement still invalidate through the
     * snapshot fields themselves.
     */
    var M19I_FORCE_INVALIDATING_REASONS = [
        'timezone', 'backtest-tf', 'data-defer', 'replay-restore',
        'tf-change', 'timeframe-change', 'param-change', 'params-change',
        'data-replace', 'indicator-add', 'indicator-remove',
        'symbol-change', 'file-change'
    ];

    Chart.prototype.scheduleIndicatorRecalc = function(reason, opts) {
        opts = opts || {};
        if (!this.indicators || !this.indicators.active || !this.indicators.active.length) return;
        if (!Array.isArray(this.data) || !this.data.length) return;

        const barCount = this.data.length;
        const dataVersion = this.dataVersion != null ? this.dataVersion : 0;
        const paramsHash = this._indicatorParamsHash();
        const timeframe = String(this.currentTimeframe || '');
        const dataFp = _indicatorDataFingerprint(this);
        const snap = this._indCalcSnapshot;

        // I-d: force only bypasses dedupe for genuinely invalidating reasons.
        let honorForce = !!opts.force;
        if (honorForce && _m19iForceDedupeEnabled()
            && M19I_FORCE_INVALIDATING_REASONS.indexOf(String(reason || '')) < 0) {
            honorForce = false;
        }

        if (!honorForce && snap
            && snap.barCount === barCount
            && snap.dataVersion === dataVersion
            && snap.paramsHash === paramsHash
            && snap.timeframe === timeframe
            && snap.dataFp === dataFp) {
            return;
        }

        if (this._indRecalcTimer) {
            clearTimeout(this._indRecalcTimer);
            this._indRecalcTimer = null;
        }

        const delay = opts.immediate ? 0
            : (reason === 'live-tick' || reason === 'replay-tick' || reason === 'replay-step' || reason === 'replay-pause') ? 0
            : 12;
        const chart = this;
        const run = function() {
            chart._indRecalcTimer = null;
            if (!opts.force
                && typeof chart._isInteractionFastRender === 'function'
                && chart._isInteractionFastRender()) {
                chart._indRecalcQueued = { reason: reason, opts: opts };
                return;
            }
            chart._runIndicatorRecalc(opts);
        };
        if (delay <= 0) run();
        else chart._indRecalcTimer = setTimeout(run, delay);
    };

    Chart.prototype._flushQueuedIndicatorRecalc = function() {
        if (!this._indRecalcQueued) return;
        const queued = this._indRecalcQueued;
        this._indRecalcQueued = null;
        this._runIndicatorRecalc(queued.opts || { force: false });
    };

    /**
     * Replay play perf: do not recompute indicators every forming-candle frame.
     * Same bar-advance gate formerly limited to Sessions/ICT/Talaria — now applies
     * to ALL active indicators (SMA/EMA/RSI/… included). Pause still full-syncs.
     * Kill-switch: window.__TALARIA_FIX_SESSION_REPLAY_PERF = false
     */
    var SESSION_REPLAY_HEAVY_TYPES = [
        'sessions', 'killzones', 'ictkz', 'sessionsplus', 'openingrange', 'or',
        'ictpd', 'ictasian', 'ictote', 'ictfvg', 'ictsesspd', 'ictliquidity',
        'icteverything', 'talariafvg', 'talariaratiogap', 'talariaweeklymap', 'talariasmc',
        'seasonality', 'cotnet', 'supertrend', 'adr'
    ];

    function _sessionReplayPerfFixEnabled() {
        return typeof window === 'undefined'
            || window.__TALARIA_FIX_SESSION_REPLAY_PERF !== false;
    }

    function _replayIndicatorBarFingerprint(chart) {
        const data = chart && chart.data;
        if (!Array.isArray(data) || !data.length) return null;
        const last = data[data.length - 1] || {};
        // Bar-advance only (length + open time). Do NOT include OHLC — forming-candle
        // animation would otherwise force a full indicator pass every paint frame.
        return [
            data.length,
            last.t,
            (chart.indicators.active || []).map(function(ind) {
                return String(ind.id || '') + ':' + String(ind.type || '').toLowerCase();
            }).join(',')
        ].join('|');
    }

    function _replayIndicatorsReady(chart) {
        if (!chart || !chart.indicators || !Array.isArray(chart.indicators.active)) return false;
        if (!chart.indicators.active.length) return false;
        const dataMap = chart.indicators.data || {};
        for (let i = 0; i < chart.indicators.active.length; i++) {
            const ind = chart.indicators.active[i];
            if (!ind || !ind.id) continue;
            if (!dataMap[ind.id]) return false;
        }
        return true;
    }

    // Back-compat aliases (older call sites / probes).
    function _sessionReplayHeavyFingerprint(chart) {
        return _replayIndicatorBarFingerprint(chart);
    }
    function _sessionReplayHeavyReady(chart) {
        return _replayIndicatorsReady(chart);
    }

    /**
     * Replay playback: coalesce to one rAF. Full sync only when the candle advances
     * (or on pause). Mid-bar forming OHLC no longer recomputes every indicator.
     */
    Chart.prototype.scheduleReplayIndicatorRecalc = function(isPlaying) {
        if (!this.indicators || !this.indicators.active || !this.indicators.active.length) return;
        if (!Array.isArray(this.data) || !this.data.length) return;
        if (typeof window !== 'undefined'
            && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true) {
            _b70ShadowRecordRequest(this, 'scheduleReplayIndicatorRecalc');
        }

        const replay = this.replaySystem;
        const passivePlay = this._multichartPassivePlayActive === true;
        const playing = isPlaying != null
            ? (!!isPlaying || passivePlay)
            : !!(replay && replay.isActive && (replay.isPlaying || passivePlay));

        if (!playing) {
            if (this._replayIndRecalcRaf != null) {
                cancelAnimationFrame(this._replayIndRecalcRaf);
                this._replayIndRecalcRaf = null;
            }
            if (this._indicatorWorkerSeq == null) this._indicatorWorkerSeq = 0;
            this._indicatorWorkerSeq++;
            this._indicatorWorkerCoalesce = false;
            this._sessionIndReplayFp = null;
            this._sessionIndReplayTipFp = null;
            this._recalcSkipTypes = null;
            // I-d: repeated pause/step/restore with byte-identical state
            // dedupes the full sync; any data/param/TF delta still recomputes.
            var skipPauseSync = false;
            if (_m19iForceDedupeEnabled()) {
                var pSnap = this._indCalcSnapshot;
                skipPauseSync = !!(pSnap
                    && pSnap.barCount === this.data.length
                    && pSnap.dataVersion === (this.dataVersion != null ? this.dataVersion : 0)
                    && pSnap.paramsHash === this._indicatorParamsHash()
                    && pSnap.timeframe === String(this.currentTimeframe || '')
                    && pSnap.dataFp === _indicatorDataFingerprint(this)
                    && _replayIndicatorsReady(this));
            }
            if (!skipPauseSync && typeof this.recalculateIndicators === 'function') {
                try { this.recalculateIndicators(); } catch (_) {}
            }
            pinReplayLegendHoverBeforeRecalc(this);
            if (typeof this.updateOHLCIndicators === 'function') this.updateOHLCIndicators();
            if (typeof this.bumpIndicatorRenderVersion === 'function') this.bumpIndicatorRenderVersion();
            syncReplayLegendAfterIndicatorRecalc(this);
            return;
        }

        const chart = this;
        const runReplayPlayIndicatorPass = function() {
            const passiveMirror = chart._multichartPassivePlayActive === true;
            if (!chart.replaySystem || !chart.replaySystem.isActive) return;
            if (!chart.replaySystem.isPlaying && !passiveMirror) return;
            if (!chart.indicators || !chart.indicators.active || !chart.indicators.active.length) return;
            if (!Array.isArray(chart.data) || !chart.data.length) return;
            if (chart._indicatorWorkerSeq == null) chart._indicatorWorkerSeq = 0;
            const tailSend = _m19iTailSendEnabled();
            if (!tailSend) {
                // b57 legacy: invalidate any in-flight worker pass every frame.
                // The tail path instead guards commits by exact array length +
                // timeframe, so responses posted this bar may still land.
                chart._indicatorWorkerSeq++;
                chart._indicatorWorkerCoalesce = false;
            }

            // Same bar → keep prior indicator arrays; only re-render / legend.
            // Applies to ALL indicators (not only Sessions/Talaria).
            // I-g: while tick-mode forming OHLC mutates, tip must track last.c
            // even though bar length/open-time fingerprint is unchanged.
            let skipAllRecalc = false;
            if (_sessionReplayPerfFixEnabled()) {
                const fp = _replayIndicatorBarFingerprint(chart);
                const replay = chart.replaySystem;
                const formingTick = _m19igTickCoherentEnabled()
                    && replay
                    && replay.animatingCandle
                    && (replay.tickProgress || 0) > 0;
                if (formingTick && fp) {
                    const last = chart.data[chart.data.length - 1] || {};
                    const tipFp = fp + '|' + last.c + '|' + last.h + '|' + last.l;
                    if (tipFp === chart._sessionIndReplayTipFp
                        && _replayIndicatorsReady(chart)) {
                        skipAllRecalc = true;
                    } else {
                        chart._sessionIndReplayTipFp = tipFp;
                        chart._sessionIndReplayFp = fp;
                    }
                } else if (fp
                    && fp === chart._sessionIndReplayFp
                    && _replayIndicatorsReady(chart)) {
                    skipAllRecalc = true;
                } else if (fp) {
                    chart._sessionIndReplayFp = fp;
                    chart._sessionIndReplayTipFp = null;
                }
            }

            if (!skipAllRecalc) {
                // I-a/I-b/I-c: steady play routes bar advances through the
                // bounded incremental pipeline instead of a full O(history)
                // synchronous rescan of every indicator.
                let usedTail = false;
                if (tailSend && typeof chart.recalculateIndicatorsIncremental === 'function') {
                    const tSnap = chart._indCalcSnapshot;
                    const barCount = chart.data.length;
                    if (tSnap
                        && tSnap.timeframe === String(chart.currentTimeframe || '')
                        && tSnap.paramsHash === chart._indicatorParamsHash()
                        && barCount >= tSnap.barCount
                        && (barCount - tSnap.barCount) <= 64
                        && _replayIndicatorsReady(chart)) {
                        try {
                            chart.recalculateIndicatorsIncremental(tSnap.barCount);
                            usedTail = true;
                        } catch (_) {
                            usedTail = false;
                        }
                    }
                }
                if (!usedTail) {
                    // Baseline / seek / self-heal: one full synchronous pass
                    // re-anchors every indicator and the dedupe snapshot.
                    try {
                        if (typeof chart.recalculateIndicators === 'function') {
                            chart._recalcSkipTypes = null;
                            try { chart.recalculateIndicators(); } finally {
                                chart._recalcSkipTypes = null;
                            }
                        }
                    } catch (_) {
                        chart._recalcSkipTypes = null;
                    }
                }
            }
            pinReplayLegendHoverBeforeRecalc(chart);
            if (typeof chart.updateOHLCIndicators === 'function') chart.updateOHLCIndicators();
            if (typeof chart.bumpIndicatorRenderVersion === 'function') chart.bumpIndicatorRenderVersion();
            syncReplayLegendAfterIndicatorRecalc(chart);
            if (typeof chart.scheduleRender === 'function') chart.scheduleRender();
        };

        if (_m19ifFrameCoherentEnabled()) {
            // I-f: run the bounded pass synchronously at tick time. The replay
            // tick calls this BEFORE the price paint (_renderReplayChartUpdate),
            // so every paint presents price and indicator series from the same
            // committed generation — no rAF gap, no worker-RTT catch-up frame.
            if (this._replayIndRecalcRaf != null) {
                cancelAnimationFrame(this._replayIndRecalcRaf);
                this._replayIndRecalcRaf = null;
            }
            runReplayPlayIndicatorPass();
            return;
        }
        // I-f OFF (b58 legacy): defer to the next animation frame; the tick's
        // price paint lands first and indicators visibly catch up afterwards.
        if (this._replayIndRecalcRaf != null) return;
        this._replayIndRecalcRaf = requestAnimationFrame(function() {
            chart._replayIndRecalcRaf = null;
            runReplayPlayIndicatorPass();
        });
    };

    Chart.prototype._runIndicatorRecalc = function(opts) {
        opts = opts || {};
        const barCount = this.data.length;
        const prev = this._indCalcSnapshot;
        const replay = this.replaySystem;
        const replayActive = !!(replay && replay.isActive);
        const replayPlaying = replayActive && (!!replay.isPlaying || this._multichartPassivePlayActive === true);
        const replaySyncMax = 12000;
        const appendOnly = !opts.force && !replayActive && prev
            && barCount > prev.barCount && (barCount - prev.barCount) <= 8;

        if (replayPlaying) {
            if (typeof this.scheduleReplayIndicatorRecalc === 'function') {
                this.scheduleReplayIndicatorRecalc(true);
            } else if (typeof this.recalculateIndicators === 'function') {
                try { this.recalculateIndicators(); } catch (_) {}
            }
            return;
        }
        if (replayActive && !replayPlaying && barCount <= replaySyncMax
            && typeof this.recalculateIndicators === 'function') {
            try { this.recalculateIndicators(); } catch (_) {}
            return;
        }
        if (appendOnly && typeof this.recalculateIndicatorsIncremental === 'function') {
            this.recalculateIndicatorsIncremental(prev.barCount);
            return;
        }
        if (typeof this.recalculateIndicatorsAsync === 'function') {
            this.recalculateIndicatorsAsync();
        } else if (typeof this.recalculateIndicators === 'function') {
            this.recalculateIndicators();
        }
    };

    Chart.prototype._applyIndicatorWorkerResults = function(results, mySeq, calcToken, tailMeta) {
        const chart = this;
        if (chart._indicatorWorkerSeq !== mySeq) return false;

        // M19-I(a): a tail commit uses a relaxed guard — the strict data token
        // (dataVersion/last-bar fingerprint) churns every replay advance, but a
        // tail merge is only valid for the exact array length it was computed
        // against, on the same timeframe. Any TF switch / data replacement
        // bumps _indicatorWorkerSeq (M19-H) and is rejected above.
        if (tailMeta) {
            if (!Array.isArray(chart.data)
                || chart.data.length !== tailMeta.totalLength
                || String(chart.currentTimeframe || '') !== tailMeta.timeframe) {
                return false;
            }
            // B62-1: same length + timeframe is NOT enough. A tick-mode forming
            // close (or volume) mutates the last bar IN PLACE, a pair/dataset
            // swap can land the same shape, and an indicator add/remove/param
            // edit can race the reply — any of these makes the reply stale
            // while seq/snapshot look current. The full post-time token
            // (t/o/h/l/c/v + dataVersion + TF + paramsHash + datasetGen)
            // rejects all of them BEFORE any merge; the owning pass's finish
            // hook reruns through the scheduler via the boolean coalesce flag
            // only (no queue, no extra worker post from here).
            if (_m19iExactTailPaintEnabled() && tailMeta.b62Token) {
                // Mint a new monotonic generation if the data ARRAY was
                // replaced since the post (multichart same-shape swap where
                // the dataVersion owner failed to bump) BEFORE comparing.
                _m19iB62ObserveData(chart);
                if (_m19iB62TailTokenStale(chart, tailMeta.b62Token)) {
                    _m19iB62Stats(chart).staleTailRejects++;
                    if (tailMeta.b62Token.datasetGen >= Number.MAX_SAFE_INTEGER
                        || _m19iB62GenOf(chart) >= Number.MAX_SAFE_INTEGER) {
                        // Generation exhaustion fails CLOSED: the tail path
                        // stops accepting (no reset, no collision) and the
                        // full async pipeline owns freshness from here.
                        chart._m19iCoalesceFullAsync = true;
                    }
                    chart._indicatorWorkerCoalesce = true;
                    return false;
                }
            }
        } else if (!_indicatorAsyncTokenMatches(chart, calcToken)) {
            return false;
        }
        if (!chart.indicators) chart.indicators = {};
        if (!chart.indicators.data) chart.indicators.data = {};

        if (tailMeta) {
            const perf = _indicatorPerf();
            const mergeWindow = perf && typeof perf.mergeIndicatorTailWindow === 'function'
                ? perf.mergeIndicatorTailWindow
                : null;
            let mergeFailed = false;
            if (_m19iExactTailPaintEnabled()) {
                // B62 atomic commit: either every series in this reply merges
                // to the new generation or none does (bounded snapshot +
                // rollback) — a mixed-generation partial commit can never
                // publish through bumpIndicatorRenderVersion below.
                mergeFailed = !_m19iB62AtomicMergeSet(
                    chart, results,
                    tailMeta.tailStart, tailMeta.fromIndex, tailMeta.totalLength
                );
                if (mergeFailed) _m19iB62Stats(chart).atomicRollbacks++;
            } else {
                // b61 legacy (kill switch): per-series in-place merge, partial
                // commits possible on failure — preserved exactly for A/B.
                Object.keys(results).forEach(function(indId) {
                    const merged = mergeWindow
                        ? mergeWindow(
                            chart.indicators.data[indId],
                            results[indId],
                            tailMeta.tailStart,
                            tailMeta.fromIndex,
                            tailMeta.totalLength
                        )
                        : null;
                    if (merged != null) {
                        chart.indicators.data[indId] = merged;
                    } else {
                        mergeFailed = true;
                    }
                });
            }
            if (mergeFailed) {
                // Shape mismatch (first pass for an indicator, param edit race…):
                // schedule one full worker pass to rebuild clean baselines.
                chart._m19iCoalesceFullAsync = true;
                chart._indicatorWorkerCoalesce = true;
                if (_b70ShadowEnabled()) return false;
            } else if (tailMeta.markComplete
                && typeof chart._markIndicatorRecalcComplete === 'function') {
                chart._markIndicatorRecalcComplete();
            }
            if (typeof chart._clearIndicatorCalculatingFlags === 'function') {
                chart._clearIndicatorCalculatingFlags();
            }
            chart.bumpIndicatorRenderVersion();
            if (_m19iExactTailPaintEnabled() && !mergeFailed && tailMeta.b62Token) {
                // B62-2 eventual fresh paint: a token-verified worker tail IS
                // the exact fresh endpoint for the current identity. Publish
                // it (with the post-bump render-version witness), release the
                // failure memo, and retire any pending fresh request — a
                // budget-skipped or fallback-classified mix converges here.
                try {
                    chart._m19iExactTailLastFp = chart._m19iExactTailPaintFp();
                    chart._m19iExactTailLastRv = chart._indicatorRenderVersion || 0;
                    chart._m19iExactTailFailFp = null;
                    chart._m19iExactTailFailRv = null;
                    chart._m19iB62PendingFreshFp = null;
                } catch (_) {}
            }
            if (typeof chart.scheduleRender === 'function') {
                if (!_b70ShadowEnabled()) chart.scheduleRender();
            }
            return true;
        }

        Object.assign(chart.indicators.data, results);
        chart.indicators.active.forEach(function(ind) {
            const t = String(ind.type || '').toLowerCase();
            if (t === 'supertrend') {
                try { recalcSupertrendOverlay(chart, ind); } catch (_) {}
            } else if (t === 'adr') {
                try { recalcAdrIndicator(chart, ind); } catch (_) {}
            } else if (t === 'dema' || t === 'tema' || t === 'hma') {
                // I-c: the worker already computed these series in this pass.
                if (!(_m19iWorkerPortEnabled() && results && results[ind.id] != null)) {
                    try { recalcMultiPassOverlayMa(chart, ind); } catch (_) {}
                }
            } else if (t === 'rsi' && ind.params && ind.params.divergenceEnabled) {
                const base = chart.indicators.data[ind.id];
                if (base) {
                    chart.indicators.data[ind.id] = enrichRsiPackWithDivergences(chart.data, base, ind.params);
                }
            }
        });
        if (typeof chart._markIndicatorRecalcComplete === 'function') {
            chart._markIndicatorRecalcComplete();
        }
        if (typeof chart._clearIndicatorCalculatingFlags === 'function') {
            chart._clearIndicatorCalculatingFlags();
        } else {
            chart.indicators.active.forEach(function(ind) { if (ind) ind._calculating = false; });
            if (typeof chart.updateOHLCIndicators === 'function') chart.updateOHLCIndicators();
        }
        chart.bumpIndicatorRenderVersion();
        if (_m19iExactTailPaintEnabled()) {
            // B62-2 eventual fresh paint (full-pass endpoint): a token-current
            // FULL worker apply is also an exact fresh endpoint — publish the
            // success memo, release the failure memo, retire the pending fresh
            // request. The fp is computed with the CURRENT stored dataset
            // generation (no ObserveData here): if the data array was replaced
            // mid-flight, the next paint hook mints a new generation and the
            // memo can never suppress that repaint.
            try {
                chart._m19iExactTailLastFp = chart._m19iExactTailPaintFp();
                chart._m19iExactTailLastRv = chart._indicatorRenderVersion || 0;
                chart._m19iExactTailFailFp = null;
                chart._m19iExactTailFailRv = null;
                chart._m19iB62PendingFreshFp = null;
            } catch (_) {}
        }
        if (typeof chart.scheduleRender === 'function') {
            if (!_b70ShadowEnabled()) chart.scheduleRender();
        }
        return true;
    };

    Chart.prototype._commitPendingIndicatorResults = function() {
        const pending = this._indicatorPendingResults;
        if (!pending || !pending.results) return;
        this._indicatorPendingResults = null;
        if (this._indicatorWorkerSeq !== pending.seq) return;
        if (!this.indicators.data) this.indicators.data = {};
        const chart = this;
        Object.assign(chart.indicators.data, pending.results);
        chart.indicators.active.forEach(function(ind) {
            const t = String(ind.type || '').toLowerCase();
            if (t === 'supertrend') {
                try { recalcSupertrendOverlay(chart, ind); } catch (_) {}
            } else if (t === 'adr') {
                try { recalcAdrIndicator(chart, ind); } catch (_) {}
            } else if (t === 'dema' || t === 'tema' || t === 'hma') {
                // I-c: the worker already computed these series in this pass.
                if (!(_m19iWorkerPortEnabled() && pending.results[ind.id] != null)) {
                    try { recalcMultiPassOverlayMa(chart, ind); } catch (_) {}
                }
            } else if (t === 'rsi' && ind.params && ind.params.divergenceEnabled) {
                const base = chart.indicators.data[ind.id];
                if (base) {
                    chart.indicators.data[ind.id] = enrichRsiPackWithDivergences(chart.data, base, ind.params);
                }
            }
        });
        if (typeof chart._clearIndicatorCalculatingFlags === 'function') {
            chart._clearIndicatorCalculatingFlags();
        }
        if (typeof chart.updateOHLCIndicators === 'function') chart.updateOHLCIndicators();
        chart.bumpIndicatorRenderVersion();
        if (_m19iExactTailPaintEnabled()) {
            // B62-2: deferred full-pass commit is a fresh endpoint too (see
            // _applyIndicatorWorkerResults full branch for the memo contract).
            try {
                chart._m19iExactTailLastFp = chart._m19iExactTailPaintFp();
                chart._m19iExactTailLastRv = chart._indicatorRenderVersion || 0;
                chart._m19iExactTailFailFp = null;
                chart._m19iExactTailFailRv = null;
                chart._m19iB62PendingFreshFp = null;
            } catch (_) {}
        }
    };

    /**
     * B62-2: forming-tip identity — the same complete field set as the B62-1
     * token (length + last t/o/h/l/c/v, dataVersion, paramsHash, TF, dataset
     * generation), serialized to a string. No object identity is compared.
     */
    Chart.prototype._m19iExactTailPaintFp = function() {
        var data = this && this.data;
        var totalLen = Array.isArray(data) ? data.length : 0;
        return [
            _indicatorDataFingerprint(this),
            this.dataVersion != null ? this.dataVersion : 0,
            typeof this._indicatorParamsHash === 'function' ? this._indicatorParamsHash() : '',
            String(this.currentTimeframe || ''),
            _m19iB62ChartPairIdentity(this),
            _m19iB62MasterGeneration(this),
            _m19iB62WindowFp(data, 0, totalLen),
            _m19iB62GenOf(this)
        ].join('|');
    };

    /**
     * B62-2 workload ceiling: staged points = (tail window × series count).
     * Measured on representative hardware (W1-B62 workload evidence): the
     * synchronous bridge costs ≈1µs per staged point, so 4096 points ≈ 4ms
     * p50 — the ceiling keeps the worst SUPPORTED paint-time bridge under
     * roughly half a 60Hz frame. The typical W5 scenario (five MA(20) +
     * TEMA(20), lookback 144) stages <1k points (≪1ms). Heavier mixes
     * (e.g. 8 series with period ≥200 → 8.5k points, measured p50 ≈8ms,
     * p95 ≈15ms) fall back to b61-window behavior for that paint
     * (skip + counter) instead of a synchronous jank spike; the regular
     * recalc pipeline still refreshes them every tick.
     */
    var M19I_B62_MAX_STAGED_POINTS = 4096;

    /**
     * B62-2: bounded exact forming-tail bridge at PAINT time (M19-I tail-send
     * extension). Runs only when the forming-tip fingerprint differs from the
     * last bridged/committed one, immediately before the indicator layer
     * cache decision — the same paint that moves the price can never blit an
     * endpoint older than the forming close it presents (RC2), and a stale
     * commit rejected by B62-1 can never survive into the next paint (RC1).
     * O(estimateTailLookback) through the SAME _m19ifApplyCoherentBridge merge
     * the I-f pass uses, so worker/main numeric parity holds by construction.
     * Never posts to the worker, never touches busy/coalesce, no queue;
     * re-entrancy guarded by _m19iExactTailPaintBusy.
     */
    Chart.prototype._m19iExactTailPaint = function() {
        if (_b70ShadowEnabled()) {
            _b70Stage3ConsumePaint(this);
            return false;
        }
        if (!_m19iExactTailPaintEnabled()) return false;
        if (this._m19iExactTailPaintBusy) return false;
        if (!this.indicators || !Array.isArray(this.indicators.active)
            || !this.indicators.active.length) return false;
        if (!Array.isArray(this.data) || !this.data.length) return false;
        // A swapped data ARRAY mints a new monotonic generation before any
        // fingerprint/memo comparison (multichart replacement detection).
        _m19iB62ObserveData(this);
        var fp = this._m19iExactTailPaintFp();
        var rv = this._indicatorRenderVersion || 0;
        if (_m19iB62GenOf(this) >= Number.MAX_SAFE_INTEGER) {
            _m19iB62Stats(this).exactTailSkips++;
            this._m19iExactTailFailFp = fp;
            this._m19iExactTailFailRv = rv;
            _m19iB62EnsureFreshAsync(this, fp);
            return false;
        }
        // Both memos carry a render-version WITNESS. _m19iExactTailLastFp is
        // published ONLY after a successful complete atomic commit (here, the
        // I-f recalc pass, or a fresh worker tail apply); any foreign render
        // bump afterwards (a b61-era stale overwrite while the switch was
        // OFF, a full recalc, a worker apply) invalidates the witness and the
        // next paint re-verifies — OFF→ON re-enable therefore self-heals with
        // ZERO writes while OFF. The failure memo only suppresses repeated
        // synchronous work for one identity; eventual freshness NEVER rests
        // on it because every failure path also requests exactly one fresh
        // worker recomputation (_m19iB62EnsureFreshAsync).
        if (fp === this._m19iExactTailLastFp && rv === this._m19iExactTailLastRv) return false;
        if (fp === this._m19iExactTailFailFp && rv === this._m19iExactTailFailRv) {
            _m19iB62EnsureFreshAsync(this, fp);
            return false;
        }
        this._m19iExactTailPaintBusy = true;
        try {
            var skipTypes = _m19iWorkerSkipTypes();
            var indicatorMap = {};
            var stagedSeries = 0;
            var wholePaintSyncOk = true;
            this.indicators.active.forEach(function(ind) {
                if (!ind || !ind.id) return;
                var t = String(ind.type || '').toLowerCase();
                // supertrend/adr/sync-only/volume/custom are recalculated
                // synchronously inside every recalc pass (I-c) or draw —
                // they are not part of the worker round-trip staleness this
                // hook repairs, so they do not gate the transaction.
                if (skipTypes.indexOf(t) >= 0) return;
                var fam = _m19iB62SyncFamily(ind);
                if (!fam) {
                    // Worker-owned family the bridge may not synchronously
                    // publish (recursive/seed-dependent, tail-unsafe, or no
                    // bridge case): the WHOLE paint transaction goes async so
                    // no mixed-generation endpoint can be painted.
                    wholePaintSyncOk = false;
                    return;
                }
                indicatorMap[ind.id] = { type: t, params: ind.params || {} };
                stagedSeries += fam.seriesCount;
            });
            if (!wholePaintSyncOk) {
                _m19iB62Stats(this).exactTailSkips++;
                this._m19iExactTailFailFp = fp;
                this._m19iExactTailFailRv = rv;
                _m19iB62EnsureFreshAsync(this, fp);
                return false;
            }
            if (stagedSeries === 0) {
                // Nothing worker-owned is active — nothing can be RTT-stale.
                _m19iB62Stats(this).exactTailSkips++;
                this._m19iExactTailFailFp = fp;
                this._m19iExactTailFailRv = rv;
                return false;
            }
            if (typeof window !== 'undefined'
                && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true) {
                _b70ShadowRecordCalculation(this, '_m19iExactTailPaint', 'paint');
            }
            var perf = _indicatorPerf();
            var totalLen = this.data.length;
            var lookback = perf && typeof perf.estimateTailLookback === 'function'
                ? perf.estimateTailLookback(this.indicators.active)
                : 256;
            var mergeFrom = Math.max(0, totalLen - 2);
            var tailStart = Math.max(0, mergeFrom - lookback);
            // CUMULATIVE budget FIRST (before any candidate computation):
            // staged points = window length × Σ per-family output series.
            // Beyond-ceiling mixes skip the synchronous work but keep the
            // eventual-fresh guarantee via one coalesced worker recompute —
            // never a synchronous jank spike, never a post storm, never
            // acceptance of a stale endpoint.
            var stagedPoints = (totalLen - tailStart) * stagedSeries;
            if (stagedPoints > M19I_B62_MAX_STAGED_POINTS) {
                _m19iB62Stats(this).exactTailBudgetSkips++;
                this._m19iExactTailFailFp = fp;
                this._m19iExactTailFailRv = rv;
                _m19iB62EnsureFreshAsync(this, fp);
                return false;
            }
            var bridgedAll = _m19ifApplyCoherentBridge(
                this, indicatorMap, tailStart, mergeFrom, totalLen
            );
            if (bridgedAll) {
                _m19iB62Stats(this).exactTailPaints++;
                if (typeof this.bumpIndicatorRenderVersion === 'function') {
                    try { this.bumpIndicatorRenderVersion(); } catch (_) {}
                }
                // Publish AFTER the successful complete atomic commit only,
                // witnessed by the post-bump render version.
                this._m19iExactTailLastFp = fp;
                this._m19iExactTailLastRv = this._indicatorRenderVersion || 0;
                this._m19iExactTailFailFp = null;
                this._m19iExactTailFailRv = null;
                this._m19iB62PendingFreshFp = null;
                return true;
            }
            // Diagnostics AFTER the (internal) rollback; the memo never
            // blocks correctness because the fresh request below owns it.
            _m19iB62Stats(this).exactTailSkips++;
            this._m19iExactTailFailFp = fp;
            this._m19iExactTailFailRv = rv;
            _m19iB62EnsureFreshAsync(this, fp);
            return false;
        } finally {
            this._m19iExactTailPaintBusy = false;
        }
    };

    Chart.prototype.drawIndicatorsOptimized = function() {
        var b70RenderToken = _b70ShadowEnabled()
            ? _b70Stage3BeginRender(this, 'drawIndicatorsOptimized') : null;
        var b70RenderError = null;
        try {
        // B62-2: exact forming tail BEFORE the layer cache decision — covers
        // both the cached-blit path and the interaction fallback below.
        if (_b70ShadowEnabled()) {
            // A prior complete generation may remain in indicators.data/cache,
            // but it is never eligible for this frame. Ownership is requested
            // after the render transaction unwinds.
            if (!_b70Stage3ConsumePaint(this)) return;
        } else {
            try { this._m19iExactTailPaint(); } catch (_) { /* paint must not throw */ }
        }
        const interaction = typeof this._isInteractionFastRender === 'function' && this._isInteractionFastRender();
        const hasHiddenOverlay = typeof this._hasHiddenOverlayIndicator === 'function' && this._hasHiddenOverlayIndicator();
        if (interaction || hasHiddenOverlay || typeof this.drawIndicators !== 'function') {
            if (typeof this.drawIndicators === 'function') this.drawIndicators();
            return;
        }

        const layerSize = this._syncIndicatorLayerCanvasSize();
        const y0 = this.yDomain && this.yDomain[0];
        const y1 = this.yDomain && this.yDomain[1];
        const key = [
            this.dataVersion != null ? this.dataVersion : 0,
            this._indicatorRenderVersion || 0,
            typeof this._indicatorParamsHash === 'function' ? this._indicatorParamsHash() : '',
            typeof this._indicatorVisibilityKey === 'function' ? this._indicatorVisibilityKey() : '',
            String(this.currentTimeframe || ''),
            this.w, this.h, layerSize.dpr,
            this.candleWidth, this.offsetX, this.priceZoom, this.priceOffset,
            this.visibleStartIndex, this.visibleEndIndex,
            y0, y1
        ].join('|');

        const blitLayer = (destCtx) => {
            // Dest ctx is DPR-scaled (CSS space). Explicit dest size keeps a 1:1
            // device-pixel blit instead of stretching a 1× bitmap.
            const prevSmooth = destCtx.imageSmoothingEnabled;
            destCtx.imageSmoothingEnabled = false;
            destCtx.drawImage(
                this._indLayerCanvas,
                0, 0, layerSize.physW, layerSize.physH,
                0, 0, layerSize.cssW, layerSize.cssH
            );
            destCtx.imageSmoothingEnabled = prevSmooth;
        };

        if (this._indLayerCacheKey === key && this._indLayerCanvas) {
            blitLayer(this.ctx);
            return;
        }

        const layerCtx = this._indLayerCtx;
        // clearRect uses current transform (dpr); clear the CSS viewport.
        layerCtx.clearRect(0, 0, layerSize.cssW, layerSize.cssH);
        const prevCtx = this.ctx;
        this.ctx = layerCtx;
        try {
            this.drawIndicators();
        } finally {
            this.ctx = prevCtx;
        }
        blitLayer(prevCtx);
        this._indLayerCacheKey = key;
        } catch (b70CaughtRenderError) {
            b70RenderError = b70CaughtRenderError;
            throw b70CaughtRenderError;
        } finally {
            _b70Stage3EndRender(this, b70RenderToken, b70RenderError);
        }
    };

    /**
     * M19-I-f coherent-presentation bridge (kill switch
     * __TALARIA_DISABLE_M19I_FRAME_COHERENT_V1): compute one worker-eligible
     * indicator's tail on the MAIN thread over the same bounded slice the
     * worker receives. Reuses the exact per-type calculators the full sync
     * path uses (pure functions of the bar array), so shapes and values match
     * both the full pass and the worker's later authoritative commit.
     * Returns undefined for types without a verified slice-pure calculator.
     */
    function _m19ifBridgeTailResult(ind, slice) {
        var t = String(ind.type || '').toLowerCase();
        var p = ind.params || {};
        switch (t) {
            case 'sma': return calculateSMAIndicatorData(slice, p);
            case 'ema': return calculateEMAIndicatorData(slice, p);
            case 'wma': return calculateWMAOverlayData(slice, p);
            case 'bb':
            case 'bollinger': return calculateBollingerBands(slice, p);
            case 'envelope':
            case 'smaenvelope':
                return calculateEnvelope(slice, p.period, p.percent, p.source || 'close');
            case 'atr':
                return calculateATR(slice, atrPeriodFromParams(p), atrSmoothingTypeFromParams(p));
            case 'cci': return calculateCCIIndicatorData(slice, p);
            case 'adx': return calculateADX(slice, p.diLength, p.adxSmoothing);
            case 'rsi':
                // Divergence-enabled RSI is excluded from the tail-safe set
                // upstream; guard anyway (divergences need full-history enrich).
                if (p.divergenceEnabled) return undefined;
                return calculateRSIIndicatorData(slice, p);
            case 'macd':
            case 'ppo':
                return calculateMACD(slice, p.fast, p.slow, p.signal, p.source || 'close', {
                    oscillatorMaType: p.oscillatorMaType,
                    signalMaType: p.signalMaType
                });
            case 'stoch':
            case 'stochastic':
                return calculateStochastic(slice, p.period, p.smoothK, p.smoothD);
            case 'dema': return calculateDEMAOverlayData(slice, p);
            case 'tema': return calculateTEMAOverlayData(slice, p);
            case 'hma': return calculateHMAOverlayData(slice, p);
            case 'roc': return calculateROC(slice, p.period, p.source || 'close');
            case 'mom':
            case 'momentum': return calculateMomentum(slice, p.period, p.source || 'close');
            case 'willr': return calculateWilliamsR(slice, p.period, p.source || 'close');
            case 'mfi': return calculateMFI(slice, p.period);
            case 'donchian':
                return calculateDonchian(slice, p.period, p.offset != null ? p.offset : 0);
            case 'keltner': return calculateKeltner(slice, p);
            case 'aroon': return calculateAroon(slice, p.period);
            case 'cmf': return calculateCMF(slice, p.period);
            case 'trix': return calculateTRIX(slice, p.period);
            case 'stddev': return calculateStdDevLine(slice, p.period, p.source || 'close');
            case 'ao': return calculateAO(slice, p.fastLength, p.slowLength);
            default: return undefined;
        }
    }

    /**
     * M19-I-f: merge synchronous main-thread tail results for every indicator
     * in the worker map, using the same merge window the worker commit will
     * use. Returns true only when EVERY mapped indicator was bridged, so the
     * caller can mark the recalc snapshot complete for this bar count.
     * Counters in chart._m19ifStats expose uncovered/rejected series — these
     * are the (diagnosed, never hidden) fallback paths where presentation
     * temporarily behaves like b58 async catch-up for that series only.
     */
    function _m19ifApplyCoherentBridge(chart, indicatorMap, tailStart, fromIndex, totalLen) {
        var perf = _indicatorPerf();
        var merge = perf && typeof perf.mergeIndicatorTailWindow === 'function'
            ? perf.mergeIndicatorTailWindow
            : null;
        var statDelta = {
            bridgePasses: 0,
            bridgedSeries: 0,
            uncoveredSeries: 0,
            mergeRejects: 0,
            fullAsyncFallbacks: 0
        };
        function publishBridgeStats() {
            var stats = chart._m19ifStats || (chart._m19ifStats = {
                bridgePasses: 0,
                bridgedSeries: 0,
                uncoveredSeries: 0,
                mergeRejects: 0,
                fullAsyncFallbacks: 0
            });
            stats.bridgePasses += statDelta.bridgePasses;
            stats.bridgedSeries += statDelta.bridgedSeries;
            stats.uncoveredSeries += statDelta.uncoveredSeries;
            stats.mergeRejects += statDelta.mergeRejects;
            stats.fullAsyncFallbacks += statDelta.fullAsyncFallbacks;
        }
        statDelta.bridgePasses++;
        var slice = chart.data.slice(tailStart);
        var all = true;
        if (_m19iExactTailPaintEnabled()) {
            // B62 (mechanism correction): WHOLE-TRANSACTION atomicity. The
            // transaction is the complete indicator map — stage EVERY
            // candidate first (zero live mutation while staging), then commit
            // the whole set atomically. Any missing candidate (a mapped
            // family without a bridge case, e.g. massindex), throw, or merge
            // failure at any position means ZERO live mutation for the whole
            // transaction — mixed TEMA + massindex can no longer advance TEMA
            // while massindex stays old. _m19iB62AtomicMergeSet restores
            // every touched series if the commit itself fails part-way.
            // NOTE the caller owns CLASSIFICATION: the b62 paint hook only
            // submits strictly-sync family maps (exact-by-construction),
            // while the I-f coherent PASS keeps its accepted mixed coverage —
            // but its lastFp success memo is published only for all-sync maps.
            if (!merge) {
                statDelta.uncoveredSeries += Object.keys(indicatorMap).length;
                publishBridgeStats();
                return false;
            }
            var members = [];
            chart.indicators.active.forEach(function(ind) {
                if (!ind || !ind.id || !indicatorMap[ind.id]) return;
                members.push(ind);
            });
            if (!members.length) return true;
            var freshById = {};
            var stagedCount = 0;
            for (var m = 0; m < members.length; m++) {
                var fresh;
                try { fresh = _m19ifBridgeTailResult(members[m], slice); } catch (_) { fresh = undefined; }
                if (fresh == null) {
                    // Zero mutation happened yet — candidates are staged only.
                    statDelta.uncoveredSeries += members.length;
                    publishBridgeStats();
                    return false;
                }
                freshById[members[m].id] = fresh;
                stagedCount++;
            }
            if (_m19iB62AtomicMergeSet(chart, freshById, tailStart, fromIndex, totalLen)) {
                statDelta.bridgedSeries += stagedCount;
            } else {
                all = false;
                statDelta.mergeRejects += stagedCount;
                _m19iB62Stats(chart).atomicRollbacks++;
            }
            publishBridgeStats();
            return all;
        }
        // b61 legacy (kill switch): compute + merge per series in place; a
        // late failure leaves earlier series committed — preserved for A/B.
        var stats = chart._m19ifStats || (chart._m19ifStats = {
            bridgePasses: 0,
            bridgedSeries: 0,
            uncoveredSeries: 0,
            mergeRejects: 0,
            fullAsyncFallbacks: 0
        });
        stats.bridgePasses++;
        if (!merge) {
            stats.uncoveredSeries += Object.keys(indicatorMap).length;
            return false;
        }
        chart.indicators.active.forEach(function(ind) {
            if (!ind || !ind.id || !indicatorMap[ind.id]) return;
            var fresh;
            try { fresh = _m19ifBridgeTailResult(ind, slice); } catch (_) { fresh = undefined; }
            if (fresh == null) {
                all = false;
                stats.uncoveredSeries++;
                return;
            }
            var merged = null;
            try {
                merged = merge(chart.indicators.data[ind.id], fresh, tailStart, fromIndex, totalLen);
            } catch (_) { merged = null; }
            if (merged != null) {
                chart.indicators.data[ind.id] = merged;
                stats.bridgedSeries++;
            } else {
                all = false;
                stats.mergeRejects++;
            }
        });
        return all;
    }

    Chart.prototype.recalculateIndicatorsIncremental = function(fromBarCount) {
        if (!this.indicators || !this.indicators.active || !this.indicators.active.length) return;
        if (!Array.isArray(this.data) || !this.data.length) return;
        if (_b70ShadowEnabled() && _b70Stage3RejectInRenderWork(this)) return;
        if (_b70ShadowEnabled()) {
            // Stage 4 routes the generation through the common COW envelope
            // producer. It may split SYNC/WORKER ownership, but publication is
            // one complete requested-set pointer transaction.
            return this.recalculateIndicators();
        }
        if (!_m19iTailSendEnabled()) {
            if (typeof window !== 'undefined'
                && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true) {
                _b70ShadowRecordCalculation(this, 'recalculateIndicatorsIncremental', 'worker');
            }
            return this._recalculateIndicatorsIncrementalLegacy(fromBarCount);
        }

        const chart = this;
        const coherent = _m19ifFrameCoherentEnabled();
        // I-f OFF (b58 legacy): worker backpressure defers the WHOLE incremental
        // pass to a later frame. I-f ON: every synchronous step below (sync-only,
        // stateful, coherent bridge) still runs so presentation never depends on
        // worker round-trip time; only the worker post itself coalesces.
        const ownsWorkerPass = !chart._indicatorWorkerBusy;
        if (!ownsWorkerPass) {
            chart._indicatorWorkerCoalesce = true;
            if (!coherent) return;
        } else {
            chart._indicatorWorkerBusy = true;
            chart._indicatorWorkerCoalesce = false;
        }
        const b70OwnerOn = typeof window !== 'undefined'
            && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true;

        function finishIncrementalPass() {
            chart._indicatorWorkerBusy = false;
            var again = chart._indicatorWorkerCoalesce;
            var wantFull = chart._m19iCoalesceFullAsync === true;
            chart._indicatorWorkerCoalesce = false;
            chart._m19iCoalesceFullAsync = false;
            if (_m19iExactTailPaintEnabled()) {
                // B62-2: the pass this fresh-request rode on has concluded
                // (applied, failed, or superseded). Retire the pending memo so
                // a later draw can re-request — bounded retry, never a freeze.
                chart._m19iB62PendingFreshFp = null;
            }
            if (wantFull) {
                if (typeof chart.recalculateIndicatorsAsync === 'function') {
                    try { chart.recalculateIndicatorsAsync(); } catch (_) {}
                } else if (typeof chart.recalculateIndicators === 'function') {
                    try { chart.recalculateIndicators(); } catch (_) {}
                }
            } else if (again && typeof chart._runIndicatorRecalc === 'function') {
                // A coalesced request re-routes through the scheduler so replay
                // play / paused / live paths each take their correct pipeline.
                try { chart._runIndicatorRecalc({ force: false }); } catch (_) {}
            }
        }

        // Drop stale continuation state for removed indicators (id-keyed).
        if (chart._m19iIndState) {
            var activeIds = {};
            chart.indicators.active.forEach(function(ind) { if (ind && ind.id) activeIds[String(ind.id)] = true; });
            Object.keys(chart._m19iIndState).forEach(function(key) {
                var sep = key.indexOf(':');
                if (sep >= 0 && !activeIds[key.slice(sep + 1)]) delete chart._m19iIndState[key];
            });
        }

        const perf = _indicatorPerf();
        const totalLen = chart.data.length;
        const lookback = perf && typeof perf.estimateTailLookback === 'function'
            ? perf.estimateTailLookback(this.indicators.active)
            : 256;
        // Refresh margin: the previously-forming bar finalizes on advance, so
        // merge from two bars before the old count; warmup extends behind it.
        const safeFromBarCount = _m19iB62SafeNonnegativeInteger(fromBarCount);
        const mergeFrom = Math.max(0, Math.min(safeFromBarCount == null ? totalLen : safeFromBarCount, totalLen) - 2);
        const tailStart = Math.max(0, mergeFrom - lookback);
        const worker = _getIndicatorWorker();

        if (chart._indicatorWorkerSeq == null) chart._indicatorWorkerSeq = 0;
        // Backpressured coherent passes must NOT bump the sequence: doing so
        // would invalidate the in-flight worker commit every tick and starve
        // the authoritative worker pipeline under continuous high-speed play.
        const mySeq = ownsWorkerPass
            ? ++chart._indicatorWorkerSeq
            : chart._indicatorWorkerSeq;

        // 1) Sync-only structural overlays (I-b bounds the covered types via
        //    checkpoint/patch caches inside their calculators).
        var needsSyncOnly = chart.indicators.active.some(function(ind) {
            return M19I_SYNC_ONLY_TYPES.indexOf(String(ind.type || '').toLowerCase()) >= 0;
        });
        if (needsSyncOnly) {
            try {
                chart._recalcOnlyTypes = M19I_SYNC_ONLY_TYPES;
                chart.recalculateIndicators();
            } catch (_) {}
            chart._recalcOnlyTypes = null;
        }

        // 2) I-c stateful main-thread continuations + trivial types. In the
        //    legacy path supertrend/adr silently went stale on append passes.
        var uncovered = [];
        var didStateful = false;
        chart.indicators.active.forEach(function(ind) {
            var t = String(ind.type || '').toLowerCase();
            if (M19I_SYNC_ONLY_TYPES.indexOf(t) >= 0) return;
            if (t === 'volume') {
                chart.indicators.data[ind.id] = { active: true };
                return;
            }
            if (t === 'custom') {
                if (typeof chart._scheduleCustomIndicatorCompute === 'function') {
                    try { chart._scheduleCustomIndicatorCompute(ind); } catch (_) {}
                }
                return;
            }
            if (_m19iWorkerPortEnabled()) {
                if (t === 'supertrend') {
                    try { recalcSupertrendOverlay(chart, ind); didStateful = true; } catch (_) {}
                    return;
                }
                if (t === 'adr') {
                    try { recalcAdrIndicator(chart, ind); didStateful = true; } catch (_) {}
                    return;
                }
            }
        });

        // 3) Worker-eligible tail map.
        const indicators = {};
        const b70SyncBridgeIndicators = {};
        const b70SyncBridgeCandidates = [];
        const b70WorkerCandidates = [];
        var needsFullAsync = false;
        const skipTypes = _m19iWorkerSkipTypes();
        chart.indicators.active.forEach(function(ind) {
            const indType = String(ind.type || '').toLowerCase();
            if (indType === 'volume' || indType === 'custom') return;
            if (skipTypes.indexOf(indType) >= 0) {
                if (M19I_SYNC_ONLY_TYPES.indexOf(indType) < 0
                    && indType !== 'supertrend' && indType !== 'adr') {
                    uncovered.push(indType);
                }
                return;
            }
            if (!_m19iIndicatorTailSafe(ind)) {
                // Cumulative/whole-history types must take a full worker pass.
                needsFullAsync = true;
                if (b70OwnerOn) b70WorkerCandidates.push(ind);
                return;
            }
            if (_m19iExactTailPaintEnabled()
                && chart._m19iB62PendingFreshFp != null
                && !_m19iB62SyncFamily(ind)) {
                // A B62 paint-time fallback requested exact freshness for this
                // identity. Keep the accepted I-f tail bridge/post path active,
                // but also force the follow-up full async pass that owns exact
                // endpoint publication for recursive/shape-incompatible rows.
                needsFullAsync = true;
            }
            if (indType === 'dema' || indType === 'tema' || indType === 'hma') {
                // Worker returns the series; keep overlay metadata current.
                ind.overlay = true;
                ind.separatePanel = false;
                var mp = ind.params && ind.params.period != null ? Math.max(1, Number(ind.params.period) | 0) : 20;
                ind.name = indType.toUpperCase() + '(' + mp + ')';
            }
            if (b70OwnerOn && _b70Stage2InstanceOwner(ind) === 'sync') {
                b70SyncBridgeIndicators[ind.id] = { type: indType, params: ind.params || {} };
                b70SyncBridgeCandidates.push(ind);
            } else {
                indicators[ind.id] = { type: indType, params: ind.params || {} };
                if (b70OwnerOn) b70WorkerCandidates.push(ind);
            }
        });

        var b70SyncTickets = b70OwnerOn
            ? _b70Stage2Claim(
                chart, 'sync', b70SyncBridgeCandidates,
                'recalculateIndicatorsIncremental:bridge', false
            ) : null;
        if (b70OwnerOn) {
            var b70SyncIds = _b70Stage2TicketIds(b70SyncTickets);
            Object.keys(b70SyncBridgeIndicators).forEach(function(id) {
                if (!b70SyncIds[String(id)]) delete b70SyncBridgeIndicators[id];
            });
        }

        // Legacy worker-skip types (I-c OFF) stay stale on this pass exactly
        // like b57; a later full recalc refreshes them.
        var coverageComplete = uncovered.length === 0 && !needsFullAsync;
        if (needsFullAsync) chart._m19iCoalesceFullAsync = true;

        // I-f: synchronously commit bounded main-thread tail results for the
        // worker-eligible series BEFORE any paint can observe the new bars.
        // The worker pass below still runs (compute gate / authoritative
        // convergence); its later commit merges the identical window, so it is
        // idempotent. Bridge-uncovered series are counted, never hidden.
        if (coherent) {
            function publishFullAsyncFallback() {
                if (!needsFullAsync) return;
                var ifStats = chart._m19ifStats || (chart._m19ifStats = {
                    bridgePasses: 0,
                    bridgedSeries: 0,
                    uncoveredSeries: 0,
                    mergeRejects: 0,
                    fullAsyncFallbacks: 0
                });
                ifStats.fullAsyncFallbacks++;
            }
            var coherentMap = b70OwnerOn ? b70SyncBridgeIndicators : indicators;
            if (Object.keys(coherentMap).length > 0) {
                if (b70OwnerOn) {
                    _b70ShadowRecordCalculation(
                        chart, 'recalculateIndicatorsIncremental:bridge', 'sync'
                    );
                }
                var b70BridgeEnvelopeTx = b70SyncTickets
                    ? _b70Stage4BeginBuild(chart, b70SyncTickets) : null;
                var b70BridgeTarget = b70BridgeEnvelopeTx
                    ? _b70Stage4BuildFacade(chart, b70BridgeEnvelopeTx) : chart;
                var bridgedAll = !b70SyncTickets || b70BridgeEnvelopeTx
                    ? _m19ifApplyCoherentBridge(
                        b70BridgeTarget, coherentMap, tailStart, mergeFrom, totalLen
                    ) : false;
                if (b70SyncTickets) {
                    var b70BridgePublished = bridgedAll
                        && _b70Stage4CommitBuild(chart, b70BridgeEnvelopeTx);
                    var b70BridgePartial = !b70BridgePublished
                        && b70BridgeEnvelopeTx
                        && b70BridgeEnvelopeTx.partial;
                    if (!bridgedAll && b70BridgeEnvelopeTx) {
                        _b70Stage4AbortBuild(chart, b70BridgeEnvelopeTx);
                    }
                    if (b70BridgePublished || b70BridgePartial) {
                        _b70Stage2Commit(chart, b70SyncTickets);
                        if (b70BridgePublished) chart.bumpIndicatorRenderVersion();
                    } else {
                        _b70Stage2ReleaseSyncFailure(chart, b70SyncTickets);
                    }
                }
                publishFullAsyncFallback();
                if (bridgedAll && coverageComplete
                    && typeof chart._markIndicatorRecalcComplete === 'function') {
                    try { chart._markIndicatorRecalcComplete(); } catch (_) {}
                }
                // B62-2: this tick's forming tip is committed — the paint-time
                // hook must not re-bridge the same fingerprint (no double
                // bounded work per forming change at high speed). bridgedAll
                // is true only after a COMPLETE atomic commit (b62 path), and
                // the memo is published ONLY when every transaction member is
                // a strictly-sync (exact) family: a coherent pass that
                // bridged a recursive family within I-f tolerance must NOT
                // claim the exact-endpoint memo — the worker's authoritative
                // merge (or the paint hook) owns that publish.
                if (bridgedAll && _m19iExactTailPaintEnabled()
                    && typeof chart._m19iExactTailPaintFp === 'function') {
                    var allSyncExact = chart.indicators.active.every(function(ind) {
                        if (!ind || !ind.id || !coherentMap[ind.id]) return true;
                        return !!_m19iB62SyncFamily(ind);
                    });
                    if (allSyncExact) {
                        try {
                            chart._m19iExactTailLastFp = chart._m19iExactTailPaintFp();
                            chart._m19iExactTailLastRv = chart._indicatorRenderVersion || 0;
                            chart._m19iExactTailFailFp = null;
                            chart._m19iExactTailFailRv = null;
                            chart._m19iB62PendingFreshFp = null;
                        } catch (_) {}
                    }
                }
            } else {
                publishFullAsyncFallback();
            }
        }

        if (Object.keys(indicators).length === 0) {
            if (ownsWorkerPass) finishIncrementalPass();
            if (!needsSyncOnly && !didStateful && !needsFullAsync) {
                try { chart.recalculateIndicators(); } catch (_) {}
            } else if (coverageComplete
                && typeof chart._markIndicatorRecalcComplete === 'function') {
                try { chart._markIndicatorRecalcComplete(); } catch (_) {}
            }
            if (typeof chart.bumpIndicatorRenderVersion === 'function') {
                try { chart.bumpIndicatorRenderVersion(); } catch (_) {}
            }
            if (typeof chart.scheduleRender === 'function') chart.scheduleRender();
            return;
        }

        if (!worker) {
            if (ownsWorkerPass) finishIncrementalPass();
            if (b70OwnerOn && b70WorkerCandidates.length) {
                var missingWorkerTickets = _b70Stage2Claim(
                    chart, 'worker', b70WorkerCandidates,
                    'recalculateIndicatorsIncremental:no-worker', false
                );
                var missingWorkerFallback = _b70Stage2ReleaseWorkerFailure(
                    chart, missingWorkerTickets
                );
                if (missingWorkerFallback.length) {
                    chart._b70Stage2FallbackIndicators = missingWorkerFallback;
                    try { chart.recalculateIndicators(); } catch (_) {}
                }
            } else {
                try { chart.recalculateIndicators(); } catch (_) {}
            }
            return;
        }

        if (!ownsWorkerPass) {
            // Coherent backpressure: this bar's series are already bridged and
            // committed above. The in-flight pass's finish hook reruns the
            // scheduler via the coalesce flag, so the worker catches up without
            // this pass invalidating or duplicating it.
            return;
        }

        var b70WorkerTickets = b70OwnerOn
            ? _b70Stage2Claim(
                chart, 'worker', b70WorkerCandidates,
                'recalculateIndicatorsIncremental:worker', false
            ) : null;
        if (b70OwnerOn) {
            var b70WorkerIds = _b70Stage2TicketIds(b70WorkerTickets);
            Object.keys(indicators).forEach(function(id) {
                if (!b70WorkerIds[String(id)]) delete indicators[id];
            });
            if (!b70WorkerTickets.length || Object.keys(indicators).length === 0) {
                finishIncrementalPass();
                return;
            }
            _b70ShadowRecordCalculation(
                chart, 'recalculateIndicatorsIncremental:worker', 'worker'
            );
        }

        // 4) O(tail) pack of bars[tailStart..n) — ownership moves to the worker
        //    via the transfer list, so nothing is cloned.
        const packed = perf && typeof perf.packBarsRangeCompact === 'function'
            ? perf.packBarsRangeCompact(chart.data, tailStart, totalLen)
            : null;
        const id = _workerNextId++;
        // B62-1 (kill-exact: only computed while enabled): observe the data
        // array reference first (a swap mints a new monotonic generation),
        // then capture the COMPLETE identity/generation token at POST time —
        // length + last-bar t/o/h/l/c/v, a bounded window content hash over
        // exactly the bars the worker will compute from, dataVersion, TF,
        // paramsHash and the dataset generation. Length+TF alone cannot see
        // a tick-mode in-place mutation of the last bar, a same-shape
        // pair/dataset swap, an in-window middle/volume edit, or an
        // indicator add/remove/param change racing the reply.
        if (_m19iExactTailPaintEnabled()) _m19iB62ObserveData(chart);
        const tailMeta = {
            tailStart: tailStart,
            fromIndex: mergeFrom,
            totalLength: totalLen,
            markComplete: coverageComplete,
            timeframe: String(chart.currentTimeframe || ''),
            b62Token: _m19iExactTailPaintEnabled()
                ? _m19iB62TailToken(chart, tailStart, totalLen)
                : null
        };

        new Promise(function(resolve, reject) {
            _workerPending.set(id, { resolve: resolve, reject: reject });
            const message = {
                type: 'CALCULATE_TAIL',
                id: id,
                payload: {
                    barsPacked: packed,
                    bars: packed ? null : chart.data.slice(tailStart),
                    tailStart: tailStart,
                    fromIndex: mergeFrom,
                    lookback: lookback,
                    totalLength: totalLen,
                    indicators: indicators
                }
            };
            if (packed && packed.buffer) {
                worker.postMessage(message, [packed.buffer]);
            } else {
                worker.postMessage(message);
            }
        }).then(function(results) {
            if (chart._indicatorWorkerSeq !== mySeq) {
                finishIncrementalPass();
                return;
            }
            if (b70WorkerTickets
                && !_b70Stage2AuthorizeWorkerApply(chart, b70WorkerTickets, results)) {
                finishIncrementalPass();
                return;
            }
            var b70TailEnvelopeTx = b70WorkerTickets
                ? _b70Stage4BeginBuild(chart, b70WorkerTickets) : null;
            if (b70WorkerTickets && !b70TailEnvelopeTx) {
                finishIncrementalPass();
                return;
            }
            if (typeof chart._applyIndicatorWorkerResults === 'function') {
                var b70TailApplied = b70TailEnvelopeTx
                    ? _b70Stage4ApplyWorkerResults(
                        chart, b70TailEnvelopeTx, results, mySeq, null, tailMeta
                    )
                    : chart._applyIndicatorWorkerResults(results, mySeq, null, tailMeta);
            }
            if (b70WorkerTickets) {
                var b70TailPublished = b70TailApplied !== false
                    && _b70Stage4CommitBuild(chart, b70TailEnvelopeTx);
                var b70TailPartial = !b70TailPublished
                    && b70TailEnvelopeTx
                    && b70TailEnvelopeTx.partial;
                if (b70TailApplied === false && b70TailEnvelopeTx) {
                    _b70Stage4AbortBuild(chart, b70TailEnvelopeTx);
                }
                if ((b70TailPublished || b70TailPartial)
                    && _b70Stage2Commit(chart, b70WorkerTickets)
                    && b70TailPublished) {
                    chart.bumpIndicatorRenderVersion();
                }
                if (b70TailPublished && typeof chart.scheduleRender === 'function') {
                    chart._b70IndicatorGenerationShadow.metrics.workerCommitRenderSchedules++;
                    chart.scheduleRender();
                }
            }
            finishIncrementalPass();
        }).catch(function() {
            if (chart._indicatorWorkerSeq !== mySeq) {
                finishIncrementalPass();
                return;
            }
            try { chart.recalculateIndicatorsAsync(); } catch (_) {
                try { chart.recalculateIndicators(); } catch (_2) {}
            }
            finishIncrementalPass();
        });
    };

    /**
     * b57 legacy incremental path, preserved verbatim for the I-a kill switch
     * (__TALARIA_DISABLE_M19I_TAIL_SEND_V1): O(history) full-array pack posted
     * with an EMPTY transfer list (structured clone per pass).
     */
    Chart.prototype._recalculateIndicatorsIncrementalLegacy = function(fromBarCount) {
        if (!this.indicators || !this.indicators.active || !this.indicators.active.length) return;
        if (!Array.isArray(this.data) || !this.data.length) return;

        const chart = this;
        if (chart._indicatorWorkerBusy) {
            chart._indicatorWorkerCoalesce = true;
            return;
        }
        chart._indicatorWorkerBusy = true;
        chart._indicatorWorkerCoalesce = false;

        function finishIncrementalPass() {
            chart._indicatorWorkerBusy = false;
            var again = chart._indicatorWorkerCoalesce;
            chart._indicatorWorkerCoalesce = false;
            if (again) {
                if (typeof chart.recalculateIndicatorsAsync === 'function') {
                    try { chart.recalculateIndicatorsAsync(); } catch (_) {}
                } else if (typeof chart.recalculateIndicators === 'function') {
                    try { chart.recalculateIndicators(); } catch (_) {}
                }
            }
        }

        const perf = _indicatorPerf();
        const lookback = perf && typeof perf.estimateTailLookback === 'function'
            ? perf.estimateTailLookback(this.indicators.active)
            : 256;
        const legacyFromBarCount = Number(fromBarCount);
        const legacySafeFromBarCount = Number.isFinite(legacyFromBarCount) && legacyFromBarCount >= 0
            ? Math.floor(legacyFromBarCount)
            : 0;
        const fromIndex = Math.max(0, legacySafeFromBarCount - lookback);
        const worker = _getIndicatorWorker();

        if (!worker) {
            finishIncrementalPass();
            try { chart.recalculateIndicators(); } catch (_) {}
            return;
        }

        if (chart._indicatorWorkerSeq == null) chart._indicatorWorkerSeq = 0;
        const mySeq = ++chart._indicatorWorkerSeq;

        // Keep main-thread sync-only overlays (Talaria FVG / Ratio+Gap / sessions)
        // fresh on append. Without this, incremental worker updates SMA/etc. and
        // leaves FVG stale until a forced full recalc (refresh / TF change).
        var syncOnlyTypes = [
            'cotnet', 'sessions', 'killzones', 'ictkz', 'sessionsplus', 'openingrange', 'or',
            'ictpd', 'ictasian', 'ictote', 'ictfvg', 'ictsesspd', 'icteverything',
            'talariafvg', 'talariaratiogap', 'talariaweeklymap', 'talariasmc'
        ];
        var needsSyncOnly = chart.indicators.active.some(function(ind) {
            return syncOnlyTypes.indexOf(String(ind.type || '').toLowerCase()) >= 0;
        });
        if (needsSyncOnly) {
            try {
                chart._recalcOnlyTypes = syncOnlyTypes;
                chart.recalculateIndicators();
            } catch (_) {}
            chart._recalcOnlyTypes = null;
        }

        const indicators = {};
        chart.indicators.active.forEach(function(ind) {
            const workerSkip = [
                'dema', 'tema', 'hma', 'supertrend', 'adr',
                'cotnet', 'sessions', 'killzones', 'ictkz', 'sessionsplus', 'openingrange', 'or',
                'ictpd', 'ictasian', 'ictote', 'ictfvg', 'ictsesspd', 'icteverything',
                'talariafvg', 'talariaratiogap', 'talariaweeklymap', 'talariasmc', 'volume', 'custom'
            ];
            const indType = String(ind.type || '').toLowerCase();
            if (workerSkip.indexOf(indType) >= 0) return;
            indicators[ind.id] = { type: indType, params: ind.params || {} };
        });

        if (Object.keys(indicators).length === 0) {
            finishIncrementalPass();
            // Sync-only types already recalculated above; still run full sync when
            // nothing was synced (e.g. volume/custom-only) or sync pass was skipped.
            if (!needsSyncOnly) {
                try { chart.recalculateIndicators(); } catch (_) {}
            } else if (typeof chart._markIndicatorRecalcComplete === 'function') {
                try { chart._markIndicatorRecalcComplete(); } catch (_) {}
            }
            if (typeof chart.bumpIndicatorRenderVersion === 'function') {
                try { chart.bumpIndicatorRenderVersion(); } catch (_) {}
            }
            if (typeof chart.scheduleRender === 'function') chart.scheduleRender();
            return;
        }

        const packed = perf && typeof perf.packBarsCompact === 'function'
            ? perf.packBarsCompact(chart.data)
            : null;
        const id = _workerNextId++;

        new Promise(function(resolve, reject) {
            _workerPending.set(id, { resolve: resolve, reject: reject });
            worker.postMessage({
                type: 'CALCULATE_TAIL',
                id: id,
                payload: {
                    barsPacked: packed,
                    bars: packed ? null : chart.data,
                    fromIndex: fromIndex,
                    lookback: lookback,
                    indicators: indicators
                }
            }, []);
        }).then(function(results) {
            if (chart._indicatorWorkerSeq !== mySeq) {
                finishIncrementalPass();
                return;
            }
            const merge = perf && typeof perf.mergeIndicatorTail === 'function'
                ? perf.mergeIndicatorTail
                : null;
            if (merge) {
                Object.keys(results).forEach(function(indId) {
                    chart.indicators.data[indId] = merge(
                        chart.indicators.data[indId],
                        results[indId],
                        fromIndex
                    );
                });
            } else {
                Object.assign(chart.indicators.data, results);
            }
            if (typeof chart._markIndicatorRecalcComplete === 'function') {
                chart._markIndicatorRecalcComplete();
            }
            if (typeof chart._clearIndicatorCalculatingFlags === 'function') {
                chart._clearIndicatorCalculatingFlags();
            }
            chart.bumpIndicatorRenderVersion();
            if (typeof chart.scheduleRender === 'function') chart.scheduleRender();
            finishIncrementalPass();
        }).catch(function() {
            if (chart._indicatorWorkerSeq !== mySeq) {
                finishIncrementalPass();
                return;
            }
            if (b70WorkerTickets) {
                var fallback = _b70Stage2ReleaseWorkerFailure(chart, b70WorkerTickets);
                if (fallback.length) {
                    chart._b70Stage2FallbackIndicators = fallback;
                    try { chart.recalculateIndicators(); } catch (_) {}
                }
            } else {
                try { chart.recalculateIndicatorsAsync(); } catch (_) {
                    try { chart.recalculateIndicators(); } catch (_2) {}
                }
            }
            finishIncrementalPass();
        });
    };

    /** Run recalculation for a single indicator synchronously (used for worker-skipped types). */
    Chart.prototype._syncRecalcSingle = function(indicator) {
        // Minimal inline dispatch for complex indicator types that require DOM context
        // or large state not worth serialising. Returns the result or undefined.
        try {
            if (!this.indicators || !this.indicators.data) this.indicators = this.indicators || {};
            switch (indicator.type) {
                case 'cotnet':
                    if (typeof this._scheduleCotNetLoad === 'function') this._scheduleCotNetLoad(indicator);
                    return { loading: true, error: null };
                default: return undefined; // fall through to full recalculateIndicators
            }
        } catch (_) { return undefined; }
    };

    Chart.prototype.recalculateIndicators = function() {
        if (!this.indicators || !this.indicators.active || this.indicators.active.length === 0) {
            return;
        }
        var b70PrivateBuild = this._b70PrivateEnvelopeBuild === true;
        if (!b70PrivateBuild
            && _b70ShadowEnabled() && _b70Stage5DeferPanelCalculation(this)) return;
        if (!b70PrivateBuild
            && _b70ShadowEnabled() && _b70Stage3RejectInRenderWork(this)) return;
        var onlyTypes = this._recalcOnlyTypes;
        var skipTypes = this._recalcSkipTypes;
        var b70Tickets = null;
        var b70AllowedIds = b70PrivateBuild ? this._b70PrivateAllowedIds : null;
        var b70DeferredWorker = false;
        if (!b70PrivateBuild && typeof window !== 'undefined'
            && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true) {
            var b70Fallback = this._b70Stage2FallbackIndicators;
            var b70Candidates = Array.isArray(b70Fallback)
                ? b70Fallback
                : this.indicators.active.filter(function(indicator) {
                    var type = String(indicator && indicator.type || '').toLowerCase();
                    if (skipTypes && skipTypes.indexOf(type) >= 0) return false;
                    if (onlyTypes && onlyTypes.indexOf(type) < 0) return false;
                    return true;
                });
            b70Tickets = _b70Stage2Claim(
                this, 'sync', b70Candidates,
                Array.isArray(b70Fallback) ? 'worker-fallback' : 'recalculateIndicators',
                Array.isArray(b70Fallback)
            );
            this._b70Stage2FallbackIndicators = null;
            b70DeferredWorker = !Array.isArray(b70Fallback)
                && b70Candidates.some(function(indicator) {
                    return _b70Stage2InstanceOwner(indicator) === 'worker';
                });
            if (!b70Tickets.length) {
                if (b70DeferredWorker && !this._indicatorWorkerBusy
                    && typeof this.recalculateIndicatorsAsync === 'function') {
                    this.recalculateIndicatorsAsync();
                }
                return;
            }
            b70AllowedIds = _b70Stage2TicketIds(b70Tickets);
        }
        if (!b70PrivateBuild && typeof window !== 'undefined'
            && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true) {
            _b70ShadowRecordCalculation(this, 'recalculateIndicators', 'sync');
        }
        if (!this.indicators.data || typeof this.indicators.data !== 'object') {
            this.indicators.data = {};
        }
        var b70EnvelopeTx = b70Tickets
            ? _b70Stage4BeginBuild(this, b70Tickets) : null;
        if (b70Tickets && !b70EnvelopeTx) {
            _b70Stage2ReleaseSyncFailure(this, b70Tickets);
            return;
        }
        if (b70EnvelopeTx) {
            var b70Facade = Object.create(this);
            b70Facade._b70PrivateEnvelopeBuild = true;
            b70Facade._b70PrivateAllowedIds = b70AllowedIds;
            b70Facade._recalcOnlyTypes = onlyTypes;
            b70Facade._recalcSkipTypes = skipTypes;
            b70Facade.indicators = {
                active: this.indicators.active,
                data: b70EnvelopeTx.stagingData
            };
            try {
                Chart.prototype.recalculateIndicators.call(b70Facade);
            } catch (b70FacadeError) {
                _b70Stage4AbortBuild(this, b70EnvelopeTx);
                _b70Stage2ReleaseSyncFailure(this, b70Tickets);
                throw b70FacadeError;
            }
            var b70FacadePublished = _b70Stage4CommitBuild(this, b70EnvelopeTx);
            if (b70FacadePublished || b70EnvelopeTx.partial) {
                _b70Stage2Commit(this, b70Tickets);
            } else {
                _b70Stage2ReleaseSyncFailure(this, b70Tickets);
                throw new Error('b70 indicator envelope validation failed');
            }
            if (b70FacadePublished
                && typeof this.bumpIndicatorRenderVersion === 'function') {
                this.bumpIndicatorRenderVersion();
            }
            if (b70FacadePublished
                && typeof this.updateOHLCIndicators === 'function') {
                this.updateOHLCIndicators();
            }
            if (b70DeferredWorker && !this._indicatorWorkerBusy
                && typeof this.recalculateIndicatorsAsync === 'function') {
                this.recalculateIndicatorsAsync();
            }
            return;
        }

        const replayPlaying = !!(this.replaySystem && this.replaySystem.isActive && this.replaySystem.isPlaying);
        if (!replayPlaying && typeof this._setAllIndicatorsCalculating === 'function') {
            this._setAllIndicatorsCalculating(true);
        }

        var b70SyncError = null;
        var b70PriorResults = b70Tickets
            ? _b70Stage2SnapshotResults(this, b70Tickets) : null;
        try {
        this.indicators.active.forEach(function(indicator) {
            indicator.type = String(indicator.type || '').toLowerCase();
            if (b70AllowedIds && !b70AllowedIds[String(indicator.id)]) return;
            if (skipTypes && skipTypes.indexOf(indicator.type) >= 0) return;
            if (onlyTypes && onlyTypes.indexOf(indicator.type) < 0) return;
            switch (indicator.type) {
                case 'sma':
                    this.indicators.data[indicator.id] = calculateSMAIndicatorData(this.data, indicator.params);
                    break;
                case 'ema':
                    this.indicators.data[indicator.id] = calculateEMAIndicatorData(this.data, indicator.params);
                    break;
                case 'wma':
                    this.indicators.data[indicator.id] = calculateWMAOverlayData(this.data, indicator.params);
                    break;
                case 'bb':
                case 'bollinger':
                    this.indicators.data[indicator.id] = calculateBollingerBands(this.data, indicator.params);
                    break;
                case 'envelope':
                case 'smaenvelope':
                    this.indicators.data[indicator.id] = calculateEnvelope(this.data, indicator.params.period, indicator.params.percent, indicator.params.source || 'close');
                    break;
                case 'vwap':
                    this.indicators.data[indicator.id] = calculateVWAPIndicatorData(this.data, indicator.params);
                    break;
                case 'atr':
                    indicator.params.period = atrPeriodFromParams(indicator.params);
                    indicator.params.smoothingType = atrSmoothingTypeFromParams(indicator.params);
                    this.indicators.data[indicator.id] = calculateATR(
                        this.data,
                        indicator.params.period,
                        indicator.params.smoothingType
                    );
                    break;
                case 'cci':
                    this.indicators.data[indicator.id] = calculateCCIIndicatorData(this.data, indicator.params);
                    break;
                case 'adx':
                    indicator.name = 'ADX(' + indicator.params.diLength + ',' + indicator.params.adxSmoothing + ')';
                    this.indicators.data[indicator.id] = calculateADX(this.data, indicator.params.diLength, indicator.params.adxSmoothing);
                    break;
                case 'rsi':
                    this.indicators.data[indicator.id] = calculateRSIIndicatorData(this.data, indicator.params);
                    break;
                case 'macd':
                case 'ppo':
                    indicator.type = 'macd';
                    this.indicators.data[indicator.id] = calculateMACD(
                        this.data,
                        indicator.params.fast,
                        indicator.params.slow,
                        indicator.params.signal,
                        indicator.params.source || 'close',
                        {
                            oscillatorMaType: indicator.params.oscillatorMaType,
                            signalMaType: indicator.params.signalMaType
                        }
                    );
                    break;
                case 'stoch':
                case 'stochastic':
                    this.indicators.data[indicator.id] = calculateStochastic(this.data, indicator.params.period, indicator.params.smoothK, indicator.params.smoothD);
                    break;
                case 'adr':
                    indicator.params.period = Math.max(1, parseInt(indicator.params.period, 10) || 14);
                    indicator.name = 'ADR(' + indicator.params.period + ')';
                    this.indicators.data[indicator.id] = _m19iWorkerPortEnabled()
                        ? _m19iAdrIncremental(this, indicator)
                        : calculateADR(this.data, indicator.params.period);
                    break;
                case 'volume':
                    // Volume data comes from candle data, no recalculation needed
                    this.indicators.data[indicator.id] = { active: true };
                    break;
                case 'sessions':
                    this.indicators.data[indicator.id] = _m19iSessionsCalc(this, indicator);
                    break;
                case 'killzones':
                case 'ictkz':
                    this.indicators.data[indicator.id] = calculateKillzones(this.data, {
                        showCBDR: indicator.params.showCBDR,
                        showAsia: indicator.params.showAsia,
                        showLondon: indicator.params.showLondon,
                        showNYAM: indicator.params.showNYAM,
                        showLC: indicator.params.showLC,
                        showNYMidnight: indicator.params.showNYMidnight,
                        showMidline: indicator.params.showMidline,
                        showBoxInfo: indicator.params.showBoxInfo,
                        showDeviations: indicator.params.showDeviations,
                        deviationCount: indicator.params.deviationCount,
                        boxTransparency: indicator.params.boxTransparency,
                        cbdrStart: indicator.params.cbdrStart,
                        cbdrEnd: indicator.params.cbdrEnd,
                        asiaStart: indicator.params.asiaStart,
                        asiaEnd: indicator.params.asiaEnd,
                        londonStart: indicator.params.londonStart,
                        londonEnd: indicator.params.londonEnd,
                        nyamStart: indicator.params.nyamStart,
                        nyamEnd: indicator.params.nyamEnd,
                        lcStart: indicator.params.lcStart,
                        lcEnd: indicator.params.lcEnd,
                        cbdrColor: indicator.style.cbdrColor,
                        asiaColor: indicator.style.asiaColor,
                        londonColor: indicator.style.londonColor,
                        nyamColor: indicator.style.nyamColor,
                        lcColor: indicator.style.lcColor,
                        nyMidnightColor: indicator.style.nyMidnightColor
                    });
                    break;
                case 'dema':
                case 'tema':
                case 'hma':
                    recalcMultiPassOverlayMa(this, indicator);
                    break;
                case 'roc':
                    this.indicators.data[indicator.id] = calculateROC(this.data, indicator.params.period, indicator.params.source || 'close');
                    break;
                case 'mom':
                case 'momentum':
                    this.indicators.data[indicator.id] = calculateMomentum(this.data, indicator.params.period, indicator.params.source || 'close');
                    break;
                case 'obv':
                    this.indicators.data[indicator.id] = calculateOBVIndicatorData(this.data, indicator.params);
                    break;
                case 'willr':
                    this.indicators.data[indicator.id] = calculateWilliamsR(this.data, indicator.params.period, indicator.params.source || 'close');
                    break;
                case 'mfi':
                    this.indicators.data[indicator.id] = calculateMFI(this.data, indicator.params.period);
                    break;
                case 'donchian':
                    this.indicators.data[indicator.id] = calculateDonchian(
                        this.data,
                        indicator.params.period,
                        indicator.params.offset != null ? indicator.params.offset : 0
                    );
                    break;
                case 'keltner':
                    applyKeltnerCalcParams(indicator, indicator.params);
                    this.indicators.data[indicator.id] = calculateKeltner(this.data, indicator.params);
                    break;
                case 'aroon':
                    this.indicators.data[indicator.id] = calculateAroon(this.data, indicator.params.period);
                    break;
                case 'cmf':
                    this.indicators.data[indicator.id] = calculateCMF(this.data, indicator.params.period);
                    break;
                case 'trix':
                    this.indicators.data[indicator.id] = calculateTRIX(this.data, indicator.params.period);
                    break;
                case 'psar':
                    this.indicators.data[indicator.id] = calculatePSAR(this.data, indicator.params);
                    break;
                case 'sessionsplus':
                    this.indicators.data[indicator.id] = calculateSessionsPlus(this.data, {
                        showSydney: indicator.params.showSydney,
                        showTokyo: indicator.params.showTokyo,
                        showAsian: indicator.params.showAsian,
                        showFrankfurt: indicator.params.showFrankfurt,
                        showLondon: indicator.params.showLondon,
                        showNewYork: indicator.params.showNewYork,
                        sydneyStart: indicator.params.sydneyStart,
                        sydneyEnd: indicator.params.sydneyEnd,
                        tokyoStart: indicator.params.tokyoStart,
                        tokyoEnd: indicator.params.tokyoEnd,
                        asianStart: indicator.params.asianStart,
                        asianEnd: indicator.params.asianEnd,
                        frankfurtStart: indicator.params.frankfurtStart,
                        frankfurtEnd: indicator.params.frankfurtEnd,
                        londonStart: indicator.params.londonStart,
                        londonEnd: indicator.params.londonEnd,
                        newYorkStart: indicator.params.newYorkStart,
                        newYorkEnd: indicator.params.newYorkEnd,
                        sydneyColor: indicator.style.sydneyColor,
                        tokyoColor: indicator.style.tokyoColor,
                        asianColor: indicator.style.asianColor,
                        frankfurtColor: indicator.style.frankfurtColor,
                        londonColor: indicator.style.londonColor,
                        newYorkColor: indicator.style.newYorkColor
                    });
                    break;
                case 'openingrange':
                case 'or':
                    applyOpeningRangeStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                    this.indicators.data[indicator.id] = calculateOpeningRange(this.data, indicator.params);
                    break;
                case 'supertrend':
                    this.indicators.data[indicator.id] = _m19iWorkerPortEnabled()
                        ? _m19iSupertrendIncremental(this, indicator)
                        : calculateSupertrend(this.data, indicator.params.period, indicator.params.multiplier);
                    break;
                case 'stddev':
                    this.indicators.data[indicator.id] = calculateStdDevLine(this.data, indicator.params.period, indicator.params.source || 'close');
                    break;
                case 'ao':
                    applyAoStyleFromParams(indicator, Object.assign({}, indicator.style, indicator.params));
                    this.indicators.data[indicator.id] = calculateAO(this.data, indicator.params.fastLength, indicator.params.slowLength);
                    break;
                case 'uo':
                    this.indicators.data[indicator.id] = calculateUltimateOscillator(this.data, indicator.params.period1, indicator.params.period2, indicator.params.period3);
                    break;
                case 'vortex':
                    this.indicators.data[indicator.id] = calculateVortex(this.data, indicator.params.period);
                    break;
                case 'dpo':
                    this.indicators.data[indicator.id] = calculateDPO(this.data, indicator.params.period, indicator.params.centered === true);
                    break;
                case 'envelope':
                case 'smaenvelope':
                    this.indicators.data[indicator.id] = calculateEnvelope(this.data, indicator.params.period, indicator.params.percent, indicator.params.source || 'close');
                    break;
                case 'stochrsi':
                    this.indicators.data[indicator.id] = calculateStochRSI(
                        this.data,
                        indicator.params.rsiPeriod,
                        indicator.params.stochLen,
                        indicator.params.smoothK,
                        indicator.params.smoothD,
                        indicator.params.source || 'close'
                    );
                    break;
                case 'massindex':
                    indicator.params.period = massIndexPeriodFromParams(indicator.params);
                    this.indicators.data[indicator.id] = calculateMassIndex(
                        this.data,
                        MASS_INDEX_EMA_PERIOD,
                        indicator.params.period
                    );
                    break;
                case 'coppock':
                    this.indicators.data[indicator.id] = calculateCoppock(this.data, indicator.params);
                    break;
                case 'rvi':
                    this.indicators.data[indicator.id] = calculateRVI(this.data, indicator.params.period);
                    break;
                case 'elderray':
                    this.indicators.data[indicator.id] = calculateElderRay(this.data, indicator.params.period);
                    break;
                case 'seasonality':
                    this.indicators.data[indicator.id] = calculateSeasonality(
                        this.data,
                        indicator.params.minSamples != null ? indicator.params.minSamples : 2
                    );
                    break;
                case 'cotnet':
                    this.indicators.data[indicator.id] = { loading: true, error: null };
                    if (typeof this._scheduleCotNetLoad === 'function') this._scheduleCotNetLoad(indicator);
                    break;
                case 'ictpd':
                    this.indicators.data[indicator.id] = calculateIctPrevDayPD(this.data);
                    break;
                case 'ictasian':
                    this.indicators.data[indicator.id] = calculateIctAsianRange(this.data, {
                        rangeStart: indicator.params.rangeStart,
                        rangeEnd: indicator.params.rangeEnd
                    });
                    break;
                case 'ictote':
                    this.indicators.data[indicator.id] = calculateIctOTE(
                        this.data,
                        indicator.params.lookback,
                        indicator.params.fibLow,
                        indicator.params.fibHigh
                    );
                    break;
                case 'ictfvg':
                    this.indicators.data[indicator.id] = _m19iIctFvgCalc(this, indicator);
                    break;
                case 'ictsesspd':
                    this.indicators.data[indicator.id] = calculateIctSessionPrevDayPD(this.data, {
                        rangeStart: indicator.params.rangeStart,
                        rangeEnd: indicator.params.rangeEnd,
                        maxLookbackDays: indicator.params.maxLookbackDays
                    });
                    break;
                case 'ictliquidity':
                    this.indicators.data[indicator.id] = calculateLiquidityEqualLevels(this.data, {
                        fractalWidth: indicator.params.fractalWidth,
                        tolerancePct: indicator.params.tolerancePct,
                        minTouches: indicator.params.minTouches,
                        maxSegments: indicator.params.maxSegments,
                        extendBars: indicator.params.extendBars
                    });
                    break;
                case 'icteverything':
                    this.indicators.data[indicator.id] = calculateIctEverything(this.data, indicator);
                    break;
                case 'talariafvg':
                    this.indicators.data[indicator.id] = _m19iTalariaFvgCalc(this, indicator);
                    break;
                case 'talariaratiogap':
                    this.indicators.data[indicator.id] = calculateTalariaRatioGapIndicator(this.data, indicator);
                    break;
                case 'talariaweeklymap':
                    this.indicators.data[indicator.id] = calculateTalariaWeeklyMapIndicator(this.data, indicator, this);
                    break;
                case 'talariasmc':
                    this.indicators.data[indicator.id] = calculateTalariaSimpleSmcIndicator(this.data, indicator, this);
                    break;
                case 'custom':
                    if (typeof this._scheduleCustomIndicatorCompute === 'function') {
                        this._scheduleCustomIndicatorCompute(indicator);
                    }
                    break;
            }
        }, this);
        } catch (b70CaughtSyncError) {
            b70SyncError = b70CaughtSyncError;
            if (b70EnvelopeTx) _b70Stage4AbortBuild(this, b70EnvelopeTx);
            else _b70Stage2RestoreResults(this, b70PriorResults);
            if (b70Tickets) _b70Stage2ReleaseSyncFailure(this, b70Tickets);
        }
        if (b70PrivateBuild) {
            if (b70SyncError) throw b70SyncError;
            return;
        }
        var b70EnvelopePublished = false;
        if (b70Tickets && !b70SyncError) {
            b70EnvelopePublished = _b70Stage4CommitBuild(this, b70EnvelopeTx);
            var b70PartialValid = !b70EnvelopePublished
                && b70EnvelopeTx.partial;
            if (b70EnvelopePublished || b70PartialValid) {
                _b70Stage2Commit(this, b70Tickets);
            } else {
                _b70Stage2ReleaseSyncFailure(this, b70Tickets);
                b70SyncError = new Error('b70 indicator envelope validation failed');
            }
        }
        this._recalcOnlyTypes = null;
        if (typeof this._clearIndicatorCalculatingFlags === 'function') {
            this._clearIndicatorCalculatingFlags();
        } else if (typeof this._setAllIndicatorsCalculating === 'function') {
            this._setAllIndicatorsCalculating(false);
        }
        // M19-I(d): a filtered pass (onlyTypes/skipTypes) leaves other
        // indicators stale — it must NOT mark the dedupe snapshot complete.
        if (!onlyTypes && !skipTypes && typeof this._markIndicatorRecalcComplete === 'function') {
            this._markIndicatorRecalcComplete();
        }
        if ((!b70Tickets || b70EnvelopePublished)
            && typeof this.bumpIndicatorRenderVersion === 'function') {
            this.bumpIndicatorRenderVersion();
        }
        if (typeof this.updateOHLCIndicators === 'function') {
            this.updateOHLCIndicators();
        }
        if (b70DeferredWorker && !b70SyncError && !this._indicatorWorkerBusy
            && typeof this.recalculateIndicatorsAsync === 'function') {
            this.recalculateIndicatorsAsync();
        }
        if (b70SyncError) throw b70SyncError;
    };
    
    Chart.prototype.setupVolumeIndicatorLine = function(indicator) {
        const volumeLine = document.getElementById('volumeIndicatorLine');
        if (!volumeLine) {
            return;
        }
        
        const self = this;
        
        // Match exact styling of other indicators
        volumeLine.style.cssText = 'display: inline-flex; align-items: center; gap: 6px; cursor:default; padding: 2px 6px; margin-right: 8px; border-radius: 3px; transition: background 0.2s;';
        
        // Update color box
        const colorBox = volumeLine.querySelector('.volume-color-box');
        if (colorBox) {
            colorBox.style.background = indicator.style.growingColor || indicator.style.upColor || 'rgba(8, 153, 129, 0.5)';
        }
        
        // Update label text and opacity based on visibility and MA settings
        const label = volumeLine.querySelector('.volume-label');
        if (label) {
            label.style.opacity = indicator.visible !== false ? '1' : '0.5';
            // Show MA period in label if MA is enabled
            if (indicator.params && (indicator.params.showMa || indicator.params.showMA)) {
                label.textContent = 'Volume MA(' + (indicator.params.maPeriod || 20) + ')';
            } else {
                label.textContent = 'Volume';
            }
        }
        
        // Hover effect - same as other indicators
        volumeLine.addEventListener('mouseenter', function() {
            volumeLine.style.background = 'rgba(120, 123, 134, 0.1)';
        });
        volumeLine.addEventListener('mouseleave', function() {
            volumeLine.style.background = 'transparent';
        });
        
        // Visibility toggle button
        const visibilityBtn = volumeLine.querySelector('.volume-visibility-btn');
        if (visibilityBtn) {
            visibilityBtn.style.opacity = indicator.visible !== false ? '1' : '0.5';
            visibilityBtn.style.cursor = 'default';
            
            // Clone to remove old listeners
            const newVisBtn = visibilityBtn.cloneNode(true);
            visibilityBtn.parentNode.replaceChild(newVisBtn, visibilityBtn);
            
            newVisBtn.addEventListener('mouseenter', function() {
                newVisBtn.style.background = 'rgba(120, 123, 134, 0.2)';
            });
            newVisBtn.addEventListener('mouseleave', function() {
                newVisBtn.style.background = 'transparent';
            });
            newVisBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                e.preventDefault();
                const nextOn = indicator.visible === false
                    || (self.chartSettings && self.chartSettings.showVolume === false);
                if (typeof self.setIndicatorVisible === 'function') {
                    self.setIndicatorVisible(indicator, nextOn, { isVolume: true });
                } else if (typeof self._setIndicatorPlotLegendVisible === 'function') {
                    self._setIndicatorPlotLegendVisible(indicator, nextOn, { isVolume: true });
                } else {
                    indicator.visible = nextOn;
                    self.chartSettings.showVolume = nextOn;
                }
                const on = typeof global.resolveIndicatorShown === 'function'
                    ? global.resolveIndicatorShown(indicator, self.chartSettings)
                    : (indicator.visible !== false);
                const currentLabel = volumeLine.querySelector('.volume-label');
                if (!on) {
                    newVisBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>';
                    newVisBtn.style.opacity = '0.5';
                    if (currentLabel) currentLabel.style.opacity = '0.5';
                } else {
                    newVisBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
                    newVisBtn.style.opacity = '1';
                    if (currentLabel) currentLabel.style.opacity = '1';
                }
                if (typeof self.render === 'function') self.render();
            });
        }
        
        // Settings button
        const settingsBtn = volumeLine.querySelector('.volume-settings-btn');
        if (settingsBtn) {
            settingsBtn.style.cursor = 'default';
            
            // Clone to remove old listeners
            const newSettingsBtn = settingsBtn.cloneNode(true);
            settingsBtn.parentNode.replaceChild(newSettingsBtn, settingsBtn);
            
            newSettingsBtn.addEventListener('mouseenter', function() {
                newSettingsBtn.style.background = 'rgba(120, 123, 134, 0.2)';
            });
            newSettingsBtn.addEventListener('mouseleave', function() {
                newSettingsBtn.style.background = 'transparent';
            });
            newSettingsBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                e.preventDefault();
                self.showVolumeSettings();
            });
        }
        
        // Remove button
        const removeBtn = volumeLine.querySelector('.volume-remove-btn');
        if (removeBtn) {
            removeBtn.style.cursor = 'default';
            
            // Clone to remove old listeners
            const newRemoveBtn = removeBtn.cloneNode(true);
            removeBtn.parentNode.replaceChild(newRemoveBtn, removeBtn);
            
            newRemoveBtn.addEventListener('mouseenter', function() {
                newRemoveBtn.style.background = 'rgba(120, 123, 134, 0.2)';
            });
            newRemoveBtn.addEventListener('mouseleave', function() {
                newRemoveBtn.style.background = 'transparent';
            });
            newRemoveBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                e.preventDefault();
                // Find and remove volume indicator
                const volumeInd = self.indicators.active.find(function(ind) {
                    return ind.type === 'volume' || ind.isVolume;
                });
                if (volumeInd) {
                    self.removeIndicator(volumeInd.id);
                }
            });
        }
        
    };
    
    Chart.prototype.hideVolumeIndicatorLine = function() {
        const volumeLine = document.getElementById('volumeIndicatorLine');
        if (volumeLine) {
            volumeLine.style.display = 'none';
            // Reset volume value to dash
            const volumeValue = volumeLine.querySelector('.volume-value');
            if (volumeValue) {
                volumeValue.textContent = '—';
            }
        }
    };
    
    Chart.prototype.showVolumeSettings = function() {
        // Find volume indicator
        const volumeInd = this.indicators.active.find(function(ind) {
            return ind.type === 'volume' || ind.isVolume;
        });
        
        if (!volumeInd) {
            return;
        }
        
        // Use the indicator-ui.js createIndicatorSettingsPanel if available
        if (typeof window.createIndicatorSettingsPanel === 'function') {
            window.createIndicatorSettingsPanel(this, 'volume', volumeInd);
            return;
        }
        
        // Fallback: use the built-in settings dialog
        this.showIndicatorSettings(volumeInd.id);
    };
    
    Chart.prototype.removeIndicator = function(id) {
        if (id == null) return;
        const idStr = String(id);
        const index = this.indicators.active.findIndex(function(ind) {
            return ind && (ind.id === id || String(ind.id) === idStr);
        });
        
        if (index >= 0) {
            const indicator = this.indicators.active[index];
            
            // If removing volume indicator, disable volume display and hide the line
            if (indicator.type === 'volume' || indicator.isVolume) {
                this.chartSettings.showVolume = false;
                this.hideVolumeIndicatorLine();
            }
            
            this.indicators.active.splice(index, 1);
            delete this.indicators.data[id];
            if (this.indicators.data[indicator.id] !== undefined) {
                delete this.indicators.data[indicator.id];
            }
            if (this.chartSettings && this.chartSettings.separatePanelHeights) {
                delete this.chartSettings.separatePanelHeights[id];
                if (indicator.id != null) delete this.chartSettings.separatePanelHeights[indicator.id];
            }
            if (this.selectedOverlayIndicatorId === id || String(this.selectedOverlayIndicatorId) === idStr) {
                this.selectedOverlayIndicatorId = null;
            }
            this._updateIndicatorPanelHeight();
            if (typeof this.calculateScales === 'function') {
                this.calculateScales();
            }
            
            if (typeof this.render === 'function') {
                this.render();
            }
            
            this.updateOHLCIndicators();
            this.persistIndicators({ force: true });
            if (typeof this.bumpIndicatorRenderVersion === 'function') {
                this.bumpIndicatorRenderVersion();
            }
            if (typeof window !== 'undefined'
                && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true) {
                _b70ShadowInvalidate(this, 'indicator-remove');
            }
            emitIndicatorsChanged(this, 'remove', indicator);
        }
    };
    
    Chart.prototype.clearIndicators = function({ confirmPrompt = true } = {}) {
        if (!this.indicators || !Array.isArray(this.indicators.active) || this.indicators.active.length === 0) {
            return false;
        }

        const count = this.indicators.active.length;

        if (confirmPrompt) {
            const confirmed = window.confirm(`Remove ${count} indicator${count === 1 ? '' : 's'}?`);
            if (!confirmed) {
                return false;
            }
        }

        // Check if any volume indicator exists and disable volume display
        const hasVolume = this.indicators.active.some(function(ind) {
            return ind.type === 'volume' || ind.isVolume;
        });
        if (hasVolume) {
            this.chartSettings.showVolume = false;
            this.hideVolumeIndicatorLine();
        }

        if (typeof this._evictClearedIndicatorSettingsV1 === 'function') {
            this._evictClearedIndicatorSettingsV1(this.indicators.active);
        }

        this.indicators.active = [];
        this.indicators.data = {};
        this.separateIndicatorPanelHeight = 0;

        if (typeof this.render === 'function') {
            this.render();
        }

        if (typeof this.updateOHLCIndicators === 'function') {
            this.updateOHLCIndicators();
        }

        this.persistIndicators({ force: true });
        if (typeof this.bumpIndicatorRenderVersion === 'function') {
            this.bumpIndicatorRenderVersion();
        }
        if (typeof window !== 'undefined'
            && window.__TALARIA_ENABLE_B70_SINGLE_INDICATOR_OWNER_V1 === true) {
            _b70ShadowInvalidate(this, 'indicator-clear');
        }
        emitIndicatorsChanged(this, 'clear', null);
        return true;
    };
    
    Chart.prototype._parseChartTimeframeForVisibility = function(timeframe) {
        if (typeof timeframe !== 'string') return null;
        const tf = timeframe.trim();
        const m = tf.match(/^(\d+)\s*([a-zA-Z]+)$/);
        if (!m) return null;
        const value = parseInt(m[1], 10);
        if (!Number.isFinite(value)) return null;
        const unitRaw = m[2];
        const unitLower = unitRaw.toLowerCase();
        if (unitLower === 'mo' || unitLower === 'mon' || unitLower === 'month' || unitLower === 'months') {
            return { value: value, unit: 'M' };
        }
        const unitChar = unitRaw.length === 1 ? unitRaw : unitRaw[0];
        if (unitChar === 'M') return { value: value, unit: 'M' };
        const u = unitChar.toLowerCase();
        if (u === 's' || u === 'm' || u === 'h' || u === 'd' || u === 'w') {
            return { value: value, unit: u };
        }
        return null;
    };

    Chart.prototype._indicatorVisibleForCurrentTimeframe = function(indicator) {
        if (!indicator || !this.currentTimeframe) return true;
        const vis = indicator.visibility;
        if (!vis || !vis._ranges) return true;
        const parsed = this._parseChartTimeframeForVisibility(this.currentTimeframe);
        if (!parsed) return true;
        const r = vis._ranges[parsed.unit]
            || (parsed.unit === 'M' ? vis._ranges.mo : null)
            || (parsed.unit === 'mo' ? vis._ranges.M : null);
        if (!r) return true;
        if (r.enabled === false) return false;
        const minV = Number.isFinite(+r.min) ? +r.min : null;
        const maxV = Number.isFinite(+r.max) ? +r.max : null;
        if (minV === null || maxV === null) return true;
        return parsed.value >= minV && parsed.value <= maxV;
    };

    Chart.prototype._vwapVisibleOnTimeframe = function(indicator) {
        if (!indicator || !indicator.params || indicator.params.hideOn1DOrAbove !== true) return true;
        const parsed = this._parseChartTimeframeForVisibility(this.currentTimeframe);
        if (!parsed) return true;
        const u = parsed.unit;
        return u !== 'd' && u !== 'w' && u !== 'M';
    };

    Chart.prototype._indicatorPlotOffset = function(indicator) {
        if (!indicator || !indicator.params) return 0;
        const off = Number(indicator.params.offset);
        return Number.isFinite(off) ? (off | 0) : 0;
    };

    Chart.prototype._indicatorSeriesLength = function(data) {
        if (Array.isArray(data)) return data.length;
        if (!data || typeof data !== 'object') return 0;
        const sample = data.line || data.vwap || data.upper || data.middle || data.lower;
        return Array.isArray(sample) ? sample.length : 0;
    };

    /** Extend draw range so positive plot offset can paint into future bars. */
    Chart.prototype._indicatorDrawEndIndex = function(data, baseEnd, plotOffset) {
        const off = Math.max(0, Number(plotOffset) | 0);
        if (!off) return baseEnd;
        const seriesLen = this._indicatorSeriesLength(data) || (this.data ? this.data.length : 0);
        return Math.max(baseEnd, Math.min(seriesLen + off, baseEnd + off));
    };

    Chart.prototype._isIndicatorPlotShown = function(indicator) {
        return resolveIndicatorShownState(indicator, this.chartSettings);
    };

    Chart.prototype._setIndicatorPlotLegendVisible = function(indicator, show, opts) {
        if (!indicator) return;
        if (typeof this.setIndicatorVisible === 'function') {
            this.setIndicatorVisible(indicator, show, opts);
            return;
        }
        opts = opts || {};
        const on = show !== false;
        if (opts.isVolume) {
            indicator.visible = on;
            if (this.chartSettings) this.chartSettings.showVolume = on;
        } else if (indicator.overlay === false || indicator.separatePanel === true) {
            indicator.hidePlot = !on;
            indicator.hideValues = !on;
            if (indicator.visible === false) indicator.visible = true;
        } else {
            indicator.visible = on;
            indicator.hidePlot = false;
        }
        if (typeof this.bumpIndicatorRenderVersion === 'function') {
            this.bumpIndicatorRenderVersion();
        } else if (typeof this._invalidateIndicatorLayerCache === 'function') {
            this._invalidateIndicatorLayerCache();
        }
        if (typeof this._emitIndicatorLifecycle === 'function') {
            this._emitIndicatorLifecycle('visibility', indicator, { visible: on });
        }
    };

    Chart.prototype.drawIndicators = function() {
        if (!this.indicators || !this.indicators.active || this.indicators.active.length === 0) {
            return;
        }

        const ctx = this.ctx;
        const m = this.margin;

        ctx.save();

        // Clip overlay lines to the main pane plus axis margins so values outside the visible
        // price range continue under the price/time panels (drawAxes paints over them afterward).
        const plotLayout = typeof this._getMainPricePlotLayout === 'function'
            ? this._getMainPricePlotLayout()
            : { m: m, plotHeight: this.h - m.t - m.b, indPanelH: 0 };
        const indPanelH = plotLayout.indPanelH || 0;
        const clipTop = 0;
        const clipBottom = indPanelH > 0 ? (this.h - m.b) : this.h;
        ctx.beginPath();
        ctx.rect(m.l, clipTop, this.w - m.l, clipBottom - clipTop);
        ctx.clip();

        const visibleStart = Number.isFinite(this.visibleStartIndex) ? this.visibleStartIndex : 0;
        const visibleEnd = Number.isFinite(this.visibleEndIndex) ? this.visibleEndIndex : (this.data ? this.data.length : 0);
        const buffer = typeof this._getIndicatorDrawBuffer === 'function'
            ? this._getIndicatorDrawBuffer()
            : 24;
        const startIndex = Math.max(0, visibleStart - buffer);
        const endIndex = Math.min(this.data ? this.data.length : 0, visibleEnd + buffer);

        // Draw each indicator
        for (let i = 0; i < this.indicators.active.length; i++) {
            const indicator = this.indicators.active[i];

            // Skip non-overlay indicators
            if (indicator.overlay === false) continue;

            if (!this._isIndicatorPlotShown(indicator)) continue;
            if (!this._indicatorVisibleForCurrentTimeframe(indicator)) continue;
            if (indicator.type === 'vwap' && !this._vwapVisibleOnTimeframe(indicator)) continue;

            const data = this.indicators.data[indicator.id];
            if (!data) continue;

            const plotOffset = this._indicatorPlotOffset(indicator);
            const drawEnd = this._indicatorDrawEndIndex(data, endIndex, plotOffset);
            const lineDrawOpts = { plotOffset: plotOffset };

            const indType = String(indicator.type || '').toLowerCase();

            // Draw based on type
            if (indicator.type === 'vwap') {
                this.drawVwapIndicator(data, indicator.style, startIndex, drawEnd, indicator.params);
            } else if (indicator.type === 'bb' || indicator.type === 'bollinger') {
                this.drawBollingerBands(data, indicator.style, startIndex, drawEnd, plotOffset);
            } else if (indicator.type === 'envelope' || indicator.type === 'smaenvelope') {
                this.drawBollingerBands(data, indicator.style, startIndex, drawEnd, plotOffset);
            } else if (indicator.type === 'donchian' || indicator.type === 'keltner') {
                this.drawBollingerBands(data, indicator.style, startIndex, drawEnd, plotOffset);
            } else if (indicator.type === 'psar') {
                this.drawParabolicSAR(data, indicator.style, startIndex, endIndex);
            } else if (indicator.type === 'sessions') {
                if (this._sessionsVisibleForMaxTimeframe(indicator)) {
                    this.drawSessions(data, indicator, startIndex, endIndex);
                }
            } else if (indicator.type === 'sessionsplus' || indicator.isSessionsPlus) {
                this.drawSessions(data, indicator, startIndex, endIndex);
            } else if (indicator.type === 'openingrange') {
                this.drawOpeningRange(data, indicator.style, startIndex, endIndex);
            } else if (indicator.type === 'ictpd' || indicator.type === 'ictasian' || indicator.type === 'ictote' || indicator.type === 'ictsesspd') {
                this.drawBollingerBands(data, indicator.style, startIndex, drawEnd, plotOffset);
            } else if (indicator.type === 'ictliquidity' || indicator.isLiquidityEq) {
                this.drawLiquidityEqLines(data, indicator.style, startIndex, endIndex);
            } else if (indicator.type === 'ictfvg' || indicator.isIctFvg) {
                this.drawIctFvgBoxes(data, indicator.style, startIndex, endIndex);
            } else if (indicator.type === 'supertrend') {
                this.drawSupertrendOverlay(data, indicator, startIndex, endIndex);
            } else if (indicator.type === 'killzones' || indicator.type === 'ictkz' || indicator.isKillzones) {
                this.drawKillzones(data, indicator.style, startIndex, endIndex);
            } else if (indicator.type === 'icteverything' || indicator.isIctEverything) {
                this.drawIctEverything(data, indicator.style, startIndex, endIndex);
            } else if (indicator.type === 'talariafvg' || indicator.isTalariaFvg) {
                if (typeof this.drawTalariaFvg === 'function') {
                    this.drawTalariaFvg(data, indicator.style, startIndex, endIndex);
                }
            } else if (indicator.type === 'talariaratiogap' || indicator.isTalariaRatioGap) {
                if (typeof this.drawTalariaRatioGap === 'function') {
                    this.drawTalariaRatioGap(data, indicator.style, startIndex, endIndex);
                }
            } else if (indicator.type === 'talariaweeklymap' || indicator.isTalariaWeeklyMap) {
                if (typeof this.drawTalariaWeeklyMap === 'function') {
                    this.drawTalariaWeeklyMap(data, indicator.style, startIndex, endIndex);
                } else if (typeof this.drawTalariaRatioGap === 'function') {
                    this.drawTalariaRatioGap(data, indicator.style, startIndex, endIndex);
                }
            } else if (indicator.type === 'talariasmc' || indicator.isTalariaSimpleSmc) {
                if (typeof this.drawTalariaSimpleSmc === 'function') {
                    this.drawTalariaSimpleSmc(data, indicator.style, startIndex, endIndex);
                }
            } else if (indicator.type === 'adr' || indicator.isADR) {
                this.drawADRBands(data, indicator.style, startIndex, endIndex);
            } else if (indicator.isATR) {
                this.drawATRBands(data, indicator.style, startIndex, endIndex);
            } else if (indicator.type === 'custom') {
                this.drawCustomOverlayPlots(data, indicator, startIndex, endIndex);
            } else if (indType === 'dema') {
                if (indicator.style.showLine !== false && Array.isArray(data)) {
                    this.drawLineIndicator(
                        data,
                        indicator.style.color,
                        indicator.style.lineWidth,
                        startIndex,
                        drawEnd,
                        indicator.style.lineStyle,
                        Object.assign({ dashStyle: indicator.style.lineDashStyle || 'Solid' }, lineDrawOpts)
                    );
                }
            } else if (indType === 'tema') {
                if (indicator.style.showLine !== false && Array.isArray(data)) {
                    this.drawLineIndicator(
                        data,
                        indicator.style.color,
                        indicator.style.lineWidth,
                        startIndex,
                        drawEnd,
                        indicator.style.lineStyle,
                        Object.assign({ dashStyle: indicator.style.lineDashStyle || 'Solid' }, lineDrawOpts)
                    );
                }
            } else if (indType === 'hma') {
                if (indicator.style.showLine !== false && Array.isArray(data)) {
                    this.drawLineIndicator(
                        data,
                        indicator.style.color,
                        indicator.style.lineWidth,
                        startIndex,
                        drawEnd,
                        indicator.style.lineStyle,
                        Object.assign({ dashStyle: indicator.style.lineDashStyle || 'Solid' }, lineDrawOpts)
                    );
                }
            } else if (indType === 'wma') {
                if (indicator.style.showLine !== false) {
                    const wmaLine = Array.isArray(data) ? data : (data && data.line);
                    if (wmaLine) {
                        this.drawLineIndicator(
                            wmaLine,
                            indicator.style.color,
                            indicator.style.lineWidth,
                            startIndex,
                            drawEnd,
                            indicator.style.lineStyle,
                            Object.assign({ dashStyle: indicator.style.lineDashStyle || 'Solid' }, lineDrawOpts)
                        );
                    }
                }
            } else if (indType === 'sma' || indType === 'ema') {
                this.drawSmoothedMaOverlay(data, indicator, startIndex, drawEnd);
            } else {
                this.drawLineIndicator(data, indicator.style.color, indicator.style.lineWidth, startIndex, drawEnd, indicator.style.lineStyle, lineDrawOpts);
            }

            if (indicator.id === this.selectedOverlayIndicatorId && isSelectableOverlayLineIndicator(indicator)) {
                const selSeries = getOverlayLineSeries(indicator, data);
                if (selSeries) {
                    this._drawOverlayLineSelectionHandles(selSeries, startIndex, endIndex, indicator.style);
                }
            }
        }

        for (let ri = 0; ri < this.indicators.active.length; ri++) {
            const rsiInd = this.indicators.active[ri];
            if (rsiInd.type !== 'rsi' || !rsiInd.params || rsiInd.params.divergenceEnabled !== true) continue;
            if (rsiInd.visible === false) continue;
            if (!this._indicatorVisibleForCurrentTimeframe(rsiInd)) continue;
            const rsiPack = this.indicators.data[rsiInd.id];
            if (!rsiPack || !Array.isArray(rsiPack.divergences) || !rsiPack.divergences.length) continue;
            rsiPack.divergences.forEach(function(seg) {
                this._drawRsiDivergenceSegment(
                    ctx,
                    m,
                    seg.i0,
                    seg.i1,
                    seg.price0,
                    seg.price1,
                    startIndex,
                    endIndex,
                    function(v) { return this.yScale(v); }.bind(this),
                    seg.type === 'bull' ? '#26a69a' : '#ef5350'
                );
            }.bind(this));
        }

        ctx.restore();
    };

    Chart.prototype.drawSmoothedMaOverlay = function(data, indicator, startIndex, endIndex) {
        if (!data) return;
        const st = indicator.style || {};
        const pr = indicator.params || {};
        const plotOffset = this._indicatorPlotOffset(indicator);
        const lineOpts = { plotOffset: plotOffset };
        const pack = Array.isArray(data) ? { line: data } : data;
        const smoothColor = st.smoothColor || '#787b86';
        const smoothW = st.smoothLineWidth != null ? st.smoothLineWidth : 1;
        const smoothStyle = st.smoothLineStyle || 'Line';
        const smoothDash = st.smoothLineDashStyle || 'Solid';
        const hasSmoothing = String(pr.smoothingType || 'None') !== 'None';
        const indTypeLo = String(indicator.type || '').toLowerCase();
        let showSmoothOverlay = hasSmoothing;
        if (indTypeLo === 'sma') {
            showSmoothOverlay = hasSmoothing && st.showSmoothMa === true;
        } else if (indTypeLo === 'ema') {
            showSmoothOverlay = hasSmoothing && st.showSmoothEma === true;
        }
        if (showSmoothOverlay) {
            if (pack.bbUpper) {
                this.drawLineIndicator(pack.bbUpper, smoothColor, smoothW, startIndex, endIndex, smoothStyle, Object.assign({ dashStyle: smoothDash }, lineOpts));
            }
            if (pack.bbLower) {
                this.drawLineIndicator(pack.bbLower, smoothColor, smoothW, startIndex, endIndex, smoothStyle, Object.assign({ dashStyle: smoothDash }, lineOpts));
            }
            if (pack.ma) {
                this.drawLineIndicator(pack.ma, smoothColor, smoothW, startIndex, endIndex, smoothStyle, Object.assign({ dashStyle: smoothDash }, lineOpts));
            }
        }
        if (st.showLine !== false && pack.line) {
            this.drawLineIndicator(
                pack.line,
                st.color || '#ff9800',
                st.lineWidth != null ? st.lineWidth : 2,
                startIndex,
                endIndex,
                st.lineStyle || 'Line',
                Object.assign({ dashStyle: st.lineDashStyle || 'Solid' }, lineOpts)
            );
        }
    };

    Chart.prototype.drawSupertrendOverlay = function(data, indicator, startIndex, endIndex) {
        if (!data || !data.line || !data.direction) return;
        const ctx = this.ctx;
        const m = this.margin;
        const style = indicator.style || {};
        const upColor = style.upColor || '#26a69a';
        const downColor = style.downColor || '#ef5350';
        const upLw = style.upLineWidth != null ? style.upLineWidth : (style.lineWidth != null ? style.lineWidth : 2);
        const downLw = style.downLineWidth != null ? style.downLineWidth : (style.lineWidth != null ? style.lineWidth : 2);
        const dashForPlot = function(plotStyle, dashStyleOpt) {
            const normalized = this._normalizePlotStyle(plotStyle || 'Line');
            if (normalized === 'Dashed' || normalized === 'Dotted' || normalized === 'Dashdot') {
                return this._lineDashForStyle(normalized);
            }
            const ds = dashStyleOpt || 'Solid';
            return this._lineDashForStyle(ds === 'Solid' ? 'Line' : ds);
        }.bind(this);
        const upDash = dashForPlot(style.upLineStyle || style.lineStyle, style.upLineDashStyle);
        const downDash = dashForPlot(style.downLineStyle || style.lineStyle, style.downLineDashStyle);
        const chartData = this.data;

        if ((style.showUpBg || style.showDownBg) && Array.isArray(chartData)) {
            const cw = Math.max(1, (this.candleWidth || 8) * 0.9);
            for (let bi = startIndex; bi < endIndex && bi < data.line.length; bi++) {
                if (data.line[bi] == null || isNaN(data.line[bi])) continue;
                const dirUp = data.direction[bi] >= 0;
                if (dirUp && !style.showUpBg) continue;
                if (!dirUp && !style.showDownBg) continue;
                const bar = chartData[bi];
                if (!bar) continue;
                const close = resolveOhlcSourceValue(bar, 'close');
                if (!Number.isFinite(close)) continue;
                const x = this.dataIndexToPixel(bi);
                if (x < m.l - 30 || x > this.w - m.r + 30) continue;
                const yLine = this.yScale(data.line[bi]);
                const yClose = this.yScale(close);
                if (!Number.isFinite(yLine) || !Number.isFinite(yClose)) continue;
                ctx.fillStyle = dirUp ? (style.upBgColor || 'rgba(38,166,154,0.15)') : (style.downBgColor || 'rgba(239,83,80,0.15)');
                ctx.fillRect(x - cw / 2, Math.min(yLine, yClose), cw, Math.abs(yClose - yLine));
            }
        }

        if (style.showBody && Array.isArray(data.body)) {
            this.drawLineIndicator(
                data.body,
                style.bodyColor || 'rgba(120,123,134,0.5)',
                style.bodyLineWidth != null ? style.bodyLineWidth : 1,
                startIndex,
                endIndex,
                style.bodyLineStyle || 'Line',
                { dashStyle: style.bodyLineDashStyle || 'Solid' }
            );
        }

        let i = startIndex;
        while (i < endIndex && i < data.line.length) {
            if (data.line[i] == null || isNaN(data.line[i])) {
                i++;
                continue;
            }
            const dirUp = data.direction[i] >= 0;
            if (dirUp && style.showUp === false) {
                i++;
                continue;
            }
            if (!dirUp && style.showDown === false) {
                i++;
                continue;
            }
            ctx.strokeStyle = dirUp ? upColor : downColor;
            ctx.lineWidth = dirUp ? upLw : downLw;
            ctx.setLineDash(dirUp ? upDash : downDash);
            ctx.beginPath();
            let started = false;
            let j = i;
            while (j < endIndex && j < data.line.length && (data.direction[j] >= 0) === dirUp && data.line[j] != null && !isNaN(data.line[j])) {
                const x = this.dataIndexToPixel(j);
                const y = this.yScale(data.line[j]);
                if (x < m.l - 30 || x > this.w - m.r + 30) {
                    if (started) ctx.stroke();
                    started = false;
                    j++;
                    continue;
                }
                if (!started) {
                    ctx.moveTo(x, y);
                    started = true;
                } else {
                    ctx.lineTo(x, y);
                }
                j++;
            }
            if (started) ctx.stroke();
            ctx.setLineDash([]);
            i = j > i ? j : i + 1;
        }
    };

    Chart.prototype.drawCustomOverlayPlots = function(data, indicator, startIndex, endIndex) {
        if (!data || data.loading) return;
        if (data.error) return;
        const plots = data.plots;
        if (!Array.isArray(plots) || plots.length === 0) return;
        const ctx = this.ctx;
        const m = this.margin;
        plots.forEach(function(plot) {
            if (!plot || !Array.isArray(plot.values)) return;
            const color = plot.color || indicator.style.color || '#2962ff';
            const lw = plot.lineWidth != null ? plot.lineWidth : (indicator.style.lineWidth || 2);
            if (plot.type === 'line') {
                ctx.strokeStyle = color;
                ctx.lineWidth = lw;
                ctx.beginPath();
                let started = false;
                for (let i = startIndex; i < endIndex && i < plot.values.length; i++) {
                    const val = plot.values[i];
                    if (val === null || val === undefined || isNaN(val)) continue;
                    const x = this.dataIndexToPixel(i);
                    const y = this.yScale(val);
                    if (x < m.l - 20 || x > this.w - m.r + 20) continue;
                    if (!started) {
                        ctx.moveTo(x, y);
                        started = true;
                    } else {
                        ctx.lineTo(x, y);
                    }
                }
                if (started) ctx.stroke();
            } else if (plot.type === 'histogram') {
                const baseline = plot.baseline != null && !isNaN(plot.baseline) ? plot.baseline : 0;
                const y0 = this.yScale(baseline);
                for (let i = startIndex; i < endIndex && i < plot.values.length; i++) {
                    const val = plot.values[i];
                    if (val === null || val === undefined || isNaN(val)) continue;
                    const x = this.dataIndexToPixel(i);
                    const y = this.yScale(val);
                    const cw = Math.max(1, (this.candleWidth || 8) * 0.8);
                    ctx.fillStyle = color;
                    ctx.fillRect(x - cw / 2, Math.min(y0, y), cw, Math.abs(y - y0));
                }
            }
        }, this);
    };

    Chart.prototype._renderCustomSeparatePanelSlot = function(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd) {
        if (!indicatorData || indicatorData.loading) {
            ctx.fillStyle = '#787b86';
            ctx.font = '11px Roboto';
            ctx.textAlign = 'center';
            ctx.fillText('Custom indicator…', (m.l + this.w - m.r) / 2, indTop + panelHeight / 2);
            ctx.textAlign = 'left';
            return;
        }
        if (indicatorData.error) {
            ctx.fillStyle = '#ef5350';
            ctx.font = '11px Roboto';
            ctx.textAlign = 'left';
            const msg = String(indicatorData.error).slice(0, 120);
            ctx.fillText(msg, m.l + 4, indTop + 14);
            return;
        }
        const plots = indicatorData.plots;
        if (!Array.isArray(plots) || plots.length === 0) return;

        let min = Infinity;
        let max = -Infinity;
        for (let pi = 0; pi < plots.length; pi++) {
            const plot = plots[pi];
            if (!plot || !Array.isArray(plot.values)) continue;
            const base = plot.baseline != null && !isNaN(plot.baseline) ? plot.baseline : 0;
            if (plot.type === 'histogram') {
                for (let i = visibleStart; i < visibleEnd && i < plot.values.length; i++) {
                    const val = plot.values[i];
                    if (val === null || val === undefined || isNaN(val)) continue;
                    min = Math.min(min, val, base);
                    max = Math.max(max, val, base);
                }
            } else {
                for (let i = visibleStart; i < visibleEnd && i < plot.values.length; i++) {
                    const val = plot.values[i];
                    if (val === null || val === undefined || isNaN(val)) continue;
                    min = Math.min(min, val);
                    max = Math.max(max, val);
                }
            }
        }
        if (min === Infinity || max === -Infinity) return;
        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;

        const dom = this._finalizePanelRange(indicator, min, max);
        min = dom.min;
        max = dom.max;

        const vSpan = Math.max(1e-12, max - min);
        const scaleY = function(val) {
            if (val === null || val === undefined) return null;
            const y = indBottom - 5 - ((val - min) / vSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return Math.max(indTop + 2, Math.min(indBottom - 2, y));
        };

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        ctx.lineWidth = 1;
        const numGridLines = 4;
        for (let g = 0; g <= numGridLines; g++) {
            const val = min + (max - min) * (g / numGridLines);
            const y = scaleY(val);
            if (y === null) continue;
            ctx.beginPath();
            ctx.moveTo(m.l, y);
            ctx.lineTo(this.w, y);
            ctx.stroke();
            ctx.fillStyle = '#787b86';
            ctx.font = '10px Roboto';
            ctx.textAlign = 'right';
            ctx.fillText(val.toFixed(2), this.w - 6, y + 3);
        }

        plots.forEach(function(plot) {
            if (!plot || !Array.isArray(plot.values)) return;
            const color = plot.color || indicator.style.color || '#2962ff';
            const lw = plot.lineWidth != null ? plot.lineWidth : 2;
            if (plot.type === 'line') {
                ctx.strokeStyle = color;
                ctx.lineWidth = lw;
                ctx.beginPath();
                let started = false;
                for (let i = visibleStart; i < visibleEnd && i < plot.values.length; i++) {
                    const val = plot.values[i];
                    if (val === null || val === undefined || isNaN(val)) continue;
                    const x = this.dataIndexToPixel(i);
                    const y = scaleY(val);
                    if (y === null) continue;
                    if (!started) {
                        ctx.moveTo(x, y);
                        started = true;
                    } else {
                        ctx.lineTo(x, y);
                    }
                }
                if (started) ctx.stroke();
            } else if (plot.type === 'histogram') {
                const baseline = plot.baseline != null && !isNaN(plot.baseline) ? plot.baseline : 0;
                const y0 = scaleY(baseline);
                if (y0 === null) return;
                for (let i = visibleStart; i < visibleEnd && i < plot.values.length; i++) {
                    const val = plot.values[i];
                    if (val === null || val === undefined || isNaN(val)) continue;
                    const x = this.dataIndexToPixel(i);
                    const y = scaleY(val);
                    if (y === null) continue;
                    const cw = Math.max(1, (this.candleWidth || 8) * 0.75);
                    ctx.fillStyle = color;
                    ctx.fillRect(x - cw / 2, Math.min(y0, y), cw, Math.abs(y - y0));
                }
            }
        }, this);

        ctx.textAlign = 'left';
    };

const DEFAULT_SEPARATE_PANEL_HEIGHT = 100;
const MIN_SEPARATE_PANEL_HEIGHT = 60;
const DEFAULT_VOLUME_PANEL_HEIGHT = 80;

Chart.prototype._getMaxSeparatePanelStackHeight = function() {
    const m = this.margin || { t: 0, b: 0 };
    return Math.max(MIN_SEPARATE_PANEL_HEIGHT, (this.h || 0) - m.t - m.b);
};

/** Volume band height for layout — honors live resize state so scales/background match slots. */
Chart.prototype._getVolumePanelHeightForLayout = function() {
    if (typeof this._volumeRendersInSeparatePanel !== 'function' || !this._volumeRendersInSeparatePanel()) {
        return 0;
    }
    if (this._separatePanelResize && Number.isFinite(this._separatePanelResize.activeVolumeHeight)) {
        return this._separatePanelResize.activeVolumeHeight;
    }
    return this._getVolumePanelHeight();
};

/** Shrink panel stack only when it exceeds chart height (never force volume back on). */
Chart.prototype._clampSeparatePanelLayout = function(panelHeights, volumePanelHeight) {
    const maxStack = this._getMaxSeparatePanelStackHeight();
    const heights = Array.isArray(panelHeights) ? panelHeights.slice() : [];
    let vol = Number.isFinite(volumePanelHeight) ? volumePanelHeight : 0;
    const volInPanel = vol > 0;

    let total = vol + heights.reduce(function(sum, h) { return sum + (Number(h) || 0); }, 0);
    if (total <= maxStack) {
        return { panelHeights: heights, volumePanelHeight: volInPanel ? Math.round(vol) : 0 };
    }

    let excess = total - maxStack;
    const shrinkOscillators = function() {
        const room = heights.map(function(h) {
            return Math.max(0, (Number(h) || 0) - MIN_SEPARATE_PANEL_HEIGHT);
        });
        const roomSum = room.reduce(function(s, r) { return s + r; }, 0);
        if (roomSum <= 0) return;
        heights.forEach(function(h, i) {
            const cut = (excess * room[i]) / roomSum;
            heights[i] = Math.max(MIN_SEPARATE_PANEL_HEIGHT, (Number(h) || 0) - cut);
        });
    };

    shrinkOscillators();
    total = vol + heights.reduce(function(s, h) { return s + h; }, 0);
    excess = total - maxStack;
    if (excess > 0 && volInPanel) {
        vol = Math.max(MIN_SEPARATE_PANEL_HEIGHT, vol - Math.min(Math.max(0, vol - MIN_SEPARATE_PANEL_HEIGHT), excess));
    }
    return { panelHeights: heights, volumePanelHeight: volInPanel ? Math.round(vol) : 0 };
};

Chart.prototype._getActiveVolumeIndicator = function() {
    if (!this.indicators || !this.indicators.active) return null;
    for (let i = 0; i < this.indicators.active.length; i++) {
        const ind = this.indicators.active[i];
        if (ind.type !== 'volume' && !ind.isVolume) continue;
        if (ind.visible === false) continue;
        if (typeof this._indicatorVisibleForCurrentTimeframe === 'function'
            && !this._indicatorVisibleForCurrentTimeframe(ind)) continue;
        return ind;
    }
    return null;
};

/** Volume bars only when the user added the Volume indicator (ignores legacy chartSettings.showVolume alone). */
Chart.prototype._isVolumeDisplayEnabled = function() {
    if (!this._getActiveVolumeIndicator()) return false;
    if (!this.chartSettings || this.chartSettings.showVolume === false) return false;
    return true;
};

/** Keep persisted showVolume aligned with whether a Volume indicator is on the chart. */
Chart.prototype._syncVolumeDisplayFromIndicators = function() {
    if (!this.chartSettings) this.chartSettings = {};
    if (typeof this._normalizeVolumeIndicatorLayout === 'function') {
        this._normalizeVolumeIndicatorLayout();
    }
    this.chartSettings.showVolume = !!this._getActiveVolumeIndicator();
};

/** Volume always renders in the main chart band (TradingView-style), never as a separate panel slot. */
Chart.prototype._volumeRendersInSeparatePanel = function() {
    return false;
};

/** Bottom overlay strip ratio — volume does not shrink the price plot. */
Chart.prototype._getVolumeOverlayRatio = function() {
    if (!this._isVolumeDisplayEnabled()) return 0;
    if (typeof this._volumeRendersInSeparatePanel === 'function' && this._volumeRendersInSeparatePanel()) {
        return 0;
    }
    const r = Number.isFinite(this.volumeHeight) ? this.volumeHeight : 0.15;
    return Math.max(0.08, Math.min(0.22, r));
};

/** Force volume indicators out of the separate-panel stack and clamp overlay height. */
Chart.prototype._normalizeVolumeIndicatorLayout = function() {
    if (this.indicators && Array.isArray(this.indicators.active)) {
        this.indicators.active.forEach(function(ind) {
            if (ind.type !== 'volume' && !ind.isVolume) return;
            ind.separatePanel = false;
            ind.isVolume = true;
        });
    }
    if (Number.isFinite(this.volumeHeight) && this.volumeHeight > 0.22) {
        this.volumeHeight = 0.15;
    }
};

Chart.prototype._getVolumePanelHeight = function() {
    const m = this.margin || { t: 0, b: 0 };
    const ch = Math.max(0, (this.h || 0) - m.t - m.b);
    const ratio = Number.isFinite(this.volumeHeight) ? this.volumeHeight : 0.15;
    const fromRatio = Math.round(ch * Math.max(0.08, Math.min(ratio, 0.35)));
    return Math.max(MIN_SEPARATE_PANEL_HEIGHT, fromRatio || DEFAULT_VOLUME_PANEL_HEIGHT);
};

/** Main price plot bounds — full pane height; volume overlays the bottom strip only. */
Chart.prototype._getMainPricePlotLayout = function() {
    const m = this.margin;
    const ch = this.h - m.t - m.b;
    const indPanelH = this.separateIndicatorPanelHeight || 0;
    const plotBottom = this.h - m.b - indPanelH;
    const plotHeight = Math.max(1, plotBottom - m.t);
    const overlayRatio = typeof this._getVolumeOverlayRatio === 'function' ? this._getVolumeOverlayRatio() : 0;
    const volumeAreaHeight = ch * overlayRatio;
    return { m: m, ch: ch, volumeAreaHeight: volumeAreaHeight, indPanelH: indPanelH, plotBottom: plotBottom, plotHeight: plotHeight };
};

/** Ensure SVG clip path for main price pane (shared by drawings + orders). */
Chart.prototype._ensureMainPlotSvgClipDef = function() {
    if (!this.svg || this.svg.empty()) return null;
    const panelIdx = (this.panelIndex !== undefined) ? this.panelIndex : '';
    const clipId = 'chart-clip-path' + (panelIdx !== '' && panelIdx !== 0 ? panelIdx : '');
    let defs = this.svg.select('defs');
    if (defs.empty()) defs = this.svg.append('defs');
    let clipPath = defs.select('#' + clipId);
    if (clipPath.empty()) {
        clipPath = defs.append('clipPath')
            .attr('id', clipId)
            .attr('clipPathUnits', 'userSpaceOnUse');
        clipPath.append('rect').attr('class', 'chart-clip-rect');
    }
    const m = this.margin || { l: 0, r: 0, t: 0, b: 0 };
    const layout = typeof this._getMainPricePlotLayout === 'function'
        ? this._getMainPricePlotLayout()
        : null;
    const plotBottom = layout && Number.isFinite(layout.plotBottom)
        ? layout.plotBottom
        : (this.h - m.b - (this.separateIndicatorPanelHeight || 0));
    const clipH = Math.max(1, plotBottom - m.t);
    clipPath.select('rect')
        .attr('x', m.l)
        .attr('y', m.t)
        .attr('width', Math.max(1, this.w - m.l - m.r))
        .attr('height', clipH);
    return 'url(#' + clipId + ')';
};

Chart.prototype._isYInMainPricePlot = function(y) {
    if (!Number.isFinite(y)) return false;
    const m = this.margin || { t: 0, b: 0 };
    const layout = typeof this._getMainPricePlotLayout === 'function'
        ? this._getMainPricePlotLayout()
        : null;
    const plotBottom = layout && Number.isFinite(layout.plotBottom)
        ? layout.plotBottom
        : (this.h - m.b - (this.separateIndicatorPanelHeight || 0));
    return y >= m.t && y <= plotBottom;
};

/** Remove DOM axis tick labels on indicator panels (canvas grids are separate). */
Chart.prototype._clearSeparatePanelAxisOverlayDecor = function() {
    const canvas = this.ctx && this.ctx.canvas;
    const wrapper = canvas ? canvas.parentElement : null;
    if (!wrapper) return;
    const overlay = wrapper.querySelector('#separatePanelsOverlay');
    if (!overlay) return;
    overlay.querySelectorAll('[data-talaria-sp-axis-tick]').forEach(function(n) { n.remove(); });
};

/** Apply main-chart grid stroke style from chartSettings (returns false when grid hidden). */
Chart.prototype._applyChartGridStrokeStyle = function(ctx, axis) {
    const cs = this.chartSettings || {};
    if (cs.showGrid === false || cs.gridStyle === 'None') return false;
    const wantVert = axis === 'vertical';
    const wantHorz = axis === 'horizontal';
    if (wantVert && cs.gridStyle !== 'Vert and horz' && cs.gridStyle !== 'Vertical') return false;
    if (wantHorz && cs.gridStyle !== 'Vert and horz' && cs.gridStyle !== 'Horizontal') return false;
    const gridLW = Math.max(1, parseInt(cs.gridLineWidth, 10) || 1);
    const gridPat = cs.gridPattern || 'solid';
    ctx.strokeStyle = cs.gridColor || 'rgba(42, 46, 57, 0.6)';
    ctx.lineWidth = gridLW;
    if (gridPat === 'dashed') ctx.setLineDash([6, 4]);
    else if (gridPat === 'dotted') ctx.setLineDash([2, 4]);
    else if (gridPat === 'longDash') ctx.setLineDash([10, 5]);
    else ctx.setLineDash([]);
    return true;
};

/** Vertical time grid through separate indicator stack — same _timeTicks as main chart. */
Chart.prototype._drawSeparatePanelVerticalTimeGrid = function(ctx, m, panelTop, panelBottom, plotRight) {
    if (!ctx || !this._applyChartGridStrokeStyle(ctx, 'vertical')) return;
    const ticks = this._timeTicks;
    if (!Array.isArray(ticks) || !ticks.length) {
        ctx.setLineDash([]);
        return;
    }
    const xMin = m.l;
    const xMax = Number.isFinite(plotRight) ? plotRight : (this.w - m.r);
    const y0 = panelTop;
    const y1 = panelBottom;
    for (let i = 0; i < ticks.length; i++) {
        const x = ticks[i].x;
        if (x < xMin || x > xMax) continue;
        ctx.beginPath();
        ctx.moveTo(x, y0);
        ctx.lineTo(x, y1);
        ctx.stroke();
    }
    ctx.setLineDash([]);
};

/** Opaque fill for the separate-panel stack — call before candles so price series cannot bleed through. */
Chart.prototype._paintSeparatePanelStackBackground = function() {
    if (typeof this._getVisibleSeparateIndicators !== 'function') return;
    const separateIndicators = this._getVisibleSeparateIndicators();
    const volumeInPanel = typeof this._volumeRendersInSeparatePanel === 'function' && this._volumeRendersInSeparatePanel();
    if (!separateIndicators.length && !volumeInPanel) return;

    const ctx = this.ctx;
    const m = this.margin;
    let panelHeights = this._getSeparatePanelHeights(separateIndicators);
    if (this._separatePanelResize && Array.isArray(this._separatePanelResize.activeHeights) &&
        this._separatePanelResize.activeHeights.length === panelHeights.length) {
        panelHeights = this._separatePanelResize.activeHeights.slice();
    }
    let volumePanelHeight = volumeInPanel ? this._getVolumePanelHeightForLayout() : 0;
    if (!this._separatePanelResize) {
        const clampedLayout = this._clampSeparatePanelLayout(panelHeights, volumePanelHeight);
        panelHeights = clampedLayout.panelHeights;
        volumePanelHeight = volumeInPanel ? clampedLayout.volumePanelHeight : 0;
    }
    const totalPanelHeight = panelHeights.reduce(function(sum, h) { return sum + h; }, 0) + volumePanelHeight;
    if (totalPanelHeight <= 0) return;

    const panelBottom = this.h - m.b;
    const panelTop = panelBottom - totalPanelHeight;
    const panelFullRight = this.w;
    const panelBackgroundColor =
        (this.chartSettings && this.chartSettings.backgroundColor) ||
        (typeof getComputedStyle === 'function'
            ? (getComputedStyle(document.documentElement).getPropertyValue('--sp-bg') || '').trim()
            : '') ||
        '#131722';
    ctx.fillStyle = panelBackgroundColor;
    ctx.fillRect(m.l, panelTop, panelFullRight - m.l, totalPanelHeight);
};

/** Reserve separate-panel height before calculateScales/drawVolume so volume stays in its own band. */
Chart.prototype._syncSeparateIndicatorPanelHeightEstimate = function() {
    if (typeof this._getVisibleSeparateIndicators !== 'function') return;
    const separateIndicators = this._getVisibleSeparateIndicators();
    let panelHeights = [];
    if (separateIndicators.length) {
        panelHeights = this._getSeparatePanelHeights(separateIndicators);
        if (this._separatePanelResize && Array.isArray(this._separatePanelResize.activeHeights) &&
            this._separatePanelResize.activeHeights.length === panelHeights.length) {
            panelHeights = this._separatePanelResize.activeHeights.slice();
        }
    }
    let volH = this._volumeRendersInSeparatePanel() ? this._getVolumePanelHeightForLayout() : 0;
    if (this._separatePanelResize) {
        this.separateIndicatorPanelHeight = panelHeights.reduce(function(sum, h) { return sum + h; }, 0) + volH;
        return;
    }
    let total = panelHeights.reduce(function(sum, h) { return sum + h; }, 0);
    if (volH > 0) {
        const clamped = this._clampSeparatePanelLayout(panelHeights, volH);
        total = clamped.panelHeights.reduce(function(sum, h) { return sum + h; }, 0) + clamped.volumePanelHeight;
    }
    this.separateIndicatorPanelHeight = total;
};

Chart.prototype._getVisibleSeparateIndicators = function() {
    if (!this.indicators || !this.indicators.active) return [];
    return this.indicators.active.filter(ind => {
        if (ind.type === 'volume' || ind.isVolume) return false;
        if (ind.type === 'stddev') {
            ind.overlay = false;
            ind.separatePanel = true;
        }
        const isSeparate = ind.overlay === false || ind.separatePanel === true;
        const isVisible = ind.visible !== false;
        if (!isSeparate || !isVisible) return false;
        return this._indicatorVisibleForCurrentTimeframe(ind);
    });
};

Chart.prototype._getSeparatePanelHeights = function(indicators) {
    if (!this.chartSettings) this.chartSettings = {};
    if (!this.chartSettings.separatePanelHeights || typeof this.chartSettings.separatePanelHeights !== 'object') {
        this.chartSettings.separatePanelHeights = {};
    }
    const store = this.chartSettings.separatePanelHeights;
    return indicators.map(indicator => {
        const saved = Number(store[indicator.id]);
        if (Number.isFinite(saved) && saved >= MIN_SEPARATE_PANEL_HEIGHT) {
            return saved;
        }
        store[indicator.id] = DEFAULT_SEPARATE_PANEL_HEIGHT;
        return DEFAULT_SEPARATE_PANEL_HEIGHT;
    });
};

Chart.prototype._evictedIndicatorSettingsStoreV1 = function() {
    if (!this._evictedIndicatorSettingsV1 || !Array.isArray(this._evictedIndicatorSettingsV1)) {
        this._evictedIndicatorSettingsV1 = [];
    }
    return this._evictedIndicatorSettingsV1;
};

Chart.prototype._rememberEvictedIndicatorPanelHeightV1 = function(indicator, height) {
    if (!indicatorEvictV1Enabled() || !indicator) return;
    const key = indicatorEvictTypeKey(indicator);
    const h = Number(height);
    if (!key || !Number.isFinite(h) || h < MIN_SEPARATE_PANEL_HEIGHT) return;
    const store = this._evictedIndicatorSettingsStoreV1();
    for (let i = store.length - 1; i >= 0; i--) {
        if (store[i] && store[i].key === key) store.splice(i, 1);
    }
    store.push({
        key,
        height: Math.max(MIN_SEPARATE_PANEL_HEIGHT, h),
        playhead: indicatorEvictPlayhead(this),
    });
    while (store.length > INDICATOR_EVICT_V1_MAX_SETTINGS) store.shift();
};

Chart.prototype._restoreEvictedIndicatorSettingsForNewIndicator = function(indicator) {
    if (!indicatorEvictV1Enabled() || !indicator) return false;
    const key = indicatorEvictTypeKey(indicator);
    if (!key || !this._evictedIndicatorSettingsV1) return false;
    for (let i = this._evictedIndicatorSettingsV1.length - 1; i >= 0; i--) {
        const entry = this._evictedIndicatorSettingsV1[i];
        if (!entry || entry.key !== key) continue;
        if (!this.chartSettings) this.chartSettings = {};
        if (!this.chartSettings.separatePanelHeights || typeof this.chartSettings.separatePanelHeights !== 'object') {
            this.chartSettings.separatePanelHeights = {};
        }
        this.chartSettings.separatePanelHeights[indicator.id] = entry.height;
        indicator._evictedSettingsRestoredAtPlayhead = indicatorEvictPlayhead(this);
        indicator._evictedSettingsSourcePlayhead = entry.playhead;
        return true;
    }
    return false;
};

Chart.prototype._evictClearedIndicatorSettingsV1 = function(indicators) {
    if (!indicatorEvictV1Enabled()
        || !Array.isArray(indicators)
        || !this.chartSettings
        || !this.chartSettings.separatePanelHeights
        || typeof this.chartSettings.separatePanelHeights !== 'object') {
        return;
    }
    const heights = this.chartSettings.separatePanelHeights;
    indicators.forEach((indicator) => {
        if (!indicator) return;
        const saved = Number(heights[indicator.id]);
        if (Number.isFinite(saved)) {
            this._rememberEvictedIndicatorPanelHeightV1(indicator, saved);
        }
        delete heights[indicator.id];
    });
};

Chart.prototype._persistSeparatePanelHeights = function(indicators, heights, saveSettings = false) {
    if (!this.chartSettings) this.chartSettings = {};
    if (!this.chartSettings.separatePanelHeights || typeof this.chartSettings.separatePanelHeights !== 'object') {
        this.chartSettings.separatePanelHeights = {};
    }
    indicators.forEach((indicator, idx) => {
        const h = Number(heights[idx]);
        if (Number.isFinite(h)) {
            this.chartSettings.separatePanelHeights[indicator.id] = Math.max(MIN_SEPARATE_PANEL_HEIGHT, h);
        }
    });
    if (saveSettings && typeof this.saveSettings === 'function') {
        this.saveSettings();
    }
};

Chart.prototype.getSeparatePanelResizeHandleAt = function(x, y, tolerance = 18) {
    if (!this.separatePanelInfo || !this.separatePanelInfo.resizeHandles) return null;
    const m = this.margin || { l: 0, r: 0 };
    // Full width including the indicator price-axis strip (grip is drawn to canvas right edge).
    if (x < m.l || x > this.w) return null;
    for (let i = 0; i < this.separatePanelInfo.resizeHandles.length; i++) {
        const handle = this.separatePanelInfo.resizeHandles[i];
        if (Math.abs(y - handle.y) <= tolerance) return handle;
    }
    return null;
};

/** Reserve panel layout immediately when a separate-panel indicator is added (before calc finishes). */
Chart.prototype._primeSeparatePanelForNewIndicator = function(indicator, typeHint) {
    if (!indicator) return;
    const t = String(typeHint || indicator.type || '').toLowerCase();
    const separateTypes = {
        rsi: 1, macd: 1, ppo: 1, stoch: 1, stochastic: 1, stochrsi: 1, cci: 1, mfi: 1,
        willr: 1, williamsr: 1, adx: 1, aroon: 1, atr: 1, adr: 1, obv: 1, ao: 1, mom: 1,
        momentum: 1, roc: 1, uo: 1, vortex: 1, elderray: 1, dpo: 1, cmf: 1, cotnet: 1
    };
    if (separateTypes[t] || indicator.separatePanel === true || indicator.overlay === false) {
        indicator.overlay = false;
        indicator.separatePanel = true;
    }
    if (typeof this._updateIndicatorPanelHeight === 'function') {
        this._updateIndicatorPanelHeight();
    }
    if (typeof this.calculateScales === 'function') {
        this.calculateScales();
    }
};

/** Auto-fit Y range bases for separate-panel line drag (before first paint caches _panelBaseMin). */
Chart.prototype._getIndicatorPanelAxisBases = function(indicator) {
    if (!indicator) return null;
    let b0 = indicator._panelBaseMin;
    let b1 = indicator._panelBaseMax;
    if (Number.isFinite(b0) && Number.isFinite(b1) && b1 > b0) {
        return { b0: b0, b1: b1 };
    }
    const t = String(indicator.type || '').toLowerCase();
    if (t === 'rsi' || t === 'stoch' || t === 'stochastic' || t === 'stochrsi' || t === 'mfi' || t === 'uo') {
        return { b0: 0, b1: 100 };
    }
    if (t === 'willr' || t === 'williamsr') return { b0: -100, b1: 0 };
    if (t === 'cci') return { b0: -200, b1: 200 };
    if (t === 'aroon') return { b0: 0, b1: 100 };
    const extent = typeof this._getIndicatorVisibleValueExtent === 'function'
        ? this._getIndicatorVisibleValueExtent(indicator)
        : null;
    if (extent && Number.isFinite(extent.min) && Number.isFinite(extent.max) && extent.max > extent.min) {
        const pad = Math.max((extent.max - extent.min) * 0.1, 1e-9);
        return { b0: extent.min - pad, b1: extent.max + pad };
    }
    return { b0: 0, b1: 100 };
};

/** Resolve live panel slot during drag (panelSlots are rebuilt every render). */
Chart.prototype._resolveSeparatePanelSlotForDrag = function() {
    const drag = this.drag;
    if (!drag) return null;
    const ind = drag.separatePanelIndicator
        || (drag.separatePanelSlot && drag.separatePanelSlot.indicator);
    if (!ind) return drag.separatePanelSlot || null;
    const spi = this.separatePanelInfo;
    if (spi && Array.isArray(spi.panelSlots)) {
        for (let i = 0; i < spi.panelSlots.length; i++) {
            const s = spi.panelSlots[i];
            if (!s || !s.indicator) continue;
            if (s.indicator === ind || (ind.id != null && s.indicator.id === ind.id)) {
                drag.separatePanelSlot = s;
                drag.separatePanelIndicator = s.indicator;
                return s;
            }
        }
    }
    if (drag.separatePanelSlot && drag.separatePanelSlot.indicator === ind) {
        return drag.separatePanelSlot;
    }
    const h = Math.max(1, Number(drag.separatePanelSlot && drag.separatePanelSlot.height) || 80);
    return { indicator: ind, top: 0, bottom: h, height: h };
};

/** Drag inside indicator plot — move the indicator line up/down (Y offset, not panel resize). */
Chart.prototype.separatePanelLineDragStep = function(slot, dy) {
    if (!Number.isFinite(dy) || dy === 0) return;
    const resolved = (typeof this._resolveSeparatePanelSlotForDrag === 'function')
        ? this._resolveSeparatePanelSlotForDrag()
        : slot;
    const activeSlot = resolved || slot;
    if (!activeSlot || !activeSlot.indicator) return;
    const ind = activeSlot.indicator;
    let b0 = ind._panelBaseMin;
    let b1 = ind._panelBaseMax;
    if ((!Number.isFinite(b0) || !Number.isFinite(b1) || b1 <= b0)
        && this._panelSnapDomains && ind.id != null) {
        const snap = this._panelSnapDomains[ind.id];
        if (snap && Number.isFinite(snap.min) && Number.isFinite(snap.max) && snap.max > snap.min) {
            b0 = snap.min;
            b1 = snap.max;
        }
    }
    if (!Number.isFinite(b0) || !Number.isFinite(b1) || b1 <= b0) {
        const bases = typeof this._getIndicatorPanelAxisBases === 'function'
            ? this._getIndicatorPanelAxisBases(ind)
            : null;
        if (!bases) return;
        b0 = bases.b0;
        b1 = bases.b1;
    }
    if (!Number.isFinite(ind._panelBaseMin) || !Number.isFinite(ind._panelBaseMax)) {
        ind._panelBaseMin = b0;
        ind._panelBaseMax = b1;
    }
    this._ensureIndicatorPanelAxis(ind);
    const pa = ind._panelAxis;
    const baseSpan = b1 - b0;
    const z = Math.max(0.02, Math.min(200, pa.zoom || 1));
    const displaySpan = baseSpan / z;
    const h = Math.max(1, activeSlot.bottom - activeSlot.top);
    const valuePerPixel = displaySpan / h;
    pa.offset = (pa.offset || 0) + dy * valuePerPixel;
    if (typeof this.bumpIndicatorRenderVersion === 'function') {
        this.bumpIndicatorRenderVersion();
    }
};

/**
 * TradingView-style panel separator drag — document-level tracking (same pattern as compare-overlay).
 */
Chart.prototype._beginSeparatePanelResizeDrag = function(startEvent, handle) {
    if (!startEvent || !handle) return false;
    if (typeof startEvent.button === 'number' && startEvent.button !== 0) return false;
    if (this._separatePanelResizeDragActive || this._separatePanelLineDragActive) return false;
    if (typeof this.startSeparatePanelResize !== 'function') return false;
    const xy = typeof this._eventCanvasLocalXY === 'function'
        ? this._eventCanvasLocalXY(startEvent)
        : [0, startEvent.clientY];
    if (!this.startSeparatePanelResize(handle, xy[1])) return false;

    if (!this.drag) this.drag = {};
    this.drag.active = true;
    this.drag.type = 'separatePanelResize';
    this.drag.startX = startEvent.clientX;
    this.drag.startY = startEvent.clientY;
    this.drag.lastX = startEvent.clientX;
    this.drag.lastY = startEvent.clientY;
    if (typeof this._lockDragCursor === 'function') this._lockDragCursor('row-resize');
    if (typeof this._beginChartDragPointerTracking === 'function') {
        this._beginChartDragPointerTracking(startEvent);
    }

    const self = this;
    self._separatePanelResizeDragActive = true;

    const onMove = function(ev) {
        if (!self._separatePanelResizeDragActive) return;
        const [, my] = typeof self._eventCanvasLocalXY === 'function'
            ? self._eventCanvasLocalXY(ev)
            : [0, ev.clientY];
        if (typeof self.updateSeparatePanelResize === 'function') {
            self.updateSeparatePanelResize(my);
        }
        self.renderPending = false;
        if (typeof self.render === 'function') self.render();
        if (typeof ev.preventDefault === 'function') ev.preventDefault();
    };
    const onUp = function() {
        if (!self._separatePanelResizeDragActive) return;
        self._separatePanelResizeDragActive = false;
        document.removeEventListener('mousemove', onMove, true);
        document.removeEventListener('mouseup', onUp, true);
        document.removeEventListener('pointermove', onMove, true);
        document.removeEventListener('pointerup', onUp, true);
        document.removeEventListener('pointercancel', onUp, true);
        if (self._separatePanelResizeHandleEl) {
            self._separatePanelResizeHandleEl.classList.remove('dragging');
            self._separatePanelResizeHandleEl = null;
        }
        if (typeof self.finishSeparatePanelResize === 'function') {
            self.finishSeparatePanelResize();
        }
        if (typeof self._finishSeparatePanelResizeInteraction === 'function') {
            self._finishSeparatePanelResizeInteraction();
        }
        if (self.drag) {
            self.drag.active = false;
            self.drag.type = null;
        }
        self._separatePanelHoverHandle = null;
        if (typeof self._releaseDragCursor === 'function') self._releaseDragCursor();
    };

    document.addEventListener('mousemove', onMove, true);
    document.addEventListener('mouseup', onUp, true);
    document.addEventListener('pointermove', onMove, true);
    document.addEventListener('pointerup', onUp, true);
    document.addEventListener('pointercancel', onUp, true);

    if (typeof startEvent.preventDefault === 'function') startEvent.preventDefault();
    if (typeof startEvent.stopPropagation === 'function') startEvent.stopPropagation();
    if (typeof startEvent.stopImmediatePropagation === 'function') startEvent.stopImmediatePropagation();
    return true;
};

/** Drag inside indicator plot — move line vertically + pan time horizontally. */
Chart.prototype._beginSeparatePanelLineDrag = function(startEvent, slot) {
    if (!startEvent || !slot || !slot.indicator) return false;
    if (typeof startEvent.button === 'number' && startEvent.button !== 0) return false;
    if (this._separatePanelLineDragActive || this._separatePanelResizeDragActive) return false;
    if (this.drag && this.drag.active) return false;

    const self = this;
    if (!self.drag) self.drag = {};
    self.drag.active = true;
    self.drag.type = 'separatePanelLine';
    self.drag.separatePanelSlot = slot;
    self.drag.separatePanelIndicator = slot.indicator;
    self.drag.startX = startEvent.clientX;
    self.drag.startY = startEvent.clientY;
    self.drag.lastX = startEvent.clientX;
    self.drag.lastY = startEvent.clientY;
    if (typeof self._lockDragCursor === 'function') self._lockDragCursor('ns-resize');
    self._separatePanelLineDragActive = true;
    if (typeof self._snapshotSeparatePanelDomains === 'function') {
        self._snapshotSeparatePanelDomains();
    }

    const onMove = function(ev) {
        if (!self._separatePanelLineDragActive) return;
        const zd = typeof self._v9LayoutZoom === 'function' ? self._v9LayoutZoom() : 1;
        const dx = (ev.clientX - self.drag.lastX) / zd;
        const dy = (ev.clientY - self.drag.lastY) / zd;
        const effectiveDx = self.timeScale && self.timeScale.locked ? 0 : dx;
        if (effectiveDx !== 0) {
            self.offsetX += effectiveDx;
            if (typeof self._constrainOffsetDuringDrag === 'function') self._constrainOffsetDuringDrag();
        }
        if (dy !== 0 && typeof self.separatePanelLineDragStep === 'function') {
            const panelSlot = typeof self._resolveSeparatePanelSlotForDrag === 'function'
                ? self._resolveSeparatePanelSlotForDrag()
                : slot;
            self.separatePanelLineDragStep(panelSlot || slot, dy);
        }
        self.drag.lastX = ev.clientX;
        self.drag.lastY = ev.clientY;
        self.renderPending = false;
        if (typeof self.render === 'function') self.render();
        if (typeof ev.preventDefault === 'function') ev.preventDefault();
    };
    const onUp = function() {
        if (!self._separatePanelLineDragActive) return;
        self._separatePanelLineDragActive = false;
        self._panelSnapDomains = null;
        document.removeEventListener('mousemove', onMove, true);
        document.removeEventListener('mouseup', onUp, true);
        document.removeEventListener('pointermove', onMove, true);
        document.removeEventListener('pointerup', onUp, true);
        document.removeEventListener('pointercancel', onUp, true);
        if (typeof self._flushChartPanFrame === 'function') {
            self._flushChartPanFrame();
        } else {
            self.renderPending = false;
            if (typeof self.render === 'function') self.render();
        }
        if (self.drag) {
            self.drag.active = false;
            self.drag.type = null;
            self.drag.separatePanelSlot = null;
            self.drag.separatePanelIndicator = null;
        }
        if (typeof self._releaseDragCursor === 'function') self._releaseDragCursor();
        if (typeof self.scheduleChartViewSave === 'function') self.scheduleChartViewSave();
        if (typeof self.dispatchScrollSync === 'function') self.dispatchScrollSync(true);
    };

    document.addEventListener('mousemove', onMove, true);
    document.addEventListener('mouseup', onUp, true);
    document.addEventListener('pointermove', onMove, true);
    document.addEventListener('pointerup', onUp, true);
    document.addEventListener('pointercancel', onUp, true);

    if (typeof startEvent.preventDefault === 'function') startEvent.preventDefault();
    if (typeof startEvent.stopPropagation === 'function') startEvent.stopPropagation();
    if (typeof startEvent.stopImmediatePropagation === 'function') startEvent.stopImmediatePropagation();
    return true;
};

/** Draggable separator grips on #chartWrapper (above overlay drag-zones). */
Chart.prototype._syncSeparatePanelSeparatorHandles = function(m) {
    const canvas = this.ctx && this.ctx.canvas;
    const wrapper = canvas ? canvas.parentElement : null;
    if (!wrapper) return;
    const handles = this.separatePanelInfo && this.separatePanelInfo.resizeHandles;
    if (!handles || !handles.length) {
        wrapper.querySelectorAll('.talaria-separate-panel-separator').forEach(function(n) { n.remove(); });
        return;
    }
    const self = this;
    const hitH = 14;
    const plotLeft = m.l;
    const plotWidth = Math.max(1, this.w - m.l);
    handles.forEach(function(handle, idx) {
        if (!handle || !Number.isFinite(handle.y)) return;
        let bar = wrapper.querySelector('.talaria-separate-panel-separator[data-sp-sep="' + idx + '"]');
        if (!bar) {
            bar = document.createElement('div');
            bar.className = 'panel-resize-handle horizontal talaria-separate-panel-separator';
            bar.setAttribute('data-sp-sep', String(idx));
            bar.title = 'Drag to resize panel';
            const onDown = function(ev) {
                if (typeof ev.button === 'number' && ev.button !== 0) return;
                const h = bar._talariaResizeHandle;
                if (!h || typeof self._beginSeparatePanelResizeDrag !== 'function') return;
                self._separatePanelResizeHandleEl = bar;
                bar.classList.add('dragging');
                self._beginSeparatePanelResizeDrag(ev, h);
            };
            bar.addEventListener('mousedown', onDown);
            bar.addEventListener('pointerdown', onDown);
            wrapper.appendChild(bar);
        }
        bar._talariaResizeHandle = handle;
        const hover = !!(self._separatePanelHoverHandle && Math.abs(self._separatePanelHoverHandle.y - handle.y) <= 2);
        bar.style.cssText = [
            'position:absolute',
            'left:' + plotLeft + 'px',
            'top:' + (handle.y - hitH / 2) + 'px',
            'width:' + plotWidth + 'px',
            'height:' + hitH + 'px',
            'z-index:210',
            'pointer-events:auto',
            'cursor:row-resize',
            'background:' + (hover ? 'rgba(106,138,255,0.18)' : 'rgba(106,138,255,0.04)'),
            'border-top:1px solid ' + (hover ? 'rgba(106,138,255,0.55)' : 'rgba(120,123,134,0.35)'),
            'transform:none',
            'touch-action:none'
        ].join(';');
    });
    wrapper.querySelectorAll('.talaria-separate-panel-separator').forEach(function(bar) {
        const idx = Number(bar.getAttribute('data-sp-sep'));
        if (!Number.isFinite(idx) || idx >= handles.length) bar.remove();
    });
};

Chart.prototype._syncSeparatePanelResizeGrips = function(_overlay, m) {
    if (typeof this._syncSeparatePanelSeparatorHandles === 'function') {
        this._syncSeparatePanelSeparatorHandles(m);
    }
};

Chart.prototype._clampVolumePanelHeight = function(heightPx) {
    const m = this.margin || { t: 0, b: 0 };
    const ch = Math.max(0, (this.h || 0) - m.t - m.b);
    const maxH = Math.round(ch * 0.35);
    return Math.max(MIN_SEPARATE_PANEL_HEIGHT, Math.min(maxH || MIN_SEPARATE_PANEL_HEIGHT, Math.round(heightPx)));
};

Chart.prototype._applyVolumePanelHeightPx = function(heightPx) {
    const nextH = this._clampVolumePanelHeight(heightPx);
    const m = this.margin || { t: 0, b: 0 };
    const ch = Math.max(1, (this.h || 0) - m.t - m.b);
    this.volumeHeight = Math.max(0.08, Math.min(0.35, nextH / ch));
    return nextH;
};

Chart.prototype.startSeparatePanelResize = function(handle, startY) {
    if (!handle || !this.separatePanelInfo || !Array.isArray(this.separatePanelInfo.panelHeights)) return false;
    const usesVolume = !!(handle.isVolume || handle.isVolumePair);
    const baseVolumeHeight = usesVolume ? this._getVolumePanelHeight() : 0;
    this._separatePanelResize = {
        handleType: handle.type || 'pair',
        handleIndex: handle.index,
        isVolume: !!handle.isVolume,
        isVolumePair: !!handle.isVolumePair,
        startY: startY,
        baseHeights: this.separatePanelInfo.panelHeights.slice(),
        activeHeights: this.separatePanelInfo.panelHeights.slice(),
        baseVolumeHeight: baseVolumeHeight,
        activeVolumeHeight: baseVolumeHeight
    };
    return true;
};

Chart.prototype.updateSeparatePanelResize = function(currentY) {
    if (!this._separatePanelResize || !this.separatePanelInfo || !Array.isArray(this.separatePanelInfo.indicators)) {
        return false;
    }
    const state = this._separatePanelResize;
    const baseHeights = state.baseHeights || state.activeHeights || [];
    let heights = baseHeights.slice();
    const dy = currentY - state.startY;
    const baseVolumeHeight = state.baseVolumeHeight != null ? state.baseVolumeHeight : (state.activeVolumeHeight || 0);
    let activeVolumeHeight = baseVolumeHeight;

    // Stack pair dividers: drag up shrinks panel above, grows panel below (+dy).
    // Top stack border (price↔panels / volume↔first ind): opposite anchor (-dy).
    if (state.handleType === 'top') {
        if (state.isVolume) {
            activeVolumeHeight = Math.max(
                MIN_SEPARATE_PANEL_HEIGHT,
                Math.min(
                    Math.round(this._getMaxSeparatePanelStackHeight() * 0.35),
                    baseVolumeHeight - dy
                )
            );
        } else {
            const topIdx = state.handleIndex;
            if (topIdx < 0 || topIdx >= heights.length) return false;
            const otherSum = heights.reduce(function(s, h, i) {
                return i === topIdx ? s : s + h;
            }, 0) + activeVolumeHeight;
            const maxTop = Math.max(MIN_SEPARATE_PANEL_HEIGHT, this._getMaxSeparatePanelStackHeight() - otherSum);
            let nextTopHeight = baseHeights[topIdx] - dy;
            nextTopHeight = Math.max(MIN_SEPARATE_PANEL_HEIGHT, Math.min(maxTop, nextTopHeight));
            heights[topIdx] = nextTopHeight;
        }
    } else if (state.isVolumePair) {
        if (heights.length === 0) return false;
        const pairTotal = baseVolumeHeight + baseHeights[0];
        let nextVolume = baseVolumeHeight - dy;
        nextVolume = Math.max(MIN_SEPARATE_PANEL_HEIGHT, Math.min(pairTotal - MIN_SEPARATE_PANEL_HEIGHT, nextVolume));
        activeVolumeHeight = nextVolume;
        heights[0] = pairTotal - activeVolumeHeight;
    } else {
        const upperIdx = state.handleIndex;
        const lowerIdx = state.handleIndex + 1;
        if (upperIdx < 0 || lowerIdx >= heights.length) return false;

        const pairTotal = baseHeights[upperIdx] + baseHeights[lowerIdx];
        let nextUpper = baseHeights[upperIdx] + dy;
        nextUpper = Math.max(MIN_SEPARATE_PANEL_HEIGHT, Math.min(pairTotal - MIN_SEPARATE_PANEL_HEIGHT, nextUpper));
        const nextLower = pairTotal - nextUpper;

        heights[upperIdx] = nextUpper;
        heights[lowerIdx] = nextLower;
    }

    state.activeHeights = heights;
    state.activeVolumeHeight = activeVolumeHeight;
    this.separateIndicatorPanelHeight = heights.reduce(function(sum, h) { return sum + h; }, 0) + activeVolumeHeight;
    return true;
};

Chart.prototype.finishSeparatePanelResize = function() {
    if (!this._separatePanelResize || !this.separatePanelInfo || !Array.isArray(this.separatePanelInfo.indicators)) return;
    let finalHeights = this._separatePanelResize.activeHeights || this._separatePanelResize.baseHeights;
    let finalVol = this._separatePanelResize.activeVolumeHeight || 0;
    const layout = this._clampSeparatePanelLayout(finalHeights, finalVol);
    finalHeights = layout.panelHeights;
    const volOut = layout.volumePanelHeight > 0 ? layout.volumePanelHeight : finalVol;
    if (volOut > 0) {
        this._applyVolumePanelHeightPx(volOut);
    }
    this._persistSeparatePanelHeights(this.separatePanelInfo.indicators, finalHeights, true);
    this._separatePanelResize = null;
};

// Render separate panel indicators (like ATR, ADR) in a sub-panel below price chart
Chart.prototype.renderSeparatePanelIndicators = function(opts) {
    opts = opts || {};
    const panFast = opts.panFast === true;
    this._panelRenderFast = panFast;
    try {
    if (!this.indicators || !this.indicators.active) {
        return;
    }
    if (!this.data || this.data.length === 0) {
        return;
    }
    
    const separateIndicators = this._getVisibleSeparateIndicators();
    const volumeInSeparatePanel = typeof this._volumeRendersInSeparatePanel === 'function'
        && this._volumeRendersInSeparatePanel();
    
    if (separateIndicators.length === 0 && !volumeInSeparatePanel) {
        const _cv = this.ctx && this.ctx.canvas;
        const _wp = _cv ? _cv.parentElement : null;
        if (_wp) {
            const _ol = _wp.querySelector('#separatePanelsOverlay');
            if (_ol) {
                _ol.innerHTML = '';
                _ol._structureKey = null;
            }
            _wp.querySelectorAll('.talaria-separate-panel-separator').forEach(function(n) { n.remove(); });
        }
        this.separatePanelInfo = null;
        this._separatePanelResize = null;
        this.separateIndicatorPanelHeight = 0;
        return;
    }
    
    const ctx = this.ctx;
    const m = this.margin;
    const totalHeight = this.h;
    const chartWidth = this.w - m.l - m.r;
    const panelAxisLeft = this.w - m.r;
    const panelFullRight = this.w;
    
    let panelHeights = this._getSeparatePanelHeights(separateIndicators);
    if (this._separatePanelResize && Array.isArray(this._separatePanelResize.activeHeights) &&
        this._separatePanelResize.activeHeights.length === panelHeights.length) {
        panelHeights = this._separatePanelResize.activeHeights.slice();
    }
    const volumeIndicator = this._volumeRendersInSeparatePanel() ? this._getActiveVolumeIndicator() : null;
    let volumePanelHeight = volumeIndicator ? this._getVolumePanelHeightForLayout() : 0;
    if (!this._separatePanelResize) {
        const layoutClamp = this._clampSeparatePanelLayout(panelHeights, volumePanelHeight);
        panelHeights = layoutClamp.panelHeights;
        volumePanelHeight = volumeIndicator ? layoutClamp.volumePanelHeight : 0;
    }
    let totalPanelHeight = panelHeights.reduce((sum, h) => sum + h, 0) + volumePanelHeight;

    // Track total height so calculateScales can reserve the right amount of space
    this.separateIndicatorPanelHeight = totalPanelHeight;

    // Bottom of the indicator stack is always the inner chart bottom (y = h - m.b), i.e. just above
    // the time-axis margin — same as yScale/volumeScale layout in calculateScales().
    // (Volume sits above this band; do NOT subtract volume height here — that misaligned slots.)
    const panelBottom = totalHeight - m.b;
    const panelTop = panelBottom - totalPanelHeight;
    
    const _isLightBg = document.body.classList.contains('light-mode');

    // Draw full panel background using the same chart background color
    // so separate indicator panes stay visually synced with the main chart.
    const panelBackgroundColor =
        (this.chartSettings && this.chartSettings.backgroundColor) ||
        (typeof getComputedStyle === 'function'
            ? (getComputedStyle(document.documentElement).getPropertyValue('--sp-bg') || '').trim()
            : '') ||
        '#131722';
    ctx.fillStyle = panelBackgroundColor;
    // Extend separate panels to the far right so each panel owns its Y-axis strip.
    ctx.fillRect(m.l, panelTop, panelFullRight - m.l, totalPanelHeight);
    // Dedicated right Y-axis strip for separate indicator panes.
    const axisStripBg = _isLightBg ? 'rgba(242, 245, 251, 0.92)' : 'rgba(10, 14, 28, 0.92)';
    ctx.fillStyle = axisStripBg;
    ctx.fillRect(panelAxisLeft, panelTop, panelFullRight - panelAxisLeft, totalPanelHeight);

    // Divider between indicator plot and indicator Y-axis strip.
    ctx.strokeStyle = 'rgba(120, 123, 134, 0.42)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(panelAxisLeft, panelTop);
    ctx.lineTo(panelAxisLeft, panelBottom);
    ctx.stroke();

    // Clip all indicator geometry to this stack so lines/labels never bleed into the time axis.
    ctx.save();
    ctx.beginPath();
    ctx.rect(m.l, panelTop, panelFullRight - m.l, totalPanelHeight);
    ctx.clip();
    
    // Outer top separator — solid divider line matching panel borders
    const panelResizeActive = !!(this._separatePanelResize);
    const hoverHandleY = !panelResizeActive && this._separatePanelHoverHandle && Number.isFinite(this._separatePanelHoverHandle.y)
        ? this._separatePanelHoverHandle.y
        : null;
    this._drawSeparatePanelResizeSeparator(ctx, m, panelTop, panelFullRight, {
        isLightBg: _isLightBg,
        isHover: hoverHandleY !== null && Math.abs(hoverHandleY - panelTop) <= 2,
        strongTop: true
    });
    
    // Visible indices (set in render() from plot left/right); keep in sync with overlay drawIndicators.
    const visibleStart = Math.max(0, Math.floor(Number.isFinite(this.visibleStartIndex) ? this.visibleStartIndex : 0));
    const visibleEnd = Math.min(this.data.length, Math.ceil(Number.isFinite(this.visibleEndIndex) ? this.visibleEndIndex : this.data.length));
    
    const panelSlots = [];
    let slotTopCursor = panelTop;
    const stackIndicators = [];

    // Volume is always the first panel directly under the main price chart.
    if (volumeIndicator && volumePanelHeight > 0) {
        panelSlots.push({
            index: 0,
            indicator: volumeIndicator,
            top: slotTopCursor,
            bottom: slotTopCursor + volumePanelHeight,
            height: volumePanelHeight,
            isVolumeSlot: true,
            isTopBelowMainChart: true
        });
        stackIndicators.push(volumeIndicator);
        slotTopCursor += volumePanelHeight;
    }

    separateIndicators.forEach(function(indicator, idx) {
        const slotHeight = panelHeights[idx];
        panelSlots.push({
            index: volumeIndicator ? idx + 1 : idx,
            indicator: indicator,
            top: slotTopCursor,
            bottom: slotTopCursor + slotHeight,
            height: slotHeight,
            isTopBelowMainChart: !volumeIndicator && idx === 0
        });
        stackIndicators.push(indicator);
        slotTopCursor += slotHeight;
    });

    // Time-aligned vertical grid — continuous with main chart (drawn after bg, under plots).
    if (typeof this._drawSeparatePanelVerticalTimeGrid === 'function') {
        this._drawSeparatePanelVerticalTimeGrid(ctx, m, panelTop, panelBottom, panelAxisLeft);
    }

    // Draw each indicator in its own slot (top-down: volume first, then oscillators)
    panelSlots.forEach((slot) => {
        const indicator = slot.indicator;
        const idx = slot.index;
        if (slot.isVolumeSlot || indicator.type === 'volume' || indicator.isVolume) {
            const indBottom = slot.bottom;
            const indTop = slot.top;
            const panelHeight = slot.height;
            if (idx > 0) {
                this._drawSeparatePanelResizeSeparator(ctx, m, indTop, panelFullRight, {
                    isLightBg: _isLightBg,
                    isHover: hoverHandleY !== null && Math.abs(hoverHandleY - indTop) <= 2,
                    strongTop: false
                });
            }
            ctx.fillStyle = axisStripBg;
            ctx.fillRect(panelAxisLeft, indTop, panelFullRight - panelAxisLeft, panelHeight);
            this._renderVolumePanel(ctx, m, indTop, indBottom, panelHeight, indicator, visibleStart, visibleEnd);
            return;
        }

        // Per-indicator slot boundaries
        const indBottom = slot.bottom;
        const indTop = slot.top;
        const panelHeight = slot.height;

        // Separator between slots — soft divider at top edge (below previous slot)
        if (idx > 0) {
            this._drawSeparatePanelResizeSeparator(ctx, m, indTop, panelFullRight, {
                isLightBg: _isLightBg,
                isHover: hoverHandleY !== null && Math.abs(hoverHandleY - indTop) <= 2,
                strongTop: false
            });
        }

        // Give every separate pane its own visible right axis background block.
        ctx.fillStyle = axisStripBg;
        ctx.fillRect(panelAxisLeft, indTop, panelFullRight - panelAxisLeft, panelHeight);
        
        let indicatorData = this.indicators.data[indicator.id];
        if (!indicatorData) return;
        if (indicator.hidePlot === true) {
            indicator._axisLabelTags = [];
            indicator._axisLabelY = null;
            indicator._axisLabelText = '';
            indicator._axisLabelColor = '';
            indicator._displayLabel = '';
            return;
        }
        if (indicator.type === 'obv' && (!indicatorData.obv || !Array.isArray(indicatorData.obv) || indicatorData.obv.length === 0)) {
            if (typeof this.recalculateIndicators === 'function') {
                this.recalculateIndicators();
            }
            indicatorData = this.indicators.data[indicator.id];
            if (!indicatorData || !indicatorData.obv || !indicatorData.obv.length) return;
        }

        this._withSeparatePanelSlotClip(ctx, m.l, indTop, indBottom, panelFullRight, () => {
        // Type-specific rendering for multi-series indicators
        if (indicator.type === 'macd' || indicator.type === 'ppo') {
            indicator.type = 'macd';
            this._renderMACDPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'stoch' || indicator.type === 'stochastic') {
            this._renderStochPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'stochrsi') {
            this._renderStochPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'adx') {
            this._renderADXPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'aroon') {
            this._renderAroonPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'rsi') {
            this._renderRsiPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'cci') {
            this._renderCciPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'mom' || indicator.type === 'momentum') {
            this._renderMomPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'roc') {
            this._renderRocPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'willr') {
            this._renderWilliamsRPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'mfi') {
            this._renderMFIPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'cmf') {
            this._renderCMFPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'dpo') {
            this._renderDpoPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'ao') {
            this._renderAOPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'vortex') {
            this._renderVortexPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'elderray') {
            this._renderElderRayPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'cotnet' || indicator.isCotNet) {
            this._renderCotNetPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'uo') {
            this._renderUltimateOscillatorPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'massindex') {
            this._renderMassIndexPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'coppock') {
            this._renderCoppockPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'atr') {
            this._renderAtrPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'adr') {
            this._renderAdrPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'stddev') {
            this._renderStddevPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'trix') {
            this._renderTrixPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'rvi') {
            this._renderRviPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'obv') {
            this._renderObvPanel(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        } else if (indicator.type === 'custom') {
            this._renderCustomSeparatePanelSlot(ctx, m, indTop, indBottom, panelHeight, indicator, indicatorData, visibleStart, visibleEnd);
            return;
        }

        // Get values array - skip non-array data
        if (!Array.isArray(indicatorData)) return;
        let values = indicatorData;
        if (!values || values.length === 0) return;
        
        // Find min/max in visible range for proper scaling
        let min = Infinity, max = -Infinity;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val !== null && val !== undefined && !isNaN(val)) {
                min = Math.min(min, val);
                max = Math.max(max, val);
            }
        }
        
        if (min === Infinity || max === -Infinity) return;
        
        // Add 10% padding to range
        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;

        const dom = this._finalizePanelRange(indicator, min, max);
        min = dom.min;
        max = dom.max;
        
        const vSpan = Math.max(1e-12, max - min);
        // Scale function for Y axis (clamp to slot so strokes never leak)
        const scaleY = (val) => {
            if (val === null || val === undefined) return null;
            let y = indBottom - 5 - ((val - min) / vSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return Math.max(indTop + 2, Math.min(indBottom - 2, y));
        };
        
        const color = indicator.style.color || '#ff6d00';
        
        // Draw Y-axis grid lines and labels (match main chart grid settings)
        ctx.font = '10px Roboto';
        ctx.textAlign = 'right';
        const numGridLines = panFast ? 2 : 4;
        const horzGridOn = typeof this._applyChartGridStrokeStyle === 'function'
            && this._applyChartGridStrokeStyle(ctx, 'horizontal');
        for (let i = 0; i <= numGridLines; i++) {
            const val = min + (max - min) * (i / numGridLines);
            const y = scaleY(val);
            
            if (horzGridOn) {
                ctx.beginPath();
                ctx.moveTo(m.l, y);
                ctx.lineTo(panelAxisLeft, y);
                ctx.stroke();
            }
            
            ctx.fillStyle = '#787b86';
            if (!panFast) ctx.fillText(val.toFixed(2), this.w - 6, y + 3);
        }
        if (horzGridOn) ctx.setLineDash([]);
        
        // Draw the indicator plot (TradingView-style line / step / area / columns / …)
        this.drawLineIndicator(values, color, indicator.style.lineWidth || 2, visibleStart, visibleEnd, indicator.style.lineStyle, {
            yScale: scaleY,
            baselineY: indBottom - 2,
            panelTop: indTop,
            panelBottom: indBottom
        });

        // Reference lines for oscillators
        if (indicator.type === 'seasonality') {
            const zy = scaleY(0);
            if (zy !== null && zy > indTop && zy < indBottom) {
                ctx.strokeStyle = 'rgba(255,255,255,0.18)';
                ctx.lineWidth = 1;
                ctx.setLineDash([3, 3]);
                ctx.beginPath();
                ctx.moveTo(m.l, zy);
                ctx.lineTo(this.w, zy);
                ctx.stroke();
                ctx.setLineDash([]);
                ctx.fillStyle = 'rgba(255,255,255,0.35)';
                ctx.font = '9px Roboto';
                ctx.textAlign = 'right';
                ctx.fillText('0', this.w - 6, zy - 2);
            }
            ctx.textAlign = 'left';
        }

        // Get current value (find the last non-null value in visible range)
        let currentValue = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && values[i] !== undefined && !isNaN(values[i])) {
                currentValue = values[i];
                break;
            }
        }
        // Fallback to last value in entire array if nothing in visible range
        if (currentValue === null) {
            for (let i = values.length - 1; i >= 0; i--) {
                if (values[i] !== null && values[i] !== undefined && !isNaN(values[i])) {
                    currentValue = values[i];
                    break;
                }
            }
        }
        
        // Get value at mouse position if hovering, otherwise use current value
        let displayValue = currentValue;
        if (this.mouseX && this.mouseX >= m.l && this.mouseX <= this.w - m.r) {
            const hoverIndex = Math.floor(this.pixelToDataIndex ? this.pixelToDataIndex(this.mouseX) : -1);
            if (hoverIndex >= 0 && hoverIndex < values.length && 
                values[hoverIndex] !== null && values[hoverIndex] !== undefined && !isNaN(values[hoverIndex])) {
                displayValue = values[hoverIndex];
            }
        }
        
        // Store for HTML overlay label
        indicator._displayColor = color;
        indicator._displayLabel = displayValue !== null && displayValue !== undefined ? displayValue.toFixed(4) : '—';
        
        indicator._axisLabelTags = [];
        // Draw current value label on right axis
        if (currentValue !== null && currentValue !== undefined && !isNaN(currentValue)) {
            const currentY = scaleY(currentValue);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = currentValue.toFixed(2);
            indicator._axisLabelColor = color;
            indicator._axisLabelTags = [{
                y: currentY,
                text: currentValue.toFixed(2),
                color: color
            }];
            
            // Dashed line at current value
            ctx.strokeStyle = color;
            ctx.lineWidth = 1;
            ctx.setLineDash([3, 3]);
            ctx.beginPath();
            ctx.moveTo(m.l, currentY);
            ctx.lineTo(this.w, currentY);
            ctx.stroke();
            ctx.setLineDash([]);
            
            // Value label box on right
            const labelWidth = 50;
            const labelHeight = 16;
            ctx.fillStyle = color;
            ctx.fillRect(this.w - m.r + 2, currentY - labelHeight/2, labelWidth, labelHeight);
            
            // Value text
            ctx.fillStyle = '#000';
            ctx.font = 'bold 10px Roboto';
            ctx.textAlign = 'center';
            ctx.fillText(currentValue.toFixed(2), this.w - m.r + 2 + labelWidth/2, currentY + 4);
        }
        });
    });
    
    // Store panel info for mouse interactions (full stacked area)
    this.separatePanelInfo = {
        top: panelTop,
        bottom: panelBottom,
        height: totalPanelHeight,
        indicators: separateIndicators,
        panelHeights: panelHeights,
        panelSlots: panelSlots,
        resizeHandles: (function() {
            const handles = [];
            const firstSlot = panelSlots[0];
            handles.push({
                type: 'top',
                index: 0,
                y: panelTop,
                isVolume: !!(firstSlot && firstSlot.isVolumeSlot)
            });
            for (let i = 0; i < panelSlots.length - 1; i++) {
                const slot = panelSlots[i];
                handles.push({
                    type: 'pair',
                    index: slot.isVolumeSlot ? 0 : (volumeIndicator ? slot.index - 1 : slot.index),
                    y: slot.bottom,
                    isVolumePair: !!slot.isVolumeSlot
                });
            }
            return handles;
        })()
    };
    
    // Separate-panel crosshair UI is DOM-driven from updateCrosshair (mousemove), not canvas paint.
    
    ctx.textAlign = 'left'; // Reset

    ctx.restore(); // end indicator-stack clip

    if (panelResizeActive) {
        this._repositionSeparatePanelOverlay(panelSlots, m);
    } else if (!panelResizeActive) {
        this._applyCrosshairIndicatorDisplays(stackIndicators);
        this._updateSeparatePanelLabels(panelSlots, stackIndicators, m);
    }
    } finally {
        this._panelRenderFast = false;
    }
};

// Draw crosshair and value for separate panel indicators
Chart.prototype.drawSeparatePanelCrosshair = function(ctx, m, panelTop, panelBottom, panelHeight, indicators, min, max) {
    if (!this.mouseX || !this.mouseY) return;
    
    const mouseX = this.mouseX;
    const mouseY = this.mouseY;
    
    // Draw vertical crosshair line
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(mouseX, panelTop);
    ctx.lineTo(mouseX, panelBottom);
    ctx.stroke();
    
    // Draw horizontal crosshair line
    ctx.beginPath();
    ctx.moveTo(m.l, mouseY);
    ctx.lineTo(this.w, mouseY);
    ctx.stroke();
    ctx.setLineDash([]);
    
    // Calculate value at mouse Y position
    const valueAtMouse = min + ((panelBottom - 5 - mouseY) / (panelHeight - 10)) * (max - min);
    
    // Draw value label at mouse position
    ctx.fillStyle = '#363a45';
    ctx.fillRect(this.w - m.r + 2, mouseY - 8, 50, 16);
    ctx.fillStyle = '#d1d4dc';
    ctx.font = '10px Roboto';
    ctx.textAlign = 'center';
    ctx.fillText(valueAtMouse.toFixed(2), this.w - m.r + 27, mouseY + 4);
    
    // Find index at mouse X and show indicator value
    const dataIndex = this.pixelToDataIndex ? this.pixelToDataIndex(mouseX) : null;
    if (dataIndex !== null && dataIndex >= 0) {
        indicators.forEach(indicator => {
            const values = this.indicators.data[indicator.id];
            if (values && values[Math.floor(dataIndex)] !== null && values[Math.floor(dataIndex)] !== undefined) {
                const val = values[Math.floor(dataIndex)];
                const color = indicator.style.color || '#ff6d00';
                
                // Show value tooltip near mouse
                ctx.fillStyle = 'rgba(19, 23, 34, 0.9)';
                ctx.fillRect(mouseX + 10, mouseY - 20, 80, 18);
                ctx.strokeStyle = color;
                ctx.lineWidth = 1;
                ctx.strokeRect(mouseX + 10, mouseY - 20, 80, 18);
                ctx.fillStyle = color;
                ctx.font = '11px Roboto';
                ctx.textAlign = 'left';
                ctx.fillText(`${indicator.name}: ${val.toFixed(2)}`, mouseX + 14, mouseY - 7);
            }
        });
    }
    
    ctx.textAlign = 'left';
};

Chart.prototype._getCrosshairBarIndex = function() {
    if (!this.data || !this.data.length) return -1;
    const replay = this.replaySystem;
    if (replay && replay.isActive) {
        const m = this.margin || { l: 0, r: 0, t: 0, b: 0 };
        const mx = Number(this.mouseX);
        const my = Number(this.mouseY);
        const inPlot = Number.isFinite(mx) && Number.isFinite(my)
            && mx >= m.l && mx <= this.w - m.r
            && my >= m.t && my <= this.h - m.b;
        if (inPlot && Number.isFinite(this.hoverIndex) && this.hoverIndex >= 0 && this.hoverIndex < this.data.length) {
            return Math.floor(this.hoverIndex);
        }
        return this.data.length - 1;
    }
    if (Number.isFinite(this.hoverIndex) && this.hoverIndex >= 0 && this.hoverIndex < this.data.length) {
        return Math.floor(this.hoverIndex);
    }
    if (Number.isFinite(this.mouseX) && typeof this.pixelToDataIndex === 'function') {
        const idx = Math.round(this.pixelToDataIndex(this.mouseX));
        if (idx >= 0 && idx < this.data.length) return idx;
    }
    return this.data.length - 1;
};

/** During replay, keep OHLC / volume legend values on the advancing playhead bar. */
Chart.prototype._syncReplayPlayheadCrosshairValues = function() {
    if (!this.replaySystem || !this.replaySystem.isActive) return;
    if (!this.data || !this.data.length) return;
    this.hoverIndex = this.data.length - 1;
    if (typeof this.syncCrosshairIndicatorValues === 'function') {
        this.syncCrosshairIndicatorValues();
    }
    const idSuffix = (this.panelIndex !== undefined && this.panelIndex !== 0) ? this.panelIndex : '';
    const ohlcDiv = typeof document !== 'undefined' ? document.getElementById('ohlcIndicators' + idSuffix) : null;
    if (ohlcDiv) {
        if (isRc6IndicatorReplayUiSyncV2Enabled()
            && typeof global.applyReplayLegendLightweightSync === 'function') {
            global.applyReplayLegendLightweightSync(this);
        } else if (ohlcDiv.childElementCount === 0
            && typeof this.updateOHLCIndicators === 'function') {
            this.updateOHLCIndicators();
        }
    }

    let candle = null;
    const replay = this.replaySystem;
    const ac = replay.animatingCandle;
    const tickReplay = typeof replay.getPlaybackMode === 'function'
        && replay.getPlaybackMode() === 'tick';
    if (ac && !replay.fastMode && tickReplay) {
        candle = {
            t: ac.t,
            o: ac.open,
            h: ac.high,
            l: ac.low,
            c: ac.close,
            v: ac.volume || 0,
        };
    } else {
        const barIdx = this.data.length - 1;
        candle = typeof this.getDisplayCandle === 'function'
            ? this.getDisplayCandle(barIdx)
            : this.data[barIdx];
    }
    if (candle && typeof this.updateOHLCFromCandle === 'function') {
        this.updateOHLCFromCandle(candle);
    }
};

Chart.prototype._pickFiniteSeriesValue = function(arr, barIdx) {
    if (!Array.isArray(arr) || barIdx < 0) return null;
    let i = Math.min(barIdx, arr.length - 1);
    while (i >= 0) {
        const v = arr[i];
        if (v !== null && v !== undefined && !isNaN(v) && Number.isFinite(Number(v))) return Number(v);
        i--;
    }
    return null;
};

/** Primary plotted numeric value at bar (for axis tag Y positioning). */
Chart.prototype._pickIndicatorPlotValue = function(indicator, barIdx) {
    if (!indicator || barIdx < 0) return null;
    const store = this.indicators && this.indicators.data ? this.indicators.data[indicator.id] : null;
    if (!store) return null;
    const type = indicator.type;
    if (type === 'rsi' && store.rsi) return this._pickFiniteSeriesValue(store.rsi, barIdx);
    if (type === 'cci' && store.cci) return this._pickFiniteSeriesValue(store.cci, barIdx);
    if (type === 'macd' && store.macd) return this._pickFiniteSeriesValue(store.macd, barIdx);
    if ((type === 'stoch' || type === 'stochastic') && store.k) return this._pickFiniteSeriesValue(store.k, barIdx);
    if (type === 'aroon' && store.up) return this._pickFiniteSeriesValue(store.up, barIdx);
    if (type === 'vortex' && store.viPlus) return this._pickFiniteSeriesValue(store.viPlus, barIdx);
    if (Array.isArray(store)) return this._pickFiniteSeriesValue(store, barIdx);
    const keys = ['cci', 'k', 'fast', 'upper', 'middle', 'lower'];
    for (let ki = 0; ki < keys.length; ki++) {
        const k = keys[ki];
        if (!Array.isArray(store[k])) continue;
        const v = this._pickFiniteSeriesValue(store[k], barIdx);
        if (v !== null) return v;
    }
    return null;
};

/** Map indicator domain value to canvas Y inside a separate panel slot. */
Chart.prototype._panelValueToSlotY = function(indicator, slot, value) {
    if (!indicator || !slot || !Number.isFinite(value)) return null;
    const b0 = Number(indicator._panelBaseMin);
    const b1 = Number(indicator._panelBaseMax);
    if (!Number.isFinite(b0) || !Number.isFinite(b1) || b1 <= b0) return null;
    let d0 = b0;
    let d1 = b1;
    if (typeof this._applyIndicatorPanelDomain === 'function') {
        const dom = this._applyIndicatorPanelDomain(b0, b1, indicator);
        if (dom && Number.isFinite(dom.min) && Number.isFinite(dom.max) && dom.max > dom.min) {
            d0 = dom.min;
            d1 = dom.max;
        }
    }
    const span = Math.max(1e-12, d1 - d0);
    const y = slot.bottom - 5 - ((value - d0) / span) * (slot.height - 10);
    if (!Number.isFinite(y)) return null;
    return Math.max(slot.top + 2, Math.min(slot.bottom - 2, y));
};

/** Live axis pill + cursor tooltip for separate indicator panels (mousemove, not canvas paint). */
Chart.prototype._syncSeparatePanelCrosshairUi = function(opts) {
    opts = opts || {};
    const canvas = this.ctx && this.ctx.canvas;
    const wrapper = canvas ? canvas.parentElement : null;
    const overlay = wrapper ? wrapper.querySelector('#separatePanelsOverlay') : null;
    if (!overlay) return;

    let liveAxis = overlay.querySelector('[data-talaria-sp-live-axis]');
    let tip = overlay.querySelector('[data-talaria-sp-crosshair-tip]');
    const setStaticAxisTagsVisible = function(visible) {
        overlay.querySelectorAll('[data-talaria-sp-axis-tag]').forEach(function(n) {
            n.style.visibility = visible ? '' : 'hidden';
        });
    };
    const hide = function() {
        if (liveAxis) liveAxis.style.display = 'none';
        if (tip) tip.style.display = 'none';
        setStaticAxisTagsVisible(true);
    };

    if (!opts.show || !opts.slot || !opts.indicator || opts.barIdx < 0) {
        hide();
        return;
    }

    let indicatorAxisAnchorFixOn = true;
    try {
        indicatorAxisAnchorFixOn = typeof window === 'undefined'
            || window.__TALARIA_DISABLE_INDICATOR_AXIS_LABEL_ANCHOR_FIX !== true;
    } catch (_) { indicatorAxisAnchorFixOn = true; }

    const ind = opts.indicator;
    const slot = opts.slot;
    const fmt = typeof this._formatIndicatorValueAtBar === 'function'
        ? this._formatIndicatorValueAtBar(ind, opts.barIdx)
        : null;

    // Tranche G (TAL-01619): keep the right-axis indicator pill on the last-bar /
    // scale anchor from render(); crosshair may still update the legend tooltip.
    if (indicatorAxisAnchorFixOn) {
        setStaticAxisTagsVisible(true);
        if (liveAxis) liveAxis.style.display = 'none';
        if (!fmt) {
            if (tip) tip.style.display = 'none';
            return;
        }
        const lineX = Number.isFinite(opts.lineX) ? opts.lineX : 0;
        const cursorY = Number.isFinite(opts.y) ? opts.y : slot.top + slot.height * 0.5;
        const indName = ind.name || ind.type || 'Indicator';
        const bg = fmt.color || ind._displayColor || (ind.style && ind.style.color) || '#2962ff';
        if (!tip) {
            tip = document.createElement('div');
            tip.setAttribute('data-talaria-sp-crosshair-tip', '1');
            overlay.appendChild(tip);
        }
        tip.textContent = indName + ': ' + ((fmt.text !== undefined && fmt.text !== null && fmt.text !== '')
            ? String(fmt.text) : '—');
        tip.style.cssText = [
            'position:absolute',
            'left:' + (lineX + 10) + 'px',
            'top:' + (cursorY - 20) + 'px',
            'padding:2px 6px',
            'border-radius:2px',
            'border:1px solid ' + bg,
            'background:rgba(19,23,34,0.92)',
            'color:' + bg,
            'font:500 11px Roboto,sans-serif',
            'line-height:1.3',
            'white-space:nowrap',
            'pointer-events:none',
            'z-index:13',
            'box-sizing:border-box'
        ].join(';');
        tip.style.display = 'block';
        return;
    }

    setStaticAxisTagsVisible(false);

    const numVal = typeof this._pickIndicatorPlotValue === 'function'
        ? this._pickIndicatorPlotValue(ind, opts.barIdx)
        : null;
    const tagY = numVal != null && typeof this._panelValueToSlotY === 'function'
        ? this._panelValueToSlotY(ind, slot, numVal)
        : null;
    if (!fmt || !Number.isFinite(tagY)) {
        hide();
        return;
    }

    const m = this.margin || { r: 56 };
    const axisLeft = this.w - m.r;
    const axisWidth = Math.max(30, m.r - 4);
    const scaleTextSize = (this.chartSettings && Number.isFinite(this.chartSettings.scaleTextSize))
        ? this.chartSettings.scaleTextSize
        : 11;
    const bg = fmt.color || ind._displayColor || (ind.style && ind.style.color) || '#2962ff';
    const textColor = (typeof this.isLightColor === 'function' && this.isLightColor(bg)) ? '#111111' : '#ffffff';
    const isTopIndicatorSlot = !!slot.isTopBelowMainChart;
    const boundaryGap = isTopIndicatorSlot ? 18 : 8;
    const topBound = slot.top + boundaryGap;
    const bottomBound = slot.bottom - 8;
    const clampedY = Math.max(topBound, Math.min(bottomBound, tagY));

    if (!liveAxis) {
        liveAxis = document.createElement('div');
        liveAxis.setAttribute('data-talaria-sp-live-axis', '1');
        overlay.appendChild(liveAxis);
    }
    liveAxis.style.cssText = [
        'position:absolute',
        'left:' + (axisLeft + 2) + 'px',
        'top:' + (clampedY - 10) + 'px',
        'width:' + axisWidth + 'px',
        'height:20px',
        'padding:0',
        'display:flex',
        'align-items:center',
        'justify-content:center',
        'border-radius:2px',
        'font:500 ' + scaleTextSize + 'px Roboto,sans-serif',
        'line-height:20px',
        'font-variant-numeric:tabular-nums',
        'color:' + textColor,
        'background:' + bg,
        'z-index:12',
        'pointer-events:none',
        'box-sizing:border-box'
    ].join(';');
    liveAxis.textContent = (fmt.text !== undefined && fmt.text !== null && fmt.text !== '') ? String(fmt.text) : '—';
    liveAxis.style.display = 'flex';

    const lineX = Number.isFinite(opts.lineX) ? opts.lineX : 0;
    const cursorY = Number.isFinite(opts.y) ? opts.y : clampedY;
    const indName = ind.name || ind.type || 'Indicator';
    if (!tip) {
        tip = document.createElement('div');
        tip.setAttribute('data-talaria-sp-crosshair-tip', '1');
        overlay.appendChild(tip);
    }
    tip.textContent = indName + ': ' + liveAxis.textContent;
    tip.style.cssText = [
        'position:absolute',
        'left:' + (lineX + 10) + 'px',
        'top:' + (cursorY - 20) + 'px',
        'padding:2px 6px',
        'border-radius:2px',
        'border:1px solid ' + bg,
        'background:rgba(19,23,34,0.92)',
        'color:' + bg,
        'font:500 11px Roboto,sans-serif',
        'line-height:1.3',
        'white-space:nowrap',
        'pointer-events:none',
        'z-index:13',
        'box-sizing:border-box'
    ].join(';');
    tip.style.display = 'block';
};

Chart.prototype._formatIndicatorValueAtBar = function(indicator, barIdx) {
    if (!indicator || barIdx < 0) return { text: '—', color: '#9ca3af' };
    const store = this.indicators && this.indicators.data ? this.indicators.data[indicator.id] : null;
    if (!store) return { text: '—', color: '#9ca3af' };
    const st = indicator.style || {};
    const color = st.color || '#9ca3af';
    const pick = (arr, decimals, col) => {
        const v = this._pickFiniteSeriesValue(arr, barIdx);
        if (v === null) return null;
        return { text: Number(v).toFixed(decimals), color: col || color };
    };
    const type = indicator.type;
    if (type === 'supertrend' && store.line) {
        const lineV = this._pickFiniteSeriesValue(store.line, barIdx);
        if (lineV !== null) {
            const dirRaw = store.direction && barIdx >= 0 && barIdx < store.direction.length
                ? store.direction[barIdx]
                : 1;
            const dirUp = (dirRaw == null ? 1 : dirRaw) >= 0;
            const col = dirUp ? (st.upColor || '#26a69a') : (st.downColor || '#ef5350');
            const priceRange = this.yScale && this.yScale.domain
                ? Math.abs(this.yScale.domain()[1] - this.yScale.domain()[0])
                : 0;
            const text = typeof this._formatLastPrice === 'function'
                ? this._formatLastPrice(Number(lineV), priceRange, this.currentSymbol)
                : Number(lineV).toFixed(typeof this.getPriceDecimals === 'function'
                    ? this.getPriceDecimals(priceRange) : 4);
            return { text: text, color: col };
        }
        return { text: '—', color: st.upColor || '#26a69a' };
    }
    if (type === 'macd' && store.macd && store.signal) {
        const m = pick(store.macd, 4, st.macdColor || color);
        const s = pick(store.signal, 4, st.signalColor || '#f23645');
        if (m && s) return { text: 'M:' + m.text + '  S:' + s.text, color: m.color };
        if (m) return m;
        if (s) return s;
    }
    if ((type === 'stoch' || type === 'stochastic') && store.k && store.d) {
        const k = pick(store.k, 2, st.kColor || color);
        const d = pick(store.d, 2, st.dColor || '#f23645');
        if (k && d) return { text: 'K:' + k.text + '  D:' + d.text, color: k.color };
        if (k) return k;
        if (d) return d;
    }
    if (type === 'aroon' && store.up && store.down) {
        const upV = this._pickFiniteSeriesValue(store.up, barIdx);
        const downV = this._pickFiniteSeriesValue(store.down, barIdx);
        const tokens = buildAroonLegendTokens(upV, downV, st);
        if (tokens.length) {
            return {
                text: tokens.map(function(t) { return t.text; }).join(' '),
                color: tokens[0].color,
                tokens: tokens
            };
        }
    }
    if (type === 'vortex' && store.viPlus && store.viMinus) {
        const plusV = this._pickFiniteSeriesValue(store.viPlus, barIdx);
        const minusV = this._pickFiniteSeriesValue(store.viMinus, barIdx);
        const tokens = buildVortexLegendTokens(plusV, minusV, st);
        if (tokens.length) {
            return {
                text: tokens.map(function(t) { return t.text; }).join(' '),
                color: tokens[0].color,
                tokens: tokens
            };
        }
    }
    if (type === 'obv' && store.obv) {
        const obvV = this._pickFiniteSeriesValue(store.obv, barIdx);
        const maV = store.ma ? this._pickFiniteSeriesValue(store.ma, barIdx) : null;
        const tokens = buildObvLegendTokens(obvV, maV, st);
        if (tokens.length) {
            return {
                text: tokens.map(function(t) { return t.text; }).join(' '),
                color: tokens[0].color,
                tokens: tokens
            };
        }
    }
    if (type === 'cci' && store.cci) {
        const v = pick(store.cci, 2, color);
        if (v) return v;
    }
    if (type === 'rsi' && store.rsi) {
        const v = pick(store.rsi, 2, color);
        if (v) return v;
    }
    if (Array.isArray(store)) {
        const decimals = (type === 'willr' || type === 'williams' || type === 'cci' || type === 'rsi' || type === 'stoch') ? 2 : 4;
        const v = pick(store, decimals, color);
        return v || { text: '—', color: color };
    }
    if (typeof store === 'object') {
        if (Array.isArray(store.upper) || Array.isArray(store.middle) || Array.isArray(store.lower)) {
            const plotOff = typeof this._indicatorPlotOffset === 'function' ? this._indicatorPlotOffset(indicator) : 0;
            const bandTokens = buildOverlayBandLegendTokens(this, store, barIdx, plotOff, st);
            if (bandTokens.length) {
                return {
                    text: bandTokens.map(function(t) { return t.text; }).join(' / '),
                    color: bandTokens[0].color,
                    tokens: bandTokens
                };
            }
        }
        const keys = ['upper', 'middle', 'lower', 'fast', 'slow', 'k', 'd', 'cci'];
        for (let ki = 0; ki < keys.length; ki++) {
            const k = keys[ki];
            if (!Array.isArray(store[k])) continue;
            const col = st[k + 'Color'] || color;
            if (k === 'upper' || k === 'middle' || k === 'lower') {
                const v = this._pickFiniteSeriesValue(store[k], barIdx);
                if (v !== null) {
                    return { text: formatOverlayLegendPrice(this, v), color: col || color };
                }
                continue;
            }
            const v = pick(store[k], k === 'cci' ? 2 : 4, col);
            if (v) return v;
        }
    }
    return { text: '—', color: color };
};

Chart.prototype._applyCrosshairIndicatorDisplays = function(indicators) {
    if (!Array.isArray(indicators) || indicators.length === 0) return;
    const barIdx = this._getCrosshairBarIndex();
    if (barIdx < 0) return;
    indicators.forEach((ind) => {
        if (!ind || ind.hideValues === true) return;
        const fmt = this._formatIndicatorValueAtBar(ind, barIdx);
        if (!fmt) return;
        if (Array.isArray(fmt.tokens) && fmt.tokens.length) {
            ind._legendValueTags = fmt.tokens.map(function(t) {
                return { text: t.text, color: t.color };
            });
            ind._displayLabel = fmt.tokens.map(function(t) { return t.text; }).join(' / ');
            ind._displayColor = fmt.tokens[0].color;
        } else {
            ind._legendValueTags = null;
            ind._displayLabel = fmt.text;
            if (fmt.color) ind._displayColor = fmt.color;
        }
    });
};

Chart.prototype.syncCrosshairIndicatorValues = function() {
    if (!this.indicators || !this.indicators.active) return;

    const overlayIndicators = this.indicators.active.filter((ind) => {
        if (ind.type === 'volume' || ind.isVolume) return false;
        return ind.overlay !== false;
    });
    this._applyCrosshairIndicatorDisplays(overlayIndicators);

    const separateIndicators = typeof this._getVisibleSeparateIndicators === 'function'
        ? this._getVisibleSeparateIndicators()
        : this.indicators.active.filter((ind) => ind.overlay === false && ind.type !== 'volume' && !ind.isVolume);
    this._applyCrosshairIndicatorDisplays(separateIndicators);

    if (this._volumeRendersInSeparatePanel && this._volumeRendersInSeparatePanel()) {
        const vol = typeof this._getActiveVolumeIndicator === 'function' ? this._getActiveVolumeIndicator() : null;
        if (vol) this._applyCrosshairIndicatorDisplays([vol]);
    }

    const idSuffix = (this.panelIndex !== undefined && this.panelIndex !== 0) ? this.panelIndex : '';
    const ohlcDiv = typeof document !== 'undefined' ? document.getElementById('ohlcIndicators' + idSuffix) : null;
    if (ohlcDiv && typeof window.talariaSyncOhlcIndicatorLegendValues === 'function') {
        window.talariaSyncOhlcIndicatorLegendValues(this, ohlcDiv);
    }

    const canvas = this.ctx && this.ctx.canvas;
    const wrapper = canvas ? canvas.parentElement : null;
    const overlay = wrapper ? wrapper.querySelector('#separatePanelsOverlay') : null;
    if (overlay) {
        const stack = [];
        if (this._volumeRendersInSeparatePanel && this._volumeRendersInSeparatePanel()) {
            const vol = typeof this._getActiveVolumeIndicator === 'function' ? this._getActiveVolumeIndicator() : null;
            if (vol) stack.push(vol);
        }
        separateIndicators.forEach((ind) => stack.push(ind));
        this._syncSeparatePanelOverlayValues(overlay, stack);
    }
};

Chart.prototype._panelMapValueToY = function(v, rMin, rSpan, panelTop, panelBottom, panelHeight) {
    if (v === null || v === undefined) return null;
    const y = panelBottom - 5 - ((v - rMin) / Math.max(1e-9, rSpan)) * (panelHeight - 10);
    return Number.isFinite(y) ? y : null;
};

/** Clip indicator geometry to one stacked pane so Y-axis pan/zoom cannot bleed into neighbors. */
Chart.prototype._withSeparatePanelSlotClip = function(ctx, left, top, bottom, fullRight, drawFn) {
    if (!ctx || typeof drawFn !== 'function') return;
    const w = Math.max(0, fullRight - left);
    const h = Math.max(0, bottom - top);
    if (w <= 0 || h <= 0) {
        drawFn();
        return;
    }
    ctx.save();
    ctx.beginPath();
    ctx.rect(left, top, w, h);
    ctx.clip();
    try {
        drawFn();
    } finally {
        ctx.restore();
    }
};

/** Per-indicator Y zoom/pan for separate panels (right-axis drag / wheel). */
Chart.prototype._ensureIndicatorPanelAxis = function(indicator) {
    if (!indicator._panelAxis) indicator._panelAxis = { zoom: 1, offset: 0 };
};

/** Visible min/max of plotted indicator values (prevents Y pan from flattening line at panel edge). */
Chart.prototype._getIndicatorVisibleValueExtent = function(indicator) {
    const store = this.indicators && this.indicators.data && indicator && indicator.id != null
        ? this.indicators.data[indicator.id]
        : null;
    if (!store) return null;
    const v0 = Math.max(0, Math.floor(Number.isFinite(this.visibleStartIndex) ? this.visibleStartIndex : 0));
    const v1 = Math.min(
        this.data ? this.data.length : 0,
        Math.ceil(Number.isFinite(this.visibleEndIndex) ? this.visibleEndIndex : (this.data ? this.data.length : 0))
    );
    if (v1 <= v0) return null;

    let min = Infinity;
    let max = -Infinity;
    const scan = function(arr) {
        if (!Array.isArray(arr)) return;
        for (let i = v0; i < v1 && i < arr.length; i++) {
            const v = arr[i];
            if (v !== null && v !== undefined && Number.isFinite(v)) {
                if (v < min) min = v;
                if (v > max) max = v;
            }
        }
    };

    const t = String(indicator.type || '').toLowerCase();
    if (Array.isArray(store)) {
        scan(store);
    } else if (store && typeof store === 'object') {
        if (t === 'macd' || t === 'ppo') {
            scan(store.macd);
            scan(store.signal);
            scan(store.histogram);
        } else if (t === 'rsi') {
            scan(store.rsi);
            scan(store.ma);
            scan(store.bbUpper);
            scan(store.bbLower);
        } else if (t === 'stoch' || t === 'stochastic' || t === 'stochrsi') {
            scan(store.k);
            scan(store.d);
        } else if (t === 'aroon') {
            scan(store.up);
            scan(store.down);
        } else if (t === 'vortex') {
            scan(store.viPlus);
            scan(store.viMinus);
        } else {
            Object.keys(store).forEach(function(k) { scan(store[k]); });
        }
    }
    if (!Number.isFinite(min) || !Number.isFinite(max)) return null;
    if (min === max) {
        const pad = Math.max(Math.abs(min) * 0.1, 1e-6);
        min -= pad;
        max += pad;
    }
    return { min: min, max: max };
};

/** Optional soft guard — not used during drag; per-slot canvas clip contains overflow. */
Chart.prototype._clampIndicatorPanelOffset = function(indicator, b0, b1) {
    if (!indicator || !Number.isFinite(b0) || !Number.isFinite(b1) || b1 <= b0) return;
    this._ensureIndicatorPanelAxis(indicator);
    const pa = indicator._panelAxis;
    const extent = this._getIndicatorVisibleValueExtent(indicator);
    if (!extent) return;
    const z = Math.max(0.02, Math.min(200, pa.zoom || 1));
    const span = (b1 - b0) / z;
    const mid0 = (b0 + b1) / 2;
    const dataLo = extent.min;
    const dataHi = extent.max;
    const dataSpan = Math.max(1e-9, dataHi - dataLo);
    const pad = Math.max(dataSpan * 0.08, span * 0.02);
    const minOffset = (dataHi + pad) - mid0 - span / 2;
    const maxOffset = (dataLo - pad) - mid0 + span / 2;
    if (minOffset > maxOffset) {
        pa.offset = 0;
        return;
    }
    pa.offset = Math.max(minOffset, Math.min(maxOffset, pa.offset || 0));
};

/** Double-click indicator right axis — reset zoom/offset to auto-fit. */
Chart.prototype.resetSeparatePanelIndicatorAxis = function(indicator) {
    if (!indicator) return;
    indicator._panelAxis = { zoom: 1, offset: 0 };
    delete indicator._panelBaseMin;
    delete indicator._panelBaseMax;
    if (typeof this.bumpIndicatorRenderVersion === 'function') {
        this.bumpIndicatorRenderVersion();
    }
    if (typeof this.scheduleRender === 'function') {
        this.scheduleRender();
    }
};

/**
 * Map auto-fit [baseMin, baseMax] to displayed domain using indicator._panelAxis.
 * Bases are stored on indicator as _panelBaseMin / _panelBaseMax each render.
 */
Chart.prototype._applyIndicatorPanelDomain = function(baseMin, baseMax, indicator) {
    this._ensureIndicatorPanelAxis(indicator);
    const b0 = baseMin;
    const b1 = baseMax;
    if (!Number.isFinite(b0) || !Number.isFinite(b1) || b1 <= b0) {
        return { min: b0, max: b1 };
    }
    const pa = indicator._panelAxis;
    const z = Math.max(0.02, Math.min(200, pa.zoom || 1));
    const mid = (b0 + b1) / 2 + (pa.offset || 0);
    const span = (b1 - b0) / z;
    return { min: mid - span / 2, max: mid + span / 2 };
};

/** Freeze auto-fit panel Y range while chart-panning (mirrors main chart _panSnapYDomain). */
Chart.prototype._snapshotSeparatePanelDomains = function() {
    this._panelSnapDomains = {};
    if (typeof this._getVisibleSeparateIndicators !== 'function') return;
    this._getVisibleSeparateIndicators().forEach(function(ind) {
        const b0 = ind._panelBaseMin;
        const b1 = ind._panelBaseMax;
        if (Number.isFinite(b0) && Number.isFinite(b1) && b1 > b0) {
            this._panelSnapDomains[ind.id] = { min: b0, max: b1 };
        }
    }, this);
};

/** True while user is dragging inside a separate panel plot or its right Y-axis. */
Chart.prototype._isSeparatePanelYInteracting = function() {
    if (this._separatePanelLineDragActive) return true;
    const d = this.drag;
    return !!(d && d.active && d.type === 'separatePanelAxis');
};

/** User has panned/zoomed a separate panel Y-axis (offset/zoom away from defaults). */
Chart.prototype._indicatorPanelHasUserAxis = function(indicator) {
    if (!indicator) return false;
    this._ensureIndicatorPanelAxis(indicator);
    const pa = indicator._panelAxis;
    const z = pa.zoom != null ? pa.zoom : 1;
    const o = pa.offset != null ? pa.offset : 0;
    return Math.abs(z - 1) > 1e-6 || Math.abs(o) > 1e-12;
};

/** Clear cached panel Y range / user zoom when reference levels (zero line, bands) change. */
Chart.prototype._resetIndicatorPanelAutoscale = function(indicator) {
    if (!indicator) return;
    delete indicator._panelBaseMin;
    delete indicator._panelBaseMax;
    this._ensureIndicatorPanelAxis(indicator);
    indicator._panelAxis.zoom = 1;
    indicator._panelAxis.offset = 0;
    if (this._panelSnapDomains && indicator.id != null) {
        delete this._panelSnapDomains[indicator.id];
    }
};

Chart.prototype._resolveIndicatorLevelValue = function(indicator, style, key, fallback) {
    const st = style || indicator.style || {};
    const pa = indicator.params || {};
    if (st[key] != null && st[key] !== '') {
        const n = Number(st[key]);
        if (Number.isFinite(n)) return n;
    }
    if (pa[key] != null && pa[key] !== '') {
        const n = Number(pa[key]);
        if (Number.isFinite(n)) return n;
    }
    return fallback != null ? fallback : 0;
};

Chart.prototype._finalizePanelRange = function(indicator, baseMin, baseMax) {
    let b0 = baseMin;
    let b1 = baseMax;
    const stored = indicator
        && Number.isFinite(indicator._panelBaseMin)
        && Number.isFinite(indicator._panelBaseMax)
        && indicator._panelBaseMax > indicator._panelBaseMin;
    const snapInteraction = (typeof this._isChartViewPanning === 'function' && this._isChartViewPanning())
        || (typeof this._isSeparatePanelYInteracting === 'function' && this._isSeparatePanelYInteracting());
    if (snapInteraction && this._panelSnapDomains && indicator && indicator.id != null) {
        const snap = this._panelSnapDomains[indicator.id];
        if (snap && Number.isFinite(snap.min) && Number.isFinite(snap.max) && snap.max > snap.min) {
            b0 = snap.min;
            b1 = snap.max;
        }
    } else if (stored
        && typeof this._indicatorPanelHasUserAxis === 'function'
        && this._indicatorPanelHasUserAxis(indicator)) {
        b0 = indicator._panelBaseMin;
        b1 = indicator._panelBaseMax;
    }
    indicator._panelBaseMin = b0;
    indicator._panelBaseMax = b1;
    return this._applyIndicatorPanelDomain(b0, b1, indicator);
};

/** Resize divider between separate indicator slots (full line + right-axis grip). */
Chart.prototype._drawSeparatePanelResizeSeparator = function(ctx, m, y, panelFullRight, opts) {
    opts = opts || {};
    const isLightBg = !!opts.isLightBg;
    const isHover = !!opts.isHover;
    const strongTop = !!opts.strongTop;
    const _sepColor = isLightBg ? 'rgba(119,130,150,0.45)' : 'rgba(110,122,145,0.38)';
    const _sepColorStrong = isLightBg ? 'rgba(80,96,122,0.6)' : 'rgba(145,160,190,0.52)';
    const _gripColor = isLightBg ? 'rgba(0, 0, 0, 0.30)' : 'rgba(150, 170, 210, 0.55)';
    const _hoverColor = isLightBg ? 'rgba(41,98,255,0.60)' : 'rgba(106,138,255,0.72)';
    const _hoverGlow = isLightBg ? 'rgba(41,98,255,0.22)' : 'rgba(106,138,255,0.30)';

    ctx.strokeStyle = isHover ? _hoverColor : (strongTop ? _sepColorStrong : _sepColor);
    ctx.lineWidth = 1;
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(m.l, y);
    ctx.lineTo(panelFullRight, y);
    ctx.stroke();

    if (isHover) {
        const handleMidX = this.w - m.r - 18;
        ctx.strokeStyle = _hoverColor;
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(handleMidX - 8, y);
        ctx.lineTo(handleMidX + 8, y);
        ctx.stroke();
        ctx.lineCap = 'butt';
    }
};

/** Plot-area hit inside a stacked indicator pane (excludes right price strip + resize grips). */
Chart.prototype._findSeparatePanelPlotSlot = function(x, y, opts) {
    opts = opts || {};
    const m = this.margin || { l: 60, r: 60 };
    const spi = this.separatePanelInfo;
    if (!spi || !Array.isArray(spi.panelSlots)) return null;
    if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
    if (x < m.l || x > this.w - m.r) return null;
    const skipResize = opts.skipResizeHandles !== false;
    for (let i = 0; i < spi.panelSlots.length; i++) {
        const slot = spi.panelSlots[i];
        if (y < slot.top || y > slot.bottom) continue;
        if (skipResize && typeof this.getSeparatePanelResizeHandleAt === 'function') {
            const handle = this.getSeparatePanelResizeHandleAt(x, y, 14);
            if (handle) return null;
        }
        return slot;
    }
    return null;
};

/** Vertical drag on right margin over a separate indicator slot */
Chart.prototype.separatePanelAxisDragStep = function(slot, dy, pointerY) {
    const ind = slot.indicator;
    const b0 = ind._panelBaseMin;
    const b1 = ind._panelBaseMax;
    if (b0 == null || b1 == null || !Number.isFinite(b0) || !Number.isFinite(b1) || b1 <= b0) return;
    this._ensureIndicatorPanelAxis(ind);
    const pa = ind._panelAxis;
    const sensitivity = 0.002;
    const zoomFactor = Math.max(0.01, 1 - dy * sensitivity);
    const newZoom = Math.max(0.02, Math.min(200, pa.zoom * zoomFactor));
    const baseSpan = b1 - b0;
    const oldSpan = baseSpan / pa.zoom;
    const newSpan = baseSpan / newZoom;
    const rangeChange = newSpan - oldSpan;
    const h = Math.max(1, slot.bottom - slot.top);
    const cursorRatio = Math.max(0, Math.min(1, (pointerY - slot.top) / h));
    const mid = (b0 + b1) / 2 + (pa.offset || 0);
    const newMid = mid - rangeChange * (0.5 - cursorRatio);
    pa.offset = newMid - (b0 + b1) / 2;
    pa.zoom = newZoom;
};

/** Mouse wheel while cursor is over separate-pane price strip */
Chart.prototype.applySeparatePanelAxisWheel = function(priceZoomFactor, mx, my) {
    const slot = this.cursor && this.cursor.separatePanelSlot;
    if (!slot || !slot.indicator) return;
    const ind = slot.indicator;
    const b0 = ind._panelBaseMin;
    const b1 = ind._panelBaseMax;
    if (b0 == null || b1 == null || !Number.isFinite(b0) || !Number.isFinite(b1) || b1 <= b0) return;
    this._ensureIndicatorPanelAxis(ind);
    const pa = ind._panelAxis;
    const oldZoom = pa.zoom || 1;
    const newZoom = Math.max(0.02, Math.min(200, oldZoom * priceZoomFactor));
    if (newZoom === oldZoom) return;
    const baseSpan = b1 - b0;
    const oldSpan = baseSpan / oldZoom;
    const newSpan = baseSpan / newZoom;
    const rangeChange = newSpan - oldSpan;
    const h = Math.max(1, slot.bottom - slot.top);
    const cursorRatio = Math.max(0, Math.min(1, (my - slot.top) / h));
    const mid = (b0 + b1) / 2 + (pa.offset || 0);
    const newMid = mid - rangeChange * (0.5 - cursorRatio);
    pa.offset = newMid - (b0 + b1) / 2;
    pa.zoom = newZoom;
};

// Handle click on separate panel indicator to open settings
Chart.prototype.handleSeparatePanelClick = function(x, y) {
    if (!this.separatePanelInfo) return false;
    
    const { top, bottom, indicators } = this.separatePanelInfo;
    
    if (y >= top && y <= bottom) {
        // Clicked in indicator panel - open settings for first indicator
        if (indicators.length > 0) {
            const indicator = indicators[0];
            if (this.v9DeleteIndicatorsMode && typeof this.removeIndicator === "function") {
                this.removeIndicator(indicator.id);
                if (typeof this.showNotification === "function") {
                    this.showNotification("Indicator removed ✓");
                }
                return true;
            }
            if (typeof window.createIndicatorSettingsPanel === "function") {
                window.createIndicatorSettingsPanel(this, indicator.type, indicator);
                return true;
            }
        }
    }
    return false;
};

    var OVERLAY_LINE_SELECT_TYPES = {
        sma: 1, ema: 1, wma: 1, dema: 1, tema: 1, hma: 1, vwap: 1,
        supertrend: 1,
        psar: 1,
        bb: 1, bollinger: 1,
        envelope: 1, smaenvelope: 1,
        donchian: 1, keltner: 1
    };

    function getOverlayHitTestSeries(indicator, data) {
        if (!indicator || !data) return [];
        if (Array.isArray(data)) return [data];
        if (indicator.type === 'custom' && Array.isArray(data.plots)) {
            const out = [];
            for (let pi = 0; pi < data.plots.length; pi++) {
                const plot = data.plots[pi];
                if (!plot || plot.type === 'histogram') continue;
                if (Array.isArray(plot.values)) out.push(plot.values);
                else if (Array.isArray(plot.data)) out.push(plot.data);
            }
            return out;
        }
        if (indicator.type === 'supertrend' && Array.isArray(data.line)) return [data.line];
        if ((indicator.type === 'sma' || indicator.type === 'ema') && Array.isArray(data.line)) return [data.line];
        if (indicator.type === 'wma' && Array.isArray(data)) return [data];
        if (indicator.type === 'vwap' && Array.isArray(data.vwap)) {
            const st = indicator.style || {};
            const p = indicator.params || {};
            const out = [];
            if (st.showVwap !== false) out.push(data.vwap);
            if (p.band1Enabled !== false && st.showUpper1 !== false && Array.isArray(data.upper1)) out.push(data.upper1);
            if (p.band1Enabled !== false && st.showLower1 !== false && Array.isArray(data.lower1)) out.push(data.lower1);
            if (p.band2Enabled === true && st.showUpper1 !== false && Array.isArray(data.upper2)) out.push(data.upper2);
            if (p.band2Enabled === true && st.showLower1 !== false && Array.isArray(data.lower2)) out.push(data.lower2);
            if (p.band3Enabled === true && st.showUpper1 !== false && Array.isArray(data.upper3)) out.push(data.upper3);
            if (p.band3Enabled === true && st.showLower1 !== false && Array.isArray(data.lower3)) out.push(data.lower3);
            return out;
        }
        if (Array.isArray(data.upper) || Array.isArray(data.middle) || Array.isArray(data.lower)) {
            const bands = [];
            if (Array.isArray(data.upper)) bands.push(data.upper);
            if (Array.isArray(data.middle)) bands.push(data.middle);
            if (Array.isArray(data.lower)) bands.push(data.lower);
            return bands;
        }
        if (Array.isArray(data.line)) return [data.line];
        return [];
    }

    function hitTestLineSeriesAtPoint(chart, series, mx, my, startIndex, endIndex, tol) {
        if (!series || !series.length || !chart.yScale) return false;
        const m = chart.margin;
        let prevX = null;
        let prevY = null;
        let prevOk = false;
        for (let i = startIndex; i < endIndex; i++) {
            const val = series[i];
            if (!Number.isFinite(val)) {
                prevOk = false;
                continue;
            }
            const x = chart.dataIndexToPixel(i);
            const y = chart.yScale(val);
            if (x < m.l - 50 || x > chart.w - m.r + 50) {
                prevOk = false;
                continue;
            }
            if (Math.hypot(mx - x, my - y) <= tol) return true;
            if (prevOk && prevX != null && prevY != null) {
                if (distPointToSegment(mx, my, prevX, prevY, x, y) <= tol) return true;
            }
            prevX = x;
            prevY = y;
            prevOk = true;
        }
        return false;
    }

    function getSeparatePanelHitTestSeries(indicator, data) {
        if (!indicator || !data) return [];
        if (Array.isArray(data)) return [data];
        if (indicator.type === 'macd' || indicator.type === 'ppo') {
            const out = [];
            const st = indicator.style || {};
            if (st.showMacd !== false && Array.isArray(data.macd)) out.push(data.macd);
            if (st.showSignal !== false && Array.isArray(data.signal)) out.push(data.signal);
            return out;
        }
        if (indicator.type === 'stoch' || indicator.type === 'stochastic' || indicator.type === 'stochrsi') {
            const out = [];
            const st = indicator.style || {};
            if (st.showK !== false && Array.isArray(data.k)) out.push(data.k);
            if (st.showD !== false && Array.isArray(data.d)) out.push(data.d);
            return out;
        }
        if (indicator.type === 'adx') {
            const out = [];
            const st = indicator.style || {};
            if (st.showPlusDI !== false && Array.isArray(data.plusDI)) out.push(data.plusDI);
            if (st.showMinusDI !== false && Array.isArray(data.minusDI)) out.push(data.minusDI);
            if (st.showAdx !== false && Array.isArray(data.adx)) out.push(data.adx);
            return out;
        }
        if (indicator.type === 'aroon' && data.up && data.down) {
            const out = [];
            const st = indicator.style || {};
            if (st.showUp !== false) out.push(data.up);
            if (st.showDown !== false) out.push(data.down);
            return out;
        }
        if (indicator.type === 'custom' && Array.isArray(data.plots)) {
            return getOverlayHitTestSeries(indicator, data);
        }
        if (Array.isArray(data.line)) return [data.line];
        return [];
    }

    function hitTestLineSeriesInPanelSlot(chart, series, indicator, slot, mx, my, startIndex, endIndex, tol) {
        if (!series || !series.length || !slot) return false;
        const b0 = indicator._panelBaseMin;
        const b1 = indicator._panelBaseMax;
        if (b0 == null || b1 == null || !Number.isFinite(b0) || !Number.isFinite(b1) || b1 <= b0) return false;
        const dom = chart._applyIndicatorPanelDomain(b0, b1, indicator);
        const aMin = dom.min;
        const aMax = dom.max;
        const aSpan = Math.max(1e-9, aMax - aMin);
        const panelHeight = slot.bottom - slot.top;
        const scaleY = function(v) {
            if (v == null || !Number.isFinite(v)) return null;
            let y = slot.bottom - 5 - ((v - aMin) / aSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return Math.max(slot.top + 2, Math.min(slot.bottom - 2, y));
        };
        let prevX = null;
        let prevY = null;
        let prevOk = false;
        const m = chart.margin;
        for (let i = startIndex; i < endIndex; i++) {
            const val = series[i];
            if (!Number.isFinite(val)) {
                prevOk = false;
                continue;
            }
            const x = chart.dataIndexToPixel(i);
            const y = scaleY(val);
            if (x < m.l - 50 || x > chart.w - m.r + 50 || y == null) {
                prevOk = false;
                continue;
            }
            if (Math.hypot(mx - x, my - y) <= tol) return true;
            if (prevOk && prevX != null && prevY != null) {
                if (distPointToSegment(mx, my, prevX, prevY, x, y) <= tol) return true;
            }
            prevX = x;
            prevY = y;
            prevOk = true;
        }
        return false;
    }

    function distPointToSegment(px, py, x1, y1, x2, y2) {
        const dx = x2 - x1;
        const dy = y2 - y1;
        if (dx === 0 && dy === 0) return Math.hypot(px - x1, py - y1);
        const t = Math.max(0, Math.min(1, ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)));
        return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
    }

    function getOverlayLineSeries(indicator, data) {
        const list = getOverlayHitTestSeries(indicator, data);
        return list.length ? list[0] : null;
    }

    function isSelectableOverlayLineIndicator(indicator) {
        if (!indicator || indicator.overlay === false || indicator.visible === false) return false;
        if (indicator.separatePanel) return false;
        const st = indicator.style || {};
        const t = String(indicator.type || '').toLowerCase();
        if ((t === 'sma' || t === 'ema' || t === 'wma' || t === 'dema' || t === 'tema' || t === 'hma')
            && st.showLine === false) {
            return false;
        }
        if (indicator.type === 'custom') return true;
        return !!OVERLAY_LINE_SELECT_TYPES[indicator.type];
    }

    Chart.prototype._getOverlayLineHitTolerance = function(indicator) {
        const lw = indicator && indicator.style && indicator.style.lineWidth != null
            ? Number(indicator.style.lineWidth) : 2;
        return Math.max(7, (Number.isFinite(lw) ? lw : 2) + 6);
    };

    Chart.prototype.findOverlayIndicatorAtPoint = function(mx, my, options) {
        if (!this.indicators || !this.indicators.active || !this.indicators.active.length) return null;
        if (!Number.isFinite(mx) || !Number.isFinite(my) || !this.yScale) return null;
        const m = this.margin;
        if (mx < m.l || mx > this.w - m.r || my < m.t || my > this.h - m.b) return null;

        const opts = options || {};
        const visibleStart = Number.isFinite(this.visibleStartIndex) ? this.visibleStartIndex : 0;
        const visibleEnd = Number.isFinite(this.visibleEndIndex) ? this.visibleEndIndex : (this.data ? this.data.length : 0);
        const buffer = 20;
        const startIndex = Math.max(0, visibleStart - buffer);
        const endIndex = Math.min(this.data ? this.data.length : 0, visibleEnd + buffer);

        for (let ai = this.indicators.active.length - 1; ai >= 0; ai--) {
            const indicator = this.indicators.active[ai];
            if (!isSelectableOverlayLineIndicator(indicator)) continue;
            if (typeof this._indicatorVisibleForCurrentTimeframe === 'function'
                && !this._indicatorVisibleForCurrentTimeframe(indicator)) continue;
            if (indicator.type === 'vwap' && typeof this._vwapVisibleOnTimeframe === 'function'
                && !this._vwapVisibleOnTimeframe(indicator)) continue;

            const data = this.indicators.data[indicator.id];
            const seriesList = getOverlayHitTestSeries(indicator, data);
            if (!seriesList.length) continue;

            const tol = opts.tolerance != null ? opts.tolerance : this._getOverlayLineHitTolerance(indicator);
            let hit = false;
            for (let si = 0; si < seriesList.length; si++) {
                if (hitTestLineSeriesAtPoint(this, seriesList[si], mx, my, startIndex, endIndex, tol)) {
                    hit = true;
                    break;
                }
            }
            if (hit) return indicator;
        }
        return null;
    };

    Chart.prototype.findSeparatePanelIndicatorAtPoint = function(mx, my, options) {
        if (!this.separatePanelInfo || !Array.isArray(this.separatePanelInfo.panelSlots)) return null;
        if (!Number.isFinite(mx) || !Number.isFinite(my)) return null;
        const m = this.margin;
        if (mx < m.l || mx > this.w - m.r) return null;

        const slot = this.separatePanelInfo.panelSlots.find(function(s) {
            return my >= s.top && my <= s.bottom;
        });
        if (!slot || !slot.indicator) return null;

        const indicator = slot.indicator;
        if (indicator.visible === false || indicator.hidePlot === true) return null;
        if (indicator.type === 'volume' || indicator.isVolume) return null;
        const isSeparatePane = indicator.separatePanel === true || indicator.overlay === false;
        if (!isSeparatePane) return null;
        if (typeof this._indicatorVisibleForCurrentTimeframe === 'function'
            && !this._indicatorVisibleForCurrentTimeframe(indicator)) return null;

        const data = this.indicators.data[indicator.id];
        const seriesList = getSeparatePanelHitTestSeries(indicator, data);
        if (!seriesList.length) return null;

        const opts = options || {};
        const visibleStart = Number.isFinite(this.visibleStartIndex) ? this.visibleStartIndex : 0;
        const visibleEnd = Number.isFinite(this.visibleEndIndex) ? this.visibleEndIndex : (this.data ? this.data.length : 0);
        const buffer = 20;
        const startIndex = Math.max(0, visibleStart - buffer);
        const endIndex = Math.min(this.data ? this.data.length : 0, visibleEnd + buffer);
        const tol = opts.tolerance != null ? opts.tolerance : this._getOverlayLineHitTolerance(indicator);

        for (let si = 0; si < seriesList.length; si++) {
            if (hitTestLineSeriesInPanelSlot(this, seriesList[si], indicator, slot, mx, my, startIndex, endIndex, tol)) {
                return indicator;
            }
        }
        return null;
    };

    Chart.prototype.handleSeparatePanelIndicatorDoubleClick = function(mx, my) {
        const hit = this.findSeparatePanelIndicatorAtPoint(mx, my);
        if (hit) return this.openOverlayIndicatorSettings(hit.id);

        const slot = typeof this._findSeparatePanelPlotSlot === 'function'
            ? this._findSeparatePanelPlotSlot(mx, my)
            : null;
        if (!slot || !slot.indicator) return false;
        const ind = slot.indicator;
        if (ind.visible === false || ind.hidePlot === true) return false;
        if (ind.type === 'volume' || ind.isVolume) return false;
        return this.openOverlayIndicatorSettings(ind.id);
    };

    Chart.prototype.selectOverlayIndicator = function(id) {
        const nextId = id || null;
        if (this.selectedOverlayIndicatorId === nextId) return;
        this.selectedOverlayIndicatorId = nextId;
        if (typeof this.scheduleRender === 'function') this.scheduleRender();
        else if (typeof this.render === 'function') this.render();
    };

    Chart.prototype.clearOverlayIndicatorSelection = function() {
        if (!this.selectedOverlayIndicatorId) return;
        this.selectedOverlayIndicatorId = null;
        if (typeof this.scheduleRender === 'function') this.scheduleRender();
        else if (typeof this.render === 'function') this.render();
    };

    Chart.prototype.openOverlayIndicatorSettings = function(id) {
        const targetId = id || this.selectedOverlayIndicatorId;
        if (!targetId) return false;
        if (typeof this.showIndicatorSettings === 'function') {
            this.showIndicatorSettings(targetId);
            return true;
        }
        return false;
    };

    Chart.prototype.handleOverlayIndicatorChartClick = function(mx, my) {
        const hit = this.findOverlayIndicatorAtPoint(mx, my);
        if (hit) {
            this.selectOverlayIndicator(hit.id);
            const dm = this.drawingManager;
            if (dm && typeof dm.deselectAll === 'function') {
                dm.deselectAll({ fromCanvasBackground: true });
            }
            return true;
        }
        if (this.selectedOverlayIndicatorId) {
            this.clearOverlayIndicatorSelection();
        }
        return false;
    };

    Chart.prototype.handleOverlayIndicatorChartDoubleClick = function(mx, my) {
        const hit = this.findOverlayIndicatorAtPoint(mx, my);
        if (!hit) return false;
        this.selectOverlayIndicator(hit.id);
        return this.openOverlayIndicatorSettings(hit.id);
    };

    /** First/last on-screen points of an overlay line (TradingView: two endpoint anchors only). */
    function visibleOverlayLineSelectionPoints(chart, series, startIndex, endIndex) {
        const m = chart.margin || { l: 0, r: 0, t: 0, b: 0 };
        let first = null;
        let last = null;
        for (let i = startIndex; i < endIndex; i++) {
            if (!Number.isFinite(series[i])) continue;
            const x = chart.dataIndexToPixel(i);
            const y = chart.yScale(series[i]);
            if (x < m.l || x > chart.w - m.r || y < m.t || y > chart.h - m.b) continue;
            if (!first) first = { x: x, y: y };
            last = { x: x, y: y };
        }
        if (!first) return [];
        if (!last || (last.x === first.x && last.y === first.y)) return [first];
        return [first, last];
    }

    Chart.prototype._drawOverlayLineSelectionHandles = function(series, startIndex, endIndex, style) {
        if (!this.ctx || !this.yScale || !series) return;
        const points = visibleOverlayLineSelectionPoints(this, series, startIndex, endIndex);
        if (!points.length) return;

        const color = (style && style.color) || '#2962ff';
        const lw = (style && style.lineWidth) || 2;
        const radius = Math.max(3, Math.min(4.5, lw + 1.5));
        const bg = (this.chartSettings && this.chartSettings.backgroundColor) || '#131722';
        const plotLayout = typeof this._getMainPricePlotLayout === 'function'
            ? this._getMainPricePlotLayout()
            : { m: this.margin || { t: 0 }, plotHeight: this.h - (this.margin?.t || 0) - (this.margin?.b || 0) };
        const plotYMin = plotLayout.m.t;
        const plotYMax = plotLayout.m.t + plotLayout.plotHeight;
        const ctx = this.ctx;

        ctx.save();
        ctx.strokeStyle = color;
        ctx.fillStyle = bg;
        ctx.lineWidth = 1.5;
        points.forEach(function(pt) {
            if (!Number.isFinite(pt.y) || pt.y < plotYMin || pt.y > plotYMax) return;
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
        });
        ctx.restore();
    };

    /** Legacy SVG layer cleanup (handles now draw on canvas with the indicator line). */
    Chart.prototype.syncOverlayIndicatorSelectionOverlay = function() {
        if (!this.svg || this.svg.empty()) return;
        this.svg.select('g.overlay-indicator-selection').selectAll('*').remove();
    };

    Chart.prototype.drawOverlayIndicatorSelection = function() {
        if (typeof this.syncOverlayIndicatorSelectionOverlay === 'function') {
            this.syncOverlayIndicatorSelectionOverlay();
        }
    };

Chart.prototype._normalizePlotStyle = function(lineStyle) {
    const raw = String(lineStyle || 'Line').trim();
    const lower = raw.toLowerCase();
    if (lower === 'solid') return 'Line';
    if (lower === 'dashed') return 'Dashed';
    if (lower === 'dotted') return 'Dotted';
    if (lower === 'dashdot') return 'Dashdot';
    const names = [
        'Line', 'Line with breaks', 'Step line', 'Step line with breaks', 'Step line with diamonds',
        'Histogram', 'Cross', 'Area', 'Area with breaks', 'Columns', 'Circles', 'Dashed', 'Dotted', 'Dashdot'
    ];
    for (let i = 0; i < names.length; i++) {
        if (names[i].toLowerCase() === lower) return names[i];
    }
    return 'Line';
};

Chart.prototype._lineDashForStyle = function(lineStyle) {
    const style = this._normalizePlotStyle(lineStyle);
    if (style === 'Dashed') return [8, 4];
    if (style === 'Dotted') return [2, 3];
    if (style === 'Dashdot') return [8, 4, 2, 4];
    return [];
};

Chart.prototype._plotBarWidthPx = function(index, lineWidth) {
    const x0 = this.dataIndexToPixel(index);
    const x1 = this.dataIndexToPixel(index + 1);
    const gap = Number.isFinite(x1) && Number.isFinite(x0) ? Math.abs(x1 - x0) : 0;
    const lw = Number(lineWidth) || 2;
    if (!Number.isFinite(gap) || gap < 1) return Math.max(2, lw * 2);
    return Math.max(1, gap * 0.72);
};

Chart.prototype.drawLineIndicator = function(data, color, lineWidth, startIndex, endIndex, lineStyle, options) {
    if (!data || !this.ctx) return;
    options = options || {};
    const ctx = this.ctx;
    const m = this.margin;
    const style = this._normalizePlotStyle(lineStyle);
    const lw = Number(lineWidth) || 2;
    const dashStyleOpt = options.dashStyle;
    const plotOffset = Number(options.plotOffset) | 0;
    const valueAt = plotOffset
        ? function(i) { return seriesValueAtPlotOffset(data, i, plotOffset); }
        : function(i) { return data[i]; };
    const dashForLine = function (plotStyle) {
        if (plotStyle === 'Dashed' || plotStyle === 'Dotted' || plotStyle === 'Dashdot') return plotStyle;
        if (dashStyleOpt) return dashStyleOpt === 'Solid' ? 'Line' : dashStyleOpt;
        return plotStyle;
    };
    const yAt = typeof options.yScale === 'function' ? options.yScale : function(v) { return this.yScale(v); }.bind(this);
    const baselineY = Number.isFinite(options.baselineY) ? options.baselineY : (this.h - m.b);
    const breakOnNull = style === 'Line with breaks' || style === 'Step line with breaks' || style === 'Area with breaks';
    const inView = function(x) { return x >= m.l - 50 && x <= this.w - m.r + 50; }.bind(this);
    const panelTopOpt = options.panelTop;
    const panelBottomOpt = options.panelBottom;
    const inPlotY = function(y) {
        if (Number.isFinite(panelTopOpt) && Number.isFinite(panelBottomOpt) && panelBottomOpt > panelTopOpt) {
            return Number.isFinite(y) && y >= panelTopOpt && y <= panelBottomOpt;
        }
        // Main-chart overlays: keep drawing through out-of-range Y; clip + axes hide the excess.
        return Number.isFinite(y);
    };

    // At sub-pixel bar spacing many consecutive indices map to the SAME screen X.
    // Drawing ctx.lineTo to duplicate pixel X is pure waste — cap draw calls to
    // at most one sample per pixel to keep indicators smooth even at max zoom-out.
    const spacing = typeof this.getCandleSpacing === 'function' ? this.getCandleSpacing() : 1;
    const drawStride = (Number.isFinite(spacing) && spacing > 0 && spacing < 1)
        ? Math.max(1, Math.floor(1 / spacing))
        : 1;

    ctx.save();
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = lw;
    ctx.lineCap = style === 'Circles' || style === 'Cross' ? 'round' : 'butt';
    ctx.lineJoin = 'round';

    const flushLine = function() {
        ctx.stroke();
        ctx.beginPath();
    };

    if (style === 'Line' || style === 'Dashed' || style === 'Dotted' || style === 'Dashdot' || style === 'Line with breaks') {
        ctx.setLineDash(this._lineDashForStyle(dashForLine(style === 'Line with breaks' ? 'Line' : style)));
        let started = false;
        for (let i = startIndex; i < endIndex; i += drawStride) {
            const val = valueAt(i);
            if (val == null || val === undefined || isNaN(val)) {
                if (breakOnNull && started) { flushLine(); started = false; }
                continue;
            }
            const x = this.dataIndexToPixel(i);
            const y = yAt(val);
            if (y == null || !Number.isFinite(y) || !inView(x) || !inPlotY(y)) continue;
            if (!started) { ctx.beginPath(); ctx.moveTo(x, y); started = true; }
            else ctx.lineTo(x, y);
        }
        if (started) ctx.stroke();
        ctx.setLineDash([]);
    } else if (style === 'Step line' || style === 'Step line with breaks' || style === 'Step line with diamonds') {
        let prev = null;
        ctx.beginPath();
        let started = false;
        const diamonds = [];
        for (let i = startIndex; i < endIndex; i += drawStride) {
            const val = valueAt(i);
            if (val == null || val === undefined || isNaN(val)) {
                if (breakOnNull && started) { flushLine(); started = false; prev = null; }
                continue;
            }
            const x = this.dataIndexToPixel(i);
            const y = yAt(val);
            if (y == null || !Number.isFinite(y) || !inView(x) || !inPlotY(y)) continue;
            if (!prev) {
                ctx.moveTo(x, y);
                started = true;
            } else {
                ctx.lineTo(x, prev.y);
                ctx.lineTo(x, y);
                if (style === 'Step line with diamonds') diamonds.push({ x: x, y: y });
            }
            prev = { x: x, y: y };
        }
        if (started) ctx.stroke();
        if (style === 'Step line with diamonds') {
            const r = Math.max(2, lw * 1.1);
            ctx.beginPath();
            diamonds.forEach(function(d) {
                ctx.moveTo(d.x + r, d.y);
                ctx.arc(d.x, d.y, r, 0, Math.PI * 2);
            });
            ctx.fill();
        }
    } else if (style === 'Histogram' || style === 'Columns') {
        const half = function(i) { return this._plotBarWidthPx(i, lw) / 2; }.bind(this);
        for (let i = startIndex; i < endIndex; i += drawStride) {
            const val = valueAt(i);
            if (val == null || val === undefined || isNaN(val)) continue;
            const x = this.dataIndexToPixel(i);
            const y = yAt(val);
            if (y == null || !Number.isFinite(y) || !inView(x) || !inPlotY(y)) continue;
            const w = half(i) * 2;
            const top = Math.min(y, baselineY);
            const h = Math.abs(baselineY - y);
            if (style === 'Columns') ctx.fillRect(x - w / 2, top, w, Math.max(1, h));
            else {
                ctx.beginPath();
                ctx.moveTo(x, baselineY);
                ctx.lineTo(x, y);
                ctx.stroke();
            }
        }
    } else if (style === 'Cross') {
        const r = Math.max(2.5, lw * 1.5);
        ctx.beginPath();
        for (let i = startIndex; i < endIndex; i += drawStride) {
            const val = valueAt(i);
            if (val == null || val === undefined || isNaN(val)) continue;
            const x = this.dataIndexToPixel(i);
            const y = yAt(val);
            if (y == null || !Number.isFinite(y) || !inView(x) || !inPlotY(y)) continue;
            ctx.moveTo(x - r, y);
            ctx.lineTo(x + r, y);
            ctx.moveTo(x, y - r);
            ctx.lineTo(x, y + r);
        }
        ctx.stroke();
    } else if (style === 'Circles') {
        const r = Math.max(2, lw * 1.1);
        ctx.beginPath();
        for (let i = startIndex; i < endIndex; i += drawStride) {
            const val = valueAt(i);
            if (val == null || val === undefined || isNaN(val)) continue;
            const x = this.dataIndexToPixel(i);
            const y = yAt(val);
            if (y == null || !Number.isFinite(y) || !inView(x) || !inPlotY(y)) continue;
            ctx.moveTo(x + r, y);
            ctx.arc(x, y, r, 0, Math.PI * 2);
        }
        ctx.fill();
    } else if (style === 'Area' || style === 'Area with breaks') {
        const fillAlpha = 0.22;
        const drawAreaSegment = function(seg) {
            if (seg.length < 2) return;
            ctx.beginPath();
            ctx.moveTo(seg[0].x, seg[0].y);
            for (let s = 1; s < seg.length; s++) ctx.lineTo(seg[s].x, seg[s].y);
            ctx.lineTo(seg[seg.length - 1].x, baselineY);
            ctx.lineTo(seg[0].x, baselineY);
            ctx.closePath();
            ctx.globalAlpha = fillAlpha;
            ctx.fill();
            ctx.globalAlpha = 1;
            ctx.beginPath();
            ctx.moveTo(seg[0].x, seg[0].y);
            for (let s = 1; s < seg.length; s++) ctx.lineTo(seg[s].x, seg[s].y);
            ctx.stroke();
        };
        let seg = [];
        for (let i = startIndex; i < endIndex; i += drawStride) {
            const val = valueAt(i);
            if (val == null || val === undefined || isNaN(val)) {
                if (breakOnNull && seg.length) { drawAreaSegment(seg); seg = []; }
                continue;
            }
            const x = this.dataIndexToPixel(i);
            const y = yAt(val);
            if (y == null || !Number.isFinite(y) || !inView(x) || !inPlotY(y)) continue;
            seg.push({ x: x, y: y });
        }
        if (seg.length) drawAreaSegment(seg);
    } else {
        ctx.setLineDash([]);
        let started = false;
        for (let i = startIndex; i < endIndex; i++) {
            const val = valueAt(i);
            if (val == null || val === undefined || isNaN(val)) continue;
            const x = this.dataIndexToPixel(i);
            const y = yAt(val);
            if (y == null || !Number.isFinite(y) || !inView(x) || !inPlotY(y)) continue;
            if (!started) { ctx.beginPath(); ctx.moveTo(x, y); started = true; }
            else ctx.lineTo(x, y);
        }
        if (started) ctx.stroke();
    }

    ctx.restore();
};

Chart.prototype._resolveIndicatorBandLineColor = function(color, opacityPct) {
    if (!color) return color;
    let op = opacityPct != null ? Number(opacityPct) : 100;
    if (!Number.isFinite(op) || op >= 100) return color;
    op = Math.max(0, Math.min(100, op)) / 100;
    const s = String(color).trim();
    const rgbaMatch = s.match(/^rgba\s*\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/i);
    if (rgbaMatch) {
        return 'rgba(' + rgbaMatch[1] + ',' + rgbaMatch[2] + ',' + rgbaMatch[3] + ',' + (parseFloat(rgbaMatch[4]) * op) + ')';
    }
    if (s.charAt(0) === '#') {
        let h = s.slice(1);
        if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
        if (h.length === 6) {
            const r = parseInt(h.slice(0, 2), 16);
            const g = parseInt(h.slice(2, 4), 16);
            const b = parseInt(h.slice(4, 6), 16);
            if (Number.isFinite(r) && Number.isFinite(g) && Number.isFinite(b)) {
                return 'rgba(' + r + ',' + g + ',' + b + ',' + op + ')';
            }
        }
    }
    return color;
};

Chart.prototype.drawOpeningRange = function(bands, style, startIndex, endIndex) {
    if (!bands || !bands.upper) return;
    style = style || {};
    const resolve = this._resolveIndicatorBandLineColor.bind(this);
    const breakStyle = function (s) {
        if (!s || s === 'Line') return 'Line with breaks';
        if (s === 'Step line') return 'Step line with breaks';
        if (s === 'Area') return 'Area with breaks';
        return s;
    };
    const drawStyle = Object.assign({}, style, {
        showFill: false,
        upperColor: resolve(style.upperColor, style.upperOpacity),
        middleColor: resolve(style.middleColor, style.middleOpacity),
        lowerColor: resolve(style.lowerColor, style.lowerOpacity),
        upperLineStyle: breakStyle(style.upperLineStyle),
        middleLineStyle: breakStyle(style.middleLineStyle),
        lowerLineStyle: breakStyle(style.lowerLineStyle)
    });
    this.drawBollingerBands(bands, drawStyle, startIndex, endIndex);
};

Chart.prototype.drawBollingerBands = function(bands, style, startIndex = 0, endIndex = bands.upper.length, plotOffset = 0) {
    const ctx = this.ctx;
    const m = this.margin;
    style = style || {};
    const off = (Number(plotOffset) | 0) || 0;
    const bandVal = function(arr, i) {
        return off ? seriesValueAtPlotOffset(arr, i, off) : arr[i];
    };

    const fillRgba = bollingerFillRgba(style);
    if (fillRgba) {
        ctx.fillStyle = fillRgba;
        ctx.beginPath();

        let pathStarted = false;
        for (let i = startIndex; i < endIndex; i++) {
            const upperVal = bandVal(bands.upper, i);
            if (upperVal === null || upperVal === undefined || isNaN(upperVal)) continue;

            const x = this.dataIndexToPixel(i);
            const y = this.yScale(upperVal);

            if (x < m.l - 50 || x > this.w - m.r + 50) continue;

            if (!pathStarted) {
                ctx.moveTo(x, y);
                pathStarted = true;
            } else {
                ctx.lineTo(x, y);
            }
        }

        for (let i = Math.min(endIndex - 1, bands.lower.length - 1); i >= startIndex; i--) {
            const lowerVal = bandVal(bands.lower, i);
            if (lowerVal === null || lowerVal === undefined || isNaN(lowerVal)) continue;
            if (!pathStarted) continue;

            const x = this.dataIndexToPixel(i);
            const y = this.yScale(lowerVal);

            if (x < m.l - 50 || x > this.w - m.r + 50) continue;

            ctx.lineTo(x, y);
        }

        if (pathStarted) {
            ctx.closePath();
            ctx.fill();
        }
    }

    const legacyW = style.lineWidth != null ? style.lineWidth : 1;
    const legacyS = style.lineStyle || 'Line';
    const upperColor = style.upperColor;
    const middleColor = style.middleColor;
    const lowerColor = style.lowerColor;

    const bandLineOpts = { plotOffset: off };

    if (style.showUpper !== false) {
        this.drawLineIndicator(
            bands.upper,
            upperColor,
            style.upperLineWidth != null ? style.upperLineWidth : legacyW,
            startIndex,
            endIndex,
            style.upperLineStyle || legacyS,
            Object.assign({ dashStyle: style.upperLineDashStyle || 'Solid' }, bandLineOpts)
        );
    }
    if (style.showMiddle !== false) {
        this.drawLineIndicator(
            bands.middle,
            middleColor,
            style.middleLineWidth != null ? style.middleLineWidth : legacyW,
            startIndex,
            endIndex,
            style.middleLineStyle || legacyS,
            Object.assign({ dashStyle: style.middleLineDashStyle || 'Solid' }, bandLineOpts)
        );
    }
    if (style.showLower !== false) {
        this.drawLineIndicator(
            bands.lower,
            lowerColor,
            style.lowerLineWidth != null ? style.lowerLineWidth : legacyW,
            startIndex,
            endIndex,
            style.lowerLineStyle || legacyS,
            Object.assign({ dashStyle: style.lowerLineDashStyle || 'Solid' }, bandLineOpts)
        );
    }
};

/** VWAP overlay — main line, band lines (1–3), optional fill between upper1/lower1. */
Chart.prototype.drawVwapIndicator = function(data, style, startIndex, endIndex, params) {
    if (!data || !Array.isArray(data.vwap)) return;
    style = style || {};
    params = params || {};
    const plotOffset = params.offset != null ? (Number(params.offset) | 0) : 0;
    const lineOpts = { plotOffset: plotOffset };
    const resolve = this._resolveIndicatorBandLineColor.bind(this);
    const legacyW = style.lineWidth != null ? style.lineWidth : 2;
    const legacyS = style.lineStyle || 'Line';
    const upperCol = resolve(style.upperColor, style.upperOpacity);
    const lowerCol = resolve(style.lowerColor, style.lowerOpacity);
    const upperW = style.upperLineWidth != null ? style.upperLineWidth : 1;
    const lowerW = style.lowerLineWidth != null ? style.lowerLineWidth : 1;
    const upperStyle = style.upperLineStyle || legacyS;
    const lowerStyle = style.lowerLineStyle || legacyS;
    const upperDash = style.upperLineDashStyle || 'Solid';
    const lowerDash = style.lowerLineDashStyle || 'Solid';
    const vwapVal = function(arr, i) {
        return plotOffset ? seriesValueAtPlotOffset(arr, i, plotOffset) : arr[i];
    };
    const drawBandLine = function(arr, lineStyle, color, width, dashStyle) {
        if (!arr) return;
        const opts = Object.assign({ dashStyle: dashStyle || 'Solid' }, lineOpts);
        this.drawLineIndicator(
            arr,
            color,
            width,
            startIndex,
            endIndex,
            lineStyle,
            opts
        );
    }.bind(this);
    const drawBandPair = function(upperArr, lowerArr, upperStyleLocal, lowerStyleLocal) {
        if (style.showUpper1 !== false && upperArr) {
            drawBandLine(upperArr, upperStyleLocal || upperStyle, upperCol, upperW, upperDash);
        }
        if (style.showLower1 !== false && lowerArr) {
            drawBandLine(lowerArr, lowerStyleLocal || lowerStyle, lowerCol, lowerW, lowerDash);
        }
    }.bind(this);

    if (style.showFill1 === true && data.upper1 && data.lower1) {
        const fillRgba = bollingerFillRgba({
            showFill: true,
            fillColor: style.fillColor,
            fillOpacity: style.fillOpacity
        });
        if (fillRgba) {
            const ctx = this.ctx;
            const m = this.margin;
            ctx.fillStyle = fillRgba;
            ctx.beginPath();
            let pathStarted = false;
            for (let i = startIndex; i < endIndex; i++) {
                const uv = vwapVal(data.upper1, i);
                if (uv == null || isNaN(uv)) continue;
                const x = this.dataIndexToPixel(i);
                const y = this.yScale(uv);
                if (x < m.l - 50 || x > this.w - m.r + 50) continue;
                if (!pathStarted) {
                    ctx.moveTo(x, y);
                    pathStarted = true;
                } else {
                    ctx.lineTo(x, y);
                }
            }
            for (let i = Math.min(endIndex - 1, data.lower1.length - 1); i >= startIndex; i--) {
                const lv = vwapVal(data.lower1, i);
                if (lv == null || isNaN(lv) || !pathStarted) continue;
                const x = this.dataIndexToPixel(i);
                const y = this.yScale(lv);
                if (x < m.l - 50 || x > this.w - m.r + 50) continue;
                ctx.lineTo(x, y);
            }
            if (pathStarted) {
                ctx.closePath();
                ctx.fill();
            }
        }
    }

    if (style.showVwap !== false) {
        const vwapColor = resolve(style.color, style.lineOpacity);
        const vwapDash = style.lineDashStyle || 'Solid';
        const vwapOpts = Object.assign({ dashStyle: vwapDash }, lineOpts);
        this.drawLineIndicator(
            data.vwap,
            vwapColor,
            legacyW,
            startIndex,
            endIndex,
            legacyS,
            vwapOpts
        );
    }
    if (params.band1Enabled !== false) {
        drawBandPair(data.upper1, data.lower1);
    }
    if (params.band2Enabled === true) {
        drawBandPair(data.upper2, data.lower2);
    }
    if (params.band3Enabled === true) {
        drawBandPair(data.upper3, data.lower3);
    }
};

/** Parabolic SAR — dots or plot-style markers; up/down colors by trend */
Chart.prototype.drawParabolicSAR = function(sar, style, startIndex = 0, endIndex) {
    if (!sar || !this.data || !this.data.length || !style) return;
    const showUp = style.showUp !== false;
    const showDown = style.showDown !== false;
    if (!showUp && !showDown) return;
    const plotStyle = this._normalizePlotStyle(style.lineStyle || 'Circles');
    const bull = style.bullColor || style.color || '#26a69a';
    const bear = style.bearColor || '#ef5350';
    const lw = style.lineWidth || 2;
    const dashStyle = style.lineDashStyle || 'Solid';
    const scatterStyles = { Circles: 1, Cross: 1 };
    const n = Math.min(sar.length, this.data.length);
    endIndex = endIndex == null ? n : Math.min(endIndex, n);
    const self = this;
    const isUpAt = function (i) {
        const bar = self.data[i];
        return bar && sar[i] != null && !isNaN(sar[i]) && bar.c >= sar[i];
    };
    const shouldDrawAt = function (i) {
        return isUpAt(i) ? showUp : showDown;
    };
    const colorAt = (i) => {
        return isUpAt(i) ? bull : bear;
    };
    if (!scatterStyles[plotStyle]) {
        const ctx = this.ctx;
        const m = this.margin;
        const dash = this._lineDashForStyle(dashStyle === 'Solid' ? 'Line' : dashStyle);
        ctx.save();
        ctx.lineWidth = lw;
        ctx.lineCap = 'butt';
        ctx.lineJoin = 'round';
        ctx.setLineDash(dash);
        let segStarted = false;
        let segColor = null;
        let prevX = null;
        let prevY = null;
        const flushSeg = function () {
            if (segStarted) ctx.stroke();
            ctx.beginPath();
            segStarted = false;
        };
        for (let i = startIndex; i < endIndex && i < sar.length; i++) {
            if (sar[i] == null || isNaN(sar[i]) || !shouldDrawAt(i)) {
                flushSeg();
                prevX = null;
                continue;
            }
            const x = this.dataIndexToPixel(i);
            const y = this.yScale(sar[i]);
            if (!Number.isFinite(x) || !Number.isFinite(y)) {
                flushSeg();
                prevX = null;
                continue;
            }
            const c = colorAt(i);
            if (segColor !== c) {
                flushSeg();
                segColor = c;
                ctx.strokeStyle = c;
            }
            if (!segStarted) {
                ctx.moveTo(x, y);
                segStarted = true;
            } else if (plotStyle.indexOf('Step') === 0 && prevX != null) {
                ctx.lineTo(x, prevY);
                ctx.lineTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
            prevX = x;
            prevY = y;
        }
        flushSeg();
        ctx.restore();
        return;
    }
    const ctx = this.ctx;
    const m = this.margin;
    const plotLayout = typeof this._getMainPricePlotLayout === 'function'
        ? this._getMainPricePlotLayout()
        : { m: m, plotHeight: this.h - m.t - m.b };
    const plotYMin = plotLayout.m.t;
    const plotYMax = plotLayout.m.t + plotLayout.plotHeight;
    const r = Math.max(1.2, lw * 0.65);
    const cross = plotStyle === 'Cross';
    ctx.save();
    ctx.lineWidth = Math.max(1, lw * 0.75);
    ctx.lineCap = 'round';
    for (let i = startIndex; i < endIndex; i++) {
        if (sar[i] === null || sar[i] === undefined || isNaN(sar[i]) || !shouldDrawAt(i)) continue;
        const x = this.dataIndexToPixel(i);
        const y = this.yScale(sar[i]);
        if (x < m.l - 50 || x > this.w - m.r + 50) continue;
        if (!Number.isFinite(y) || y < plotYMin || y > plotYMax) continue;
        const col = colorAt(i);
        ctx.strokeStyle = col;
        ctx.fillStyle = col;
        if (cross) {
            const s = r + 1;
            ctx.beginPath();
            ctx.moveTo(x - s, y);
            ctx.lineTo(x + s, y);
            ctx.moveTo(x, y - s);
            ctx.lineTo(x, y + s);
            ctx.stroke();
        } else {
            ctx.beginPath();
            ctx.arc(x, y, r, 0, Math.PI * 2);
            ctx.fill();
        }
    }
    ctx.restore();
};

// Draw ADR Bands - upper and lower bands based on Average Daily Range
Chart.prototype.drawADRBands = function(data, style, startIndex = 0, endIndex) {
    if (!data || !data.upper || !data.lower) return;
    
    const ctx = this.ctx;
    const m = this.margin;
    const color = style.color || '#00bcd4';
    const lineWidth = style.lineWidth || 2;
    
    // Draw upper band
    ctx.strokeStyle = color;
    ctx.lineWidth = lineWidth;
    ctx.setLineDash([5, 5]); // Dashed line for ADR bands
    
    // Upper band
    ctx.beginPath();
    let started = false;
    for (let i = startIndex; i < endIndex && i < data.upper.length; i++) {
        if (data.upper[i] === null) continue;
        
        const x = this.dataIndexToPixel(i);
        const y = this.yScale(data.upper[i]);
        
        if (x < m.l - 50 || x > this.w - m.r + 50) continue;
        
        if (!started) {
            ctx.moveTo(x, y);
            started = true;
        } else {
            ctx.lineTo(x, y);
        }
    }
    if (started) ctx.stroke();
    
    // Lower band
    ctx.beginPath();
    started = false;
    for (let i = startIndex; i < endIndex && i < data.lower.length; i++) {
        if (data.lower[i] === null) continue;
        
        const x = this.dataIndexToPixel(i);
        const y = this.yScale(data.lower[i]);
        
        if (x < m.l - 50 || x > this.w - m.r + 50) continue;
        
        if (!started) {
            ctx.moveTo(x, y);
            started = true;
        } else {
            ctx.lineTo(x, y);
        }
    }
    if (started) ctx.stroke();
    
    ctx.setLineDash([]); // Reset to solid line
};

// Draw ATR Bands - upper and lower bands based on ATR multiplier
Chart.prototype.drawATRBands = function(data, style, startIndex = 0, endIndex) {
    if (!data || !data.upper || !data.lower) return;
    
    const ctx = this.ctx;
    const m = this.margin;
    const color = style.color || '#ff6d00';
    const lineWidth = style.lineWidth || 2;
    
    ctx.strokeStyle = color;
    ctx.lineWidth = lineWidth;
    ctx.globalAlpha = 0.8;
    
    // Upper band
    ctx.beginPath();
    let started = false;
    for (let i = startIndex; i < endIndex && i < data.upper.length; i++) {
        if (data.upper[i] === null) continue;
        
        const x = this.dataIndexToPixel(i);
        const y = this.yScale(data.upper[i]);
        
        if (x < m.l - 50 || x > this.w - m.r + 50) continue;
        
        if (!started) {
            ctx.moveTo(x, y);
            started = true;
        } else {
            ctx.lineTo(x, y);
        }
    }
    if (started) ctx.stroke();
    
    // Lower band
    ctx.beginPath();
    started = false;
    for (let i = startIndex; i < endIndex && i < data.lower.length; i++) {
        if (data.lower[i] === null) continue;
        
        const x = this.dataIndexToPixel(i);
        const y = this.yScale(data.lower[i]);
        
        if (x < m.l - 50 || x > this.w - m.r + 50) continue;
        
        if (!started) {
            ctx.moveTo(x, y);
            started = true;
        } else {
            ctx.lineTo(x, y);
        }
    }
    if (started) ctx.stroke();
    
    ctx.globalAlpha = 1.0;
};

Chart.prototype._chartBarMinutes = function() {
    if (typeof this.parseTimeframe !== 'function' || !this.currentTimeframe) return null;
    const ms = this.parseTimeframe(this.currentTimeframe);
    return ms ? ms / 60000 : null;
};

Chart.prototype._sessionsVisibleForMaxTimeframe = function(indicator) {
    if (!indicator || !indicator.params) return true;
    const maxRaw = indicator.params.maxTimeframeMinutes;
    const maxMin = maxRaw != null ? Number(maxRaw) : 0;
    if (!Number.isFinite(maxMin) || maxMin <= 0) return true;
    const barMin = this._chartBarMinutes();
    if (!Number.isFinite(barMin)) return true;
    return barMin <= maxMin;
};

// Draw Sessions indicator — merged session boxes with optional labels
Chart.prototype.drawSessions = function(data, indicator, startIndex, endIndex) {
    const style = (indicator && indicator.style) || indicator || {};
    const perCandle = Array.isArray(data)
        ? data
        : (data && Array.isArray(data.perCandle) ? data.perCandle : null);
    if (!perCandle || !perCandle.length) return;

    const ctx = this.ctx;
    const m = this.margin;
    const plotLayout = typeof this._getMainPricePlotLayout === 'function'
        ? this._getMainPricePlotLayout()
        : null;
    const priceAreaBottom = plotLayout ? plotLayout.plotBottom : (this.h - m.b);
    const plotH = priceAreaBottom - m.t;
    const showLabels = style.showSessionLabels !== false;
    const end = Math.min(endIndex != null ? endIndex : perCandle.length, perCandle.length);
    const start = Math.max(0, startIndex || 0);

    const activeKeys = {};
    for (let i = start; i < end; i++) {
        const list = perCandle[i];
        if (!list || !list.length) continue;
        list.forEach(function (s) {
            if (s && s.type) activeKeys[s.type] = true;
        });
    }

    const self = this;
    Object.keys(activeKeys).forEach(function (sessionKey) {
        let runStart = null;
        let runColor = null;
        let runName = null;

        function flushRun(runEnd) {
            if (runStart == null || runEnd < runStart) return;
            const x1 = self.dataIndexToPixel(runStart);
            const x2 = self.dataIndexToPixel(runEnd);
            const cw = self.candleWidth || 8;
            const left = Math.min(x1, x2) - cw / 2;
            const width = Math.max(cw, Math.abs(x2 - x1) + cw);
            if (left + width < m.l || left > self.w - m.r) return;
            ctx.fillStyle = runColor || 'rgba(120,123,134,0.12)';
            ctx.fillRect(left, m.t, width, plotH);
            if (showLabels && runName) {
                const midX = left + width / 2;
                ctx.save();
                ctx.font = '600 11px system-ui, -apple-system, Segoe UI, sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'top';
                ctx.fillStyle = 'rgba(209, 212, 220, 0.92)';
                ctx.fillText(runName, midX, m.t + 6);
                ctx.restore();
            }
        }

        for (let i = start; i < end; i++) {
            const list = perCandle[i] || [];
            const hit = list.find(function (s) { return s && s.type === sessionKey; });
            if (hit) {
                if (runStart == null) {
                    runStart = i;
                    runColor = hit.color;
                    runName = hit.name || sessionKey;
                }
            } else if (runStart != null) {
                flushRun(i - 1);
                runStart = null;
                runColor = null;
                runName = null;
            }
        }
        if (runStart != null) flushRun(end - 1);
    });
};

// Draw ICT Kill Zones indicator - session boxes with high/low boundaries
Chart.prototype.drawKillzones = function(data, style, startIndex = 0, endIndex) {
    if (!data || !data.boxes || data.boxes.length === 0) return;
    
    const ctx = this.ctx;
    const m = this.margin;
    const plotLayout = typeof this._getMainPricePlotLayout === 'function'
        ? this._getMainPricePlotLayout()
        : null;
    const priceAreaBottom = plotLayout ? plotLayout.plotBottom : (this.h - m.b);
    
    const transparency = data.boxTransparency !== undefined ? data.boxTransparency : 88;
    const baseFillAlpha = killzonesBoxFillAlpha(transparency);
    
    const colorToRgba = function(c, alpha) {
        if (alpha == null || isNaN(alpha)) alpha = 0.18;
        alpha = Math.min(1, Math.max(0, alpha));
        if (!c || typeof c !== 'string') return 'rgba(100,120,160,' + alpha + ')';
        const s = c.trim();
        if (s.indexOf('rgba') === 0 || s.indexOf('rgb(') === 0) {
            const m = s.match(/rgba?\s*\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)/i);
            if (m) return 'rgba(' + m[1] + ',' + m[2] + ',' + m[3] + ',' + alpha + ')';
        }
        let hex = s.replace('#', '');
        if (hex.length === 3) {
            hex = hex.split('').map(function(ch) { return ch + ch; }).join('');
        }
        if (hex.length === 6) {
            const r = parseInt(hex.slice(0, 2), 16);
            const g = parseInt(hex.slice(2, 4), 16);
            const b = parseInt(hex.slice(4, 6), 16);
            if (!isNaN(r) && !isNaN(g) && !isNaN(b)) return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
        }
        return 'rgba(100,120,160,' + alpha + ')';
    };
    
    const roundRectPath = function(context, x, y, w, h, r) {
        const rad = Math.min(r, w / 2, h / 2);
        if (typeof context.roundRect === 'function') {
            context.beginPath();
            context.roundRect(x, y, w, h, rad);
        } else {
            context.beginPath();
            context.moveTo(x + rad, y);
            context.lineTo(x + w - rad, y);
            context.quadraticCurveTo(x + w, y, x + w, y + rad);
            context.lineTo(x + w, y + h - rad);
            context.quadraticCurveTo(x + w, y + h, x + w - rad, y + h);
            context.lineTo(x + rad, y + h);
            context.quadraticCurveTo(x, y + h, x, y + h - rad);
            context.lineTo(x, y + rad);
            context.quadraticCurveTo(x, y, x + rad, y);
            context.closePath();
        }
    };
    
    const boxes = data.boxes.slice().sort(function(a, b) {
        if (a.startIndex !== b.startIndex) return a.startIndex - b.startIndex;
        return (a.endIndex || 0) - (b.endIndex || 0);
    });
    
    const self = this;
    ctx.save();
    ctx.imageSmoothingEnabled = true;
    
    boxes.forEach(function(box) {
        let startIdx = box.startIndex;
        let endIdx = box.endIndex;
        if (self.replaySystem && self.replaySystem.isActive && self.data && self.data.length > 0) {
            const maxIdx = self.data.length - 1;
            startIdx = Math.min(Math.max(startIdx, 0), maxIdx);
            endIdx = Math.min(Math.max(endIdx, 0), maxIdx);
        }
        const x1 = self.dataIndexToPixel(startIdx);
        const x2 = self.dataIndexToPixel(endIdx);
        const yTop = self.yScale(box.high);
        const yBot = self.yScale(box.low);
        
        if (x2 < m.l || x1 > self.w - m.r) return;
        
        const drawX1 = Math.max(x1, m.l);
        const drawX2 = Math.min(x2, self.w - m.r);
        const boxWidth = drawX2 - drawX1;
        const top = Math.min(yTop, yBot);
        const bot = Math.max(yTop, yBot);
        const boxHeight = bot - top;
        
        if (boxWidth <= 0 || boxHeight <= 0) return;
        
        const fillCol = colorToRgba(box.color, baseFillAlpha);
        const edgeCol = colorToRgba(box.color, Math.min(0.85, baseFillAlpha * 1.75 + 0.06));
        
        roundRectPath(ctx, drawX1, top, boxWidth, boxHeight, 3);
        ctx.fillStyle = fillCol;
        ctx.fill();
        
        ctx.strokeStyle = edgeCol;
        ctx.lineWidth = 1;
        ctx.setLineDash([]);
        roundRectPath(ctx, drawX1, top, boxWidth, boxHeight, 3);
        ctx.stroke();
        
        if (data.showMidline) {
            const midY = (top + bot) / 2;
            ctx.strokeStyle = colorToRgba(box.color, 0.2);
            ctx.lineWidth = 1;
            ctx.setLineDash([7, 6]);
            ctx.beginPath();
            ctx.moveTo(drawX1 + 1, midY);
            ctx.lineTo(drawX2 - 1, midY);
            ctx.stroke();
            ctx.setLineDash([]);
        }
        
        if (data.showBoxInfo && boxWidth > 48) {
            const range = box.range;
            const pipMultiplier = self.pipSize || 0.0001;
            const pips = Math.round(range / pipMultiplier);
            const label = box.name + ' · ' + pips + ' pips';
            ctx.font = '600 11px Roboto, system-ui, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';
            const tw = ctx.measureText(label).width + 16;
            const th = 18;
            let lx = (drawX1 + drawX2) / 2 - tw / 2;
            let ly = top - 6;
            lx = Math.max(m.l + 2, Math.min(lx, self.w - m.r - tw - 2));
            if (ly - th < m.t + 4) {
                ly = bot + th + 8;
            }
            ctx.fillStyle = 'rgba(13, 17, 23, 0.88)';
            roundRectPath(ctx, lx, ly - th, tw, th, 4);
            ctx.fill();
            ctx.strokeStyle = 'rgba(255,255,255,0.1)';
            ctx.lineWidth = 1;
            roundRectPath(ctx, lx, ly - th, tw, th, 4);
            ctx.stroke();
            ctx.fillStyle = style.textColor || '#d1d4dc';
            ctx.fillText(label, lx + tw / 2, ly - 4);
        }
        
        if (data.showDeviations && data.deviationCount > 0) {
            const devRange = box.range;
            ctx.setLineDash([5, 5]);
            ctx.strokeStyle = colorToRgba(box.color, 0.26);
            ctx.lineWidth = 1;
            for (let d = 1; d <= data.deviationCount; d++) {
                const upperDevPrice = box.high + (devRange * d);
                const upperY = self.yScale(upperDevPrice);
                if (upperY >= m.t && upperY <= priceAreaBottom) {
                    ctx.beginPath();
                    ctx.moveTo(drawX1, upperY);
                    ctx.lineTo(drawX2, upperY);
                    ctx.stroke();
                }
                const lowerDevPrice = box.low - (devRange * d);
                const lowerY = self.yScale(lowerDevPrice);
                if (lowerY <= priceAreaBottom && lowerY >= m.t) {
                    ctx.beginPath();
                    ctx.moveTo(drawX1, lowerY);
                    ctx.lineTo(drawX2, lowerY);
                    ctx.stroke();
                }
            }
            ctx.setLineDash([]);
        }
    });
    
    ctx.restore();
    
    if (data.showNYMidnight && data.nyMidnight && data.nyMidnight.length > 0) {
        const nyRaw = data.nyMidnightColor || '#2d62b6';
        const nyStroke = colorToRgba(nyRaw, 0.38);
        const prec = self._symbolPrecision != null ? self._symbolPrecision : (self.pricePrecision != null ? self.pricePrecision : 5);
        
        data.nyMidnight.forEach(function(midnight) {
            const visLeft = m.l;
            const visRight = self.w - m.r;
            const xOpen = self.dataIndexToPixel(midnight.index);
            const endIdx = midnight.endIndex != null ? midnight.endIndex : midnight.index;
            const xDayEnd = self.dataIndexToPixel(endIdx);
            const xSegLeft = Math.min(xOpen, xDayEnd);
            const xSegRight = Math.max(xOpen, xDayEnd);
            const y = self.yScale(midnight.price);
            
            const hLeft = Math.max(xSegLeft, visLeft);
            const hRight = Math.min(xSegRight, visRight);
            const vertInView = xOpen >= visLeft && xOpen <= visRight;
            if (hLeft >= hRight && !vertInView) return;
            
            ctx.save();
            ctx.strokeStyle = nyStroke;
            ctx.globalAlpha = 0.9;
            
            if (vertInView) {
                ctx.lineWidth = 1;
                ctx.setLineDash([10, 14]);
                ctx.beginPath();
                ctx.moveTo(xOpen, m.t + 2);
                ctx.lineTo(xOpen, priceAreaBottom - 1);
                ctx.stroke();
            }
            
            if (hLeft < hRight) {
                ctx.setLineDash([12, 8]);
                ctx.lineWidth = 1.15;
                ctx.beginPath();
                ctx.moveTo(hLeft, y);
                ctx.lineTo(hRight, y);
                ctx.stroke();
            }
            ctx.setLineDash([]);
            ctx.globalAlpha = 1;
            
            const priceText = 'Midnight open ' + midnight.price.toFixed(prec);
            ctx.font = '600 11px Roboto, system-ui, sans-serif';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'bottom';
            const tw = ctx.measureText(priceText).width + 14;
            const th = 18;
            let lx;
            if (vertInView) {
                lx = xOpen + 6;
                if (lx + tw > visRight - 2) lx = xOpen - tw - 6;
            } else {
                lx = Math.min(hRight - tw - 6, visRight - tw - 8);
                lx = Math.max(hLeft + 4, lx);
            }
            let ly = y - 6;
            if (ly - th < m.t + 2) ly = y + th + 4;
            ctx.fillStyle = 'rgba(13, 17, 23, 0.9)';
            roundRectPath(ctx, lx, ly - th, tw, th, 4);
            ctx.fill();
            ctx.strokeStyle = colorToRgba(nyRaw, 0.55);
            ctx.lineWidth = 1;
            roundRectPath(ctx, lx, ly - th, tw, th, 4);
            ctx.stroke();
            ctx.fillStyle = style.textColor || '#d1d4dc';
            ctx.fillText(priceText, lx + 7, ly - 5);
            ctx.restore();
        });
    }
};

function _ictOverlayTableAnchor(pos, chartW, chartH, margin, panelW, panelH) {
    const pad = 10;
    const plotL = margin.l;
    const plotR = chartW - margin.r;
    const plotT = margin.t;
    const plotB = chartH - margin.b;
    const p = String(pos || 'Top Right');
    let x = plotL + pad;
    let y = plotT + pad;
    if (p.indexOf('Right') >= 0) x = plotR - pad - panelW;
    else if (p.indexOf('Center') >= 0) x = (plotL + plotR - panelW) / 2;
    if (p.indexOf('Bottom') >= 0) y = plotB - pad - panelH;
    else if (p.indexOf('Middle') >= 0) y = (plotT + plotB - panelH) / 2;
    x = Math.max(plotL + 4, Math.min(x, plotR - panelW - 4));
    y = Math.max(plotT + 4, Math.min(y, plotB - panelH - 4));
    return { x: x, y: y };
}

function _ictBiasValueColor(bias) {
    const b = String(bias || '').toLowerCase();
    if (b === 'bullish') return '#26a69a';
    if (b === 'bearish') return '#ef5350';
    if (b === 'consolidating') return '#787b86';
    if (b === 'unclear') return '#ff9800';
    return null;
}

function _ictWrapCanvasLines(ctx, text, maxWidth) {
    const out = [];
    String(text || '').split(/\r?\n/).forEach(function (para) {
        const words = para.trim().split(/\s+/).filter(Boolean);
        if (!words.length) {
            out.push('');
            return;
        }
        let line = words[0];
        for (let i = 1; i < words.length; i++) {
            const next = line + ' ' + words[i];
            if (ctx.measureText(next).width <= maxWidth) line = next;
            else {
                out.push(line);
                line = words[i];
            }
        }
        out.push(line);
    });
    return out.length ? out : [''];
}

Chart.prototype._drawIctOverlayTable = function(anchorPos, title, rows, textColor, options) {
    options = options || {};
    const ctx = this.ctx;
    const m = this.margin;
    const titleFont = '700 11px Roboto, system-ui, sans-serif';
    const bodyFont = '500 11px Roboto, system-ui, sans-serif';
    const padX = 10;
    const padY = 7;
    const lineH = 14;
    const gap = 4;
    const maxInnerW = options.maxWidth != null ? options.maxWidth : 220;
    ctx.save();
    ctx.font = titleFont;
    let innerW = ctx.measureText(String(title || '')).width;
    ctx.font = bodyFont;
    rows.forEach(function (row) {
        if (row.kind === 'text') {
            _ictWrapCanvasLines(ctx, row.text, maxInnerW).forEach(function (ln) {
                innerW = Math.max(innerW, ctx.measureText(ln).width);
            });
        } else {
            innerW = Math.max(innerW, ctx.measureText(String(row.left || '')).width + 12 + ctx.measureText(String(row.right || '')).width);
        }
    });
    innerW = Math.min(maxInnerW, Math.max(72, innerW));
    let rowCount = 0;
    rows.forEach(function (row) {
        if (row.kind === 'text') rowCount += _ictWrapCanvasLines(ctx, row.text, innerW).length;
        else rowCount += 1;
    });
    const panelW = innerW + padX * 2;
    const panelH = padY * 2 + lineH + gap + rowCount * lineH;
    const anchor = _ictOverlayTableAnchor(anchorPos, this.w, this.h, m, panelW, panelH);
    ctx.fillStyle = options.bg || 'rgba(13, 17, 23, 0.92)';
    ctx.strokeStyle = options.border || 'rgba(255,255,255,0.12)';
    ctx.lineWidth = 1;
    const rx = anchor.x;
    const ry = anchor.y;
    const rr = 4;
    ctx.beginPath();
    ctx.moveTo(rx + rr, ry);
    ctx.lineTo(rx + panelW - rr, ry);
    ctx.quadraticCurveTo(rx + panelW, ry, rx + panelW, ry + rr);
    ctx.lineTo(rx + panelW, ry + panelH - rr);
    ctx.quadraticCurveTo(rx + panelW, ry + panelH, rx + panelW - rr, ry + panelH);
    ctx.lineTo(rx + rr, ry + panelH);
    ctx.quadraticCurveTo(rx, ry + panelH, rx, ry + panelH - rr);
    ctx.lineTo(rx, ry + rr);
    ctx.quadraticCurveTo(rx, ry, rx + rr, ry);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.font = titleFont;
    ctx.fillStyle = textColor || '#d1d4dc';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText(String(title || ''), anchor.x + padX, anchor.y + padY);
    let y = anchor.y + padY + lineH + gap;
    ctx.font = bodyFont;
    rows.forEach(function (row) {
        if (row.kind === 'text') {
            _ictWrapCanvasLines(ctx, row.text, innerW).forEach(function (ln) {
                ctx.fillStyle = textColor || '#d1d4dc';
                ctx.fillText(ln, anchor.x + padX, y);
                y += lineH;
            });
            return;
        }
        ctx.fillStyle = textColor || '#d1d4dc';
        ctx.fillText(String(row.left || ''), anchor.x + padX, y);
        const biasCol = _ictBiasValueColor(row.right);
        ctx.fillStyle = biasCol || textColor || '#d1d4dc';
        ctx.textAlign = 'right';
        ctx.fillText(String(row.right || ''), anchor.x + panelW - padX, y);
        ctx.textAlign = 'left';
        y += lineH;
    });
    ctx.restore();
};

Chart.prototype.drawIctEverything = function(data, style, startIndex = 0, endIndex) {
    if (!data || !data.dom) return;
    const ctx = this.ctx;
    const m = this.margin;
    const plotLayout = typeof this._getMainPricePlotLayout === 'function'
        ? this._getMainPricePlotLayout()
        : null;
    const priceAreaBottom = plotLayout ? plotLayout.plotBottom : (this.h - m.b);
    const n = this.data ? this.data.length : 0;
    endIndex = endIndex == null ? n : Math.min(endIndex, n);
    const self = this;

    const colorToRgba = function(c, alpha) {
        if (alpha == null || isNaN(alpha)) alpha = 0.18;
        alpha = Math.min(1, Math.max(0, alpha));
        if (!c || typeof c !== 'string') return 'rgba(100,120,160,' + alpha + ')';
        const s = c.trim();
        if (s.indexOf('rgba') === 0 || s.indexOf('rgb(') === 0) {
            const mm = s.match(/rgba?\s*\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)/i);
            if (mm) return 'rgba(' + mm[1] + ',' + mm[2] + ',' + mm[3] + ',' + alpha + ')';
        }
        let hex = s.replace('#', '');
        if (hex.length === 3) {
            hex = hex.split('').map(function(ch) { return ch + ch; }).join('');
        }
        if (hex.length === 6) {
            const r = parseInt(hex.slice(0, 2), 16);
            const g = parseInt(hex.slice(2, 4), 16);
            const b = parseInt(hex.slice(4, 6), 16);
            if (!isNaN(r) && !isNaN(g) && !isNaN(b)) return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
        }
        return 'rgba(100,120,160,' + alpha + ')';
    };

    if (data.sessionStrips && data.sessionStrips.length) {
        const candleWidth = this.candleWidth || 8;
        for (let i = startIndex; i < endIndex && i < data.sessionStrips.length; i++) {
            const row = data.sessionStrips[i];
            if (!row || !row.length) continue;
            const x = self.dataIndexToPixel(i);
            if (x < m.l - candleWidth || x > self.w - m.r + candleWidth) continue;
            row.forEach(function(seg) {
                ctx.fillStyle = seg.color;
                ctx.fillRect(x - candleWidth / 2, m.t, candleWidth, priceAreaBottom - m.t);
            });
        }
    }

    if (data.boxes && data.boxes.length) {
        const kzLike = {
            boxes: data.boxes,
            showMidline: false,
            showBoxInfo: data.showBoxInfo !== false,
            showDeviations: false,
            boxTransparency: data.boxTransparency != null ? data.boxTransparency : 88
        };
        this.drawKillzones(kzLike, style, startIndex, endIndex);
    }

    if (data.boxDeviations && data.boxDeviations.length) {
        data.boxDeviations.forEach(function(seg) {
            if (seg.endIndex < startIndex || seg.startIndex > endIndex) return;
            const x1 = self.dataIndexToPixel(seg.startIndex);
            const x2 = self.dataIndexToPixel(seg.endIndex);
            if (x2 < m.l || x1 > self.w - m.r) return;
            const drawX1 = Math.max(x1, m.l);
            const drawX2 = Math.min(x2, self.w - m.r);
            const y = self.yScale(seg.price);
            if (y < m.t || y > priceAreaBottom) return;
            ctx.save();
            ctx.strokeStyle = colorToRgba(seg.color || '#787b86', 0.45);
            ctx.lineWidth = seg.lw != null ? seg.lw : 1;
            ctx.setLineDash(seg.dash && seg.dash.length ? seg.dash : []);
            ctx.beginPath();
            ctx.moveTo(drawX1, y);
            ctx.lineTo(drawX2, y);
            ctx.stroke();
            ctx.setLineDash([]);
            ctx.restore();
        });
    }

    if (data.verticals && data.verticals.length) {
        data.verticals.forEach(function(v) {
            if (v.index < startIndex || v.index > endIndex) return;
            const x = self.dataIndexToPixel(v.index);
            if (x < m.l || x > self.w - m.r) return;
            ctx.save();
            ctx.strokeStyle = colorToRgba(v.color || '#787b86', 0.55);
            ctx.lineWidth = v.lw != null ? v.lw : 1;
            ctx.setLineDash(v.dash && v.dash.length ? v.dash : []);
            ctx.beginPath();
            ctx.moveTo(x, m.t + 2);
            ctx.lineTo(x, priceAreaBottom - 1);
            ctx.stroke();
            ctx.setLineDash([]);
            ctx.restore();
        });
    }

    if (data.horizontals && data.horizontals.length) {
        const prec = self._symbolPrecision != null ? self._symbolPrecision : (self.pricePrecision != null ? self.pricePrecision : 5);
        data.horizontals.forEach(function(h) {
            if (h.endIndex < startIndex || h.startIndex > endIndex) return;
            const x1 = self.dataIndexToPixel(h.startIndex);
            const x2 = self.dataIndexToPixel(h.endIndex);
            const drawX1 = Math.max(x1, m.l);
            const drawX2 = Math.min(x2, self.w - m.r);
            const y = self.yScale(h.price);
            if (y < m.t || y > priceAreaBottom) return;
            ctx.save();
            ctx.strokeStyle = colorToRgba(h.color || '#787b86', 0.65);
            ctx.lineWidth = h.lw != null ? h.lw : 1;
            ctx.setLineDash(h.dash && h.dash.length ? h.dash : []);
            ctx.beginPath();
            ctx.moveTo(drawX1, y);
            ctx.lineTo(drawX2, y);
            ctx.stroke();
            ctx.setLineDash([]);
            if (h.showLabel && h.label && drawX2 - drawX1 > 40) {
                const txt = String(h.label) + ' ' + h.price.toFixed(prec);
                ctx.font = '600 10px Roboto, system-ui, sans-serif';
                ctx.fillStyle = 'rgba(13, 17, 23, 0.88)';
                const tw = ctx.measureText(txt).width + 8;
                ctx.fillRect(drawX2 - tw - 2, y - 16, tw, 14);
                ctx.fillStyle = style.textColor || '#d1d4dc';
                ctx.textAlign = 'left';
                ctx.textBaseline = 'top';
                ctx.fillText(txt, drawX2 - tw, y - 15);
            }
            ctx.restore();
        });
    }

    if (data.dowMarks && data.dowMarks.length && this.data) {
        ctx.save();
        ctx.font = '700 11px Roboto, system-ui, sans-serif';
        data.dowMarks.forEach(function(dm) {
            if (dm.index < startIndex || dm.index > endIndex) return;
            const x = self.dataIndexToPixel(dm.index);
            if (!self.data[dm.index]) return;
            var y;
            if (dm.bottom) {
                y = self.h - m.b - 4;
                ctx.textBaseline = 'bottom';
            } else {
                y = m.t + 18;
                ctx.textBaseline = 'top';
            }
            ctx.fillStyle = colorToRgba(dm.color || '#787b86', 0.9);
            ctx.textAlign = 'center';
            ctx.fillText(dm.text || '', x, y);
        });
        ctx.restore();
    }

    const P = data._params || {};
    if (P.BIAS_M_Bool) {
        const biasRows = [];
        const nameIds = ['txt52', 'txt53', 'txt54', 'txt55'];
        for (let bi = 1; bi <= 4; bi++) {
            if (!P['BIASbool' + bi]) continue;
            biasRows.push({
                left: String(P[nameIds[bi - 1]] != null ? P[nameIds[bi - 1]] : '').trim(),
                right: String(P['BIASOption' + bi] != null ? P['BIASOption' + bi] : '')
            });
        }
        if (biasRows.length) {
            this._drawIctOverlayTable(
                P.TabOption2 || 'Bottom Right',
                P.txt100 || 'BIAS',
                biasRows,
                P.Tab2txtCol || style.textColor || '#787b86'
            );
        }
    }
    if (P.NOTES_M_Bool) {
        const noteBody = String(P.notes != null ? P.notes : '').trim();
        if (noteBody) {
            this._drawIctOverlayTable(
                P.TabOption3 || 'Top Center',
                P.txt101 || 'NOTES',
                [{ kind: 'text', text: noteBody }],
                P.Tab3txtCol || style.textColor || '#787b86',
                { maxWidth: 260 }
            );
        }
    }
};

Chart.prototype.drawIctFvgBoxes = function(data, style, startIndex = 0, endIndex) {
    if (!data || !data.boxes || data.boxes.length === 0) return;
    const ctx = this.ctx;
    const m = this.margin;
    const bull = style.bullColor || 'rgba(38, 166, 154, 0.22)';
    const bear = style.bearColor || 'rgba(239, 83, 80, 0.22)';
    const lw = style.lineWidth || 1;
    const n = this.data ? this.data.length : 0;
    endIndex = endIndex == null ? n : Math.min(endIndex, n);

    data.boxes.forEach(function(box) {
        if (box.endIndex < startIndex || box.startIndex > endIndex) return;
        let si = box.startIndex;
        let ei = box.endIndex;
        if (this.replaySystem && this.replaySystem.isActive && n > 0) {
            const maxIdx = n - 1;
            si = Math.min(Math.max(si, 0), maxIdx);
            ei = Math.min(Math.max(ei, 0), maxIdx);
        }
        const x1 = this.dataIndexToPixel(si);
        const x2 = this.dataIndexToPixel(ei);
        const topP = Math.max(box.top, box.bottom);
        const botP = Math.min(box.top, box.bottom);
        const yTop = this.yScale(topP);
        const yBot = this.yScale(botP);
        if (x2 < m.l || x1 > this.w - m.r) return;
        const drawX1 = Math.max(x1, m.l);
        const drawX2 = Math.min(x2, this.w - m.r);
        const boxWidth = drawX2 - drawX1;
        const boxHeight = yBot - yTop;
        if (boxWidth <= 0 || boxHeight <= 0) return;
        ctx.fillStyle = box.bullish ? bull : bear;
        ctx.fillRect(drawX1, yTop, boxWidth, boxHeight);
        ctx.strokeStyle = box.bullish ? 'rgba(38, 166, 154, 0.55)' : 'rgba(239, 83, 80, 0.55)';
        ctx.lineWidth = lw;
        ctx.strokeRect(drawX1, yTop, boxWidth, boxHeight);
    }, this);
};

Chart.prototype.drawLiquidityEqLines = function(data, style, startIndex = 0, endIndex) {
    if (!data || !data.segments || data.segments.length === 0) return;
    const ctx = this.ctx;
    const m = this.margin;
    const plotLayout = typeof this._getMainPricePlotLayout === 'function'
        ? this._getMainPricePlotLayout()
        : null;
    const priceAreaBottom = plotLayout ? plotLayout.plotBottom : (this.h - m.b);
    const hiCol = style.highColor || '#f23645';
    const loCol = style.lowColor || '#2962ff';
    const lw = style.lineWidth != null ? style.lineWidth : 1;
    const n = this.data ? this.data.length : 0;
    endIndex = endIndex == null ? n : Math.min(endIndex, n);
    ctx.setLineDash([6, 4]);
    data.segments.forEach(function(seg) {
        if (seg.endIndex < startIndex || seg.startIndex > endIndex) return;
        const x1 = this.dataIndexToPixel(seg.startIndex);
        const x2 = this.dataIndexToPixel(seg.endIndex);
        if (x2 < m.l || x1 > this.w - m.r) return;
        const drawX1 = Math.max(x1, m.l);
        const drawX2 = Math.min(x2, this.w - m.r);
        const y = this.yScale(seg.price);
        if (y < m.t || y > priceAreaBottom) return;
        ctx.strokeStyle = seg.kind === 'high' ? hiCol : loCol;
        ctx.lineWidth = lw;
        ctx.beginPath();
        ctx.moveTo(drawX1, y);
        ctx.lineTo(drawX2, y);
        ctx.stroke();
    }, this);
    ctx.setLineDash([]);
};
    
    Chart.prototype.updateOHLCIndicators = function() {
        if (typeof ensureTalariaIndLegendHoverCss === 'function') {
            ensureTalariaIndLegendHoverCss();
        }
        const idSuffix = (this.panelIndex !== undefined && this.panelIndex !== 0) ? this.panelIndex : '';
        const div = document.getElementById('ohlcIndicators' + idSuffix);

        if (!div) return;

        if (document.getElementById('indicator-settings-modal') || document.querySelector('[data-v9-ind-sett="1"]')) return;

        if (typeof talariaRebuildOhlcIndicatorLegend === 'function') {
            talariaRebuildOhlcIndicatorLegend(this, div);
            return;
        }

        div.innerHTML = '';

        if (!this.indicators || !this.indicators.active || this.indicators.active.length === 0) {
            if (this.chartSettings && this.chartSettings.showIndicatorTitles === false) {
                div.style.display = 'none';
            } else {
                div.style.display = '';
            }
            if (typeof window.talariaSyncOhlcLegendChevron === 'function') {
                window.talariaSyncOhlcLegendChevron(this);
            }
            return;
        }

        // Legacy fallback when indicator-ui.js has not loaded yet.
        const overlayIndicators = this.indicators.active.filter(function(ind) {
            if (ind.type === 'volume' || ind.isVolume) return false;
            return ind.overlay !== false;
        });

        for (let i = 0; i < overlayIndicators.length; i++) {
            const indicator = overlayIndicators[i];
            const item = document.createElement('div');
            item.className = 'talaria-ind-legend-row';
            item.textContent = '- ' + indicator.name;
            div.appendChild(item);
        }

        if (this.chartSettings && this.chartSettings.showIndicatorTitles === false) {
            div.style.display = 'none';
        } else {
            div.style.display = '';
        }
        if (typeof window.talariaSyncOhlcLegendChevron === 'function') {
            window.talariaSyncOhlcLegendChevron(this);
        }
    };
    
    Chart.prototype.showIndicatorSettings = function(id) {
        try {
            const indicator = this.indicators.active.find(function(ind) {
                return ind.id === id;
            });

            if (!indicator) {
                console.warn('[chart] showIndicatorSettings: indicator not found', id);
                return;
            }

            const resolveKey = typeof window.__v9ResolveIndicatorDefinitionKey === 'function'
                ? window.__v9ResolveIndicatorDefinitionKey
                : function(t) { return t; };
            const settingsType = resolveKey(indicator.type);

            // Single UI path: indicator-ui.js (must load after this file — see dist-v9/index.html).
            if (typeof window.createIndicatorSettingsPanel === 'function') {
                window.createIndicatorSettingsPanel(this, settingsType, indicator);
                return;
            }

            // If indicator-ui is still loading, V9 React may still open when definitions + hook exist.
            if (typeof window.__v9OpenIndicatorSettings === 'function' && window.INDICATOR_DEFINITIONS) {
                try {
                    if (window.__v9OpenIndicatorSettings(this, indicator.type, indicator) === true) {
                        return;
                    }
                } catch (e) {
                    console.warn('[chart] __v9OpenIndicatorSettings', e);
                }
            }

            console.error(
                '[chart] Indicator settings unavailable: load /chart/modules/indicator-ui.js after chart-indicators-full.js ' +
                '(defines window.createIndicatorSettingsPanel and INDICATOR_DEFINITIONS).'
            );
        } catch (error) {
            console.warn('[chart] showIndicatorSettings failed:', error);
        }
    };
    
    // Recompute the total pixel height reserved for separate-panel indicators
    Chart.prototype._updateIndicatorPanelHeight = function() {
        if (typeof this._syncSeparateIndicatorPanelHeightEstimate === 'function') {
            this._syncSeparateIndicatorPanelHeightEstimate();
            return;
        }
        const indicators = this._getVisibleSeparateIndicators();
        if (!indicators.length) {
            this.separateIndicatorPanelHeight = 0;
            return;
        }
        const heights = this._getSeparatePanelHeights(indicators);
        this.separateIndicatorPanelHeight = heights.reduce((sum, h) => sum + h, 0);
    };

    Chart.prototype._getVolumeRenderConfig = function(indicator) {
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const st = (indicator && indicator.style) || {};
        const pa = (indicator && indicator.params) || {};
        const colors = volumeColorsFromStyle(st, resolve);
        return {
            showBars: st.showVolume !== false,
            usePrevClose: pa.colorBasedOnPrevClose === true,
            growingColor: colors.growing,
            fallingColor: colors.falling,
            growingBarWidth: st.growingLineWidth != null ? st.growingLineWidth : 1,
            fallingBarWidth: st.fallingLineWidth != null ? st.fallingLineWidth : 1,
            showMa: pa.showMa === true || pa.showMA === true,
            maPeriod: pa.maPeriod != null ? Math.max(1, Number(pa.maPeriod) | 0) : 20,
            maColor: resolve(st.maColor || '#2962ff', st.maOpacity),
            maLineWidth: st.maLineWidth != null ? st.maLineWidth : 2,
            maLineDashStyle: st.maLineDashStyle || 'Solid'
        };
    };

    Chart.prototype._renderVolumePanel = function(ctx, m, indTop, indBottom, panelHeight, indicator, visibleStart, visibleEnd) {
        if (!this.data || !this.data.length || !this._isVolumeDisplayEnabled()) return;
        if (!indicator || indicator.visible === false) return;

        const cfg = this._getVolumeRenderConfig(indicator);
        const upColor = cfg.growingColor;
        const downColor = cfg.fallingColor;
        const showMA = cfg.showMa;
        const maPeriod = cfg.maPeriod;
        const maColor = cfg.maColor;
        const baseCw = Math.max(1, this.candleWidth || 6);

        ctx.save();
        ctx.beginPath();
        ctx.rect(m.l, indTop, this.w - m.l - m.r, panelHeight);
        ctx.clip();

        let maxVol = 1;
        for (let i = visibleStart; i < visibleEnd && i < this.data.length; i++) {
            const v = Number(this.data[i] && this.data[i].v);
            if (Number.isFinite(v) && v > maxVol) maxVol = v;
        }

        const volBandBottom = indBottom - 3;
        const volBandTop = indTop + 3;
        const scaleY = (typeof d3 !== 'undefined' && d3.scaleLinear)
            ? d3.scaleLinear().domain([0, maxVol]).range([volBandBottom, volBandTop])
            : function(v) { return volBandBottom - (v / maxVol) * (volBandBottom - volBandTop); };

        const fast = this._panelRenderFast === true;
        const plotPxVol = Math.max(1, this.w - m.l - m.r);
        let drewLod = false;
        if (cfg.showBars) {
        if (fast && typeof this._aggregateVisibleOhlcvBuckets === 'function' && typeof this._getCandleRenderMaxBuckets === 'function') {
            const visSlice = [];
            for (let i = visibleStart; i < visibleEnd && i < this.data.length; i++) {
                const bar = this.data[i];
                if (bar) visSlice.push(bar);
            }
            const maxBuckets = this._getCandleRenderMaxBuckets(visSlice.length, plotPxVol, { panFast: true });
            const volLod = this._aggregateVisibleOhlcvBuckets(visSlice, maxBuckets, plotPxVol);
            if (volLod && volLod.length) {
                drewLod = true;
                volLod.forEach(function(b) {
                    const v = volumeFromOhlcBar(b);
                    const midIdx = Number.isFinite(b.midIdx) ? b.midIdx : 0;
                    const x = Number.isFinite(b._pixelX) ? b._pixelX : this.dataIndexToPixel(midIdx);
                    if (x < m.l - 10 || x > this.w - m.r + 10) return;
                    const volumeY = scaleY(v);
                    const barH = Math.max(1, volBandBottom - volumeY);
                    const isGreen = cfg.usePrevClose
                        ? volumeBarIsGrowing(this, midIdx, { c: b.c, o: b.o }, true)
                        : Number(b.c) >= Number(b.o);
                    const thick = isGreen ? cfg.growingBarWidth : cfg.fallingBarWidth;
                    const barW = Number.isFinite(b._pixelX)
                        ? Math.max(1, thick)
                        : Math.max(1, baseCw * (thick / 2));
                    ctx.fillStyle = isGreen ? upColor : downColor;
                    ctx.fillRect(x - barW / 2, volumeY, barW, barH);
                }, this);
            }
        }
        if (!drewLod) {
        for (let i = visibleStart; i < visibleEnd && i < this.data.length; i++) {
            const bar = this.data[i];
            if (!bar) continue;
            const v = Number(bar.v);
            if (!Number.isFinite(v)) continue;
            const x = this.dataIndexToPixel(i);
            if (x < m.l - 10 || x > this.w - m.r + 10) continue;
            const volumeY = scaleY(v);
            const barH = Math.max(1, volBandBottom - volumeY);
            const isGreen = volumeBarIsGrowing(this, i, bar, cfg.usePrevClose);
            const thick = isGreen ? cfg.growingBarWidth : cfg.fallingBarWidth;
            const barW = Math.max(1, baseCw * (thick / 2));
            ctx.fillStyle = isGreen ? upColor : downColor;
            ctx.fillRect(x - barW / 2, volumeY, barW, barH);
        }
        }
        }

        if (showMA && this.data.length >= maPeriod && typeof d3 !== 'undefined') {
            const maKey = String(this.dataVersion || '') + '|' + maPeriod + '|' + this.data.length;
            let volumeMA = this._volumeMaSeriesCache;
            if (this._volumeMaSeriesCacheKey !== maKey || !Array.isArray(volumeMA) || volumeMA.length !== this.data.length) {
                volumeMA = new Array(this.data.length);
                for (let i = 0; i < this.data.length; i++) {
                    if (i < maPeriod - 1) {
                        volumeMA[i] = null;
                    } else {
                        let sum = 0;
                        for (let j = 0; j < maPeriod; j++) sum += this.data[i - j].v;
                        volumeMA[i] = sum / maPeriod;
                    }
                }
                this._volumeMaSeriesCache = volumeMA;
                this._volumeMaSeriesCacheKey = maKey;
            }
            ctx.strokeStyle = maColor;
            ctx.lineWidth = cfg.maLineWidth;
            ctx.setLineDash(this._lineDashForStyle(cfg.maLineDashStyle));
            ctx.beginPath();
            let started = false;
            for (let i = visibleStart; i < visibleEnd && i < volumeMA.length; i++) {
                const maValue = volumeMA[i];
                if (maValue === null || maValue === undefined || !Number.isFinite(maValue)) continue;
                const x = this.dataIndexToPixel(i);
                if (x < m.l - 10 || x > this.w - m.r + 10) continue;
                let y = scaleY(maValue);
                if (!Number.isFinite(y)) continue;
                y = Math.max(volBandTop, Math.min(volBandBottom, y));
                if (!started) { ctx.moveTo(x, y); started = true; }
                else { ctx.lineTo(x, y); }
            }
            if (started) ctx.stroke();
            ctx.setLineDash([]);
        }

        let displayValue = null;
        let displayColor = upColor;
        const barIdx = typeof this._getCrosshairBarIndex === 'function'
            ? this._getCrosshairBarIndex()
            : (Number.isFinite(this.hoverIndex) ? this.hoverIndex : (this.data.length - 1));
        if (barIdx >= 0 && barIdx < this.data.length) {
            const hb = this.data[barIdx];
            const hv = Number(hb && hb.v);
            if (Number.isFinite(hv)) {
                displayValue = hv;
                displayColor = volumeBarIsGrowing(this, barIdx, hb, cfg.usePrevClose) ? upColor : downColor;
            }
        }
        indicator._displayColor = displayColor;
        indicator._displayLabel = displayValue !== null
            ? (displayValue >= 1e9 ? (displayValue / 1e9).toFixed(2) + 'B'
                : displayValue >= 1e6 ? (displayValue / 1e6).toFixed(2) + 'M'
                : displayValue >= 1e3 ? (displayValue / 1e3).toFixed(1) + 'K'
                : String(Math.round(displayValue)))
            : '—';
        indicator._axisLabelTags = [];

        ctx.restore();
    };

    // ---- Helper: draw a single line in a sub-panel using a pre-computed scaleY ----
    Chart.prototype._drawPanelLine = function(ctx, m, values, color, lineWidth, visibleStart, visibleEnd, scaleY, clipTop, clipBottom, lineStyle, dashStyle) {
        if (!values) return;
        ctx.strokeStyle = color;
        ctx.lineWidth = lineWidth || 2;
        var dash = dashStyle;
        if (!dash && (lineStyle === 'Dashed' || lineStyle === 'Dotted' || lineStyle === 'Dashdot')) dash = lineStyle;
        if (!dash) dash = 'Solid';
        var dashKey = dash === 'Solid' ? 'Line' : dash;
        ctx.setLineDash(this._lineDashForStyle ? this._lineDashForStyle(dashKey) : []);
        ctx.beginPath();
        let started = false;
        const useClip = Number.isFinite(clipTop) && Number.isFinite(clipBottom) && clipBottom > clipTop;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val === null || val === undefined || isNaN(val)) { started = false; continue; }
            const x = this.dataIndexToPixel(i);
            let y = scaleY(val);
            // Do not skip by x: panel ctx is already clipped; skipping broke polylines at pan edges.
            if (y === null || !Number.isFinite(y)) { started = false; continue; }
            if (!started) { ctx.moveTo(x, y); started = true; }
            else { ctx.lineTo(x, y); }
        }
        if (started) ctx.stroke();
        ctx.setLineDash([]);
    };

    Chart.prototype._drawPanelHLine = function(ctx, m, panelTop, panelBottom, scaleY, value, color, lineStyle, labelText, lineWidth, dashStyle) {
        if (value === null || value === undefined || isNaN(value)) return;
        const y = scaleY(value);
        if (y === null || !Number.isFinite(y)) return;
        // Reference levels may sit on the panel edge after autoscale — clip handles masking.
        if (y < panelTop - 4 || y > panelBottom + 4) return;
        ctx.strokeStyle = color || '#787b86';
        ctx.lineWidth = lineWidth != null ? lineWidth : 1;
        var dash = dashStyle;
        if (!dash && (lineStyle === 'Dashed' || lineStyle === 'Dotted' || lineStyle === 'Dashdot')) dash = lineStyle;
        if (!dash) dash = lineStyle || 'Dotted';
        var dashKey = dash === 'Solid' ? 'Line' : dash;
        ctx.setLineDash(this._lineDashForStyle ? this._lineDashForStyle(dashKey) : [3, 3]);
        ctx.beginPath();
        ctx.moveTo(m.l, y);
        ctx.lineTo(this.w, y);
        ctx.stroke();
        ctx.setLineDash([]);
        if (labelText != null && labelText !== '') {
            ctx.fillStyle = color || '#787b86';
            ctx.font = '9px Roboto';
            ctx.textAlign = 'right';
            ctx.fillText(String(labelText), this.w - 6, y - 2);
        }
    };

    // Shared right-axis ticks + grid for separate indicator panels.
    Chart.prototype._drawPanelAxisTicks = function(ctx, m, min, max, scaleY, decimals, suffix) {
        const fast = this._panelRenderFast === true;
        const d = Number.isFinite(decimals) ? decimals : 2;
        const sfx = suffix != null ? String(suffix) : '';
        ctx.font = '10px Roboto';
        ctx.textAlign = 'right';
        ctx.fillStyle = '#787b86';
        const numGridLines = fast ? 2 : 4;
        const plotRight = this.w - m.r;
        const horzGridOn = typeof this._applyChartGridStrokeStyle === 'function'
            && this._applyChartGridStrokeStyle(ctx, 'horizontal');
        for (let i = 0; i <= numGridLines; i++) {
            const tickVal = min + (max - min) * (i / numGridLines);
            const tickY = scaleY(tickVal);
            if (!Number.isFinite(tickY)) continue;
            if (horzGridOn) {
                ctx.beginPath();
                ctx.moveTo(m.l, tickY);
                ctx.lineTo(plotRight, tickY);
                ctx.stroke();
            }
            if (!fast) ctx.fillText(tickVal.toFixed(d) + sfx, this.w - 6, tickY + 3);
        }
        if (horzGridOn) ctx.setLineDash([]);
    };

    // ---- Awesome Oscillator: histogram from zero (growing / falling colors) ----
    Chart.prototype._renderAOPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, values, visibleStart, visibleEnd) {
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const zeroVal = 0;

        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val !== null && val !== undefined && !isNaN(val)) {
                min = Math.min(min, val);
                max = Math.max(max, val);
            }
        }
        min = Math.min(min, zeroVal);
        max = Math.max(max, zeroVal);
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const aMin = dom.min;
        const aMax = dom.max;
        const aSpan = Math.max(1e-9, aMax - aMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - aMin) / aSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        this._drawPanelAxisTicks(ctx, m, aMin, aMax, scaleY, 2);

        const zeroY = scaleY(zeroVal);
        if (zeroY !== null && Number.isFinite(zeroY)) {
            ctx.strokeStyle = 'rgba(120, 123, 134, 0.45)';
            ctx.lineWidth = 1;
            ctx.setLineDash([3, 3]);
            ctx.beginPath();
            ctx.moveTo(m.l, zeroY);
            ctx.lineTo(this.w, zeroY);
            ctx.stroke();
            ctx.setLineDash([]);
        }
        if (style.showAO !== false) {
            const baseBarW = Math.max(1, (this.candleWidth || 8) * 0.8);
            for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
                const val = values[i];
                if (val === null || val === undefined || isNaN(val)) continue;
                const prevVal = i > 0 ? values[i - 1] : null;
                const growing = prevVal === null || prevVal === undefined || isNaN(prevVal) || val > prevVal;
                const thick = growing
                    ? (style.histColor0LineWidth != null ? style.histColor0LineWidth : 1)
                    : (style.histColor1LineWidth != null ? style.histColor1LineWidth : 1);
                const barW = Math.max(1, baseBarW * (thick / 2));
                const x = this.dataIndexToPixel(i);
                const y = scaleY(val);
                const z = (zeroY !== null && Number.isFinite(zeroY)) ? zeroY : scaleY(0);
                if (z === null || y === null) continue;
                ctx.fillStyle = aoHistogramBarColor(val, prevVal, style, resolve);
                ctx.fillRect(x - barW / 2, Math.min(y, z), barW, Math.max(1, Math.abs(y - z)));
            }
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        const tagColor = resolve(style.histColor0 || '#26a69a', style.histColor0Opacity);
        indicator._displayColor = tagColor;
        indicator._displayLabel = last !== null ? last.toFixed(4) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(4);
            indicator._axisLabelColor = tagColor;
            indicator._axisLabelTags = [{
                y: currentY,
                text: last.toFixed(4),
                color: tagColor
            }];
        }
    };

    // ---- MACD panel: histogram bars + MACD line + signal line + zero line ----
    Chart.prototype._renderMACDPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, data, visibleStart, visibleEnd) {
        if (!data.macd || !data.signal || !data.histogram) return;
        const style = indicator.style || {};
        const macdArr = data.macd, signalArr = data.signal, histArr = data.histogram;
        const zeroVal = style.zeroValue != null ? style.zeroValue : 0;
        const zeroW = style.zeroLineWidth != null ? style.zeroLineWidth : 1;

        let min = Infinity, max = -Infinity;
        for (let i = visibleStart; i < visibleEnd; i++) {
            [macdArr[i], signalArr[i], histArr[i]].forEach(v => {
                if (v !== null && v !== undefined && !isNaN(v)) { min = Math.min(min, v); max = Math.max(max, v); }
            });
        }
        if (Number.isFinite(zeroVal)) {
            min = Math.min(min, zeroVal);
            max = Math.max(max, zeroVal);
        }
        if (min === Infinity) return;
        const range = max - min || 1;
        min -= range * 0.1; max += range * 0.1;
        const domM = this._finalizePanelRange(indicator, min, max);
        min = domM.min; max = domM.max;
        const mSpan = Math.max(1e-12, max - min);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - min) / mSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        if (style.showBg) {
            ctx.fillStyle = style.bgColor || 'rgba(19,23,34,0.15)';
            ctx.fillRect(m.l, panelTop, Math.max(0, this.w - m.l), Math.max(0, panelBottom - panelTop));
        }

        this._drawPanelAxisTicks(ctx, m, min, max, scaleY, 4);

        const zeroY = scaleY(zeroVal);
        if (style.showZero !== false && zeroY !== null && zeroY > panelTop && zeroY < panelBottom) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, zeroVal,
                style.zeroColor || 'rgba(120,123,134,0.45)', style.zeroLineStyle || 'Line', zeroVal, zeroW, style.zeroLineDashStyle || 'Solid');
        }

        if (style.showHist !== false) {
            const barW = Math.max(1, (this.candleWidth || 8) * 0.8);
            for (let i = visibleStart; i < visibleEnd && i < histArr.length; i++) {
                const val = histArr[i];
                if (val === null || val === undefined || isNaN(val)) continue;
                const prevVal = i > 0 ? histArr[i - 1] : null;
                const x = this.dataIndexToPixel(i);
                const y = scaleY(val);
                const z = (zeroY !== null && !isNaN(zeroY)) ? zeroY : scaleY(0);
                if (z === null || y === null) continue;
                ctx.fillStyle = macdHistogramBarColor(val, prevVal, style);
                ctx.fillRect(x - barW / 2, Math.min(y, z), barW, Math.max(1, Math.abs(y - z)));
            }
        }

        if (style.showMacd !== false) {
            this._drawPanelLine(ctx, m, macdArr, style.macdColor || '#2962ff', style.macdLineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.macdLineStyle || 'Line', style.macdLineDashStyle || 'Solid');
        }
        if (style.showSignal !== false) {
            this._drawPanelLine(ctx, m, signalArr, style.signalColor || '#f23645', style.signalLineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.signalLineStyle || 'Line', style.signalLineDashStyle || 'Solid');
        }

        let lastM = null, lastS = null;
        for (let i = Math.min(visibleEnd - 1, macdArr.length - 1); i >= visibleStart; i--) {
            if (macdArr[i] !== null && !isNaN(macdArr[i])) { lastM = macdArr[i]; lastS = signalArr[i]; break; }
        }

        const macdTags = [];
        if (lastM !== null && Number.isFinite(lastM) && style.showMacd !== false) {
            const yM = scaleY(lastM);
            if (Number.isFinite(yM)) {
                const mColor = style.macdColor || '#2962ff';
                macdTags.push({ y: yM, text: lastM.toFixed(4), color: mColor });
            }
        }
        if (lastS !== null && Number.isFinite(lastS) && style.showSignal !== false) {
            const yS = scaleY(lastS);
            if (Number.isFinite(yS)) {
                const sColor = style.signalColor || '#f23645';
                macdTags.push({ y: yS, text: lastS.toFixed(4), color: sColor });
            }
        }
        macdTags.sort(function(a, b) { return a.y - b.y; });
        for (let i = 1; i < macdTags.length; i++) {
            if (macdTags[i].y - macdTags[i - 1].y < 18) macdTags[i].y = macdTags[i - 1].y + 18;
        }
        for (let i = macdTags.length - 2; i >= 0; i--) {
            if (macdTags[i + 1].y > panelBottom - 8) {
                macdTags[i + 1].y = panelBottom - 8;
                if (macdTags[i + 1].y - macdTags[i].y < 18) macdTags[i].y = macdTags[i + 1].y - 18;
            }
            if (macdTags[i].y < panelTop + 8) macdTags[i].y = panelTop + 8;
        }
        indicator._axisLabelTags = macdTags;
        if (macdTags.length > 0) {
            indicator._axisLabelY = macdTags[0].y;
            indicator._axisLabelText = macdTags[0].text;
            indicator._axisLabelColor = macdTags[0].color;
        }
        macdTags.forEach((tag) => {
            const labelWidth = 58;
            const labelHeight = 16;
            ctx.fillStyle = tag.color;
            ctx.fillRect(this.w - m.r + 2, tag.y - labelHeight / 2, labelWidth, labelHeight);
            ctx.fillStyle = '#000';
            ctx.font = 'bold 10px Roboto';
            ctx.textAlign = 'center';
            ctx.fillText(tag.text, this.w - m.r + 2 + labelWidth / 2, tag.y + 4);
        });

        indicator._displayColor = style.macdColor || '#2962ff';
        indicator._displayLabel = lastM !== null ? 'M:' + lastM.toFixed(5) + (lastS !== null ? '  S:' + lastS.toFixed(5) : '') : '';
    };

    Chart.prototype._renderVortexPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, data, visibleStart, visibleEnd) {
        if (!data || !data.viPlus || !data.viMinus) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const a = data.viPlus;
        const b = data.viMinus;
        const refVal = 1;
        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd; i++) {
            if (a[i] != null && !isNaN(a[i])) {
                min = Math.min(min, a[i]);
                max = Math.max(max, a[i]);
            }
            if (b[i] != null && !isNaN(b[i])) {
                min = Math.min(min, b[i]);
                max = Math.max(max, b[i]);
            }
        }
        if (Number.isFinite(refVal)) {
            min = Math.min(min, refVal);
            max = Math.max(max, refVal);
        }
        if (min === Infinity) return;
        const range = max - min || 1;
        min -= range * 0.08;
        max += range * 0.08;
        const dom = this._finalizePanelRange(indicator, min, max);
        min = dom.min;
        max = dom.max;
        const vSpan = Math.max(1e-12, max - min);
        const scaleY = function(val) {
            if (val === null || val === undefined) return null;
            const y = panelBottom - 5 - ((val - min) / vSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };
        this._drawPanelAxisTicks(ctx, m, min, max, scaleY, 2);

        const plusColor = resolve(style.plusColor || '#00e676', style.plusOpacity);
        if (style.showPlus !== false) {
            this._drawPanelLine(ctx, m, a, plusColor, style.plusLineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.plusLineStyle || 'Line', style.plusLineDashStyle || 'Solid');
        }
        const minusColor = resolve(style.minusColor || '#f23645', style.minusOpacity);
        if (style.showMinus !== false) {
            this._drawPanelLine(ctx, m, b, minusColor, style.minusLineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.minusLineStyle || 'Line', style.minusLineDashStyle || 'Solid');
        }

        let lastPlus = null;
        let lastMinus = null;
        for (let i = Math.min(visibleEnd - 1, a.length - 1); i >= visibleStart; i--) {
            if (lastPlus === null && a[i] !== null && !isNaN(a[i])) lastPlus = a[i];
            if (lastMinus === null && b[i] !== null && !isNaN(b[i])) lastMinus = b[i];
            if (lastPlus !== null && lastMinus !== null) break;
        }

        const legendTokens = buildVortexLegendTokens(lastPlus, lastMinus, style);
        const vortexTags = [];
        if (lastPlus !== null && Number.isFinite(lastPlus) && style.showPlus !== false) {
            const yPlus = scaleY(lastPlus);
            if (Number.isFinite(yPlus)) {
                vortexTags.push({ y: yPlus, text: '+' + lastPlus.toFixed(3), color: plusColor });
            }
        }
        if (lastMinus !== null && Number.isFinite(lastMinus) && style.showMinus !== false) {
            const yMinus = scaleY(lastMinus);
            if (Number.isFinite(yMinus)) {
                vortexTags.push({ y: yMinus, text: '-' + lastMinus.toFixed(3), color: minusColor });
            }
        }
        vortexTags.sort(function(a, b) { return a.y - b.y; });
        for (let ti = 1; ti < vortexTags.length; ti++) {
            if (vortexTags[ti].y - vortexTags[ti - 1].y < 18) vortexTags[ti].y = vortexTags[ti - 1].y + 18;
        }
        for (let ti = vortexTags.length - 2; ti >= 0; ti--) {
            if (vortexTags[ti + 1].y > panelBottom - 2) {
                vortexTags[ti + 1].y = panelBottom - 2;
                if (vortexTags[ti + 1].y - vortexTags[ti].y < 18) vortexTags[ti].y = vortexTags[ti + 1].y - 18;
            }
            if (vortexTags[ti].y < panelTop + 2) vortexTags[ti].y = panelTop + 2;
        }
        indicator._axisLabelTags = vortexTags;
        if (vortexTags.length > 0) {
            indicator._axisLabelY = vortexTags[0].y;
            indicator._axisLabelText = vortexTags[0].text;
            indicator._axisLabelColor = vortexTags[0].color;
        } else {
            indicator._axisLabelY = null;
            indicator._axisLabelText = '';
            indicator._axisLabelColor = '';
        }
        indicator._displayColor = plusColor;
        indicator._legendValueTags = legendTokens.map(function(t) {
            return { text: t.text, color: t.color };
        });
        indicator._displayLabel = legendTokens.length
            ? legendTokens.map(function(t) { return t.text; }).join(' ')
            : 'VI';
    };

    Chart.prototype._renderElderRayPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, data, visibleStart, visibleEnd) {
        if (!data || !data.bull || !data.bear) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const a = data.bull;
        const b = data.bear;
        const zeroVal = style.zeroValue != null ? style.zeroValue : 0;
        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd; i++) {
            if (a[i] != null && !isNaN(a[i])) {
                min = Math.min(min, a[i]);
                max = Math.max(max, a[i]);
            }
            if (b[i] != null && !isNaN(b[i])) {
                min = Math.min(min, b[i]);
                max = Math.max(max, b[i]);
            }
        }
        if (Number.isFinite(zeroVal)) {
            min = Math.min(min, zeroVal);
            max = Math.max(max, zeroVal);
        }
        if (min === Infinity) return;
        const range = max - min || 1;
        min -= range * 0.08;
        max += range * 0.08;
        const dom = this._finalizePanelRange(indicator, min, max);
        min = dom.min;
        max = dom.max;
        const vSpan = Math.max(1e-12, max - min);
        const scaleY = function(val) {
            if (val === null || val === undefined) return null;
            const y = panelBottom - 5 - ((val - min) / vSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };
        this._drawPanelAxisTicks(ctx, m, min, max, scaleY, 2);

        const zeroW = style.zeroLineWidth != null ? style.zeroLineWidth : 1;
        if (style.showZero !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, zeroVal,
                resolve(style.zeroColor, style.zeroOpacity), style.zeroLineStyle || 'Line', null, zeroW, style.zeroLineDashStyle || 'Solid');
        }

        const baselineY = scaleY(zeroVal);
        if (style.showBBPower !== false && baselineY != null && Number.isFinite(baselineY)) {
            const bullColor = resolve(style.bullColor || '#26a69a', style.bullOpacity);
            const bearColor = resolve(style.bearColor || '#ef5350', style.bearOpacity);
            const bullW = style.bullLineWidth != null ? style.bullLineWidth : 1;
            const bearW = style.bearLineWidth != null ? style.bearLineWidth : 1;
            const baseOpts = {
                yScale: scaleY,
                baselineY: baselineY,
                panelTop: panelTop,
                panelBottom: panelBottom
            };
            this.drawLineIndicator(a, bullColor, bullW, visibleStart, visibleEnd, style.bullLineStyle || 'Columns', Object.assign({}, baseOpts, {
                dashStyle: style.bullLineDashStyle || 'Solid'
            }));
            this.drawLineIndicator(b, bearColor, bearW, visibleStart, visibleEnd, style.bearLineStyle || 'Columns', Object.assign({}, baseOpts, {
                dashStyle: style.bearLineDashStyle || 'Solid'
            }));
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, a.length - 1); i >= visibleStart; i--) {
            if (a[i] !== null && !isNaN(a[i])) { last = a[i]; break; }
        }
        const tagColor = resolve(style.bullColor || '#26a69a', style.bullOpacity);
        indicator._displayColor = tagColor;
        indicator._displayLabel = last !== null ? last.toFixed(4) : 'Elder Ray';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(4);
            indicator._axisLabelColor = tagColor;
            indicator._axisLabelTags = [{ y: currentY, text: last.toFixed(4), color: tagColor }];
        }
    };

    Chart.prototype._renderCotNetPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, data, visibleStart, visibleEnd) {
        if (!data) return;
        if (data.loading) {
            ctx.fillStyle = '#787b86';
            ctx.font = '11px Roboto';
            ctx.textAlign = 'center';
            ctx.fillText('Loading COT…', (m.l + this.w - m.r) / 2, panelTop + panelHeight / 2);
            ctx.textAlign = 'left';
            return;
        }
        if (data.error) {
            ctx.fillStyle = '#ef5350';
            ctx.font = '11px Roboto';
            ctx.textAlign = 'left';
            ctx.fillText(String(data.error).slice(0, 140), m.l + 4, panelTop + 14);
            ctx.textAlign = 'left';
            return;
        }
        if (!data.bull || !data.bear) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const showC = indicator.params && indicator.params.showCommercial !== false;
        const showL = indicator.params && indicator.params.showLarge !== false;
        const a = data.bull;
        const b = data.bear;
        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd; i++) {
            if (showC && a[i] != null && !isNaN(a[i])) {
                min = Math.min(min, a[i]);
                max = Math.max(max, a[i]);
            }
            if (showL && b[i] != null && !isNaN(b[i])) {
                min = Math.min(min, b[i]);
                max = Math.max(max, b[i]);
            }
        }
        if (min === Infinity) return;
        const range = max - min || 1;
        min -= range * 0.08;
        max += range * 0.08;
        if (min > 0) min = Math.min(min, 0);
        if (max < 0) max = Math.max(max, 0);
        const dom = this._finalizePanelRange(indicator, min, max);
        min = dom.min;
        max = dom.max;
        const vSpan = Math.max(1e-12, max - min);
        const scaleY = function(val) {
            if (val === null || val === undefined) return null;
            const y = panelBottom - 5 - ((val - min) / vSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };
        const zy = scaleY(0);
        if (zy !== null && zy > panelTop && zy < panelBottom) {
            ctx.strokeStyle = 'rgba(0,0,0,0.45)';
            ctx.lineWidth = 1;
            ctx.setLineDash([4, 4]);
            ctx.beginPath();
            ctx.moveTo(m.l, zy);
            ctx.lineTo(this.w, zy);
            ctx.stroke();
            ctx.setLineDash([]);
        }
        const lw = style.lineWidth != null ? style.lineWidth : 2;
        const lineStyle = style.lineStyle || 'Line';
        const dashStyle = style.lineDashStyle || 'Solid';
        const bullColor = resolve(style.bullColor || '#26a69a', style.bullOpacity);
        const bearColor = resolve(style.bearColor || '#ef5350', style.bearOpacity);
        if (showC) {
            this._drawPanelLine(ctx, m, a, bullColor, lw, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, lineStyle, dashStyle);
        }
        if (showL) {
            this._drawPanelLine(ctx, m, b, bearColor, lw, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, lineStyle, dashStyle);
        }
        indicator._displayColor = bullColor;
        indicator._displayLabel = '';
        indicator._axisLabelTags = [];
        indicator._axisLabelY = null;
        indicator._axisLabelText = '';
        indicator._axisLabelColor = '';
    };

    // ---- TRIX: auto-scaled line + configurable zero ----
    Chart.prototype._renderTrixPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, values, visibleStart, visibleEnd) {
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const zeroVal = style.zeroValue != null ? style.zeroValue : 0;

        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val !== null && val !== undefined && !isNaN(val)) {
                min = Math.min(min, val);
                max = Math.max(max, val);
            }
        }
        if (Number.isFinite(zeroVal)) {
            min = Math.min(min, zeroVal);
            max = Math.max(max, zeroVal);
        }
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const tMin = dom.min;
        const tMax = dom.max;
        const tSpan = Math.max(1e-9, tMax - tMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - tMin) / tSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        this._drawPanelAxisTicks(ctx, m, tMin, tMax, scaleY, 2);

        const zeroW = style.zeroLineWidth != null ? style.zeroLineWidth : 1;
        if (style.showZero !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, zeroVal,
                resolve(style.zeroColor, style.zeroOpacity), style.zeroLineStyle || 'Dotted', zeroVal, zeroW, style.zeroLineDashStyle || 'Dotted');
        }

        const lineColor = resolve(style.color || '#8d6e63', style.lineOpacity);
        const plotStyle = this._normalizePlotStyle(style.lineStyle || 'Line');
        const dashStyle = style.lineDashStyle || 'Solid';
        if (style.showLine !== false) {
            if (plotStyle === 'Histogram' || plotStyle === 'Columns') {
                const lw = style.lineWidth != null ? style.lineWidth : 2;
                const half = function(i) { return this._plotBarWidthPx(i, lw) / 2; }.bind(this);
                ctx.fillStyle = lineColor;
                for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
                    const val = values[i];
                    if (val == null || isNaN(val)) continue;
                    const x = this.dataIndexToPixel(i);
                    const y = scaleY(val);
                    const z = scaleY(zeroVal);
                    if (y == null || z == null || !Number.isFinite(y) || !Number.isFinite(z)) continue;
                    const w = half(i) * 2;
                    const top = Math.min(y, z);
                    ctx.fillRect(x - w / 2, top, w, Math.max(1, Math.abs(z - y)));
                }
            } else {
                this._drawPanelLine(ctx, m, values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, plotStyle, dashStyle);
            }
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(4) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(4);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{
                y: currentY,
                text: last.toFixed(4),
                color: lineColor
            }];
        }
    };

    Chart.prototype._drawPanelLineWithPlotOffset = function(ctx, m, values, plotOffset, color, lineWidth, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, lineStyle, dashStyle) {
        if (!values || !values.length) return;
        const off = Number(plotOffset) | 0;
        ctx.strokeStyle = color;
        ctx.lineWidth = lineWidth || 2;
        var dash = dashStyle;
        if (!dash && (lineStyle === 'Dashed' || lineStyle === 'Dotted' || lineStyle === 'Dashdot')) dash = lineStyle;
        if (!dash) dash = 'Solid';
        var dashKey = dash === 'Solid' ? 'Line' : dash;
        ctx.setLineDash(this._lineDashForStyle ? this._lineDashForStyle(dashKey) : []);
        let started = false;
        ctx.beginPath();
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = rviSeriesAtPlotOffset(values, i, off);
            const y = scaleY(val);
            const x = this.dataIndexToPixel(i);
            if (y === null || !Number.isFinite(y) || !Number.isFinite(x)) {
                started = false;
                continue;
            }
            if (!started) {
                ctx.moveTo(x, y);
                started = true;
            } else {
                ctx.lineTo(x, y);
            }
        }
        if (started) ctx.stroke();
        ctx.setLineDash([]);
    };

    // ---- RVI: RVGI + signal (offset) around zero ----
    Chart.prototype._renderRviPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, data, visibleStart, visibleEnd) {
        const pack = data && data.rvi ? data : { rvi: Array.isArray(data) ? data : [], signal: [] };
        const rviArr = pack.rvi;
        const signalArr = pack.signal || [];
        if (!rviArr.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const plotOffset = indicator.params.offset != null ? Number(indicator.params.offset) : 0;

        let min = Infinity;
        let max = -Infinity;
        const consider = (arr, off) => {
            for (let i = visibleStart; i < visibleEnd && i < arr.length; i++) {
                const val = rviSeriesAtPlotOffset(arr, i, off);
                if (val !== null && val !== undefined && !isNaN(val)) {
                    min = Math.min(min, val);
                    max = Math.max(max, val);
                }
            }
        };
        consider(rviArr, 0);
        if (style.showSignal !== false) consider(signalArr, plotOffset);
        min = Math.min(min, 0);
        max = Math.max(max, 0);
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const rMin = dom.min;
        const rMax = dom.max;
        const rSpan = Math.max(1e-9, rMax - rMin);
        const scaleY = v => this._panelMapValueToY(v, rMin, rSpan, panelTop, panelBottom, panelHeight);

        this._drawPanelAxisTicks(ctx, m, rMin, rMax, scaleY, 2);

        const zy = scaleY(0);
        if (zy !== null && zy > panelTop && zy < panelBottom) {
            ctx.strokeStyle = 'rgba(120,123,134,0.35)';
            ctx.lineWidth = 1;
            ctx.setLineDash([3, 3]);
            ctx.beginPath();
            ctx.moveTo(m.l, zy);
            ctx.lineTo(this.w, zy);
            ctx.stroke();
            ctx.setLineDash([]);
        }

        const rviColor = resolve(style.color || '#ffa726', style.lineOpacity);
        const sigColor = resolve(style.signalColor || '#2962ff', style.signalOpacity);
        if (style.showRvi !== false) {
            this._drawPanelLine(ctx, m, rviArr, rviColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }
        if (style.showSignal !== false) {
            this._drawPanelLineWithPlotOffset(ctx, m, signalArr, plotOffset, sigColor, style.signalLineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.signalLineStyle || 'Line', style.signalLineDashStyle || 'Solid');
        }

        let lastR = null;
        let lastS = null;
        for (let i = Math.min(visibleEnd - 1, rviArr.length - 1); i >= visibleStart; i--) {
            if (lastR === null && rviArr[i] !== null && !isNaN(rviArr[i])) lastR = rviArr[i];
            if (lastS === null) {
                const sv = rviSeriesAtPlotOffset(signalArr, i, plotOffset);
                if (sv !== null && !isNaN(sv)) lastS = sv;
            }
            if (lastR !== null && lastS !== null) break;
        }
        const tags = [];
        if (lastR !== null && Number.isFinite(lastR) && style.showRvi !== false) {
            const yR = scaleY(lastR);
            if (Number.isFinite(yR)) tags.push({ y: yR, text: lastR.toFixed(4), color: rviColor });
        }
        if (lastS !== null && Number.isFinite(lastS) && style.showSignal !== false) {
            const yS = scaleY(lastS);
            if (Number.isFinite(yS)) tags.push({ y: yS, text: lastS.toFixed(4), color: sigColor });
        }
        tags.sort(function(a, b) { return a.y - b.y; });
        for (let i = 1; i < tags.length; i++) {
            if (tags[i].y - tags[i - 1].y < 18) tags[i].y = tags[i - 1].y + 18;
        }
        indicator._displayColor = rviColor;
        indicator._displayLabel = lastR !== null ? lastR.toFixed(4) : '';
        indicator._axisLabelTags = tags;
        if (tags.length) {
            indicator._axisLabelY = tags[tags.length - 1].y;
            indicator._axisLabelText = tags[tags.length - 1].text;
            indicator._axisLabelColor = tags[tags.length - 1].color;
        }
    };

    Chart.prototype._renderAdrPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, values, visibleStart, visibleEnd) {
        if (!Array.isArray(values) || !values.length) return;
        const barCount = Array.isArray(this.data) ? this.data.length : 0;
        if (barCount > 0 && values.length !== barCount) {
            try { recalcAdrIndicator(this, indicator); } catch (_) {}
            values = this.indicators && this.indicators.data ? this.indicators.data[indicator.id] : values;
            if (!Array.isArray(values) || values.length !== barCount) return;
        }

        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val !== null && val !== undefined && !isNaN(val)) {
                min = Math.min(min, val);
                max = Math.max(max, val);
            }
        }
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const aMin = dom.min;
        const aMax = dom.max;
        const aSpan = Math.max(1e-9, aMax - aMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - aMin) / aSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        this._drawPanelAxisTicks(ctx, m, aMin, aMax, scaleY, 2);

        const lineColor = resolve(style.color || '#26a69a', style.lineOpacity);
        const plotStyle = this._normalizePlotStyle(style.lineStyle || 'Step line');
        const dashStyle = style.lineDashStyle || 'Solid';
        this.drawLineIndicator(values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, plotStyle, {
            yScale: scaleY,
            baselineY: panelBottom - 2,
            panelTop: panelTop,
            panelBottom: panelBottom,
            dashStyle: dashStyle
        });

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(2) : '';
        indicator._axisLabelTags = [];
        indicator._axisLabelY = null;
        indicator._axisLabelText = '';
        if (style.showLabel !== false && last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(2);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{ y: currentY, text: last.toFixed(2), color: lineColor }];
        }
    };

    Chart.prototype._renderAtrPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, values, visibleStart, visibleEnd) {
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);

        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val !== null && val !== undefined && !isNaN(val)) {
                min = Math.min(min, val);
                max = Math.max(max, val);
            }
        }
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const aMin = dom.min;
        const aMax = dom.max;
        const aSpan = Math.max(1e-9, aMax - aMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - aMin) / aSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        this._drawPanelAxisTicks(ctx, m, aMin, aMax, scaleY, 2);

        const lineColor = resolve(style.color || '#ff6d00', style.lineOpacity);
        if (style.showLine !== false) {
            this._drawPanelLine(ctx, m, values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(2) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(2);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{ y: currentY, text: last.toFixed(2), color: lineColor }];
        }
    };

    Chart.prototype._renderCoppockPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, values, visibleStart, visibleEnd) {
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);

        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val !== null && val !== undefined && !isNaN(val)) {
                min = Math.min(min, val);
                max = Math.max(max, val);
            }
        }
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const cMin = dom.min;
        const cMax = dom.max;
        const cSpan = Math.max(1e-9, cMax - cMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - cMin) / cSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        this._drawPanelAxisTicks(ctx, m, cMin, cMax, scaleY, 2);

        const lineColor = resolve(style.color || '#8e24aa', style.lineOpacity);
        if (style.showCoppock !== false) {
            this._drawPanelLine(ctx, m, values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(2) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(2);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{ y: currentY, text: last.toFixed(2), color: lineColor }];
        }
    };

    Chart.prototype._renderMassIndexPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, values, visibleStart, visibleEnd) {
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);

        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val !== null && val !== undefined && !isNaN(val)) {
                min = Math.min(min, val);
                max = Math.max(max, val);
            }
        }
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const mMin = dom.min;
        const mMax = dom.max;
        const mSpan = Math.max(1e-9, mMax - mMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - mMin) / mSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        this._drawPanelAxisTicks(ctx, m, mMin, mMax, scaleY, 2);

        const lineColor = resolve(style.color || '#00bcd4', style.lineOpacity);
        if (style.showLine !== false) {
            this._drawPanelLine(ctx, m, values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(2) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(2);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{ y: currentY, text: last.toFixed(2), color: lineColor }];
        }
    };

    Chart.prototype._renderUltimateOscillatorPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, data, visibleStart, visibleEnd) {
        if (!Array.isArray(data)) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const domS = this._finalizePanelRange(indicator, 0, 100);
        const sMin = domS.min;
        const sMax = domS.max;
        const sSpan = Math.max(1e-9, sMax - sMin);
        const scaleY = function(v) {
            if (v === null || v === undefined) return null;
            const y = panelBottom - 5 - ((v - sMin) / sSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };
        this._drawPanelAxisTicks(ctx, m, sMin, sMax, scaleY, 2);
        [[70, 'rgba(239,83,80,0.45)'], [50, 'rgba(120,123,134,0.3)'], [30, 'rgba(38,166,154,0.45)']].forEach(function(row) {
            const lvl = row[0];
            const col = row[1];
            const ry = scaleY(lvl);
            if (ry !== null && ry > panelTop && ry < panelBottom) {
                ctx.strokeStyle = col;
                ctx.lineWidth = 1;
                ctx.setLineDash([3, 3]);
                ctx.beginPath();
                ctx.moveTo(m.l, ry);
                ctx.lineTo(this.w, ry);
                ctx.stroke();
                ctx.setLineDash([]);
            }
        }, this);
        const lineColor = resolve(style.color || '#7e57c2', style.lineOpacity);
        if (style.showLine !== false) {
            this._drawPanelLine(ctx, m, data, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }
        let last = null;
        for (let i = Math.min(visibleEnd - 1, data.length - 1); i >= visibleStart; i--) {
            if (data[i] !== null && !isNaN(data[i])) { last = data[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(2) : 'UO';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(2);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{
                y: currentY,
                text: last.toFixed(2),
                color: lineColor
            }];
        }
    };

    // ---- Stochastic panel: %K + %D lines + configurable levels + optional background ----
    Chart.prototype._renderStochPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, data, visibleStart, visibleEnd) {
        if (!data.k || !data.d) return;
        const kArr = data.k;
        const dArr = data.d;
        const style = indicator.style || {};
        const levelDefaults = { overbought: 80, oversold: 20, mid: 50 };
        const domS = this._finalizePanelRange(indicator, 0, 100);
        const sMin = domS.min;
        const sMax = domS.max;
        const sSpan = Math.max(1e-9, sMax - sMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - sMin) / sSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        const obVal = style.overboughtValue != null ? style.overboughtValue : levelDefaults.overbought;
        const osVal = style.oversoldValue != null ? style.oversoldValue : levelDefaults.oversold;
        const midVal = style.midValue != null ? style.midValue : levelDefaults.mid;
        const obW = style.overboughtLineWidth != null ? style.overboughtLineWidth : 1;
        const osW = style.oversoldLineWidth != null ? style.oversoldLineWidth : 1;
        const midW = style.midLineWidth != null ? style.midLineWidth : 1;

        if (style.showBg) {
            const yUpper = scaleY(obVal);
            const yLower = scaleY(osVal);
            if (Number.isFinite(yUpper) && Number.isFinite(yLower)) {
                const fillTop = Math.min(yUpper, yLower);
                const fillHeight = Math.abs(yLower - yUpper);
                if (fillHeight > 0) {
                    ctx.fillStyle = style.bgColor || 'rgba(19,23,34,0.15)';
                    ctx.fillRect(m.l, fillTop, Math.max(0, this.w - m.l), fillHeight);
                }
            }
        }

        this._drawPanelAxisTicks(ctx, m, sMin, sMax, scaleY, 2);

        if (style.showOverbought !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, obVal,
                style.overboughtColor || '#787b86', style.overboughtLineStyle || 'Line', obVal, obW, style.overboughtLineDashStyle || 'Dotted');
        }
        if (style.showOversold !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, osVal,
                style.oversoldColor || '#787b86', style.oversoldLineStyle || 'Line', osVal, osW, style.oversoldLineDashStyle || 'Dotted');
        }
        if (style.showMid !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, midVal,
                style.midColor || 'rgba(120,123,134,0.45)', style.midLineStyle || 'Line', midVal, midW, style.midLineDashStyle || 'Dotted');
        }

        const kWidth = style.kLineWidth != null ? style.kLineWidth : (style.lineWidth || 2);
        const dWidth = style.dLineWidth != null ? style.dLineWidth : (style.lineWidth || 2);
        if (style.showK !== false) {
            this._drawPanelLine(ctx, m, kArr, style.kColor || '#2962ff', kWidth, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.kLineStyle || style.lineStyle || 'Line', style.kLineDashStyle || 'Solid');
        }
        if (style.showD !== false) {
            this._drawPanelLine(ctx, m, dArr, style.dColor || '#f23645', dWidth, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.dLineStyle || style.lineStyle || 'Line', style.dLineDashStyle || 'Solid');
        }

        let lastK = null, lastD = null;
        for (let i = Math.min(visibleEnd - 1, kArr.length - 1); i >= visibleStart; i--) {
            if (kArr[i] !== null && !isNaN(kArr[i])) { lastK = kArr[i]; lastD = dArr[i]; break; }
        }
        const stochTags = [];
        if (lastK !== null && Number.isFinite(lastK)) {
            const yK = scaleY(lastK);
            if (Number.isFinite(yK)) stochTags.push({ y: yK, text: lastK.toFixed(2), color: style.kColor || '#2962ff' });
        }
        if (lastD !== null && Number.isFinite(lastD)) {
            const yD = scaleY(lastD);
            if (Number.isFinite(yD)) stochTags.push({ y: yD, text: lastD.toFixed(2), color: style.dColor || '#f23645' });
        }
        stochTags.sort(function(a, b) { return a.y - b.y; });
        for (let i = 1; i < stochTags.length; i++) {
            if (stochTags[i].y - stochTags[i - 1].y < 18) stochTags[i].y = stochTags[i - 1].y + 18;
        }
        for (let i = stochTags.length - 2; i >= 0; i--) {
            if (stochTags[i + 1].y > panelBottom - 8) {
                stochTags[i + 1].y = panelBottom - 8;
                if (stochTags[i + 1].y - stochTags[i].y < 18) stochTags[i].y = stochTags[i + 1].y - 18;
            }
            if (stochTags[i].y < panelTop + 8) stochTags[i].y = panelTop + 8;
        }
        indicator._axisLabelTags = stochTags;
        if (stochTags.length > 0) {
            indicator._axisLabelY = stochTags[0].y;
            indicator._axisLabelText = stochTags[0].text;
            indicator._axisLabelColor = stochTags[0].color;
        } else {
            indicator._axisLabelY = null;
            indicator._axisLabelText = '';
            indicator._axisLabelColor = '';
        }
        indicator._displayColor = style.kColor || '#2962ff';
        indicator._displayLabel = lastK !== null ? 'K:' + lastK.toFixed(2) + (lastD !== null ? '  D:' + lastD.toFixed(2) : '') : '';
    };

    // ---- ADX panel: ADX + +DI + -DI lines + 25 threshold ----
    Chart.prototype._renderADXPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, data, visibleStart, visibleEnd) {
        if (!data.adx || !data.plusDI || !data.minusDI) return;
        const adxArr = data.adx, plusArr = data.plusDI, minusArr = data.minusDI;
        const style = indicator.style || {};
        const legacyW = style.lineWidth || 2;
        const legacyS = style.lineStyle || 'Line';

        let max = 0;
        for (let i = visibleStart; i < visibleEnd; i++) {
            [adxArr[i], plusArr[i], minusArr[i]].forEach(v => { if (v !== null && !isNaN(v)) max = Math.max(max, v); });
        }
        max = Math.max(max * 1.1, 60);
        const domA = this._finalizePanelRange(indicator, 0, max);
        const aMin = domA.min;
        const aMax = domA.max;
        const aSpan = Math.max(1e-9, aMax - aMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - aMin) / aSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };
        this._drawPanelAxisTicks(ctx, m, aMin, aMax, scaleY, 2);

        // 25 threshold line
        const thY = scaleY(25);
        if (thY !== null && thY > panelTop && thY < panelBottom) {
            ctx.strokeStyle = 'rgba(255,255,255,0.2)';
            ctx.lineWidth = 1;
            ctx.setLineDash([3, 3]);
            ctx.beginPath();
            ctx.moveTo(m.l, thY);
            ctx.lineTo(this.w, thY);
            ctx.stroke();
            ctx.setLineDash([]);
            ctx.fillStyle = 'rgba(255,255,255,0.35)';
            ctx.font = '9px Roboto';
            ctx.textAlign = 'right';
            ctx.fillText('25', this.w - 6, thY - 2);
        }

        if (style.showPlusDI !== false) {
            this._drawPanelLine(ctx, m, plusArr, style.plusDIColor || '#00e676', style.plusDILineWidth != null ? style.plusDILineWidth : legacyW, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.plusDILineStyle || legacyS, style.plusDILineDashStyle || 'Solid');
        }
        if (style.showMinusDI !== false) {
            this._drawPanelLine(ctx, m, minusArr, style.minusDIColor || '#f23645', style.minusDILineWidth != null ? style.minusDILineWidth : legacyW, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.minusDILineStyle || legacyS, style.minusDILineDashStyle || 'Solid');
        }
        if (style.showAdx !== false) {
            this._drawPanelLine(ctx, m, adxArr, style.adxColor || '#ff00ff', style.adxLineWidth != null ? style.adxLineWidth : legacyW, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.adxLineStyle || legacyS, style.adxLineDashStyle || 'Solid');
        }

        let lastADX = null;
        for (let i = Math.min(visibleEnd - 1, adxArr.length - 1); i >= visibleStart; i--) {
            if (adxArr[i] !== null && !isNaN(adxArr[i])) { lastADX = adxArr[i]; break; }
        }
        indicator._displayColor = style.adxColor || '#ff00ff';
        indicator._displayLabel = lastADX !== null ? lastADX.toFixed(2) : '';
    };

    // ---- Aroon panel: Up / Down fixed 0–100% scale with edge padding ----
    Chart.prototype._renderAroonPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, data, visibleStart, visibleEnd) {
        if (!data || !data.up || !data.down) return;
        const upArr = data.up;
        const downArr = data.down;
        const style = indicator.style || {};
        const padY = 8;
        const clipTop = panelTop + padY;
        const clipBottom = panelBottom - padY;
        const dom = this._finalizePanelRange(indicator, 0, 100);
        const aMin = dom.min;
        const aMax = dom.max;
        const aSpan = Math.max(1e-9, aMax - aMin);
        const plotH = Math.max(1, panelHeight - padY * 2);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            const y = panelBottom - padY - ((v - aMin) / aSpan) * plotH;
            if (!Number.isFinite(y)) return null;
            return Math.max(clipTop, Math.min(clipBottom, y));
        };

        this._drawPanelAxisTicks(ctx, m, aMin, aMax, scaleY, 2, '%');

        const upColor = style.upColor || '#26a69a';
        const downColor = style.downColor || '#ef5350';
        if (style.showUp !== false) {
            this._drawPanelLine(ctx, m, upArr, upColor, style.upLineWidth || 2, visibleStart, visibleEnd, scaleY, clipTop, clipBottom, style.upLineStyle || 'Line', style.upLineDashStyle || 'Solid');
        }
        if (style.showDown !== false) {
            this._drawPanelLine(ctx, m, downArr, downColor, style.downLineWidth || 2, visibleStart, visibleEnd, scaleY, clipTop, clipBottom, style.downLineStyle || 'Line', style.downLineDashStyle || 'Solid');
        }

        let lastU = null, lastD = null;
        for (let i = Math.min(visibleEnd - 1, upArr.length - 1); i >= visibleStart; i--) {
            if (upArr[i] !== null && !isNaN(upArr[i])) { lastU = upArr[i]; lastD = downArr[i]; break; }
        }
        const legendTokens = buildAroonLegendTokens(lastU, lastD, style);
        const aroonTags = [];
        if (lastU !== null && Number.isFinite(lastU) && style.showUp !== false) {
            const yU = scaleY(lastU);
            if (Number.isFinite(yU)) aroonTags.push({ y: yU, text: lastU.toFixed(2) + '%', color: upColor });
        }
        if (lastD !== null && Number.isFinite(lastD) && style.showDown !== false) {
            const yD = scaleY(lastD);
            if (Number.isFinite(yD)) aroonTags.push({ y: yD, text: lastD.toFixed(2) + '%', color: downColor });
        }
        aroonTags.sort(function(a, b) { return a.y - b.y; });
        for (let i = 1; i < aroonTags.length; i++) {
            if (aroonTags[i].y - aroonTags[i - 1].y < 18) aroonTags[i].y = aroonTags[i - 1].y + 18;
        }
        for (let i = aroonTags.length - 2; i >= 0; i--) {
            if (aroonTags[i + 1].y > clipBottom) {
                aroonTags[i + 1].y = clipBottom;
                if (aroonTags[i + 1].y - aroonTags[i].y < 18) aroonTags[i].y = aroonTags[i + 1].y - 18;
            }
            if (aroonTags[i].y < clipTop) aroonTags[i].y = clipTop;
        }
        indicator._axisLabelTags = aroonTags;
        if (aroonTags.length > 0) {
            indicator._axisLabelY = aroonTags[0].y;
            indicator._axisLabelText = aroonTags[0].text;
            indicator._axisLabelColor = aroonTags[0].color;
        } else {
            indicator._axisLabelY = null;
            indicator._axisLabelText = '';
            indicator._axisLabelColor = '';
        }
        indicator._displayColor = upColor;
        indicator._legendValueTags = legendTokens.map(function(t) {
            return { text: t.text, color: t.color };
        });
        indicator._displayLabel = legendTokens.length
            ? legendTokens.map(function(t) { return t.text; }).join(' ')
            : '';
    };

    // ---- RSI panel: 0–100 + bands + MA + gradient fills ----
    Chart.prototype._drawRsiDivergenceSegment = function(ctx, m, i0, i1, val0, val1, visibleStart, visibleEnd, scaleYFn, color, clipTop, clipBottom) {
        if (i0 == null || i1 == null || !Number.isFinite(val0) || !Number.isFinite(val1)) return;
        if (i1 < visibleStart && i0 < visibleStart) return;
        if (i0 > visibleEnd && i1 > visibleEnd) return;
        const x0 = this.dataIndexToPixel(i0);
        const x1 = this.dataIndexToPixel(i1);
        let y0 = scaleYFn(val0);
        let y1 = scaleYFn(val1);
        if (!Number.isFinite(x0) || !Number.isFinite(x1) || !Number.isFinite(y0) || !Number.isFinite(y1)) return;
        const useClip = Number.isFinite(clipTop) && Number.isFinite(clipBottom) && clipBottom > clipTop;
        if (useClip) {
            y0 = Math.max(clipTop + 0.5, Math.min(clipBottom - 0.5, y0));
            y1 = Math.max(clipTop + 0.5, Math.min(clipBottom - 0.5, y1));
        }
        ctx.save();
        ctx.strokeStyle = color || '#787b86';
        ctx.lineWidth = 1.5;
        ctx.setLineDash(this._lineDashForStyle ? this._lineDashForStyle('Dashed') : [4, 3]);
        ctx.beginPath();
        ctx.moveTo(x0, y0);
        ctx.lineTo(x1, y1);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.restore();
    };

    Chart.prototype._renderRsiPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, data, visibleStart, visibleEnd) {
        const pack = data && data.rsi ? data : { rsi: data, ma: null, bbUpper: null, bbLower: null };
        const values = pack.rsi;
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const levelDefaults = { overbought: 70, oversold: 30, mid: 50 };
        const dom = this._finalizePanelRange(indicator, 0, 100);
        const rMin = dom.min;
        const rMax = dom.max;
        const rSpan = Math.max(1e-9, rMax - rMin);
        const scaleY = v => this._panelMapValueToY(v, rMin, rSpan, panelTop, panelBottom, panelHeight);

        const obVal = style.overboughtValue != null ? style.overboughtValue : levelDefaults.overbought;
        const osVal = style.oversoldValue != null ? style.oversoldValue : levelDefaults.oversold;
        const midVal = style.midValue != null ? style.midValue : levelDefaults.mid;
        const obW = style.overboughtLineWidth != null ? style.overboughtLineWidth : 1;
        const osW = style.oversoldLineWidth != null ? style.oversoldLineWidth : 1;
        const midW = style.midLineWidth != null ? style.midLineWidth : 1;
        const panelW = Math.max(0, this.w - m.l);

        if (style.showObGradient) {
            const yOb = scaleY(obVal);
            if (Number.isFinite(yOb)) {
                const fillTop = Math.min(panelTop, yOb);
                const fillH = Math.max(0, Math.max(panelTop, yOb) - fillTop);
                if (fillH > 0) {
                    ctx.fillStyle = style.obGradientColor || 'rgba(239,83,80,0.12)';
                    ctx.fillRect(m.l, fillTop, panelW, fillH);
                }
            }
        }
        if (style.showOsGradient) {
            const yOs = scaleY(osVal);
            if (Number.isFinite(yOs)) {
                const fillTop = Math.min(yOs, panelBottom);
                const fillH = Math.max(0, panelBottom - fillTop);
                if (fillH > 0) {
                    ctx.fillStyle = style.osGradientColor || 'rgba(38,166,154,0.12)';
                    ctx.fillRect(m.l, fillTop, panelW, fillH);
                }
            }
        }
        if (style.showBg) {
            const yUpper = scaleY(obVal);
            const yLower = scaleY(osVal);
            if (Number.isFinite(yUpper) && Number.isFinite(yLower)) {
                const fillTop = Math.min(yUpper, yLower);
                const fillHeight = Math.abs(yLower - yUpper);
                if (fillHeight > 0) {
                    ctx.fillStyle = style.bgColor || 'rgba(19,23,34,0.15)';
                    ctx.fillRect(m.l, fillTop, panelW, fillHeight);
                }
            }
        }

        this._drawPanelAxisTicks(ctx, m, rMin, rMax, scaleY, 0);

        if (style.showOverbought !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, obVal,
                style.overboughtColor || '#787b86', style.overboughtLineStyle || 'Line', obVal, obW, style.overboughtLineDashStyle || 'Dotted');
        }
        if (style.showOversold !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, osVal,
                style.oversoldColor || '#787b86', style.oversoldLineStyle || 'Line', osVal, osW, style.oversoldLineDashStyle || 'Dotted');
        }
        if (style.showMid !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, midVal,
                style.midColor || 'rgba(120,123,134,0.45)', style.midLineStyle || 'Line', midVal, midW, style.midLineDashStyle || 'Dotted');
        }

        const maWidth = style.maLineWidth != null ? style.maLineWidth : 1;
        if (style.showMa !== false && pack.bbUpper) {
            this._drawPanelLine(ctx, m, pack.bbUpper, style.maColor || '#ff9800', maWidth, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.maLineStyle || 'Line', style.maLineDashStyle || 'Solid');
        }
        if (style.showMa !== false && pack.bbLower) {
            this._drawPanelLine(ctx, m, pack.bbLower, style.maColor || '#ff9800', maWidth, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.maLineStyle || 'Line', style.maLineDashStyle || 'Solid');
        }
        if (style.showMa !== false && pack.ma) {
            this._drawPanelLine(ctx, m, pack.ma, style.maColor || '#ff9800', maWidth, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.maLineStyle || 'Line', style.maLineDashStyle || 'Solid');
        }
        if (style.showLine !== false) {
            this._drawPanelLine(ctx, m, values, style.color || '#9c27b0', style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }

        if (indicator.params && indicator.params.divergenceEnabled === true && Array.isArray(pack.divergences) && pack.divergences.length) {
            pack.divergences.forEach(function(seg) {
                this._drawRsiDivergenceSegment(
                    ctx,
                    m,
                    seg.i0,
                    seg.i1,
                    seg.rsi0,
                    seg.rsi1,
                    visibleStart,
                    visibleEnd,
                    scaleY,
                    seg.type === 'bull' ? '#26a69a' : '#ef5350',
                    panelTop,
                    panelBottom
                );
            }.bind(this));
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = style.color || '#9c27b0';
        indicator._displayLabel = last !== null ? last.toFixed(2) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(2);
            indicator._axisLabelColor = style.color || '#9c27b0';
            indicator._axisLabelTags = [{ y: currentY, text: last.toFixed(2), color: style.color || '#9c27b0' }];
        }
    };

    // ---- CCI panel: auto-scaled + CCI-based MA + bands + upper–lower background ----
    Chart.prototype._renderCciPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, data, visibleStart, visibleEnd) {
        const pack = data && data.cci ? data : { cci: data, ma: null, bbUpper: null, bbLower: null };
        const values = pack.cci;
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const upperVal = style.upperValue != null ? style.upperValue : 100;
        const lowerVal = style.lowerValue != null ? style.lowerValue : -100;
        const midVal = style.midValue != null ? style.midValue : 0;

        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val !== null && val !== undefined && !isNaN(val)) {
                min = Math.min(min, val);
                max = Math.max(max, val);
            }
        }
        [upperVal, lowerVal, midVal].forEach(function(v) {
            if (Number.isFinite(v)) {
                min = Math.min(min, v);
                max = Math.max(max, v);
            }
        });
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const cMin = dom.min;
        const cMax = dom.max;
        const cSpan = Math.max(1e-9, cMax - cMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - cMin) / cSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        const panelW = Math.max(0, this.w - m.l);
        const upperW = style.upperLineWidth != null ? style.upperLineWidth : 1;
        const lowerW = style.lowerLineWidth != null ? style.lowerLineWidth : 1;
        const midW = style.midLineWidth != null ? style.midLineWidth : 1;
        const maW = style.maLineWidth != null ? style.maLineWidth : 1;

        if (style.showBg) {
            const yUpper = scaleY(upperVal);
            const yLower = scaleY(lowerVal);
            if (Number.isFinite(yUpper) && Number.isFinite(yLower)) {
                const fillTop = Math.min(yUpper, yLower);
                const fillHeight = Math.abs(yLower - yUpper);
                if (fillHeight > 0) {
                    ctx.fillStyle = resolve(style.bgColor, style.bgOpacity);
                    ctx.fillRect(m.l, fillTop, panelW, fillHeight);
                }
            }
        }

        this._drawPanelAxisTicks(ctx, m, cMin, cMax, scaleY, 2);

        if (style.showUpper !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, upperVal,
                resolve(style.upperColor, style.upperOpacity), style.upperLineStyle || 'Dotted', upperVal, upperW, style.upperLineDashStyle || 'Dotted');
        }
        if (style.showLower !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, lowerVal,
                resolve(style.lowerColor, style.lowerOpacity), style.lowerLineStyle || 'Dotted', lowerVal, lowerW, style.lowerLineDashStyle || 'Dotted');
        }
        if (style.showMid !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, midVal,
                resolve(style.midColor, style.midOpacity), style.midLineStyle || 'Dotted', midVal, midW, style.midLineDashStyle || 'Dotted');
        }

        const maColor = resolve(style.maColor || '#ff9800', style.maOpacity);
        if (style.showMa !== false && pack.bbUpper) {
            this._drawPanelLine(ctx, m, pack.bbUpper, maColor, maW, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.maLineStyle || 'Line', style.maLineDashStyle || 'Solid');
        }
        if (style.showMa !== false && pack.bbLower) {
            this._drawPanelLine(ctx, m, pack.bbLower, maColor, maW, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.maLineStyle || 'Line', style.maLineDashStyle || 'Solid');
        }
        if (style.showMa !== false && pack.ma) {
            this._drawPanelLine(ctx, m, pack.ma, maColor, maW, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.maLineStyle || 'Line', style.maLineDashStyle || 'Solid');
        }

        const lineColor = resolve(style.color || '#00e676', style.lineOpacity);
        if (style.showLine !== false) {
            this._drawPanelLine(ctx, m, values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(2) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(2);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{
                y: currentY,
                text: last.toFixed(2),
                color: lineColor
            }];
        }
    };

    // ---- DPO panel: auto-scaled + middle line + optional background ----
    Chart.prototype._renderDpoPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, values, visibleStart, visibleEnd) {
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const midVal = style.midValue != null ? style.midValue : 0;
        const midW = style.midLineWidth != null ? style.midLineWidth : 1;

        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val !== null && val !== undefined && !isNaN(val)) {
                min = Math.min(min, val);
                max = Math.max(max, val);
            }
        }
        if (Number.isFinite(midVal)) {
            min = Math.min(min, midVal);
            max = Math.max(max, midVal);
        }
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const dMin = dom.min;
        const dMax = dom.max;
        const dSpan = Math.max(1e-9, dMax - dMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - dMin) / dSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        if (style.showBg) {
            ctx.fillStyle = resolve(style.bgColor || 'rgba(19,23,34,0.15)', style.bgOpacity);
            ctx.fillRect(m.l, panelTop, Math.max(0, this.w - m.l), Math.max(0, panelBottom - panelTop));
        }

        this._drawPanelAxisTicks(ctx, m, dMin, dMax, scaleY, 2);

        if (style.showMid !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, midVal,
                resolve(style.midColor, style.midOpacity), style.midLineStyle || 'Dotted', midVal, midW, style.midLineDashStyle || 'Dotted');
        }

        const lineColor = resolve(style.color || '#78909c', style.lineOpacity);
        if (style.showLine !== false) {
            this._drawPanelLine(ctx, m, values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(5) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(5);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{
                y: currentY,
                text: last.toFixed(5),
                color: lineColor
            }];
        }
    };

    // ---- OBV panel: auto-scaled OBV + optional smoothing MA / BB ----
    Chart.prototype._renderObvPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, data, visibleStart, visibleEnd) {
        const pack = data && data.obv ? data : { obv: data, ma: null, bbUpper: null, bbLower: null };
        const values = pack.obv;
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);

        let min = Infinity;
        let max = -Infinity;
        const consider = function(series) {
            if (!Array.isArray(series)) return;
            for (let i = visibleStart; i < visibleEnd && i < series.length; i++) {
                const val = series[i];
                if (val !== null && val !== undefined && !isNaN(val)) {
                    min = Math.min(min, val);
                    max = Math.max(max, val);
                }
            }
        };
        consider(values);
        consider(pack.ma);
        consider(pack.bbUpper);
        consider(pack.bbLower);
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const oMin = dom.min;
        const oMax = dom.max;
        const oSpan = Math.max(1e-9, oMax - oMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - oMin) / oSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        this._drawPanelAxisTicks(ctx, m, oMin, oMax, scaleY, 2);

        const maColor = resolve(style.maColor || '#ff9800', style.maOpacity);
        const maW = style.maLineWidth != null ? style.maLineWidth : 1;
        if (style.showMa !== false && pack.bbUpper) {
            this._drawPanelLine(ctx, m, pack.bbUpper, maColor, maW, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.maLineStyle || 'Line', style.maLineDashStyle || 'Solid');
        }
        if (style.showMa !== false && pack.bbLower) {
            this._drawPanelLine(ctx, m, pack.bbLower, maColor, maW, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.maLineStyle || 'Line', style.maLineDashStyle || 'Solid');
        }
        if (style.showMa !== false && pack.ma) {
            this._drawPanelLine(ctx, m, pack.ma, maColor, maW, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.maLineStyle || 'Line', style.maLineDashStyle || 'Solid');
        }

        const lineColor = resolve(style.color || '#78909c', style.lineOpacity);
        if (style.showObv !== false) {
            this._drawPanelLine(ctx, m, values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }

        const barIdx = typeof this._getCrosshairBarIndex === 'function' ? this._getCrosshairBarIndex() : -1;
        let obvVal = null;
        let maVal = null;
        if (barIdx >= 0) {
            obvVal = this._pickFiniteSeriesValue(values, barIdx);
            if (pack.ma) maVal = this._pickFiniteSeriesValue(pack.ma, barIdx);
        }
        if (obvVal === null) {
            for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
                if (values[i] !== null && !isNaN(values[i])) { obvVal = values[i]; break; }
            }
        }
        if (maVal === null && pack.ma) {
            for (let i = Math.min(visibleEnd - 1, pack.ma.length - 1); i >= visibleStart; i--) {
                if (pack.ma[i] !== null && !isNaN(pack.ma[i])) { maVal = pack.ma[i]; break; }
            }
        }
        const legendTokens = buildObvLegendTokens(obvVal, maVal, style);
        indicator._displayColor = lineColor;
        indicator._legendValueTags = legendTokens.map(function(t) {
            return { text: t.text, color: t.color };
        });
        indicator._displayLabel = legendTokens.length
            ? legendTokens.map(function(t) { return t.text; }).join(' ')
            : '';
        const obvTags = [];
        if (obvVal !== null && Number.isFinite(obvVal) && style.showObv !== false) {
            const yObv = scaleY(obvVal);
            if (Number.isFinite(yObv)) {
                obvTags.push({ y: yObv, text: formatObvLegendNumber(obvVal), color: lineColor });
            }
        }
        if (maVal !== null && Number.isFinite(maVal) && style.showMa !== false) {
            const yMa = scaleY(maVal);
            if (Number.isFinite(yMa)) {
                obvTags.push({ y: yMa, text: formatObvLegendNumber(maVal), color: maColor });
            }
        }
        obvTags.sort(function(a, b) { return a.y - b.y; });
        for (let ti = 1; ti < obvTags.length; ti++) {
            if (obvTags[ti].y - obvTags[ti - 1].y < 18) obvTags[ti].y = obvTags[ti - 1].y + 18;
        }
        indicator._axisLabelTags = obvTags;
        if (obvTags.length > 0) {
            indicator._axisLabelY = obvTags[0].y;
            indicator._axisLabelText = obvTags[0].text;
            indicator._axisLabelColor = obvTags[0].color;
        } else {
            indicator._axisLabelY = null;
            indicator._axisLabelText = '';
            indicator._axisLabelColor = '';
        }
    };

    // ---- Standard Deviation panel: auto-scaled volatility line + optional background ----
    Chart.prototype._renderStddevPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, values, visibleStart, visibleEnd) {
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);

        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val !== null && val !== undefined && !isNaN(val)) {
                min = Math.min(min, val);
                max = Math.max(max, val);
            }
        }
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const sMin = dom.min;
        const sMax = dom.max;
        const sSpan = Math.max(1e-9, sMax - sMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - sMin) / sSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        if (style.showBg) {
            ctx.fillStyle = resolve(style.bgColor || 'rgba(19,23,34,0.15)', style.bgOpacity);
            ctx.fillRect(m.l, panelTop, Math.max(0, this.w - m.l), Math.max(0, panelBottom - panelTop));
        }

        this._drawPanelAxisTicks(ctx, m, sMin, sMax, scaleY, 2);

        const lineColor = resolve(style.color || '#ab47bc', style.lineOpacity);
        if (style.showLine !== false) {
            this._drawPanelLine(ctx, m, values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(5) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(5);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{
                y: currentY,
                text: last.toFixed(5),
                color: lineColor
            }];
        }
    };

    // ---- Momentum panel: auto-scaled MOM line + optional background ----
    Chart.prototype._renderMomPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, values, visibleStart, visibleEnd) {
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);

        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val !== null && val !== undefined && !isNaN(val)) {
                min = Math.min(min, val);
                max = Math.max(max, val);
            }
        }
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const mMin = dom.min;
        const mMax = dom.max;
        const mSpan = Math.max(1e-9, mMax - mMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - mMin) / mSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        if (style.showBg) {
            ctx.fillStyle = resolve(style.bgColor || 'rgba(19,23,34,0.15)', style.bgOpacity);
            ctx.fillRect(m.l, panelTop, Math.max(0, this.w - m.l), Math.max(0, panelBottom - panelTop));
        }

        this._drawPanelAxisTicks(ctx, m, mMin, mMax, scaleY, 2);

        const lineColor = resolve(style.color || '#66bb6a', style.lineOpacity);
        if (style.showLine !== false) {
            this._drawPanelLine(ctx, m, values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(5) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(5);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{
                y: currentY,
                text: last.toFixed(5),
                color: lineColor
            }];
        }
    };

    // ---- Williams %R: fixed −100 … 0, configurable bands + optional background ----
    Chart.prototype._renderWilliamsRPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, values, visibleStart, visibleEnd) {
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const levelDefaults = { overbought: -20, oversold: -80, mid: -50 };
        const obVal = style.overboughtValue != null ? style.overboughtValue : levelDefaults.overbought;
        const osVal = style.oversoldValue != null ? style.oversoldValue : levelDefaults.oversold;
        const midVal = style.midValue != null ? style.midValue : levelDefaults.mid;
        const obW = style.overboughtLineWidth != null ? style.overboughtLineWidth : 1;
        const osW = style.oversoldLineWidth != null ? style.oversoldLineWidth : 1;
        const midW = style.midLineWidth != null ? style.midLineWidth : 1;

        const dom = this._finalizePanelRange(indicator, -100, 0);
        const wMin = dom.min;
        const wMax = dom.max;
        const wSpan = Math.max(1e-9, wMax - wMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - wMin) / wSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        if (style.showBg) {
            const yUpper = scaleY(obVal);
            const yLower = scaleY(osVal);
            if (Number.isFinite(yUpper) && Number.isFinite(yLower)) {
                const fillTop = Math.min(yUpper, yLower);
                const fillHeight = Math.abs(yLower - yUpper);
                if (fillHeight > 0) {
                    ctx.fillStyle = resolve(style.bgColor, style.bgOpacity);
                    ctx.fillRect(m.l, fillTop, Math.max(0, this.w - m.l), fillHeight);
                }
            }
        }

        this._drawPanelAxisTicks(ctx, m, wMin, wMax, scaleY, 0);

        if (style.showOverbought !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, obVal,
                resolve(style.overboughtColor, style.overboughtOpacity), style.overboughtLineStyle || 'Dotted', obVal, obW, style.overboughtLineDashStyle || 'Dotted');
        }
        if (style.showOversold !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, osVal,
                resolve(style.oversoldColor, style.oversoldOpacity), style.oversoldLineStyle || 'Dotted', osVal, osW, style.oversoldLineDashStyle || 'Dotted');
        }
        if (style.showMid !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, midVal,
                resolve(style.midColor, style.midOpacity), style.midLineStyle || 'Dotted', midVal, midW, style.midLineDashStyle || 'Dotted');
        }

        const lineColor = resolve(style.color || '#ec407a', style.lineOpacity);
        if (style.showLine !== false) {
            this._drawPanelLine(ctx, m, values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(2) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(2);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{
                y: currentY,
                text: last.toFixed(2),
                color: lineColor
            }];
        }
    };

    // ---- ROC: auto-scaled ROC line + zero line + optional background ----
    Chart.prototype._renderRocPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, values, visibleStart, visibleEnd) {
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const zeroVal = typeof this._resolveIndicatorLevelValue === 'function'
            ? this._resolveIndicatorLevelValue(indicator, style, 'zeroValue', 0)
            : (style.zeroValue != null ? Number(style.zeroValue) : 0);

        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val !== null && val !== undefined && !isNaN(val)) {
                min = Math.min(min, val);
                max = Math.max(max, val);
            }
        }
        if (Number.isFinite(zeroVal)) {
            min = Math.min(min, zeroVal);
            max = Math.max(max, zeroVal);
        }
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const mMin = dom.min;
        const mMax = dom.max;
        const mSpan = Math.max(1e-9, mMax - mMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - mMin) / mSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        if (style.showBg) {
            ctx.fillStyle = resolve(style.bgColor || 'rgba(19,23,34,0.15)', style.bgOpacity);
            ctx.fillRect(m.l, panelTop, Math.max(0, this.w - m.l), Math.max(0, panelBottom - panelTop));
        }

        this._drawPanelAxisTicks(ctx, m, mMin, mMax, scaleY, 2);

        const zeroW = style.zeroLineWidth != null ? style.zeroLineWidth : 1;
        if (style.showZero !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, zeroVal,
                resolve(style.zeroColor, style.zeroOpacity), style.zeroLineStyle || 'Dotted', zeroVal, zeroW, style.zeroLineDashStyle || 'Dotted');
        }

        const lineColor = resolve(style.color || '#ffa726', style.lineOpacity);
        if (style.showLine !== false) {
            this._drawPanelLine(ctx, m, values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(4) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(4);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{
                y: currentY,
                text: last.toFixed(4),
                color: lineColor
            }];
        }
    };

    // ---- CMF: auto-scaled with CMF line + configurable zero level ----
    Chart.prototype._renderCMFPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, values, visibleStart, visibleEnd) {
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const zeroVal = style.zeroValue != null ? style.zeroValue : 0;

        let min = Infinity;
        let max = -Infinity;
        for (let i = visibleStart; i < visibleEnd && i < values.length; i++) {
            const val = values[i];
            if (val !== null && val !== undefined && !isNaN(val)) {
                min = Math.min(min, val);
                max = Math.max(max, val);
            }
        }
        if (Number.isFinite(zeroVal)) {
            min = Math.min(min, zeroVal);
            max = Math.max(max, zeroVal);
        }
        if (min === Infinity || max === -Infinity) return;

        const range = max - min || 1;
        min = min - range * 0.1;
        max = max + range * 0.1;
        const dom = this._finalizePanelRange(indicator, min, max);
        const mMin = dom.min;
        const mMax = dom.max;
        const mSpan = Math.max(1e-9, mMax - mMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - mMin) / mSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        this._drawPanelAxisTicks(ctx, m, mMin, mMax, scaleY, 2);

        const zeroW = style.zeroLineWidth != null ? style.zeroLineWidth : 1;
        if (style.showZero !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, zeroVal,
                resolve(style.zeroColor, style.zeroOpacity), style.zeroLineStyle || 'Dotted', zeroVal, zeroW, style.zeroLineDashStyle || 'Dotted');
        }

        const lineColor = resolve(style.color || '#29b6f6', style.lineOpacity);
        if (style.showLine !== false) {
            this._drawPanelLine(ctx, m, values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(4) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(2);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{
                y: currentY,
                text: last.toFixed(2),
                color: lineColor
            }];
        }
    };

    // ---- MFI: 0–100 with configurable levels + optional OB–OS background ----
    Chart.prototype._renderMFIPanel = function(ctx, m, panelTop, panelBottom, panelHeight, indicator, values, visibleStart, visibleEnd) {
        if (!values || !values.length) return;
        const style = indicator.style || {};
        const resolve = this._resolveIndicatorBandLineColor.bind(this);
        const levelDefaults = { overbought: 80, oversold: 20, mid: 50 };
        const domS = this._finalizePanelRange(indicator, 0, 100);
        const sMin = domS.min;
        const sMax = domS.max;
        const sSpan = Math.max(1e-9, sMax - sMin);
        const scaleY = v => {
            if (v === null || v === undefined) return null;
            let y = panelBottom - 5 - ((v - sMin) / sSpan) * (panelHeight - 10);
            if (!Number.isFinite(y)) return null;
            return y;
        };

        const obVal = style.overboughtValue != null ? style.overboughtValue : levelDefaults.overbought;
        const osVal = style.oversoldValue != null ? style.oversoldValue : levelDefaults.oversold;
        const midVal = style.midValue != null ? style.midValue : levelDefaults.mid;
        const obW = style.overboughtLineWidth != null ? style.overboughtLineWidth : 1;
        const osW = style.oversoldLineWidth != null ? style.oversoldLineWidth : 1;
        const midW = style.midLineWidth != null ? style.midLineWidth : 1;

        if (style.showBg) {
            const yUpper = scaleY(obVal);
            const yLower = scaleY(osVal);
            if (Number.isFinite(yUpper) && Number.isFinite(yLower)) {
                const fillTop = Math.min(yUpper, yLower);
                const fillHeight = Math.abs(yLower - yUpper);
                if (fillHeight > 0) {
                    ctx.fillStyle = resolve(style.bgColor, style.bgOpacity);
                    ctx.fillRect(m.l, fillTop, Math.max(0, this.w - m.l), fillHeight);
                }
            }
        }

        this._drawPanelAxisTicks(ctx, m, sMin, sMax, scaleY, 2);

        if (style.showOverbought !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, obVal,
                resolve(style.overboughtColor, style.overboughtOpacity), style.overboughtLineStyle || 'Line', obVal, obW, style.overboughtLineDashStyle || 'Dotted');
        }
        if (style.showOversold !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, osVal,
                resolve(style.oversoldColor, style.oversoldOpacity), style.oversoldLineStyle || 'Line', osVal, osW, style.oversoldLineDashStyle || 'Dotted');
        }
        if (style.showMid !== false) {
            this._drawPanelHLine(ctx, m, panelTop, panelBottom, scaleY, midVal,
                resolve(style.midColor, style.midOpacity), style.midLineStyle || 'Line', midVal, midW, style.midLineDashStyle || 'Dotted');
        }

        const lineColor = resolve(style.color || '#5c6bc0', style.lineOpacity);
        if (style.showLine !== false) {
            this._drawPanelLine(ctx, m, values, lineColor, style.lineWidth || 2, visibleStart, visibleEnd, scaleY, panelTop, panelBottom, style.lineStyle || 'Line', style.lineDashStyle || 'Solid');
        }

        let last = null;
        for (let i = Math.min(visibleEnd - 1, values.length - 1); i >= visibleStart; i--) {
            if (values[i] !== null && !isNaN(values[i])) { last = values[i]; break; }
        }
        indicator._displayColor = lineColor;
        indicator._displayLabel = last !== null ? last.toFixed(2) : '';
        if (last !== null && Number.isFinite(last)) {
            const currentY = scaleY(last);
            indicator._axisLabelY = currentY;
            indicator._axisLabelText = last.toFixed(2);
            indicator._axisLabelColor = lineColor;
            indicator._axisLabelTags = [{
                y: currentY,
                text: last.toFixed(2),
                color: lineColor
            }];
        }
    };

    Chart.prototype._renderSeparatePanelLegendValue = function(el, ind) {
        if (!el || !ind) return;
        el.innerHTML = '';
        if (ind.hideValues === true) return;
        const tags = Array.isArray(ind._legendValueTags) && ind._legendValueTags.length
            ? ind._legendValueTags
            : (Array.isArray(ind._axisLabelTags) ? ind._axisLabelTags : []);
        if (tags.length > 1) {
            tags.forEach(function(tag, i) {
                const sp = document.createElement('span');
                sp.textContent = String(tag && tag.text != null ? tag.text : '—');
                sp.style.cssText = 'color:' + (tag && tag.color ? tag.color : '#9ca3af') + ';';
                el.appendChild(sp);
                if (i < tags.length - 1) {
                    const gap = document.createElement('span');
                    gap.textContent = ' / ';
                    gap.style.cssText = 'color:#6b7280;';
                    el.appendChild(gap);
                }
            });
            return;
        }
        const t = (ind._displayLabel !== undefined && ind._displayLabel !== '') ? String(ind._displayLabel) : '—';
        const sp = document.createElement('span');
        sp.textContent = t;
        sp.style.cssText = 'color:' + (ind._displayColor || '#9ca3af') + ';';
        el.appendChild(sp);
    };

    /** Update crosshair-driven values on separate-panel legend rows without rebuilding DOM. */
    Chart.prototype._syncSeparatePanelOverlayValues = function(overlay, indicators) {
        if (!overlay || !Array.isArray(indicators)) return;
        const byId = {};
        overlay.querySelectorAll('[data-talaria-sp-val]').forEach(function(n) {
            byId[n.getAttribute('data-talaria-sp-val')] = n;
        });
        indicators.forEach(function(ind) {
            const el = byId[String(ind.id)];
            if (!el) return;
            this._renderSeparatePanelLegendValue(el, ind);
        }, this);
    };

    /** Reposition legend rows without rebuilding DOM (pan + resize). */
    Chart.prototype._syncSeparatePanelOverlayPositions = function(overlay, panelSlots) {
        if (!overlay || !Array.isArray(panelSlots) || panelSlots.length === 0) return;
        overlay.style.zIndex = '35';
        if (Number.isFinite(this.w) && Number.isFinite(this.h)) {
            overlay.style.width = this.w + 'px';
            overlay.style.height = this.h + 'px';
        }
        const bars = overlay.querySelectorAll('.talaria-ind-legend-row');
        panelSlots.forEach(function(slot, idx) {
            const bar = bars[idx];
            if (!bar || !slot || !Number.isFinite(slot.top)) return;
            bar.style.top = (slot.top + 2) + 'px';
        });
        const m = this.margin || { l: 60, r: 60 };
        if (typeof this._syncSeparatePanelDragZones === 'function') {
            this._syncSeparatePanelDragZones(overlay, panelSlots, m);
        }
        if (typeof this._syncSeparatePanelSeparatorHandles === 'function') {
            this._syncSeparatePanelSeparatorHandles(m);
        } else if (typeof this._syncSeparatePanelResizeGrips === 'function') {
            this._syncSeparatePanelResizeGrips(overlay, m);
        }
    };

    /** Forward DOM pointer/mouse events to the canvas so chart pan handlers run. */
    Chart.prototype._forwardPointerEventToCanvas = function(e) {
        const canvas = this.ctx && this.ctx.canvas;
        if (!canvas || !e || typeof e.clientX !== 'number' || typeof e.clientY !== 'number') return;
        const type = e.type || 'mousedown';
        const detail = type === 'dblclick' ? 2 : (type === 'click' ? 1 : 0);
        canvas.dispatchEvent(new MouseEvent(type, {
            bubbles: true,
            cancelable: true,
            view: window,
            detail: detail,
            clientX: e.clientX,
            clientY: e.clientY,
            screenX: e.screenX,
            screenY: e.screenY,
            button: e.button,
            buttons: e.buttons,
            ctrlKey: !!e.ctrlKey,
            shiftKey: !!e.shiftKey,
            altKey: !!e.altKey,
            metaKey: !!e.metaKey
        }));
    };

    Chart.prototype._separatePanelLegendHit = function(target) {
        return !!(target && target.closest && (
            target.closest('.talaria-ind-legend-row') ||
            target.closest('.talaria-ind-actions')
        ));
    };

    Chart.prototype._separatePanelPlotCursorAt = function(mx, my) {
        if (typeof this.findSeparatePanelIndicatorAtPoint === 'function'
            && this.findSeparatePanelIndicatorAtPoint(mx, my)) {
            return 'ns-resize';
        }
        return typeof this.getCurrentCursorStyle === 'function'
            ? this.getCurrentCursorStyle()
            : 'crosshair';
    };

    /** Transparent hit layers over each indicator plot band — legend sits above; drags reach the chart. */
    Chart.prototype._syncSeparatePanelDragZones = function(overlay, panelSlots, m) {
        if (!overlay || !Array.isArray(panelSlots) || panelSlots.length === 0) return;
        const self = this;
        const plotWidth = Math.max(1, (this.w || 0) - m.l - m.r);
        panelSlots.forEach(function(slot, idx) {
            if (!slot || !Number.isFinite(slot.top) || !Number.isFinite(slot.height)) return;
            let zone = overlay.querySelector('[data-talaria-sp-drag-zone="' + idx + '"]');
            if (!zone) {
                zone = document.createElement('div');
                zone.setAttribute('data-talaria-sp-drag-zone', String(idx));
                const skipLegendHit = function(ev) {
                    return typeof self._separatePanelLegendHit === 'function' && self._separatePanelLegendHit(ev.target);
                };
                const onPanStart = function(ev) {
                    if (typeof ev.button === 'number' && ev.button !== 0) return;
                    if (self.drag && self.drag.active) return;
                    if (self._separatePanelResizeDragActive || self._separatePanelLineDragActive) return;
                    if (self.tool) return;
                    if (skipLegendHit(ev)) return;
                    if (ev.target && ev.target.closest && (
                        ev.target.closest('.talaria-separate-panel-separator') ||
                        ev.target.closest('.panel-resize-handle')
                    )) return;
                    const xy = typeof self._eventCanvasLocalXY === 'function'
                        ? self._eventCanvasLocalXY(ev)
                        : [0, 0];
                    self.mouseX = xy[0];
                    self.mouseY = xy[1];
                    if (typeof self._beginSeparatePanelLineDrag === 'function'
                        && self._beginSeparatePanelLineDrag(ev, slot)) {
                        if (self.replaySystem && self.replaySystem.isActive
                            && typeof self.replaySystem.onUserPan === 'function') {
                            self.replaySystem.onUserPan();
                        }
                        return;
                    }
                };
                const onDblClick = function(ev) {
                    if (skipLegendHit(ev)) return;
                    ev.preventDefault();
                    ev.stopPropagation();
                    if (typeof self._forwardPointerEventToCanvas === 'function') {
                        self._forwardPointerEventToCanvas(ev);
                    }
                };
                const onZoneMove = function(ev) {
                    if (skipLegendHit(ev)) return;
                    let cur = 'crosshair';
                    if (typeof self._eventCanvasLocalXY === 'function') {
                        const xy = self._eventCanvasLocalXY(ev);
                        if (typeof self.getSeparatePanelResizeHandleAt === 'function') {
                            const rh = self.getSeparatePanelResizeHandleAt(xy[0], xy[1], 20);
                            if (rh) {
                                zone.style.cursor = 'ns-resize';
                                return;
                            }
                        }
                        if (typeof self._separatePanelPlotCursorAt === 'function') {
                            cur = self._separatePanelPlotCursorAt(xy[0], xy[1]);
                        }
                    } else if (typeof self.getCurrentCursorStyle === 'function') {
                        cur = self.getCurrentCursorStyle();
                    }
                    zone.style.cursor = cur;
                };
                zone.addEventListener('mousedown', onPanStart);
                zone.addEventListener('pointerdown', onPanStart);
                zone.addEventListener('dblclick', onDblClick);
                zone.addEventListener('mousemove', onZoneMove);
                overlay.insertBefore(zone, overlay.firstChild);
            }
            const defaultCursor = typeof this.getCurrentCursorStyle === 'function'
                ? this.getCurrentCursorStyle()
                : 'crosshair';
            const topInset = 8;
            const zoneTop = slot.top + topInset;
            const zoneHeight = Math.max(1, slot.height - topInset);
            zone.style.cssText = [
                'position:absolute',
                'left:' + m.l + 'px',
                'top:' + zoneTop + 'px',
                'width:' + plotWidth + 'px',
                'height:' + zoneHeight + 'px',
                'z-index:1',
                'pointer-events:auto',
                'cursor:' + defaultCursor,
                'background:transparent',
                'touch-action:none'
            ].join(';');
        }, this);
        overlay.querySelectorAll('[data-talaria-sp-drag-zone]').forEach(function(z) {
            const idx = Number(z.getAttribute('data-talaria-sp-drag-zone'));
            if (!Number.isFinite(idx) || idx >= panelSlots.length) z.remove();
        });
    };

    /** Move existing separate-panel legend rows during height resize (no DOM rebuild). */
    Chart.prototype._repositionSeparatePanelOverlay = function(panelSlots, marginArg) {
        const canvas = this.ctx && this.ctx.canvas;
        const wrapper = canvas ? canvas.parentElement : null;
        if (!wrapper || !Array.isArray(panelSlots) || panelSlots.length === 0) return;
        const overlay = wrapper.querySelector('#separatePanelsOverlay');
        if (!overlay) return;
        this._syncSeparatePanelOverlayPositions(overlay, panelSlots);
        const mSync = marginArg || this.margin || { l: 60, r: 60 };
        if (typeof this._syncSeparatePanelSeparatorHandles === 'function') {
            this._syncSeparatePanelSeparatorHandles(mSync);
        } else if (typeof this._syncSeparatePanelResizeGrips === 'function') {
            this._syncSeparatePanelResizeGrips(overlay, mSync);
        }
        overlay.querySelectorAll('[data-talaria-sp-axis-tag]').forEach(function(n) { n.remove(); });
        overlay.querySelectorAll('[data-talaria-sp-axis-tick]').forEach(function(n) { n.remove(); });
    };

    /** Keep persistent right-axis tags in sync during replay/crosshair updates. */
    Chart.prototype._syncSeparatePanelAxisTags = function(overlay, indicators, panelSlots) {
        if (!overlay || !Array.isArray(indicators)) return;
        overlay.querySelectorAll('[data-talaria-sp-axis-tag]').forEach(function(n) { n.remove(); });
        overlay.querySelectorAll('[data-talaria-sp-axis-tick]').forEach(function(n) { n.remove(); });
        const m = this.margin || { r: 56 };
        const axisLeft = this.w - m.r;
        const axisWidth = Math.max(30, m.r - 4);
        const scaleTextSize = (this.chartSettings && Number.isFinite(this.chartSettings.scaleTextSize))
            ? this.chartSettings.scaleTextSize
            : 11;

        const slotById = {};
        if (Array.isArray(panelSlots)) {
            panelSlots.forEach(function(slot) {
                if (slot && slot.indicator) slotById[String(slot.indicator.id)] = slot;
            });
            // Draw all inter-panel separators on axis overlay so they are always visible.
            if (panelSlots.length > 1) {
                panelSlots.slice(0, -1).forEach(function(slot) {
                    if (!slot || !Number.isFinite(slot.top)) return;
                    const sep = document.createElement('div');
                    sep.setAttribute('data-talaria-sp-axis-tick', '1');
                    sep.style.cssText = [
                        'position:absolute',
                        'left:' + axisLeft + 'px',
                        'top:' + (slot.top - 1.5) + 'px',
                        'width:' + m.r + 'px',
                        'height:3px',
                        'background:rgba(120, 123, 134, 0.42)',
                        'z-index:10',
                        'pointer-events:none'
                    ].join(';');
                    overlay.appendChild(sep);
                });
            }
            // Divider between main price-axis region and indicator-axis region.
            const topSlot = panelSlots[0];
            if (topSlot && Number.isFinite(topSlot.top)) {
                const split = document.createElement('div');
                split.setAttribute('data-talaria-sp-axis-tick', '1');
                split.style.cssText = [
                    'position:absolute',
                    'left:' + axisLeft + 'px',
                    'top:' + (topSlot.top - 1.5) + 'px',
                    'width:' + m.r + 'px',
                    'height:3px',
                    'background:rgba(120, 123, 134, 0.42)',
                    'z-index:10',
                    'pointer-events:none'
                ].join(';');
                overlay.appendChild(split);
            }
        }

        indicators.forEach(function(indicator) {
            if (indicator.type === 'volume' || indicator.isVolume) return;
            const slot = slotById[String(indicator.id)];
            // Keep a safety gap under the split line so indicator axis values
            // never overlap with the main price-axis labels.
            const isTopIndicatorSlot = !!(slot && slot.isTopBelowMainChart);
            const boundaryGap = isTopIndicatorSlot ? 18 : 8;
            const topBound = slot ? slot.top + boundaryGap : 0;
            const bottomBound = slot ? slot.bottom - 8 : Number.MAX_SAFE_INTEGER;
            const tags = Array.isArray(indicator._axisLabelTags) && indicator._axisLabelTags.length
                ? indicator._axisLabelTags
                : (Number.isFinite(indicator._axisLabelY) ? [{
                    y: indicator._axisLabelY,
                    text: indicator._axisLabelText,
                    color: indicator._axisLabelColor || indicator._displayColor || indicator.style.color || '#2962ff'
                }] : []);
            if (indicator.hideValues === true) return;

            if (slot) {
                const b0 = Number(indicator._panelBaseMin);
                const b1 = Number(indicator._panelBaseMax);
                let d0 = b0;
                let d1 = b1;
                if (Number.isFinite(b0) && Number.isFinite(b1) && b1 > b0 && typeof this._applyIndicatorPanelDomain === 'function') {
                    const dom = this._applyIndicatorPanelDomain(b0, b1, indicator);
                    if (dom && Number.isFinite(dom.min) && Number.isFinite(dom.max) && dom.max > dom.min) {
                        d0 = dom.min;
                        d1 = dom.max;
                    }
                }
                if (Number.isFinite(d0) && Number.isFinite(d1) && d1 > d0) {
                    const span = Math.max(1e-12, d1 - d0);
                    const decimals = span >= 100 ? 0 : (span >= 10 ? 2 : 4);
                    const tickCount = 4;
                    for (let i = 0; i <= tickCount; i++) {
                        const v = d0 + (d1 - d0) * (i / tickCount);
                        const y = slot.bottom - 5 - ((v - d0) / span) * (slot.height - 10);
                        if (!Number.isFinite(y)) continue;
                        if (y < topBound || y > bottomBound) continue;
                        // Keep a small gap so tick labels don't overlap colored live-value tags.
                        const tooCloseToTag = tags.some(function(tag) {
                            if (!Number.isFinite(tag.y)) return false;
                            const tagY = Math.max(topBound, Math.min(bottomBound, tag.y));
                            return Math.abs(y - tagY) < 14;
                        });
                        if (tooCloseToTag) continue;
                        const tick = document.createElement('div');
                        tick.setAttribute('data-talaria-sp-axis-tick', '1');
                        tick.style.cssText = [
                            'position:absolute',
                            'left:' + (axisLeft + 2) + 'px',
                            'top:' + (y - 8) + 'px',
                            'height:16px',
                            'width:' + axisWidth + 'px',
                            'display:flex',
                            'align-items:center',
                            'justify-content:center',
                            'font:500 ' + scaleTextSize + 'px Roboto,sans-serif',
                            'line-height:16px',
                            'font-variant-numeric:tabular-nums',
                            'color:#787b86',
                            'z-index:10',
                            'pointer-events:none',
                            'white-space:nowrap'
                        ].join(';');
                        tick.textContent = v.toFixed(decimals);
                        overlay.appendChild(tick);
                    }
                }
            }
            tags.forEach(function(tag) {
                if (indicator.style && indicator.style.showLabel === false) return;
                if (!Number.isFinite(tag.y)) return;
                const y = Math.max(topBound, Math.min(bottomBound, tag.y));
                const axisTag = document.createElement('div');
                axisTag.setAttribute('data-talaria-sp-axis-tag', '1');
                const bg = (tag.color || indicator._displayColor || indicator.style.color || '#2962ff');
                const textColor = (typeof this.isLightColor === 'function' && this.isLightColor(bg)) ? '#111111' : '#ffffff';
                axisTag.style.cssText = [
                    'position:absolute',
                    'left:' + (axisLeft + 2) + 'px',
                    'top:' + (y - 10) + 'px',
                    'width:' + axisWidth + 'px',
                    'height:20px',
                    'padding:0',
                    'display:flex',
                    'align-items:center',
                    'justify-content:center',
                    'border-radius:2px',
                    'font:500 ' + scaleTextSize + 'px Roboto,sans-serif',
                    'line-height:20px',
                    'font-variant-numeric:tabular-nums',
                    'color:' + textColor,
                    'background:' + bg,
                    'z-index:11',
                    'pointer-events:none',
                    'box-sizing:border-box'
                ].join(';');
                axisTag.textContent = (tag.text !== undefined && tag.text !== null && tag.text !== '') ? String(tag.text) : '—';
                overlay.appendChild(axisTag);
            });
        }, this);
    };

    // Build/refresh indicator label pills for each separate panel slot (matches OHLC panel style)
    Chart.prototype._updateSeparatePanelLabels = function(panelSlots, indicators, m) {
        const canvas = this.ctx && this.ctx.canvas;
        const wrapper = canvas ? canvas.parentElement : null;
        if (!wrapper) return;
        if (!Array.isArray(panelSlots) || panelSlots.length === 0) return;

        // Structure key only — do NOT include _displayLabel (it updates every crosshair move and caused
        // full DOM rebuilds + shifting icon columns when value string width changed).
        const structureKey = panelSlots.map(function(slot) {
            return slot.indicator.id + ':' + Math.round(slot.top) + ':' + Math.round(slot.height);
        }).join('|') + '|' + indicators.map(function(ind) {
            return ind.id + ':' + (ind.visible !== false ? '1' : '0') + ':' + (ind.hidePlot === true ? '1' : '0') + ':' + (ind._displayColor || '');
        }).join('|');

        let overlay = wrapper.querySelector('#separatePanelsOverlay');
        if (overlay && overlay._structureKey === structureKey) {
            this._syncSeparatePanelOverlayPositions(overlay, panelSlots);
            this._syncSeparatePanelOverlayValues(overlay, indicators);
            this._syncSeparatePanelAxisTags(overlay, indicators, panelSlots);
            return;
        }

        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'separatePanelsOverlay';
            overlay.style.cssText = 'position:absolute;top:0;left:0;pointer-events:none;z-index:35;';
            if (Number.isFinite(this.w) && Number.isFinite(this.h)) {
                overlay.style.width = this.w + 'px';
                overlay.style.height = this.h + 'px';
            }
            wrapper.appendChild(overlay);
        }
        overlay.innerHTML = '';
        overlay._structureKey = structureKey;

        const self = this;
        // Use accent color cached by applyChartSettings — avoids getComputedStyle in the hot render path
        const accentColor = this._cachedAccentColor || '#2962ff';

        indicators.forEach(function(indicator, idx) {
            const slot = panelSlots[idx];
            if (!slot) return;
            const isVolume = indicator.type === 'volume' || indicator.isVolume;
            const slotTop = slot.top;
            const visible = indicator.visible !== false;
            const showPlot = isVolume
                ? (self.chartSettings.showVolume !== false)
                : (indicator.hidePlot !== true);
            const showValues = indicator.hideValues !== true;

            // Compact-width row (name + value + actions) so crosshair / chart hits pass beside the strip
            const bar = document.createElement('div');
            bar.className = 'talaria-ind-legend-row';
            bar.style.cssText = [
                'position:absolute',
                'top:' + (slotTop + 2) + 'px',
                'left:' + (m.l + 6) + 'px',
                'width:max-content',
                'max-width:' + Math.max(120, (self.w || 0) - m.l - m.r - 12) + 'px',
                'box-sizing:border-box',
                'display:flex',
                'align-items:center',
                'gap:6px',
                'justify-content:flex-start',
                'min-width:0',
                'z-index:10',
                'pointer-events:auto',
                'cursor:default',
                'user-select:none',
                'font-family:Roboto,sans-serif'
            ].join(';') + ';margin:0;background:transparent;border:none;border-radius:0;padding:2px 4px 2px 0;';

            bar.onmousedown = function(e) {
                e.stopPropagation();
            };
            bar.ondblclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                if (typeof self.showIndicatorSettings === 'function') {
                    self.showIndicatorSettings(indicator.id);
                }
            };

            const nameEl = document.createElement('span');
            nameEl.textContent = '- ' + indicator.name;
            nameEl.style.cssText = 'color:#d1d4dc;font-size:11px;font-weight:500;user-select:none;opacity:1' +
                ';flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:40%;';
            bar.appendChild(nameEl);

            const valEl = document.createElement('span');
            valEl.setAttribute('data-talaria-sp-val', String(indicator.id));
            valEl.style.cssText = 'font-size:10px;font-weight:500;font-variant-numeric:tabular-nums;text-align:left;' +
                'min-width:auto;flex:0 0 auto;display:inline-flex;gap:3px;align-items:center;opacity:1;';
            self._renderSeparatePanelLegendValue(valEl, indicator);
            bar.appendChild(valEl);

            const actions = document.createElement('span');
            actions.className = 'talaria-ind-actions';
            actions.style.cssText = 'display:inline-flex;align-items:center;gap:4px;margin-left:2px;flex:0 0 auto;padding:2px;background:transparent;border:none;box-shadow:none;pointer-events:auto;';
            const baseActionStyle = getTalariaActionBtnStyle();

            const eyeBtn = document.createElement('span');
            eyeBtn.title = showPlot ? 'Hide indicator' : 'Show indicator';
            const applyPlotEyeState = () => {
                const on = typeof global.resolveIndicatorShown === 'function'
                    ? global.resolveIndicatorShown(indicator, self.chartSettings)
                    : (isVolume
                        ? (self.chartSettings.showVolume !== false)
                        : (indicator.hidePlot !== true));
                eyeBtn.style.cssText = baseActionStyle + 'color:' + (on ? '#d1d4dc' : '#787b86') + ';background:transparent;opacity:1;';
            };
            applyPlotEyeState();
            const eyeOpenSvg = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.35"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
            const eyeClosedSvg = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.35"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
            eyeBtn.innerHTML = showPlot ? eyeOpenSvg : eyeClosedSvg;
            eyeBtn.onmouseenter = function() { eyeBtn.style.background = 'rgba(255, 255, 255, 0.08)'; };
            eyeBtn.onmouseleave = function() { applyPlotEyeState(); };
            eyeBtn.onclick = function(e) {
                e.stopPropagation();
                const nextOn = typeof global.resolveIndicatorShown === 'function'
                    ? !global.resolveIndicatorShown(indicator, self.chartSettings)
                    : (isVolume
                        ? (self.chartSettings && self.chartSettings.showVolume === false)
                        : (indicator.hidePlot === true));
                if (typeof self.setIndicatorVisible === 'function') {
                    self.setIndicatorVisible(indicator, nextOn, { isVolume: isVolume });
                } else if (typeof self._setIndicatorPlotLegendVisible === 'function') {
                    self._setIndicatorPlotLegendVisible(indicator, nextOn, { isVolume: isVolume });
                } else if (isVolume) {
                    const next = !(self.chartSettings.showVolume !== false);
                    self.chartSettings.showVolume = next;
                    indicator.visible = next;
                } else {
                    const nextHidden = !(indicator.hidePlot === true);
                    indicator.hidePlot = nextHidden;
                    indicator.hideValues = nextHidden;
                    if (typeof self.bumpIndicatorRenderVersion === 'function') {
                        self.bumpIndicatorRenderVersion();
                    }
                }
                const on = typeof global.resolveIndicatorShown === 'function'
                    ? global.resolveIndicatorShown(indicator, self.chartSettings)
                    : (isVolume
                        ? (self.chartSettings.showVolume !== false)
                        : (indicator.hidePlot !== true));
                eyeBtn.innerHTML = on ? eyeOpenSvg : eyeClosedSvg;
                applyPlotEyeState();
            };
            actions.appendChild(eyeBtn);

            const setBtn = document.createElement('span');
            setBtn.style.cssText = baseActionStyle + 'color:#787b86;background:transparent;border:none;box-shadow:none;';
            setBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.65 1.65 0 0 0 15 19.4a1.65 1.65 0 0 0-1 .6 1.65 1.65 0 0 0-.33 1V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-.33-1 1.65 1.65 0 0 0-1-.6 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-.6-1 1.65 1.65 0 0 0-1-.33H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1-.33 1.65 1.65 0 0 0 .6-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-.6 1.65 1.65 0 0 0 .33-1V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 .33 1 1.65 1.65 0 0 0 1 .6 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.36.23.6.62.6 1s.24.77.6 1a1.65 1.65 0 0 0 1 .33H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1 .33c-.36.23-.6.62-.6 1z"/></svg>';
            setBtn.title = 'Indicator settings';
            setBtn.onmouseenter = function() {
                setBtn.style.color = '#d1d4dc';
                setBtn.style.background = 'rgba(255, 255, 255, 0.08)';
            };
            setBtn.onmouseleave = function() {
                setBtn.style.color = '#787b86';
                setBtn.style.background = 'transparent';
            };
            setBtn.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                if (typeof self.showIndicatorSettings === 'function') self.showIndicatorSettings(indicator.id);
            };
            actions.appendChild(setBtn);

            const delBtn = document.createElement('span');
            delBtn.textContent = '×';
            delBtn.title = 'Remove indicator';
            delBtn.style.cssText = baseActionStyle + 'color:#f23645;font-size:16px;font-weight:600;line-height:1;background:transparent;';
            delBtn.onmouseenter = function() { delBtn.style.background = 'rgba(242, 54, 69, 0.2)'; };
            delBtn.onmouseleave = function() { delBtn.style.color = '#f23645'; delBtn.style.background = 'transparent'; };
            delBtn.onclick = function(e) {
                e.stopPropagation();
                if (typeof self.removeIndicator === 'function') self.removeIndicator(indicator.id);
            };
            actions.appendChild(delBtn);

            bar.appendChild(actions);
            overlay.appendChild(bar);

        });
        this._syncSeparatePanelDragZones(overlay, panelSlots, m);
        if (typeof this._syncSeparatePanelSeparatorHandles === 'function') {
            this._syncSeparatePanelSeparatorHandles(m);
        } else if (typeof this._syncSeparatePanelResizeGrips === 'function') {
            this._syncSeparatePanelResizeGrips(overlay, m);
        }
        this._syncSeparatePanelAxisTags(overlay, indicators, panelSlots);
    };

    Chart.prototype.drawOverlayIndicatorPriceLabels = function(visible) {
        if (!this.indicators || !this.indicators.active || !this.yScale || !this.ctx) return;

        const m = this.margin;
        const plotLayout = typeof this._getMainPricePlotLayout === 'function'
            ? this._getMainPricePlotLayout()
            : null;
        const maxY = plotLayout ? plotLayout.plotBottom : (this.h - m.b);
        // Price-axis tags always show the last bar value — never follow the crosshair.
        const lastBarIdx = this.data && this.data.length ? this.data.length - 1 : -1;
        const labels = [];
        let labelOrder = 0;

        this.indicators.active.forEach(function(indicator) {
            if (indicator.overlay === false || indicator.visible === false || indicator.hidePlot === true) return;
            if (!this._indicatorVisibleForCurrentTimeframe(indicator)) return;
            if (indicator.style && indicator.style.showLabel === false) return;
            if (indicator.style && indicator.style.showLine === false) return;

            if (indicator.type === 'supertrend') {
                const stData = this.indicators.data[indicator.id];
                if (!stData || !Array.isArray(stData.line)) return;
                let val = null;
                let dirUp = true;
                for (let i = stData.line.length - 1; i >= 0; i--) {
                    if (Number.isFinite(stData.line[i])) {
                        val = stData.line[i];
                        dirUp = (stData.direction[i] == null ? 1 : stData.direction[i]) >= 0;
                        break;
                    }
                }
                if (!Number.isFinite(val)) return;
                const y = this.yScale(val);
                if (!Number.isFinite(y) || y < m.t || y > maxY) return;
                labels.push({
                    y: y,
                    val: val,
                    color: dirUp ? (indicator.style.upColor || '#26a69a') : (indicator.style.downColor || '#ef5350'),
                    order: labelOrder++,
                    key: String(indicator.id)
                });
                return;
            }

            const bandData = this.indicators.data[indicator.id];
            if (bandData && (Array.isArray(bandData.upper) || Array.isArray(bandData.middle) || Array.isArray(bandData.lower))) {
                const st = indicator.style || {};
                const plotOff = this._indicatorPlotOffset(indicator);
                const barIdx = lastBarIdx >= 0 ? lastBarIdx : 0;
                const bandDefs = [
                    { k: 'upper', arr: bandData.upper, show: st.showUpper !== false, color: st.upperColor || '#2962ff' },
                    { k: 'middle', arr: bandData.middle, show: st.showMiddle !== false, color: st.middleColor || '#787b86' },
                    { k: 'lower', arr: bandData.lower, show: st.showLower !== false, color: st.lowerColor || '#2962ff' }
                ];
                bandDefs.forEach(function(b) {
                    if (!b.show || !b.arr) return;
                    const val = seriesValueAtPlotOffset(b.arr, barIdx, plotOff);
                    if (!Number.isFinite(val)) return;
                    const y = this.yScale(val);
                    if (!Number.isFinite(y) || y < m.t || y > maxY) return;
                    labels.push({
                        y: y,
                        val: val,
                        color: b.color || '#2962ff',
                        order: labelOrder++,
                        key: String(indicator.id) + ':' + b.k,
                        pinY: true
                    });
                }, this);
                return;
            }

            if (!OVERLAY_LINE_SELECT_TYPES[indicator.type]) return;

            const data = this.indicators.data[indicator.id];
            const lineArr = Array.isArray(data) ? data : (data && Array.isArray(data.line) ? data.line : null);
            if (!lineArr) return;

            const plotOff = this._indicatorPlotOffset(indicator);
            const barIdx = lastBarIdx >= 0 ? lastBarIdx : (lineArr.length - 1);
            const val = seriesValueAtPlotOffset(lineArr, barIdx, plotOff);
            if (!Number.isFinite(val)) return;

            const y = this.yScale(val);
            if (!Number.isFinite(y) || y < m.t || y > maxY) return;

            labels.push({
                y: y,
                val: val,
                color: indicator.style.color || '#2962ff',
                order: labelOrder++,
                key: String(indicator.id)
            });
        }, this);

        if (!labels.length) return;

        const pinnedLabels = [];
        const stackLabels = [];
        labels.forEach(function(lbl) {
            if (lbl.pinY) pinnedLabels.push(lbl);
            else stackLabels.push(lbl);
        });

        if (!this._overlayLabelAnchorY) this._overlayLabelAnchorY = Object.create(null);
        if (!this._overlayLabelDisplayY) this._overlayLabelDisplayY = Object.create(null);
        const anchorMap = this._overlayLabelAnchorY;
        const displayMap = this._overlayLabelDisplayY;
        const activeKeys = Object.create(null);
        const anchorLerp = 0.34;
        const displayLerp = 0.38;
        const minGap = 21;
        const topBound = m.t + 10;
        const bottomBound = maxY - 10;
        const snapPx = 0.45;

        // Stable stack order (indicator list order) — never sort by Y (causes slot swaps).
        stackLabels.sort(function(a, b) { return a.order - b.order; });

        stackLabels.forEach(function(lbl) {
            if (!lbl.key) return;
            activeKeys[lbl.key] = true;
            const rawY = lbl.y;
            const prevAnchor = anchorMap[lbl.key];
            let anchorY = Number.isFinite(prevAnchor)
                ? prevAnchor + (rawY - prevAnchor) * anchorLerp
                : rawY;
            if (Number.isFinite(prevAnchor) && Math.abs(rawY - anchorY) < snapPx) anchorY = rawY;
            lbl.anchorY = anchorY;
            anchorMap[lbl.key] = anchorY;
        });

        // Push apart in stable order, then shift the whole stack if clamping would collapse labels.
        const stackYs = stackLabels.map(function(lbl) { return lbl.anchorY; });
        for (let i = 1; i < stackYs.length; i++) {
            if (stackYs[i] - stackYs[i - 1] < minGap) {
                stackYs[i] = stackYs[i - 1] + minGap;
            }
        }
        if (stackYs.length) {
            if (stackYs[stackYs.length - 1] > bottomBound) {
                const shiftUp = stackYs[stackYs.length - 1] - bottomBound;
                for (let i = 0; i < stackYs.length; i++) stackYs[i] -= shiftUp;
            }
            if (stackYs[0] < topBound) {
                const shiftDown = topBound - stackYs[0];
                for (let i = 0; i < stackYs.length; i++) stackYs[i] += shiftDown;
            }
            for (let i = 1; i < stackYs.length; i++) {
                if (stackYs[i] - stackYs[i - 1] < minGap) {
                    stackYs[i] = stackYs[i - 1] + minGap;
                }
            }
            for (let i = 0; i < stackYs.length; i++) {
                stackYs[i] = Math.max(topBound, Math.min(bottomBound, stackYs[i]));
            }
        }

        stackLabels.forEach(function(lbl, idx) {
            if (!lbl.key) return;
            const targetY = stackYs[idx];
            const prevDisplay = displayMap[lbl.key];
            let displayY = Number.isFinite(prevDisplay)
                ? prevDisplay + (targetY - prevDisplay) * displayLerp
                : targetY;
            if (Number.isFinite(prevDisplay) && Math.abs(targetY - displayY) < snapPx) displayY = targetY;
            lbl.y = displayY;
            displayMap[lbl.key] = displayY;
        });

        pinnedLabels.forEach(function(lbl) {
            if (lbl.key) activeKeys[lbl.key] = true;
        });

        Object.keys(anchorMap).forEach(function(k) {
            if (!activeKeys[k]) delete anchorMap[k];
        });
        Object.keys(displayMap).forEach(function(k) {
            if (!activeKeys[k]) delete displayMap[k];
        });

        const ctx = this.ctx;
        const axisLeft = !!this.priceAxisLeft;
        const axisW = axisLeft ? m.l : m.r;
        const labelWidth = axisW - 4;
        const labelX = axisLeft ? 2 : this.w - m.r;
        const priceRange = this.yScale.domain()[1] - this.yScale.domain()[0];
        const formatPrice = function(val) {
            if (typeof this._formatLastPrice === 'function') {
                return this._formatLastPrice(Number(val), Math.abs(priceRange), this.currentSymbol);
            }
            const decimals = typeof this.getPriceDecimals === 'function' ? this.getPriceDecimals(Math.abs(priceRange)) : 4;
            return Number(val).toFixed(decimals);
        }.bind(this);
        const scaleTextSize = (this.chartSettings && this.chartSettings.scaleTextSize) || 11;
        const radius = 2;

        labels.forEach(function(lbl) {
            const bgColor = lbl.color;
            const priceText = formatPrice(lbl.val);
            const labelHeight = 20;
            const labelY = lbl.y - labelHeight / 2;
            const textColor = (typeof this.isLightColor === 'function' && this.isLightColor(bgColor)) ? '#111111' : '#ffffff';

            ctx.fillStyle = bgColor;
            ctx.beginPath();
            ctx.moveTo(labelX + radius, labelY);
            ctx.lineTo(labelX + labelWidth - radius, labelY);
            ctx.arcTo(labelX + labelWidth, labelY, labelX + labelWidth, labelY + radius, radius);
            ctx.lineTo(labelX + labelWidth, labelY + labelHeight - radius);
            ctx.arcTo(labelX + labelWidth, labelY + labelHeight, labelX + labelWidth - radius, labelY + labelHeight, radius);
            ctx.lineTo(labelX + radius, labelY + labelHeight);
            ctx.arcTo(labelX, labelY + labelHeight, labelX, labelY + labelHeight - radius, radius);
            ctx.lineTo(labelX, labelY + radius);
            ctx.arcTo(labelX, labelY, labelX + radius, labelY, radius);
            ctx.closePath();
            ctx.fill();

            ctx.fillStyle = textColor;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.font = '500 ' + scaleTextSize + 'px Roboto';
            ctx.fillText(priceText, labelX + labelWidth / 2, labelY + labelHeight / 2);
        }, this);
    };

    if (typeof Chart.prototype.drawCurrentPriceLabel === 'function' && !Chart.prototype._overlayPriceLabelsHooked) {
        Chart.prototype._overlayPriceLabelsHooked = true;
        const _origDrawCurrentPriceLabel = Chart.prototype.drawCurrentPriceLabel;
        Chart.prototype.drawCurrentPriceLabel = function(visible) {
            _origDrawCurrentPriceLabel.call(this, visible);
            if (typeof this.drawOverlayIndicatorPriceLabels === 'function') {
                this.drawOverlayIndicatorPriceLabels(visible);
            }
        };
    }

    // Mark as loaded
    installIndicatorPersistRehydrateWrappers();
    window.INDICATORS_MODULE_LOADED = true;
    global.talariaSeriesValueAtPlotOffset = seriesValueAtPlotOffset;
    global.talariaFormatOverlayLegendPrice = formatOverlayLegendPrice;
    global.talariaBuildOverlayBandLegendTokens = buildOverlayBandLegendTokens;
    
    } // End of attachIndicatorMethods
    
    // Start initialization
    initIndicatorsModule();
    
})(window);